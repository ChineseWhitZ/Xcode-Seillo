import SwiftUI

// ─── AnimationTokens.swift ────────────────────────────────────────────────────
//
// Complementa SeillAnimation (en SeillColors.swift) con tokens faltantes
// y el catálogo de transiciones compuestas reutilizables SeillTransitions.
//
// SeillAnimation cubre los tokens de interacción base.
// Este archivo cubre:
//   · SeillDuration   — constantes de tiempo explícitas
//   · SeillTransitions — AnyTransition compuestos listos para usar
//   · Animation+Seill — overloads de conveniencia
//
// Ruta: Seillo/Theme/AnimationTokens.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Duration Constants

/// Constantes de duración en segundos.
/// Usarlas directamente evita números mágicos dispersos en el código.
enum SeillDuration {
    /// Microinteracciones: tap, badge pop, icon bounce. 0.15s–0.22s
    static let micro:      Double = 0.18
    /// Transiciones de elemento: fade, slide de un componente. 0.25s–0.30s
    static let short:      Double = 0.28
    /// Transiciones de panel: sheet appear, card expand. 0.35s–0.45s
    static let medium:     Double = 0.38
    /// Transiciones de pantalla completa. 0.45s–0.55s
    static let long:       Double = 0.50
    /// Animaciones de celebración / showcase. 0.6s+
    static let celebration: Double = 0.65
    /// Shimmer loop — sincronizado con TimelineView si se usa
    static let shimmer:    Double = 1.40
    /// Countdown ring — 1 tick por segundo
    static let countdown:  Double = 1.00
}

// MARK: - SeillTransitions

/// Catálogo de transiciones compuestas listas para usar con `.transition(...)`.
///
/// Uso:
///   MyView().transition(SeillTransitions.cardEntrance)
///   MyView().transition(SeillTransitions.stampReveal)
enum SeillTransitions {

    // ── Entrada de elementos en lista ──────────────────────────────────────

    /// Tarjeta de lealtad entrando desde abajo con fade.
    /// Usar en: TabCardsView cards, BizTabClientsView rows.
    static let cardEntrance: AnyTransition =
        .asymmetric(
            insertion:  .opacity.combined(with: .move(edge: .bottom)),
            removal:    .opacity.combined(with: .scale(scale: 0.96))
        )

    /// Fila de lista con slide sutil desde abajo.
    /// Usar en: HistoryView, NotificationsView.
    static let listRow: AnyTransition =
        .asymmetric(
            insertion:  .opacity.combined(with: .offset(y: 12)),
            removal:    .opacity
        )

    // ── Stamp & reward ─────────────────────────────────────────────────────

    /// Sello individual que aparece con pop.
    /// Usar en: ElegantStampProgressView, StampReceivedSheet.
    static let stampReveal: AnyTransition =
        .asymmetric(
            insertion:  .scale(scale: 0.55).combined(with: .opacity),
            removal:    .scale(scale: 0.80).combined(with: .opacity)
        )

    /// Premio desbloqueado — entra con bounce.
    static let rewardUnlock: AnyTransition =
        .asymmetric(
            insertion:  .scale(scale: 0.70).combined(with: .opacity),
            removal:    .opacity
        )

    // ── Skeleton / loading ─────────────────────────────────────────────────

    /// Skeleton sale, contenido real entra.
    /// Usar en: TabCardsView, BizTabDashboardView.
    static let skeletonToContent: AnyTransition =
        .asymmetric(
            insertion:  .opacity.combined(with: .move(edge: .bottom)),
            removal:    .opacity
        )

    /// Skeleton puro (sin dirección — crossfade limpio).
    static let skeletonFade: AnyTransition = .opacity

    // ── Sheets & modals ────────────────────────────────────────────────────

    /// Sheet que sube desde abajo (suplementa la presentación nativa).
    /// Usar en contenido interno del sheet cuando el sheet ya está visible.
    static let sheetContent: AnyTransition =
        .asymmetric(
            insertion:  .opacity.combined(with: .offset(y: 20)),
            removal:    .opacity.combined(with: .offset(y: 10))
        )

    // ── Estados vacíos y error ─────────────────────────────────────────────

    /// Vista de estado vacío / error — entra suavemente.
    static let emptyState: AnyTransition =
        .opacity.combined(with: .move(edge: .bottom))

    // ── Celebración ────────────────────────────────────────────────────────

    /// Icono de celebración — escala desde el centro.
    static let heroEntrance: AnyTransition =
        .asymmetric(
            insertion:  .scale(scale: 0.60).combined(with: .opacity),
            removal:    .opacity
        )

    // ── QR ─────────────────────────────────────────────────────────────────

    /// QR que emerge al cargar.
    static let qrReveal: AnyTransition =
        .asymmetric(
            insertion:  .scale(scale: 0.88).combined(with: .opacity),
            removal:    .opacity
        )
}

// MARK: - Animation + Seill Convenience

extension Animation {

    /// Spring fluido para expansión de cards y modales.
    /// Más masa que `SeillAnimation.chrome` — adecuado para elementos grandes.
    static let seillExpand = Animation.spring(response: 0.42, dampingFraction: 0.80)

    /// Spring de salida — rápido, sin bounce. Para dismiss y colapso.
    static let seillCollapse = Animation.spring(response: 0.28, dampingFraction: 0.95)

    /// Fade rápido para transiciones de estado (loading → content).
    static let seillFade = Animation.easeOut(duration: SeillDuration.short)

    /// Ease estándar para el countdown ring y animaciones lineales continuas.
    static let seillCountdown = Animation.linear(duration: SeillDuration.countdown)

    /// Spring para confirmaciones positivas — reward, stamp, success.
    static let seillCelebration = Animation.spring(response: 0.50, dampingFraction: 0.58)
}
