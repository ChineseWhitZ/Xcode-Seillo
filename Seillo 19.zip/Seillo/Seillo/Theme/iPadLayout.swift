import SwiftUI

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - SeillLayout — extensiones iPad
// ═══════════════════════════════════════════════════════════════════════════════

extension SeillLayout {

    // ── Contenido central ────────────────────────────────────────────────────

    /// Ancho máximo del área de contenido en iPad.
    static let contentMaxWidth: CGFloat = 700

    /// Padding horizontal dentro del área de contenido en iPad.
    static let iPadHPad: CGFloat = 32

    // ── Tab bar en iPad portrait ──────────────────────────────────────────────

    /// Ancho máximo del pill flotante en iPad portrait.
    static let tabBarMaxWidthIPad: CGFloat = 480

    /// Bottom padding del pill en iPad (safe area es mayor).
    static let tabBarBottomPaddingIPad: CGFloat = 32

    // ── Sidebar de negocio en landscape ──────────────────────────────────────

    /// Ancho fijo de la sidebar de negocio en iPad landscape.
    static let bizSidebarWidth: CGFloat = 252

    // ── Grids adaptativos ─────────────────────────────────────────────────────

    /// Stat cards en iPad: 4 columnas en vez de 2.
    static let statColumnsIPad: Int = 4

    /// Loyalty cards en iPad: 2 columnas en vez de 1.
    static let cardColumnsIPad: Int = 2

    // ── Componentes visuales ──────────────────────────────────────────────────

    /// Tamaño de sello individual en StampsRowView / ElegantStampProgressView.
    static var stampSize: CGFloat        { isIPad ? 36 : 28 }
    static var stampCellHeight: CGFloat  { isIPad ? 48 : 38 }

    /// Altura del mapa de vista rápida en TabCercaView.
    static var mapPreviewHeight: CGFloat { isIPad ? 300 : 200 }

    /// Dot de actividad en ActivityRow.
    static var activityDotSize: CGFloat  { isIPad ? 8 : 6 }

    /// Factor de escala de fuentes para textos muy pequeños (8–10pt).
    /// Evita que labels secundarios sean ilegibles en iPad.
    static var tinyFontBoost: CGFloat    { isIPad ? 2 : 0 }
    static let chartHeightIPad: CGFloat = 160

    // ── Sheets ────────────────────────────────────────────────────────────────

    /// Ancho máximo del contenido dentro de un sheet en iPad.
    /// Los sheets en iPad son paneles flotantes de ~540pt — este valor centra
    /// el contenido con margen interno cómodo.
    static let sheetContentMaxWidth: CGFloat = 460
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - Detents adaptativos
// ═══════════════════════════════════════════════════════════════════════════════

/// Devuelve detents correctos según dispositivo.
/// En iPhone usa el height exacto. En iPad usa .medium para aprovechar el panel.
func adaptiveDetents(height: CGFloat) -> Set<PresentationDetent> {
    isIPad ? [.medium] : [.height(height)]
}

/// Para sheets grandes (listados, formularios complejos): siempre .large.
let largeDetent: Set<PresentationDetent> = [.large]

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - Helpers de orientación
// ═══════════════════════════════════════════════════════════════════════════════

@inlinable
func isLandscape(_ geo: GeometryProxy) -> Bool {
    geo.size.width > geo.size.height
}

var isIPad: Bool {
    UIDevice.current.userInterfaceIdiom == .pad
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - SeillContentBox
// ═══════════════════════════════════════════════════════════════════════════════

/// Centra el contenido de scroll con maxWidth en iPad.
struct SeillContentBox<Content: View>: View {
    @Environment(\.horizontalSizeClass) private var hSizeClass
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .frame(
                maxWidth: hSizeClass == .regular
                    ? SeillLayout.contentMaxWidth
                    : .infinity
            )
            .frame(maxWidth: .infinity)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - SeillSheetBox
// ═══════════════════════════════════════════════════════════════════════════════

/// Wrapper para contenido de sheets en iPad.
/// Centra el contenido con sheetContentMaxWidth y padding lateral cómodo.
struct SeillSheetBox<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .frame(maxWidth: isIPad ? SeillLayout.sheetContentMaxWidth : .infinity)
            .frame(maxWidth: .infinity)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - Extensión View
// ═══════════════════════════════════════════════════════════════════════════════

extension View {
    func adaptiveHPadding(_ iPhoneValue: CGFloat = 16) -> some View {
        modifier(AdaptiveHPaddingModifier(iPhoneValue: iPhoneValue))
    }
}

private struct AdaptiveHPaddingModifier: ViewModifier {
    @Environment(\.horizontalSizeClass) private var hSizeClass
    let iPhoneValue: CGFloat

    func body(content: Content) -> some View {
        content.padding(
            .horizontal,
            hSizeClass == .regular ? SeillLayout.iPadHPad : iPhoneValue
        )
    }
}
