import SwiftUI

// MARK: - planColor(for:)

/// Devuelve el color de acento canónico para un tier de plan SaaS.
///
/// Uso:
///   let color = planColor(for: subscription.plan.tier)
func planColor(for tier: PlanTier) -> Color {
    switch tier {
    case .free:       return .seilMuted        // gris — plan sin pagar
    case .starter:    return .seilBlue         // azul — entrando al ecosistema
    case .growth:     return .seilGreen        // verde — crecimiento
    case .pro:        return .seilAccent       // naranja Seillo — máxima potencia
    case .enterprise: return .seilPurple       // púrpura — nivel corporativo
    }
}

// MARK: - Extensiones de conveniencia en SubscriptionPlan

extension SubscriptionPlan {
    /// Color canónico del plan — atajo para no llamar planColor(for:) cada vez.
    var color: Color { planColor(for: tier) }
}

extension BusinessSubscription {
    /// Color canónico del plan activo.
    var planColor: Color { plan.color }
}
