import SwiftUI
import UIKit

// ─── Seillo Color System ───────────────────────────────────────────────────
//
//  DOS MODOS — sin modo oscuro intermedio.
//
//  MODO AMOLED (estándar)  → .preferredColorScheme(.dark)
//  ────────────────────────────────────────────────────────────────
//  Negro puro #000000. Aprovecha píxeles apagados en OLED/Super Retina.
//  Texto blanco puro, bordes ligeramente más visibles.
//
//  MODO CLARO              → .preferredColorScheme(.light)
//  ────────────────────────────────────────────────────────────────
//  Fondos cálidos crema (#F5F2EF). Texto casi negro cálido (#1A1410).
//  Liquid Glass se ve espectacular sobre fondos claros.
//
//  Implementación: UIColor con UITraitCollection. El sistema de iOS
//  propaga el trait automáticamente cuando SeillApp aplica
//  .preferredColorScheme(). No se necesita ningún cambio en las Views.
//
// ─────────────────────────────────────────────────────────────────

extension Color {

    // MARK: - Adaptive helper (ARGB hex8 / RGB hex6)

    private static func adaptive(light: String, dark: String) -> Color {
        Color(UIColor { traits in
            let hex = traits.userInterfaceStyle == .dark ? dark : light
            let h   = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
            var raw: UInt64 = 0
            Scanner(string: h).scanHexInt64(&raw)
            let a, r, g, b: UInt64
            switch h.count {
            case 8:  (a, r, g, b) = (raw >> 24, raw >> 16 & 0xFF, raw >> 8 & 0xFF, raw & 0xFF)
            default: (a, r, g, b) = (255,       raw >> 16,        raw >> 8 & 0xFF, raw & 0xFF)
            }
            return UIColor(
                red:   CGFloat(r) / 255,
                green: CGFloat(g) / 255,
                blue:  CGFloat(b) / 255,
                alpha: CGFloat(a) / 255
            )
        })
    }

    // MARK: - Backgrounds
    //                                Claro              AMOLED
    static let seilBg      = adaptive(light: "#F5F2EF", dark: "#000000")
    static let seilSurface = adaptive(light: "#FFFFFF", dark: "#080808")
    static let seilCard    = adaptive(light: "#FFFFFF", dark: "#101010")
    static let seilCard2   = adaptive(light: "#F0ECE8", dark: "#161616")

    // MARK: - Brand (idénticos en ambos modos)
    static let seilAccent  = Color(hex: "#FF5A00")
    static let seilAccent2 = Color(hex: "#FF8340")
    static let seilGold    = Color(hex: "#FFB800")
    static let seilGreen   = Color(hex: "#00C97A")

    // MARK: - Semánticos
    static let seilDanger  = Color(hex: "#FF3B30")
    static let seilBlue    = Color(hex: "#4F9FFF")
    static let seilPurple  = Color(hex: "#B06FEF")
    static let seilRose    = Color(hex: "#FF4460")

    // MARK: - Text
    //   Claro: texto casi negro cálido
    //   AMOLED: blanco puro
    //   seilMuted  ≈ 38% opacidad → 0x61 alpha
    //   seilMuted2 ≈ 60% opacidad → 0x99 alpha
    static let seilText    = adaptive(light: "#1A1410",   dark: "#FFFFFF")
    static let seilMuted   = adaptive(light: "#611A1410", dark: "#61FFFFFF")
    static let seilMuted2  = adaptive(light: "#991A1410", dark: "#99FFFFFF")

    // MARK: - Borders
    //   Claro: negro a baja opacidad (6-8%)
    //   AMOLED: blanco a baja opacidad (11-13%)
    static let seilBorder      = adaptive(light: "#10000000", dark: "#1CFFFFFF")
    static let seilBorderGlass = adaptive(light: "#14000000", dark: "#21FFFFFF")

    // MARK: - Shadows (solo visibles en modo claro)
    //   En AMOLED las sombras son invisibles sobre negro.
    static let seilShadow = adaptive(light: "#18000000", dark: "#00000000")

    // MARK: - Glow
    static let accentGlow = Color(hex: "#FF5A00").opacity(0.30)
}

extension Color {
    init(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: h).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch h.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red:   Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// ─── Gradient Presets ──────────────────────────────────────────────────────
// Versiones oscuras (AMOLED) y claras de cada gradiente de tarjeta.

struct SeillGradients {

    // ── AMOLED (oscuro) ──────────────────────────────────────────────────
    static let orangeCard = LinearGradient(
        colors: [Color(hex: "#1A0800"), Color(hex: "#3D1A00"), Color(hex: "#6B2E00")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let blueCard = LinearGradient(
        colors: [Color(hex: "#04101A"), Color(hex: "#082A45"), Color(hex: "#0A3D6B")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let purpleCard = LinearGradient(
        colors: [Color(hex: "#0D0616"), Color(hex: "#1E0A36"), Color(hex: "#2E1056")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let greenCard = LinearGradient(
        colors: [Color(hex: "#041008"), Color(hex: "#0A2E14"), Color(hex: "#0F4A1E")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    // ── Claro (pastel cálido) ────────────────────────────────────────────
    static let orangeCardLight = LinearGradient(
        colors: [Color(hex: "#FFF5EE"), Color(hex: "#FFE8D4"), Color(hex: "#FFE0C8")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let blueCardLight = LinearGradient(
        colors: [Color(hex: "#EFF6FF"), Color(hex: "#D8EAFF"), Color(hex: "#C5DFFF")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let purpleCardLight = LinearGradient(
        colors: [Color(hex: "#F5EEFF"), Color(hex: "#EAD8FF"), Color(hex: "#DFC8FF")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let greenCardLight = LinearGradient(
        colors: [Color(hex: "#EDFFF5"), Color(hex: "#D4F5E4"), Color(hex: "#C0F0D8")],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    static let accent = LinearGradient(
        colors: [Color.seilAccent, Color.seilAccent2],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
}

// ─── Typography System ─────────────────────────────────────────────────────
struct SeillFont {
    static func display(_ size: CGFloat = 28) -> Font {
        .system(size: size, weight: .heavy, design: .rounded)
    }
    static func title(_ size: CGFloat = 20) -> Font {
        .system(size: size, weight: .bold, design: .rounded)
    }
    static func headline(_ size: CGFloat = 16) -> Font {
        .system(size: size, weight: .semibold, design: .rounded)
    }
    static func body(_ size: CGFloat = 14) -> Font {
        .system(size: size, weight: .regular, design: .rounded)
    }
    static func caption(_ size: CGFloat = 11) -> Font {
        .system(size: size, weight: .medium, design: .rounded)
    }
    static func label(_ size: CGFloat = 13) -> Font {
        .system(size: size, weight: .bold, design: .rounded)
    }
    /// Extra-black para badges y chips de estado
    static func badge(_ size: CGFloat = 9) -> Font {
        .system(size: size, weight: .black, design: .rounded)
    }
    /// Tracking labels — section headers, categorías
    static func micro(_ size: CGFloat = 10) -> Font {
        .system(size: size, weight: .bold, design: .rounded)
    }
    /// Iconos de toolbar y navegación
    static func icon(_ size: CGFloat = 18) -> Font {
        .system(size: size, weight: .semibold)
    }
}

// ─── Animation System ──────────────────────────────────────────────────────
struct SeillAnimation {
    static let screenTransition = Animation.interpolatingSpring(stiffness: 280, damping: 28)
    // BAJO: 0.22s en 120Hz ProMotion (8.3 frames) puede verse abrupta —
    // el ojo percibe el inicio antes de que el spring tenga masa suficiente.
    // 0.32s (38 frames a 120Hz) da al spring tiempo de arranque visible.
    static let listEntrance     = Animation.easeOut(duration: 0.32)
    static let panelCascade     = Animation.interpolatingSpring(stiffness: 240, damping: 26)
    static let buttonPress      = Animation.spring(response: 0.20, dampingFraction: 0.60)
    static let chrome           = Animation.spring(response: 0.28, dampingFraction: 0.82)
    static let tabBarShow       = Animation.easeInOut(duration: 0.22)
    static let tabBarHide       = Animation.easeInOut(duration: 0.18)
    static let microBounce      = Animation.spring(response: 0.18, dampingFraction: 0.45)
}

// ─── Layout Constants ──────────────────────────────────────────────────────
struct SeillLayout {
    static let tabBarCornerRadius: CGFloat = 26
    static let tabBarHorizontalPadding: CGFloat = 16
    static let tabBarInternalPadding: CGFloat = 10
    static let tabBarBottomPadding: CGFloat = 24
    static let tabBarScrollReserve: CGFloat = 90
}
