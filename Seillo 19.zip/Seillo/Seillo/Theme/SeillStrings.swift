import SwiftUI

// ─── SeillStrings ─────────────────────────────────────────────────────────────
// Acceso tipado a todas las claves de Localizable.xcstrings.
// Uso: Text(SeillStrings.action.cancel)
//      Text(SeillStrings.greeting.morning)
//
// Ventajas vs hardcodear:
//  - El compilador detecta claves inexistentes
//  - Un solo lugar para cambiar cualquier string
//  - La traducción automática funciona sin tocar las views
//
// Para migrar una view:
//  Antes: Text("Cancelar")
//  Después: Text(SeillStrings.action.cancel)
// ─────────────────────────────────────────────────────────────────────────────

enum SeillStrings {

    // MARK: - Actions
    enum action {
        static let back          = String(localized: "action.back")
        static let cancel        = String(localized: "action.cancel")
        static let save          = String(localized: "action.save")
        static let saveChanges   = String(localized: "action.saveChanges")
        static let done          = String(localized: "action.done")
        static let `continue`    = String(localized: "action.continue")
        static let next          = String(localized: "action.next")
        static let close         = String(localized: "action.close")
        static let edit          = String(localized: "action.edit")
        static let delete        = String(localized: "action.delete")
        static let send          = String(localized: "action.send")
        static let redeem        = String(localized: "action.redeem")
        static let redeemReward  = String(localized: "action.redeemReward")
        static let signOut       = String(localized: "action.signOut")
        static let signOutQuestion = String(localized: "action.signOutQuestion")
        static let viewDetail    = String(localized: "action.viewDetail")
        static let viewBusiness  = String(localized: "action.viewBusiness")
        static let explore       = String(localized: "action.explore")
        static let openSettings  = String(localized: "action.openSettings")
        static let renew         = String(localized: "action.renew")
    }

    // MARK: - Greetings
    // Hardcodeados en español — mercado peruano, sin dependencia del locale del dispositivo.
    enum greeting {
        static let morning   = "Buenos días"
        static let afternoon = "Buenas tardes"
        static let evening   = "Buenas noches"

        /// Devuelve el saludo correcto según la hora actual
        static var current: String {
            let hour = Calendar.current.component(.hour, from: Date())
            if hour < 12 { return morning   }
            if hour < 19 { return afternoon }
            return evening
        }
    }

    // MARK: - Tabs
    enum tab {
        static let cards   = String(localized: "tab.cards")
        static let rewards = String(localized: "tab.rewards")
        static let nearby  = String(localized: "tab.nearby")
        static let profile = String(localized: "tab.profile")
    }

    // MARK: - Auth
    enum auth {
        static let welcomeBack         = String(localized: "auth.welcomeBack")
        static let signInSubtitle      = String(localized: "auth.signInSubtitle")
        static let email               = String(localized: "auth.email")
        static let password            = String(localized: "auth.password")
        static let forgotPassword      = String(localized: "auth.forgotPassword")
        static let signIn              = String(localized: "auth.signIn")
        static let createAccount       = String(localized: "auth.createAccount")
        static let name                = String(localized: "auth.name")
        static let minChars            = String(localized: "auth.minChars")
        static let incorrectCredentials = String(localized: "auth.incorrectCredentials")
    }

    // MARK: - Cards
    enum cards {
        static let myCards      = String(localized: "cards.myCards")
        static let emptyTitle   = String(localized: "cards.empty.title")
        static let emptySubtitle = String(localized: "cards.empty.subtitle")
        static let almostReady  = String(localized: "cards.almostReady")
        static let rewardReady  = String(localized: "cards.rewardReady")
        static let tapToRedeem  = String(localized: "cards.tapToRedeem")
        static let tapToViewDetail = String(localized: "cards.tapToViewDetail")
        static let explore      = String(localized: "cards.explore")
        static let findFirst    = String(localized: "cards.findFirst")
    }

    // MARK: - Rewards
    enum rewards {
        static let myRewards       = String(localized: "rewards.myRewards")
        static let readyToRedeem   = String(localized: "rewards.readyToRedeem")
        static let inProgress      = String(localized: "rewards.inProgress")
        static let emptyTitle      = String(localized: "rewards.empty.title")
        static let closestToUnlock = String(localized: "rewards.closestToUnlock")
    }

    // MARK: - Nearby
    enum nearby {
        static let title             = String(localized: "nearby.title")
        static let searchPlaceholder = String(localized: "nearby.searchPlaceholder")
    }

    // MARK: - Profile
    enum profile {
        static let activity      = String(localized: "profile.activity")
        static let help          = String(localized: "profile.help")
        static let history       = String(localized: "profile.history")
        static let myQR          = String(localized: "profile.myQR")
        static let inviteFriends = String(localized: "profile.inviteFriends")
        static let faq           = String(localized: "profile.faq")
        static let about         = String(localized: "profile.about")
        static let settings      = String(localized: "profile.settings")
        static let deleteAccount = String(localized: "profile.deleteAccount")
    }

    // MARK: - Settings
    enum settings {
        static let notifications = String(localized: "settings.notifications")
        static let appearance    = String(localized: "settings.appearance")
        static let privacy       = String(localized: "settings.privacy")
        static let account       = String(localized: "settings.account")
        static let darkMode      = String(localized: "settings.darkMode")
        static let haptics       = String(localized: "settings.haptics")
        static let language      = String(localized: "settings.language")
        static let privacyPolicy = String(localized: "settings.privacyPolicy")
        static let terms         = String(localized: "settings.terms")
        static let stampsReceived = String(localized: "settings.stampsReceived")
        static let readyRewards  = String(localized: "settings.readyRewards")
        static let campaigns     = String(localized: "settings.campaigns")
    }

    // MARK: - Card Detail
    enum detail {
        static let aboutBusiness = String(localized: "detail.aboutBusiness")
        static let yourCard      = String(localized: "detail.yourCard")
        static let business      = String(localized: "detail.business")
        static let reviews       = String(localized: "detail.reviews")
        static let showQR        = String(localized: "detail.showQR")
        static let showQRRedeem  = String(localized: "detail.showQRRedeem")
        static let rewardReady   = String(localized: "detail.rewardReady")
    }

    // MARK: - QR
    enum qr {
        static let title    = String(localized: "qr.title")
        static let subtitle = String(localized: "qr.subtitle")
        static let expired  = String(localized: "qr.expired")
        static let renew    = String(localized: "qr.renew")
    }

    // MARK: - Scanner (Business)
    enum scan {
        static let title          = String(localized: "scan.title")
        static let giveStamp      = String(localized: "scan.giveStamp")
        static let stampRegistered = String(localized: "scan.stampRegistered")
        static let keepScanning   = String(localized: "scan.keepScanning")
        static let cameraDisabled = String(localized: "scan.cameraDisabled")
        static let live           = String(localized: "scan.live")
    }

    // MARK: - Business
    enum biz {
        static let dashboard        = String(localized: "biz.dashboard")
        static let stampedToday     = String(localized: "biz.stampedToday")
        static let customersToday   = String(localized: "biz.customersToday")
        static let redemptionsToday = String(localized: "biz.redemptionsToday")
        static let retention        = String(localized: "biz.retention")
        static let recentActivity   = String(localized: "biz.recentActivity")
        static let newProgram       = String(localized: "biz.newProgram")
        static let plans            = String(localized: "biz.plans")
        static let exportCustomers  = String(localized: "biz.exportCustomers")
        static let inviteCustomers  = String(localized: "biz.inviteCustomers")
        static let sendNotification = String(localized: "biz.sendNotification")
        static let advancedAnalytics = String(localized: "biz.advancedAnalytics")
        static let openStatus       = String(localized: "biz.openStatus")
    }
}
