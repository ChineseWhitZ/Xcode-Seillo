import SwiftUI
import UIKit

// ─── SwipeBackModifier ────────────────────────────────────────────────────────
// Restaura el gesto interactivo de retroceso (edge swipe) de iOS cuando
// se oculta la navigation bar con .navigationBarBackButtonHidden(true)
// o .toolbar(.hidden, for: .navigationBar).
//
// Uso:   .enableSwipeBack()
//
// Ruta: Seillo/Seillo/Theme/SwipeBackModifier.swift
// ─────────────────────────────────────────────────────────────────────────────

extension View {
    /// Restaura el swipe-to-go-back nativo de iOS en pantallas con
    /// navigation bar oculta.
    func enableSwipeBack() -> some View {
        background(SwipeBackConfigurator())
    }
}

// UIKit bridge — busca el UINavigationController padre y habilita el gesture
private struct SwipeBackConfigurator: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> SwipeBackViewController {
        SwipeBackViewController()
    }
    func updateUIViewController(_ vc: SwipeBackViewController, context: Context) {}
}

private class SwipeBackViewController: UIViewController {
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Subir por la jerarquía de VCs hasta encontrar el UINavigationController
        if let nav = navigationController {
            nav.interactivePopGestureRecognizer?.isEnabled = true
            nav.interactivePopGestureRecognizer?.delegate = nil
        }
    }
}
