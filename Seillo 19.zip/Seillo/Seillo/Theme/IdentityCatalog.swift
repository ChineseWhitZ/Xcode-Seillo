import SwiftUI

// ─── Identity Catalog ─────────────────────────────────────────────────────────
//
// Mapa local de ID → estilo visual para badges, frames y títulos.
// El backend solo manda IDs. Este archivo es la única fuente de verdad
// para colores e iconos del sistema de identidad.
//
// Ruta: Seillo/Theme/IdentityCatalog.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Visual Styles

struct BadgeStyle {
    let bg     : Color
    let stroke : Color
    let icon   : String      // SF Symbol name
}

struct FrameStyle {
    let ringColor   : Color
    let ringColor2  : Color?       // segundo anillo si aplica
    let dashPattern : [CGFloat]?   // nil = sólido, ej: [3,3] = dashes
    let hasAccents  : Bool         // diamantes en puntos cardinales (Founder)
    let hasTicks    : Bool         // marcas cardinales (Leyenda)
    let hasArcs     : Bool         // arcos (Explorador)
    let hasDots     : Bool         // puntos (Coleccionista)
    let strokeWidth : CGFloat
    let avatarBg    : Color
    let avatarFg    : Color
}

struct TituloStyle {
    let bg     : Color
    let fg     : Color
    let stroke : Color
    let icon   : String      // SF Symbol name
}

// MARK: - Badge Catalog

private let badgeCatalog: [String: BadgeStyle] = [
    "founding_member": BadgeStyle(
        bg: Color(hex: "#FAEEDA"), stroke: Color(hex: "#EF9F27"), icon: "star.fill"
    ),
    "early_backer": BadgeStyle(
        bg: Color(hex: "#E6F1FB"), stroke: Color(hex: "#85B7EB"), icon: "checkmark.circle.fill"
    ),
    "supporter": BadgeStyle(
        bg: Color(hex: "#EAF3DE"), stroke: Color(hex: "#97C459"), icon: "heart.fill"
    ),
    "early_bird": BadgeStyle(
        bg: Color(hex: "#FAECE7"), stroke: Color(hex: "#F0997B"), icon: "bell.fill"
    ),
    "og": BadgeStyle(
        bg: Color(hex: "#EEEDFE"), stroke: Color(hex: "#AFA9EC"), icon: "crown.fill"
    ),
    "primer_sello": BadgeStyle(
        bg: Color(hex: "#F1EFE8"), stroke: Color(hex: "#B4B2A9"), icon: "clock.fill"
    ),
    "racha_7": BadgeStyle(
        bg: Color(hex: "#FAECE7"), stroke: Color(hex: "#F0997B"), icon: "flame.fill"
    ),
    "madrugador": BadgeStyle(
        bg: Color(hex: "#FAEEDA"), stroke: Color(hex: "#FAC775"), icon: "sun.max.fill"
    ),
    "noctambulo": BadgeStyle(
        bg: Color(hex: "#EEEDFE"), stroke: Color(hex: "#AFA9EC"), icon: "moon.fill"
    ),
    "centenario": BadgeStyle(
        bg: Color(hex: "#EAF3DE"), stroke: Color(hex: "#97C459"), icon: "star.fill"
    ),
    "explorador": BadgeStyle(
        bg: Color(hex: "#E1F5EE"), stroke: Color(hex: "#5DCAA5"), icon: "safari.fill"
    ),
    "conector": BadgeStyle(
        bg: Color(hex: "#E6F1FB"), stroke: Color(hex: "#85B7EB"), icon: "person.2.fill"
    ),
    "cafetero": BadgeStyle(
        bg: Color(hex: "#FAEEDA"), stroke: Color(hex: "#EF9F27"), icon: "cup.and.saucer.fill"
    ),
    "lector": BadgeStyle(
        bg: Color(hex: "#E1F5EE"), stroke: Color(hex: "#5DCAA5"), icon: "book.fill"
    ),
    "gourmet": BadgeStyle(
        bg: Color(hex: "#EEEDFE"), stroke: Color(hex: "#AFA9EC"), icon: "fork.knife"
    ),
]

// MARK: - Frame Catalog

private let frameCatalog: [String: FrameStyle] = [
    "founder": FrameStyle(
        ringColor: Color(hex: "#EF9F27"), ringColor2: Color(hex: "#BA7517"),
        dashPattern: nil, hasAccents: true, hasTicks: false, hasArcs: false, hasDots: false,
        strokeWidth: 2.5, avatarBg: Color(hex: "#241A12"), avatarFg: Color(hex: "#F5EDE4")
    ),
    "backer": FrameStyle(
        ringColor: Color(hex: "#378ADD"), ringColor2: Color(hex: "#378ADD"),
        dashPattern: [4, 4], hasAccents: false, hasTicks: false, hasArcs: false, hasDots: false,
        strokeWidth: 2, avatarBg: Color(hex: "#0C2744"), avatarFg: Color(hex: "#B5D4F4")
    ),
    "supporter": FrameStyle(
        ringColor: Color(hex: "#1D9E75"), ringColor2: nil,
        dashPattern: nil, hasAccents: false, hasTicks: false, hasArcs: false, hasDots: false,
        strokeWidth: 1.5, avatarBg: Color(hex: "#04342C"), avatarFg: Color(hex: "#9FE1CB")
    ),
    "leyenda": FrameStyle(
        ringColor: .seilPurple, ringColor2: .seilPurple,
        dashPattern: nil, hasAccents: false, hasTicks: true, hasArcs: false, hasDots: false,
        strokeWidth: 2, avatarBg: Color(hex: "#1A1040"), avatarFg: Color(hex: "#CECBF6")
    ),
    "explorador": FrameStyle(
        ringColor: Color(hex: "#0F6E56"), ringColor2: Color(hex: "#1D9E75"),
        dashPattern: nil, hasAccents: false, hasTicks: false, hasArcs: true, hasDots: false,
        strokeWidth: 1.5, avatarBg: Color(hex: "#04302A"), avatarFg: Color(hex: "#9FE1CB")
    ),
    "coleccionista": FrameStyle(
        ringColor: .seilAccent2, ringColor2: nil,
        dashPattern: nil, hasAccents: false, hasTicks: false, hasArcs: false, hasDots: true,
        strokeWidth: 1.5, avatarBg: Color(hex: "#241A12"), avatarFg: Color(hex: "#F5EDE4")
    ),
    "aniversario": FrameStyle(
        ringColor: Color(hex: "#888780"), ringColor2: Color(hex: "#444441"),
        dashPattern: nil, hasAccents: false, hasTicks: false, hasArcs: true, hasDots: false,
        strokeWidth: 1, avatarBg: Color(hex: "#161412"), avatarFg: Color(hex: "#D3D1C7")
    ),
]

// MARK: - Título Catalog

private let tituloCatalog: [String: TituloStyle] = [
    "fundador_seillo": TituloStyle(
        bg: Color(hex: "#FAEEDA"), fg: Color(hex: "#854F0B"),
        stroke: Color(hex: "#EF9F27"), icon: "star.fill"
    ),
    "early_backer": TituloStyle(
        bg: Color(hex: "#E6F1FB"), fg: Color(hex: "#185FA5"),
        stroke: Color(hex: "#85B7EB"), icon: "checkmark.circle.fill"
    ),
    "primer_supporter": TituloStyle(
        bg: Color(hex: "#EAF3DE"), fg: Color(hex: "#3B6D11"),
        stroke: Color(hex: "#97C459"), icon: "heart.fill"
    ),
    "og_member": TituloStyle(
        bg: Color(hex: "#EEEDFE"), fg: Color(hex: "#3C3489"),
        stroke: Color(hex: "#AFA9EC"), icon: "crown.fill"
    ),
    "centenario": TituloStyle(
        bg: Color(hex: "#EAF3DE"), fg: Color(hex: "#3B6D11"),
        stroke: Color(hex: "#97C459"), icon: "star.fill"
    ),
    "veterano": TituloStyle(
        bg: Color(hex: "#FAECE7"), fg: Color(hex: "#993C1D"),
        stroke: Color(hex: "#F0997B"), icon: "trophy.fill"
    ),
    "conector": TituloStyle(
        bg: Color(hex: "#E1F5EE"), fg: Color(hex: "#0F6E56"),
        stroke: Color(hex: "#5DCAA5"), icon: "person.2.fill"
    ),
    "influencer": TituloStyle(
        bg: Color(hex: "#E6F1FB"), fg: Color(hex: "#185FA5"),
        stroke: Color(hex: "#85B7EB"), icon: "person.2.fill"
    ),
    "fiel_negocio": TituloStyle(
        bg: Color(hex: "#FAEEDA"), fg: Color(hex: "#854F0B"),
        stroke: Color(hex: "#EF9F27"), icon: "house.fill"
    ),
]

// MARK: - Public Access

/// Devuelve el estilo visual de un badge por su ID.
/// Si el ID no existe, devuelve un estilo genérico gris.
func badgeStyleFor(_ id: String) -> BadgeStyle {
    badgeCatalog[id] ?? BadgeStyle(
        bg: Color(hex: "#F1EFE8"), stroke: Color(hex: "#B4B2A9"), icon: "diamond.fill"
    )
}

/// Devuelve el estilo de un frame por su ID, o nil si no existe.
func frameStyleFor(_ id: String) -> FrameStyle? {
    frameCatalog[id]
}

/// Devuelve el estilo de un título por su ID.
/// Si el ID no existe, devuelve un estilo genérico gris.
func tituloStyleFor(_ id: String) -> TituloStyle {
    tituloCatalog[id] ?? TituloStyle(
        bg: Color(hex: "#F1EFE8"), fg: Color(hex: "#5F5E5A"),
        stroke: Color(hex: "#B4B2A9"), icon: "diamond.fill"
    )
}
