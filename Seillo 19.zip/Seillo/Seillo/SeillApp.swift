import SwiftUI

@main
struct SeillApp: App {
    @StateObject private var authManager     = AuthManager()
    @StateObject private var profileStore    = ProfileStore()
    @StateObject private var bizProfileStore = BizProfileStore()

    // Flags de onboarding — persisten en UserDefaults
    @AppStorage("onboarding_app_done")  private var onboardingDone  = false
    @AppStorage("tutorial_client_done") private var tutorialDone    = false
    @AppStorage("biz_wizard_done")      private var bizWizardDone   = false
    @AppStorage("user_wizard_done")     private var userWizardDone  = false

    // Apariencia: "amoled" (estándar) o "light"
    @AppStorage("app_appearance") private var appearance = "amoled"

    var body: some Scene {
        WindowGroup {
            ZStack {
                Color.seilBg.ignoresSafeArea()
                currentRoot
            }
            .task {
                await authManager.checkAppleCredentialState()
            }
            .animation(.easeInOut(duration: 0.40), value: authManager.isLoading)
            // Spring en lugar de easeInOut para isLoggedIn:
            // el overshoot del spring hace que HomeView (y su tab bar)
            // parezca que "aterriza" desde abajo — idéntico al comportamiento
            // de Music y App Store al volver de una pantalla de login.
            .animation(.spring(response: 0.55, dampingFraction: 0.88), value: authManager.isLoggedIn)
            .animation(.easeInOut(duration: 0.36), value: onboardingDone)
            .animation(.easeInOut(duration: 0.36), value: tutorialDone)
            .animation(.easeInOut(duration: 0.36), value: userWizardDone)
            .animation(.easeInOut(duration: 0.36), value: bizWizardDone)
            .preferredColorScheme(appearance == "light" ? .light : .dark)
        }
    }

    @ViewBuilder
    private var currentRoot: some View {
        if authManager.isLoading {
            SplashView()

        } else if authManager.isLoggedIn {
            if authManager.isBusiness {
                if !bizWizardDone {
                    BizOnboardingWizard { bizWizardDone = true }
                        .environmentObject(bizProfileStore)
                } else {
                    BusinessHomeView()
                        .environmentObject(authManager)
                        .environmentObject(bizProfileStore)
                        .task { await bizProfileStore.load() }
                }
            } else {
                // Flujo cliente: wizard → tutorial → home
                if !userWizardDone {
                    UserWizardView { userWizardDone = true }
                } else if !tutorialDone {
                    UserTutorialView { tutorialDone = true }
                } else {
                    HomeView()
                        .environmentObject(authManager)
                        .environmentObject(profileStore)
                        .task { profileStore.refreshFromLocal() }
                }
            }
        } else {
            if !onboardingDone {
                OnboardingView { onboardingDone = true }
            } else {
                WelcomeView()
                    .environmentObject(authManager)
            }
        }
    }
}
