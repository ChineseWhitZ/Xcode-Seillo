import SwiftUI

// ─── Friend Models ────────────────────────────────────────────────────────────
//
// Modelos tipados para el sistema de amigos.
// Usa String id (del backend) en lugar de UUID autogenerado.
//
// Ruta: Seillo/Models/FriendModels.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Friend Activity Type

enum FriendActivityType: String, Codable {
    case stamp    // acumulo un sello
    case reward   // canjeo un premio
    case levelUp  // subio de nivel
    case joined   // se acaba de unir
}

// MARK: - Friend Activity

/// Actividad reciente de un amigo que se muestra en el banner de HomeView.
struct FriendActivity: Identifiable {
    var id            : String
    var friendName    : String
    var friendInitial : String
    var friendColor   : Color
    var type          : FriendActivityType
    var bizName       : String?   = nil
    var bizIcon       : String?   = nil
    var bizColor      : Color?    = nil
    var detail        : String
    var levelName     : String?   = nil
    var timeAgo       : String
}

// MARK: - Friend Status

enum FriendStatus: String, Codable {
    case friend
    case pending
    case incoming
}

// MARK: - Friend

/// Modelo principal de amigo. Usa String id compatible con backend.
struct Friend: Identifiable {
    var id          : String
    var name        : String
    var initial     : String
    var color       : Color
    var level       : String
    var levelIcon   : String
    var levelColor  : Color
    var totalStamps : Int
    var topBiz      : String
    var status      : FriendStatus
    var mutualCount : Int
    var solicitudId : String = ""
}

// MARK: - Search Result

struct FriendSearchResult: Identifiable {
    let id               : String
    var nombre           : String
    var avatarId         : Int = 0
    var totalSellos      : Int = 0
    var yaAmigo          : Bool = false
    var solicitudEnviada : Bool = false
}
