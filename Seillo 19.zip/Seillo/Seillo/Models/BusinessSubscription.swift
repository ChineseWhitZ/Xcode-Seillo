import Foundation

struct BusinessSubscription {

    let plan                   : SubscriptionPlan

    // ── Uso actual ───────────────────────────────────────────────────────────
    let localesActuales        : Int
    let tarjetasActivasActuales: Int
    let clientesActuales       : Int

    // ── Fechas (ISO 8601) ────────────────────────────────────────────────────
    let fechaInicio            : String
    let fechaRenovacion        : String

    // ── Checklist de onboarding ───────────────────────────────────────────────
    let creoLocal              : Bool
    let creoTarjeta            : Bool
    let configuroRecompensa    : Bool
    let activoQr               : Bool
    let invitóStaff            : Bool

    // MARK: - Init con valores por defecto

    init(
        plan                    : SubscriptionPlan,
        localesActuales         : Int  = 0,
        tarjetasActivasActuales : Int  = 0,
        clientesActuales        : Int  = 0,
        fechaInicio             : String = "2025-01-01",
        fechaRenovacion         : String = "2026-04-01",
        creoLocal               : Bool = false,
        creoTarjeta             : Bool = false,
        configuroRecompensa     : Bool = false,
        activoQr                : Bool = false,
        invitóStaff             : Bool = false
    ) {
        self.plan                    = plan
        self.localesActuales         = localesActuales
        self.tarjetasActivasActuales = tarjetasActivasActuales
        self.clientesActuales        = clientesActuales
        self.fechaInicio             = fechaInicio
        self.fechaRenovacion         = fechaRenovacion
        self.creoLocal               = creoLocal
        self.creoTarjeta             = creoTarjeta
        self.configuroRecompensa     = configuroRecompensa
        self.activoQr                = activoQr
        self.invitóStaff             = invitóStaff
    }

    // MARK: - Porcentajes de uso

    /// 0.0 – 1.0. Devuelve 0 si el plan tiene clientes ilimitados.
    var porcentajeClientes: Double {
        guard plan.maxClientes > 0 else { return 0 }
        return min(Double(clientesActuales) / Double(plan.maxClientes), 1.0)
    }

    /// 0.0 – 1.0. Devuelve 0 si el plan tiene locales ilimitados.
    var porcentajeLocales: Double {
        guard plan.maxLocales > 0 else { return 0 }
        return min(Double(localesActuales) / Double(plan.maxLocales), 1.0)
    }

    // MARK: - Alertas de límite

    /// `true` cuando el negocio alcanzó el 80 % o más del límite de clientes.
    var cercaLimiteClientes: Bool {
        plan.maxClientes > 0 && porcentajeClientes >= 0.8
    }

    /// `true` cuando el negocio alcanzó el 80 % o más del límite de locales.
    var cercaLimiteLocales: Bool {
        plan.maxLocales > 0 && porcentajeLocales >= 0.8
    }

    // MARK: - Labels de uso

    /// "34 / 50 clientes" · "Ilimitados"
    func textoLimiteClientes() -> String {
        plan.maxClientes <= 0
            ? "Ilimitados"
            : "\(clientesActuales) / \(plan.maxClientes) clientes"
    }

    /// "1 / 1 local" · "Ilimitados"
    func textoLimiteLocales() -> String {
        plan.maxLocales <= 0
            ? "Ilimitados"
            : "\(localesActuales) / \(plan.maxLocales) local\(plan.maxLocales == 1 ? "" : "es")"
    }

    // MARK: - Onboarding

    /// 0.0 – 1.0. Porcentaje del checklist de onboarding completado.
    /// Los planes con staff incluyen el ítem de invitar al equipo.
    var progresoOnboarding: Double {
        var items: [Bool] = [creoLocal, creoTarjeta, configuroRecompensa, activoQr]
        if plan.tieneStaff { items.append(invitóStaff) }
        let completados = items.filter { $0 }.count
        return Double(completados) / Double(items.count)
    }

    // MARK: - Mock para previews

    static let mockFree = BusinessSubscription(
        plan                    : PlanCatalog.free,
        localesActuales         : 1,
        tarjetasActivasActuales : 1,
        clientesActuales        : 38,
        creoLocal               : true,
        creoTarjeta             : true,
        configuroRecompensa     : false,
        activoQr                : false
    )

    static let mockGrowth = BusinessSubscription(
        plan                    : PlanCatalog.growth,
        localesActuales         : 2,
        tarjetasActivasActuales : 5,
        clientesActuales        : 843,
        creoLocal               : true,
        creoTarjeta             : true,
        configuroRecompensa     : true,
        activoQr                : true,
        invitóStaff             : false
    )

    static let mockPro = BusinessSubscription(
        plan                    : PlanCatalog.pro,
        localesActuales         : 4,
        tarjetasActivasActuales : 7,
        clientesActuales        : 2_100,
        creoLocal               : true,
        creoTarjeta             : true,
        configuroRecompensa     : true,
        activoQr                : true,
        invitóStaff             : true
    )
}
