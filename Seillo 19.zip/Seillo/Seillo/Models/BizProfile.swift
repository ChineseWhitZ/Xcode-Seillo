import SwiftUI
import Combine

// ─── BizProfile Model ──────────────────────────────────────────────────────
// ─── BizMenuItem ──────────────────────────────────────────────────────────────
struct BizMenuItem: Identifiable, Codable {
    var id:          String = UUID().uuidString
    var categoria:   String          // "Bebidas", "Comida", "Servicios", etc.
    var nombre:      String
    var descripcion: String
    var precio:      String          // "S/ 12", "S/ 25", etc.
    var badge:       String?         // "Popular", "Nuevo", "Favorito" — nil si no aplica
}

struct BizProfile {
    var nombre:           String
    var direccion:        String
    var categoriaId:      String
    var sellosParaPremio: Int
    var premioTexto:      String
    var menu:             [BizMenuItem]

    static let empty = BizProfile(
        nombre: "", direccion: "", categoriaId: "cafe",
        sellosParaPremio: 10, premioTexto: "", menu: []
    )

    static func fromApi(_ json: [String: Any]) -> BizProfile {
        BizProfile(
            nombre:           json["nombre"]           as? String ?? "",
            direccion:        json["direccion"]         as? String ?? "",
            categoriaId:      json["categoriaId"]       as? String ?? "cafe",
            sellosParaPremio: json["sellosParaPremio"]  as? Int    ?? 10,
            premioTexto:      json["premioTexto"]       as? String ?? "",
            menu:             []   // TODO: parsear del JSON cuando el backend lo soporte
        )
    }

    var categoriaLabel: String {
        let map = [
            "cafe": "Café", "restaurante": "Restaurante",
            "barberia": "Barbería", "jugueria": "Juguería",
            "gym": "Gimnasio", "pasteleria": "Pastelería",
            "farmacia": "Farmacia", "tienda": "Tienda"
        ]
        return map[categoriaId] ?? "Negocio"
    }

    var categoriaIcon: String {
        let map = [
            "cafe": "cup.and.saucer.fill", "restaurante": "fork.knife",
            "barberia": "scissors",         "jugueria": "cup.and.saucer",
            "gym": "dumbbell.fill",          "pasteleria": "birthday.cake.fill",
            "farmacia": "cross.case.fill",   "tienda": "basket.fill"
        ]
        return map[categoriaId] ?? "storefront.fill"
    }
}

// ─── BizProfileStore (replaces Flutter's BizProfileScope InheritedWidget) ──
@MainActor
class BizProfileStore: ObservableObject {
    @Published var profile   = BizProfile.empty
    @Published var isLoading = true

    private let api = APIClient.shared

    init() {
        self.profile   = BizProfile.empty
        self.isLoading = true
    }

    func load() async {
        guard TokenStore.isLoggedIn else {
            isLoading = false
            return
        }
        do {
            let dto: NegocioPerfilDTO = try await api.get("api/negocio/perfil")
            profile = BizProfile(
                nombre: dto.nombre,
                direccion: dto.direccion,
                categoriaId: dto.categoriaId,
                sellosParaPremio: dto.sellosParaPremio,
                premioTexto: dto.premioTexto,
                menu: []
            )
        } catch {
            // Silently fail — profile stays empty
        }
        isLoading = false
    }

    func update(_ updated: BizProfile) {
        profile = updated
    }

    // Mock pre-cargado para desarrollo sin backend
    static var mockCafe: BizProfileStore {
        let store = BizProfileStore()
        store.profile = BizProfile(
            nombre: "Café Inti",
            direccion: "Jr. Schell 392, Miraflores",
            categoriaId: "cafe",
            sellosParaPremio: 10,
            premioTexto: "Café a elección gratis",
            menu: [
                BizMenuItem(categoria: "Bebidas calientes",
                            nombre: "Americano",
                            descripcion: "Shot doble, agua caliente",
                            precio: "S/ 8",  badge: nil),
                BizMenuItem(categoria: "Bebidas calientes",
                            nombre: "Latte de especialidad",
                            descripcion: "Con leche de avena",
                            precio: "S/ 12", badge: "Popular"),
                BizMenuItem(categoria: "Bebidas calientes",
                            nombre: "Capuccino Inti",
                            descripcion: "Con canela Cusqueña",
                            precio: "S/ 10", badge: nil),
                BizMenuItem(categoria: "Pastelería",
                            nombre: "Croissant de mantequilla",
                            descripcion: "Horneado en el día",
                            precio: "S/ 9",  badge: "Favorito"),
                BizMenuItem(categoria: "Pastelería",
                            nombre: "Muffin de arándanos",
                            descripcion: "Sin gluten",
                            precio: "S/ 8",  badge: nil),
            ]
        )
        store.isLoading = false
        return store
    }
}
