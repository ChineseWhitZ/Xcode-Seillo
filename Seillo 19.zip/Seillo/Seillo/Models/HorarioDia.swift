import Foundation

// ─── Horario ──────────────────────────────────────────────────────────────────
//
// Modelo de horario diario para negocios.
// Usado en BizOnboardingWizard y EditBizProfileView.
//
// Ruta: Seillo/Models/HorarioDia.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - HorarioDia (UI)

struct HorarioDia: Identifiable {
    let id = UUID()
    let dia       : Int          // 0=Lunes ... 6=Domingo
    var abierto   : Bool  = true
    var horaInicio: String = "08:00"
    var horaCierre: String = "20:00"

    /// Nombre del día para mostrar en la UI
    var diaLabel: String {
        switch dia {
        case 0: return "Lunes"
        case 1: return "Martes"
        case 2: return "Miércoles"
        case 3: return "Jueves"
        case 4: return "Viernes"
        case 5: return "Sábado"
        case 6: return "Domingo"
        default: return "—"
        }
    }

    /// Abreviatura para vistas compactas
    var diaShort: String {
        switch dia {
        case 0: return "Lun"
        case 1: return "Mar"
        case 2: return "Mié"
        case 3: return "Jue"
        case 4: return "Vie"
        case 5: return "Sáb"
        case 6: return "Dom"
        default: return "—"
        }
    }

    /// Semana completa con valores por defecto (L-V abierto, S-D cerrado)
    static var defaultWeek: [HorarioDia] {
        (0...6).map { dia in
            HorarioDia(
                dia: dia,
                abierto: dia < 5,   // L-V abierto, S-D cerrado
                horaInicio: "08:00",
                horaCierre: dia < 5 ? "20:00" : "14:00"
            )
        }
    }
}

// MARK: - DTO (para API)

/// Representación que el backend espera/devuelve.
/// abierto es Int (0 o 1) y las horas llevan segundos.
struct HorarioDiaDTO: Codable {
    let dia        : Int
    let abierto    : Int            // 0 o 1
    let horaInicio : String         // "08:00:00"
    let horaCierre : String         // "20:00:00"

    enum CodingKeys: String, CodingKey {
        case dia
        case abierto
        case horaInicio = "hora_inicio"
        case horaCierre = "hora_cierre"
    }
}

// MARK: - Conversores

extension HorarioDia {
    /// Convierte el modelo UI a DTO para enviar al servidor
    func toDTO() -> HorarioDiaDTO {
        HorarioDiaDTO(
            dia: dia,
            abierto: abierto ? 1 : 0,
            horaInicio: horaInicio.toServerHour(),
            horaCierre: horaCierre.toServerHour()
        )
    }
}

extension HorarioDiaDTO {
    /// Convierte el DTO del servidor a modelo UI
    func toUI() -> HorarioDia {
        HorarioDia(
            dia: dia,
            abierto: abierto == 1,
            horaInicio: horaInicio.toDisplayHour(),
            horaCierre: horaCierre.toDisplayHour()
        )
    }
}

// MARK: - String helpers

extension String {
    /// "08:00:00" → "08:00"
    func toDisplayHour() -> String {
        String(prefix(5))
    }

    /// "08:00" → "08:00:00"
    func toServerHour() -> String {
        count == 5 ? "\(self):00" : self
    }
}
