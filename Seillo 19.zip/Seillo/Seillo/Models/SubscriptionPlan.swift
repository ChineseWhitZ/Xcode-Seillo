import SwiftUI

// MARK: - PlanTier

enum PlanTier: Int, CaseIterable, Comparable {
    case free       = 0
    case starter    = 1
    case growth     = 2
    case pro        = 3
    case enterprise = 4

    // Permite comparar tiers con < > >= <=
    static func < (lhs: PlanTier, rhs: PlanTier) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}

// MARK: - SubscriptionPlan

struct SubscriptionPlan {
    let tier               : PlanTier
    let nombre             : String
    let tagline            : String
    let precioMensual      : Int        // 0 = gratis · precios en Soles (PEN)
    let esEnterprise       : Bool

    // ── Límites numéricos ────────────────────────────────────────────────────
    let maxLocales         : Int        // -1 = ilimitado
    let maxTarjetasActivas : Int        // -1 = ilimitado
    let maxClientes        : Int        // -1 = ilimitado

    // ── Feature flags ────────────────────────────────────────────────────────
    let tienePromociones        : Bool
    let tieneAutomatizaciones   : Bool
    let tieneStaff              : Bool
    let tieneBrandingPropio     : Bool  // false = branding Seillo visible
    let tieneAnaliticaAvanzada  : Bool
    let tienePushNotifications  : Bool
    let tieneIntegracionesApi   : Bool
    let tieneSoportePrioritario : Bool
    let tieneOnboardingDedicado : Bool

    // ── Helpers ──────────────────────────────────────────────────────────────

    /// `true` si este plan es igual o superior al tier indicado.
    func esAlMenosTier(_ minTier: PlanTier) -> Bool {
        tier >= minTier
    }

    /// Precio formateado en Soles peruanos: "S/. 299" · "Gratis" · "A medida"
    var precioFormateado: String {
        if esEnterprise   { return "A medida" }
        if precioMensual == 0 { return "Gratis" }
        return "S/. \(precioMensual)"
    }

    /// Label corto del límite de clientes: "50 clientes" · "Ilimitados"
    func labelLimiteClientes() -> String {
        maxClientes <= 0 ? "Ilimitados" : "\(maxClientes) clientes"
    }

    /// Label corto del límite de locales: "1 local" · "Ilimitados"
    func labelLimiteLocales() -> String {
        maxLocales <= 0 ? "Ilimitados" : maxLocales == 1 ? "1 local" : "\(maxLocales) locales"
    }

    /// Label corto del límite de tarjetas: "1 tarjeta" · "Ilimitadas"
    func labelLimiteTarjetas() -> String {
        maxTarjetasActivas <= 0 ? "Ilimitadas" : maxTarjetasActivas == 1 ? "1 tarjeta" : "\(maxTarjetasActivas) tarjetas"
    }
}

// MARK: - PlanCatalog

/// Catálogo oficial de planes de Seillo.
/// Precios en Soles peruanos (PEN) — actualizar aquí cuando cambien.
enum PlanCatalog {

    static let free = SubscriptionPlan(
        tier                    : .free,
        nombre                  : "Free",
        tagline                 : "Para empezar sin riesgo",
        precioMensual           : 0,
        esEnterprise            : false,
        maxLocales              : 1,
        maxTarjetasActivas      : 1,
        maxClientes             : 50,
        tienePromociones        : false,
        tieneAutomatizaciones   : false,
        tieneStaff              : false,
        tieneBrandingPropio     : false,
        tieneAnaliticaAvanzada  : false,
        tienePushNotifications  : false,
        tieneIntegracionesApi   : false,
        tieneSoportePrioritario : false,
        tieneOnboardingDedicado : false
    )

    static let starter = SubscriptionPlan(
        tier                    : .starter,
        nombre                  : "Starter",
        tagline                 : "Para negocios que arrancan",
        precioMensual           : 152,          // S/. 152 / mes
        esEnterprise            : false,
        maxLocales              : 1,
        maxTarjetasActivas      : 3,
        maxClientes             : 300,
        tienePromociones        : false,
        tieneAutomatizaciones   : false,
        tieneStaff              : false,
        tieneBrandingPropio     : false,
        tieneAnaliticaAvanzada  : false,
        tienePushNotifications  : false,
        tieneIntegracionesApi   : false,
        tieneSoportePrioritario : false,
        tieneOnboardingDedicado : false
    )

    static let growth = SubscriptionPlan(
        tier                    : .growth,
        nombre                  : "Growth",
        tagline                 : "Para negocios que escalan",
        precioMensual           : 299,          // S/. 299 / mes
        esEnterprise            : false,
        maxLocales              : 3,
        maxTarjetasActivas      : 10,
        maxClientes             : 1500,
        tienePromociones        : true,
        tieneAutomatizaciones   : false,
        tieneStaff              : true,
        tieneBrandingPropio     : false,
        tieneAnaliticaAvanzada  : true,
        tienePushNotifications  : true,
        tieneIntegracionesApi   : false,
        tieneSoportePrioritario : false,
        tieneOnboardingDedicado : false
    )

    static let pro = SubscriptionPlan(
        tier                    : .pro,
        nombre                  : "Pro",
        tagline                 : "El poder completo de Seillo",
        precioMensual           : 549,          // S/. 549 / mes
        esEnterprise            : false,
        maxLocales              : -1,
        maxTarjetasActivas      : -1,
        maxClientes             : -1,
        tienePromociones        : true,
        tieneAutomatizaciones   : true,
        tieneStaff              : true,
        tieneBrandingPropio     : true,
        tieneAnaliticaAvanzada  : true,
        tienePushNotifications  : true,
        tieneIntegracionesApi   : false,
        tieneSoportePrioritario : true,
        tieneOnboardingDedicado : false
    )

    static let enterprise = SubscriptionPlan(
        tier                    : .enterprise,
        nombre                  : "Enterprise",
        tagline                 : "Para grandes operaciones",
        precioMensual           : 0,            // precio a medida
        esEnterprise            : true,
        maxLocales              : -1,
        maxTarjetasActivas      : -1,
        maxClientes             : -1,
        tienePromociones        : true,
        tieneAutomatizaciones   : true,
        tieneStaff              : true,
        tieneBrandingPropio     : true,
        tieneAnaliticaAvanzada  : true,
        tienePushNotifications  : true,
        tieneIntegracionesApi   : true,
        tieneSoportePrioritario : true,
        tieneOnboardingDedicado : true
    )

    /// Lista ordenada de menor a mayor — útil para la pantalla de Planes.
    static let todos: [SubscriptionPlan] = [free, starter, growth, pro, enterprise]

    /// Busca un plan por su tier.
    static func byTier(_ tier: PlanTier) -> SubscriptionPlan {
        todos.first { $0.tier == tier } ?? free
    }

    /// Parsea el string que devuelve el backend ("pro", "growth", etc.).
    static func fromString(_ value: String) -> SubscriptionPlan {
        switch value.lowercased() {
        case "starter":    return starter
        case "growth":     return growth
        case "pro":        return pro
        case "enterprise": return enterprise
        default:           return free
        }
    }
}
