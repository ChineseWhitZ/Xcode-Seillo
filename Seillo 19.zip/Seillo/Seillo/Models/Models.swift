import SwiftUI
import CoreLocation

// ─── LoyaltyCard ──────────────────────────────────────────────────────────
struct LoyaltyCard: Identifiable, Codable {
    let id: String
    let bizName: String
    let location: String       // categoria / tag
    let rewardText: String
    let totalStamps: Int
    var filledStamps: Int
    let negocioId: String
    let programaId: String

    // UI-computed, not from API
    var stampColor: Color {
        colorForCategory(location)
    }
    /// Hex string sin # para serializar al widget (evita dependencia de SwiftUI.Color en el App Group)
    var stampColorHex: String {
        stampColorHexForCategory(location)
    }
    var gradientColors: [Color] {
        gradientForCategory(location)
    }
    var icon: String {
        iconForCategory(location)
    }

    // ── API mapping ────────────────────────────────────────────────────────
    enum CodingKeys: String, CodingKey {
        case id
        case bizName       = "negocio_nombre"
        case location      = "categoria"
        case rewardText    = "premio"
        case totalStamps   = "sellos_meta"
        case filledStamps  = "sellos_actuales"
        case negocioId     = "negocio_id"
        case programaId    = "programa_id"
    }

    var progress: Double {
        guard totalStamps > 0 else { return 0 }
        return Double(filledStamps) / Double(totalStamps)
    }
    var isComplete: Bool { filledStamps >= totalStamps }
    var remainingStamps: Int { max(0, totalStamps - filledStamps) }
}

func iconForCategory(_ cat: String) -> String {
    let c = cat.lowercased()
    // ── Categorías peruanas ────────────────────────────────────────────────
    if c.contains("poll") || c.contains("brasa")                             { return "flame.fill" }
    if c.contains("cevich") || c.contains("cebich") || c.contains("marino") { return "fish.fill" }
    if c.contains("sanguch") || c.contains("sángu")                         { return "bag.fill" }
    if c.contains("chifa") || c.contains("oriental") || c.contains("chino") { return "fork.knife.circle.fill" }
    if c.contains("helad")                                                   { return "snowflake" }
    if c.contains("panader") || c.contains("bakery")                        { return "leaf.fill" }
    if c.contains("bodega")                                                  { return "storefront.fill" }
    if c.contains("veterina") || c.contains("mascota")                      { return "pawprint.fill" }
    if c.contains("estética") || c.contains("estetica") || c.contains("peluc") { return "comb.fill" }
    if c.contains("tatua") || c.contains("piercing")                        { return "paintbrush.pointed.fill" }
    if c.contains("lavand")                                                  { return "bubbles.and.sparkles.fill" }
    // ── Categorías base ────────────────────────────────────────────────────
    if c.contains("caf") || c.contains("coffee")                            { return "cup.and.saucer.fill" }
    if c.contains("pizza") || c.contains("comida") || c.contains("restaur") { return "fork.knife" }
    if c.contains("barber") || c.contains("corte") || c.contains("salon")   { return "scissors" }
    if c.contains("jug") || c.contains("beb") || c.contains("drink")        { return "cup.and.saucer" }
    if c.contains("gym") || c.contains("fitness")                           { return "dumbbell.fill" }
    if c.contains("dulc") || c.contains("cake") || c.contains("pastel")     { return "birthday.cake.fill" }
    if c.contains("farma") || c.contains("salud")                           { return "cross.case.fill" }
    if c.contains("super") || c.contains("tiend") || c.contains("market")   { return "basket.fill" }
    return "storefront.fill"
}

func colorForCategory(_ cat: String) -> Color {
    let c = cat.lowercased()
    // ── Categorías peruanas ────────────────────────────────────────────────
    if c.contains("poll") || c.contains("brasa")                             { return .seilRose }
    if c.contains("cevich") || c.contains("cebich") || c.contains("marino") { return Color(hex: "#00B4D8") }
    if c.contains("sanguch") || c.contains("sángu")                         { return Color(hex: "#E8892B") }
    if c.contains("chifa") || c.contains("oriental") || c.contains("chino") { return Color(hex: "#FF3B30") }
    if c.contains("helad")                                                   { return Color(hex: "#5BC8E8") }
    if c.contains("panader") || c.contains("bakery")                        { return Color(hex: "#D4A843") }
    if c.contains("bodega")                                                  { return .seilAccent }
    if c.contains("veterina") || c.contains("mascota")                      { return .seilGreen }
    if c.contains("estética") || c.contains("estetica") || c.contains("peluc") { return Color.seilPurple }
    if c.contains("tatua") || c.contains("piercing")                        { return Color.seilPurple }
    if c.contains("lavand")                                                  { return Color.seilBlue }
    // ── Categorías base ────────────────────────────────────────────────────
    if c.contains("caf") || c.contains("coffee")                            { return .seilGold }
    if c.contains("pizza") || c.contains("restaur")                         { return Color.seilBlue }
    if c.contains("barber") || c.contains("salon")                          { return Color.seilPurple }
    if c.contains("jug") || c.contains("beb")                               { return Color.seilGreen }
    if c.contains("gym")                                                     { return Color.seilRose }
    return .seilAccent
}

private func stampColorHexForCategory(_ cat: String) -> String {
    let c = cat.lowercased()
    // ── Categorías peruanas ────────────────────────────────────────────────
    if c.contains("poll") || c.contains("brasa")                             { return "FF4460" }  // brasas
    if c.contains("cevich") || c.contains("cebich") || c.contains("marino") { return "00B4D8" }  // mar
    if c.contains("sanguch") || c.contains("sángu")                         { return "E8892B" }  // pan tostado
    if c.contains("chifa") || c.contains("oriental") || c.contains("chino") { return "FF3B30" }  // rojo chino
    if c.contains("helad")                                                   { return "5BC8E8" }  // hielo
    if c.contains("panader") || c.contains("bakery")                        { return "D4A843" }  // trigo dorado
    if c.contains("bodega")                                                  { return "FF5A00" }
    if c.contains("veterina") || c.contains("mascota")                      { return "00C97A" }
    if c.contains("estética") || c.contains("estetica") || c.contains("peluc") { return "B06FEF" }
    if c.contains("tatua") || c.contains("piercing")                        { return "B06FEF" }
    if c.contains("lavand")                                                  { return "4F9FFF" }
    // ── Categorías base ────────────────────────────────────────────────────
    if c.contains("café") || c.contains("cafe") || c.contains("pastel")     { return "FFB800" }
    if c.contains("pizza") || c.contains("restaur")                         { return "4F9FFF" }
    if c.contains("barber") || c.contains("salon")                          { return "B06FEF" }
    if c.contains("jug") || c.contains("beb")                               { return "00C97A" }
    if c.contains("gym")                                                     { return "FF4460" }
    return "FF5A00"  // default naranja
}

private func gradientForCategory(_ cat: String) -> [Color] {
    let base = colorForCategory(cat)
    let isDark = UITraitCollection.current.userInterfaceStyle == .dark

    if isDark {
        // AMOLED: negro → color saturado profundo
        return [
            base.opacity(0.08),
            base.opacity(0.18),
            base.opacity(0.32)
        ]
    } else {
        // Claro: fondo casi blanco con tinte suave del color de la categoría.
        // El texto usa el color saturado sobre este fondo → alto contraste,
        // como una tarjeta física impresa sobre papel crema.
        return [
            base.opacity(0.12),
            base.opacity(0.19),
            base.opacity(0.26)
        ]
    }
}

// ─── Business ─────────────────────────────────────────────────────────────
struct MenuItem: Identifiable {
    let id = UUID()
    let name: String
    let desc: String
    let price: String
    let badge: String?
}

struct MenuCategory: Identifiable {
    let id = UUID()
    let label: String
    let items: [MenuItem]
}

struct ReviewItem: Identifiable {
    let id = UUID()
    let name: String
    let date: String
    let text: String
    let stars: Int
    let avatarColor: Color
}

struct Business: Identifiable {
    let id = UUID()
    let name: String
    let district: String
    let address: String
    let hoursNow: String
    let desc: String
    let bannerColors: [Color]
    let rating: Double
    let reviewCount: Int
    let tags: [String]
    let menu: [MenuCategory]
    let reviews: [ReviewItem]
    let lat: Double
    let lon: Double

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }
}

// ─── UserProfile ──────────────────────────────────────────────────────────
struct UserProfile {
    var nombre: String
    var email: String
    var avatarId: Int

    var nombreCorto: String {
        let parts = nombre.trimmingCharacters(in: .whitespaces).components(separatedBy: " ")
        guard parts.count > 1 else { return parts[0] }
        return "\(parts[0]) \(String(parts[1].prefix(1)))."
    }

    static var saludo: String {
        let hour = Calendar.current.component(.hour, from: Date())
        if hour < 12 { return "Buenos días" }
        if hour < 19 { return "Buenas tardes" }
        return "Buenas noches"
    }

    // 16 combinaciones: 8 iconos × colores del sistema Seillo.
    // avatarId 0-15 — cada par (icono, color) es único y reconocible.
    static let avatarOptions: [(icon: String, color: Color)] = [
        // Fila 1 — Accent (naranja)
        ("bolt.fill",           .seilAccent),
        ("flame.fill",          .seilAccent),
        // Fila 2 — Blue (azul)
        ("star.fill",           .seilBlue),
        ("moon.fill",           .seilBlue),
        // Fila 3 — Green (verde)
        ("leaf.fill",           .seilGreen),
        ("heart.fill",          .seilGreen),
        // Fila 4 — Gold (dorado)
        ("crown.fill",          .seilGold),
        ("trophy.fill",         .seilGold),
        // Fila 5 — Purple (morado)
        ("sparkles",            .seilPurple),
        ("music.note",          .seilPurple),
        // Fila 6 — Rose (rosa)
        ("pawprint.fill",       .seilRose),
        ("gamecontroller.fill", .seilRose),
        // Fila 7 — Accent2 (naranja claro)
        ("camera.fill",         .seilAccent2),
        ("paintbrush.fill",     .seilAccent2),
        // Fila 8 — seilGold oscuro (ámbar)
        ("book.fill",           Color(hex: "#D4A843")),
        ("bicycle",             Color(hex: "#D4A843")),
    ]

    var avatarColor: Color { UserProfile.avatarOptions[avatarId % UserProfile.avatarOptions.count].color }
    var avatarIcon:  String { UserProfile.avatarOptions[avatarId % UserProfile.avatarOptions.count].icon }
}

// ─── Notification ─────────────────────────────────────────────────────────
struct NotificationItem: Identifiable {
    let id = UUID()
    let title: String
    let body: String
    let time: String
    let icon: String
    let color: Color
    var isRead: Bool
}

// ─── Level System ─────────────────────────────────────────────────────────
struct UserLevel {
    let name: String
    let icon: String
    let color: Color
    let minSellos: Int
    let nextSellos: Int

    static let levels: [UserLevel] = [
        UserLevel(name: "Nuevo",   icon: "flag.fill",             color: Color.seilMuted2, minSellos: 0,   nextSellos: 20),
        UserLevel(name: "Regular", icon: "flame.fill",            color: Color.seilBlue, minSellos: 20,  nextSellos: 50),
        UserLevel(name: "Fiel",    icon: "rosette",               color: .seilAccent,           minSellos: 50,  nextSellos: 100),
        UserLevel(name: "VIP",     icon: "diamond.fill",          color: .seilGold,             minSellos: 100, nextSellos: 200),
        UserLevel(name: "Leyenda", icon: "medal.fill",            color: Color.seilPurple, minSellos: 200, nextSellos: 200),
    ]

    static func level(for sellos: Int) -> UserLevel {
        levels.reversed().first { sellos >= $0.minSellos } ?? levels[0]
    }
}

// ─── Business helpers (compatibilidad con vistas) ─────────────────────────
extension Business {
    /// Distancia aproximada (usada en TabCercaView / NearbyBusinessRow)
    var dist: String {
        switch name {
        case "Café Inti":        return "200m"
        case "Pizzería Fuego":   return "1.2km"
        case "Barbería Rey":     return "3.4km"
        case "Juguería Verde":   return "800m"
        case "Brasa Real":       return "2.1km"
        case "El Marino Ceviche": return "1.8km"
        case "La Lucha Criolla": return "3.1km"
        default:                 return "—"
        }
    }
}

// ─── UserProfile helpers ──────────────────────────────────────────────────
extension UserProfile {
    /// Primer nombre para el saludo en HomeView
    var firstName: String {
        nombre.components(separatedBy: " ").first ?? nombre
    }
}

// ─── NotificationItem iconColor alias ────────────────────────────────────
extension NotificationItem {
    var iconColor: Color { color }
}

// ─── HistoryEntry ─────────────────────────────────────────────────────────────
// Movido desde MockData.swift — es un modelo de dominio, no datos mock.

struct HistoryEntry: Identifiable {
    let id = UUID()
    let bizName:  String
    let action:   String      // "Sello recibido" / "Premio canjeado"
    let date:     String
    let icon:     String
    let color:    Color
    let isReward: Bool
}

// ─── Domain models movidos desde MockData.swift ───────────────────────────────
// Estos son tipos de dominio puro — no contienen datos inventados.

struct CardEntry {
    let business: Business
    let card:     LoyaltyCard
}

struct RachaData {
    let diasActuales:    Int       // racha activa
    let diasRecord:      Int       // mejor racha histórica
    let actividadSemana: [Bool]    // últimos 7 días con/sin actividad
}

struct VisitEntry: Identifiable {
    let id       = UUID()
    let date:    String      // "Hoy, 10:42 am"
    let stamp:   Int         // número de sello recibido (1-based)
    let isReward: Bool       // fue un canje
}

struct ExploreItem: Identifiable {
    let id         = UUID()
    let business:  Business
    let distance:  String
    let isOpen:    Bool
    let hasLoyalty: Bool
}

struct Reward: Identifiable {
    let id:             UUID     = UUID()
    let bizName:        String
    let rewardText:     String
    let expiryDate:     String
    let isReady:        Bool
    let icon:           String
    let color:          Color
    let gradientColors: [Color]
}
