import SwiftUI

// ─── Seillo Identity System ───────────────────────────────────────────────────
//
// Modelos del sistema de identidad de usuario:
//   badges, marcos de perfil y títulos.
//
// El frontend mapea los IDs a estilos visuales (color, icono) localmente
// a través de IdentityCatalog.swift. El backend solo manda IDs y nombres.
//
// Ruta: Seillo/Models/IdentityModels.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Tipo de item de identidad

enum IdentityItemType: String, Codable {
    case event    // otorgado manualmente en eventos especiales
    case earned   // desbloqueado automáticamente por comportamiento
    case seasonal // disponible por tiempo limitado
}

// MARK: - Badge

struct BadgeInfo: Identifiable, Codable, Equatable {
    let id    : String
    let nombre: String
    let tipo  : IdentityItemType
}

// MARK: - Frame

struct FrameInfo: Identifiable, Codable, Equatable {
    let id    : String
    let nombre: String
    let tipo  : IdentityItemType
}

// MARK: - Título

struct TituloInfo: Identifiable, Codable, Equatable {
    let id   : String
    let texto: String
    let tipo : IdentityItemType
}

// MARK: - Identidad completa del usuario (propia)

struct UserIdentity: Equatable {
    var badgesGanados  : [BadgeInfo]  = []
    var badgesVisibles : [String]     = []
    var framesGanados  : [FrameInfo]  = []
    var frameActivo    : String?      = nil
    var titulosGanados : [TituloInfo] = []
    var tituloActivo   : String?      = nil

    var tituloActivoTexto: String? {
        titulosGanados.first { $0.id == tituloActivo }?.texto
    }

    var badgesVisiblesInfo: [BadgeInfo] {
        badgesVisibles.compactMap { visId in
            badgesGanados.first { $0.id == visId }
        }
    }

    static let empty = UserIdentity()
}

// MARK: - Identidad pública (perfil de otro usuario)

struct PublicIdentity: Equatable {
    var frameActivo    : String?
    var tituloTexto    : String?
    var badgesVisibles : [BadgeInfo]

    init(
        frameActivo: String? = nil,
        tituloTexto: String? = nil,
        badgesVisibles: [BadgeInfo] = []
    ) {
        self.frameActivo    = frameActivo
        self.tituloTexto    = tituloTexto
        self.badgesVisibles = badgesVisibles
    }
}

// MARK: - Perfil público completo

struct PublicProfile: Identifiable, Equatable {
    let id              : String
    var nombre          : String
    var avatarId        : Int
    var nivel           : String
    var totalSellos     : Int
    var totalTarjetas   : Int
    var totalPremios    : Int
    var tarjetasActivas : [PublicTarjeta]
    var identidad       : PublicIdentity
    var esAmigo         : Bool

    init(
        id: String,
        nombre: String,
        avatarId: Int = 0,
        nivel: String = "Nuevo",
        totalSellos: Int = 0,
        totalTarjetas: Int = 0,
        totalPremios: Int = 0,
        tarjetasActivas: [PublicTarjeta] = [],
        identidad: PublicIdentity = PublicIdentity(),
        esAmigo: Bool = false
    ) {
        self.id              = id
        self.nombre          = nombre
        self.avatarId        = avatarId
        self.nivel           = nivel
        self.totalSellos     = totalSellos
        self.totalTarjetas   = totalTarjetas
        self.totalPremios    = totalPremios
        self.tarjetasActivas = tarjetasActivas
        self.identidad       = identidad
        self.esAmigo         = esAmigo
    }
}

// MARK: - Tarjeta activa en perfil público

struct PublicTarjeta: Identifiable, Equatable {
    let id             : String
    let negocioNombre  : String
    let sellosActuales : Int
    let sellosMeta     : Int
    let categoria      : String

    init(
        id: String = UUID().uuidString,
        negocioNombre: String,
        sellosActuales: Int,
        sellosMeta: Int,
        categoria: String
    ) {
        self.id             = id
        self.negocioNombre  = negocioNombre
        self.sellosActuales = sellosActuales
        self.sellosMeta     = sellosMeta
        self.categoria      = categoria
    }

    var progress: Double {
        guard sellosMeta > 0 else { return 0 }
        return Double(sellosActuales) / Double(sellosMeta)
    }
}

// MARK: - Request para PATCH /api/cliente/identidad

struct UpdateIdentityRequest {
    let frameActivo    : String?
    let tituloActivo   : String?
    let badgesVisibles : [String]?
}
