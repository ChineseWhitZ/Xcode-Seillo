import Foundation

// MARK: - AutomationTipo

enum AutomationTipo: String, CaseIterable, Identifiable {
    case bienvenida         = "BIENVENIDA"
    case recordatorio7d     = "RECORDATORIO_7D"
    case recordatorio15d    = "RECORDATORIO_15D"
    case recordatorio30d    = "RECORDATORIO_30D"
    case premioDesbloqueado = "PREMIO_DESBLOQUEADO"
    case postSello          = "POST_SELLO"
    case cumpleanos         = "CUMPLEANOS"
    case recuperacionDormido = "RECUPERACION_DORMIDO"

    var id: String { rawValue }

    var nombre: String {
        switch self {
        case .bienvenida:          return "Bienvenida automática"
        case .recordatorio7d:      return "Recordatorio a los 7 días"
        case .recordatorio15d:     return "Recordatorio a los 15 días"
        case .recordatorio30d:     return "Recordatorio a los 30 días"
        case .premioDesbloqueado:  return "Premio desbloqueado"
        case .postSello:           return "Agradecimiento post-visita"
        case .cumpleanos:          return "Felicitación de cumpleaños"
        case .recuperacionDormido: return "Recuperación de cliente dormido"
        }
    }

    var descripcion: String {
        switch self {
        case .bienvenida:
            return "Saluda al cliente cuando se registra o escanea por primera vez."
        case .recordatorio7d:
            return "Si el cliente no vuelve en 7 días, se le recuerda que tiene una tarjeta activa."
        case .recordatorio15d:
            return "Reactivación para clientes que llevan 15 días sin visitar."
        case .recordatorio30d:
            return "Último intento de recuperación antes de marcar al cliente como dormido."
        case .premioDesbloqueado:
            return "Notifica al cliente en el momento exacto en que completa su tarjeta."
        case .postSello:
            return "Después de cada sello, muestra el progreso actual e incentiva la próxima visita."
        case .cumpleanos:
            return "Saluda al cliente en su cumpleaños con un mensaje especial."
        case .recuperacionDormido:
            return "Campaña automática para clientes con más de 45 días sin actividad."
        }
    }

    var triggerLabel: String {
        switch self {
        case .bienvenida:          return "Primer escaneo del cliente"
        case .recordatorio7d:      return "7 días sin visita"
        case .recordatorio15d:     return "15 días sin visita"
        case .recordatorio30d:     return "30 días sin visita"
        case .premioDesbloqueado:  return "Cliente completa la tarjeta de sellos"
        case .postSello:           return "Sello registrado"
        case .cumpleanos:          return "Fecha de cumpleaños del cliente"
        case .recuperacionDormido: return "45 días sin visita"
        }
    }

    var accionLabel: String {
        switch self {
        case .bienvenida:          return "Enviar push de bienvenida"
        case .recordatorio7d:      return "Enviar push de recordatorio"
        case .recordatorio15d:     return "Enviar push de reactivación"
        case .recordatorio30d:     return "Enviar push de recuperación"
        case .premioDesbloqueado:  return "Enviar push de premio listo"
        case .postSello:           return "Enviar push con progreso"
        case .cumpleanos:          return "Enviar push de cumpleaños"
        case .recuperacionDormido: return "Enviar push especial + alerta al negocio"
        }
    }

    var icono: String {
        switch self {
        case .bienvenida:          return "hand.wave.fill"
        case .recordatorio7d:      return "bell.badge.fill"
        case .recordatorio15d:     return "bell.badge.fill"
        case .recordatorio30d:     return "bell.slash.fill"
        case .premioDesbloqueado:  return "trophy.fill"
        case .postSello:           return "checkmark.seal.fill"
        case .cumpleanos:          return "birthday.cake.fill"
        case .recuperacionDormido: return "moon.zzz.fill"
        }
    }
}

// MARK: - AutomationRule

struct AutomationRule: Identifiable {
    let id            : String
    let tipo          : AutomationTipo
    var isActive      : Bool

    // Métricas — opcionales hasta que el backend las envíe
    let totalDisparos : Int
    let ultimoDisparo : String?     // ISO 8601 o nil si nunca se ejecutó

    // Helpers de display — vienen del tipo (no del backend)
    var nombre        : String { tipo.nombre }
    var descripcion   : String { tipo.descripcion }
    var triggerLabel  : String { tipo.triggerLabel }
    var accionLabel   : String { tipo.accionLabel }
    var icono         : String { tipo.icono }
}

// MARK: - Mock data

extension AutomationRule {
    /// Lista mock con todos los tipos predefinidos.
    /// Bienvenida y Premio activos por defecto, el resto inactivos.
    /// TODO: reemplazar con respuesta de GET /api/negocio/automatizaciones
    static let defaultRules: [AutomationRule] = AutomationTipo.allCases
        .enumerated()
        .map { index, tipo in
            AutomationRule(
                id            : "mock_\(tipo.rawValue.lowercased())",
                tipo          : tipo,
                isActive      : index == 0 || index == 4,   // bienvenida y premio
                totalDisparos : [47, 8, 0, 0, 12, 0, 0, 0][safe: index] ?? 0,
                ultimoDisparo : index == 0 ? "2025-03-18T14:32:00"
                              : index == 4 ? "2025-03-17T09:15:00"
                              : nil
            )
        }
}

// MARK: - Safe subscript helper

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
