import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// ClientSegment.swift
//
// Ruta: Seillo/Seillo/Models/ClientSegment.swift
//
// Segmentos automáticos calculados desde los datos de cada cliente.
// El cálculo es local — no requiere backend porque los datos de visitas
// ya vienen en el modelo de cliente.
//
// Equivalente a:
//   ClientSegment.kt (com.example.seillo.domain.model)
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - ClientSegment

enum ClientSegment: CaseIterable {
    case nuevo
    case frecuente
    case top
    case enRiesgo
    case inactivo
    case dormido
    case premioPendiente
    case regular

    var label: String {
        switch self {
        case .nuevo:           return "Nuevo"
        case .frecuente:       return "Frecuente"
        case .top:             return "Top"
        case .enRiesgo:        return "En riesgo"
        case .inactivo:        return "Inactivo"
        case .dormido:         return "Dormido"
        case .premioPendiente: return "Premio listo"
        case .regular:         return "Regular"
        }
    }

    var badgeLabel: String {
        switch self {
        case .nuevo:           return "NUEVO"
        case .frecuente:       return "FRECUENTE"
        case .top:             return "TOP"
        case .enRiesgo:        return "EN RIESGO"
        case .inactivo:        return "INACTIVO"
        case .dormido:         return "DORMIDO"
        case .premioPendiente: return "PREMIO LISTO"
        case .regular:         return ""
        }
    }

    var chipLabel: String {
        switch self {
        case .nuevo:           return "Nuevos"
        case .frecuente:       return "Frecuentes"
        case .top:             return "Top"
        case .enRiesgo:        return "En riesgo"
        case .inactivo:        return "Inactivos"
        case .dormido:         return "Dormidos"
        case .premioPendiente: return "Premio listo"
        case .regular:         return "Regulares"
        }
    }

    /// Color visual del badge — se resuelve en la capa UI, no en el dominio.
    var color: Color {
        switch self {
        case .nuevo:           return .seilGreen
        case .frecuente:       return .seilBlue
        case .top:             return .seilGold
        case .enRiesgo:        return .seilGold.opacity(0.85)
        case .inactivo:        return .seilRose.opacity(0.85)
        case .dormido:         return .seilDanger
        case .premioPendiente: return .seilGold
        case .regular:         return .seilMuted2
        }
    }

    /// Si `true`, el segmento se muestra como badge en la fila del cliente.
    var showsBadge: Bool {
        switch self {
        case .regular, .frecuente: return false
        default:                   return true
        }
    }
}

// MARK: - Cálculo de segmento

extension BizClient {
    /// Calcula el segmento del cliente a partir de sus datos locales.
    /// Prioridad: NUEVO > PREMIO > TOP > DORMIDO > INACTIVO > EN RIESGO > FRECUENTE > REGULAR
    var segment: ClientSegment {
        // 1. Nuevo — primera visita hace < 7 días
        if let dias = diasDesdePrimeraVisita, dias < 7 {
            return .nuevo
        }
        // 2. Premio pendiente — tarjeta completa
        if isComplete {
            return .premioPendiente
        }
        // 3. Top — 3 o más canjes históricos
        if totalCanjes >= 3 {
            return .top
        }
        // 4. Sin última visita registrada
        guard let diasUltima = diasDesdeUltimaVisita else {
            return .regular
        }
        // 5. Dormido — más de 30 días
        if diasUltima > 30 { return .dormido }
        // 6. Inactivo — entre 15 y 30 días
        if diasUltima >= 15 { return .inactivo }
        // 7. En riesgo — entre 8 y 14 días
        if diasUltima >= 8 { return .enRiesgo }
        // 8. Frecuente — visitó en los últimos 7 días
        return .frecuente
    }
}

// MARK: - Conteo por segmento

extension Array where Element == BizClient {
    func contarPorSegmento() -> [ClientSegment: Int] {
        Dictionary(grouping: self, by: \.segment).mapValues(\.count)
    }
}
