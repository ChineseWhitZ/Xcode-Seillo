import SwiftUI
import Combine

// ─── Campaign ─────────────────────────────────────────────────────────────────
//
// Modelo de campanas de negocio (sellos dobles, happy hour, oferta especial).
// Fuente unica de verdad — BizCampaignsView NO redefine estos tipos.
//
// Ruta: Seillo/Models/Campaign.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - CampaignType

enum CampaignType: String, CaseIterable, Identifiable, Codable {
    case doubleStamps = "doubleStamps"
    case happyHour    = "happyHour"
    case specialOffer = "specialOffer"

    var id: String { rawValue }

    var label: String {
        switch self {
        case .doubleStamps: return "Doble sellos"
        case .happyHour:    return "Happy hour"
        case .specialOffer: return "Promocion especial"
        }
    }
    var subtitle: String {
        switch self {
        case .doubleStamps: return "Tus clientes ganan 2 sellos por visita"
        case .happyHour:    return "Sellos extra en un horario especifico"
        case .specialOffer: return "Comunicado libre para tus clientes"
        }
    }
    var icon: String {
        switch self {
        case .doubleStamps: return "star.circle.fill"
        case .happyHour:    return "clock.fill"
        case .specialOffer: return "megaphone.fill"
        }
    }
    var color: Color {
        switch self {
        case .doubleStamps: return .seilAccent
        case .happyHour:    return .seilGold
        case .specialOffer: return .seilBlue
        }
    }
}

// MARK: - CampaignStatus

enum CampaignStatus: String, Codable {
    case active    = "active"
    case paused    = "paused"
    case scheduled = "scheduled"
    case expired   = "expired"

    var label: String {
        switch self {
        case .active:    return "Activa"
        case .paused:    return "Pausada"
        case .scheduled: return "Programada"
        case .expired:   return "Vencida"
        }
    }
    var color: Color {
        switch self {
        case .active:    return .seilGreen
        case .paused:    return Color.seilText.opacity(0.60)
        case .scheduled: return .seilGold
        case .expired:   return .seilRose
        }
    }
}

// MARK: - Campaign

class Campaign: Identifiable, ObservableObject {
    let id: String
    let type: CampaignType
    let title: String
    let description: String
    let startDate: Date
    let endDate: Date
    @Published var status: CampaignStatus
    var programaId: String?
    var programaNombre: String?

    init(id: String, type: CampaignType, title: String,
         description: String, startDate: Date, endDate: Date,
         status: CampaignStatus = .active,
         programaId: String? = nil, programaNombre: String? = nil) {
        self.id              = id
        self.type            = type
        self.title           = title
        self.description     = description
        self.startDate       = startDate
        self.endDate         = endDate
        self.status          = status
        self.programaId      = programaId
        self.programaNombre  = programaNombre
    }

    var isActive: Bool { status == .active }
    var daysLeft: Int  { Calendar.current.dateComponents([.day], from: Date(), to: endDate).day ?? 0 }
}

// MARK: - Helper

func daysFromNow(_ d: Int) -> Date {
    Calendar.current.date(byAdding: .day, value: d, to: .now) ?? .now
}
