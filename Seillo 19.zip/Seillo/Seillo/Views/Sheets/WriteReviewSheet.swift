import SwiftUI

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - WriteReviewSheet
// ═══════════════════════════════════════════════════════════════════════════════
//
// Solo se muestra si card.filledStamps > 0.
// El badge "Reseña verificada" es el diferenciador clave de Sello.

private enum ReviewStep { case form, success }

struct WriteReviewSheet: View {
    let card: LoyaltyCard
    var onSubmit: ((Int, String) -> Void)? = nil

    @Environment(\.dismiss) private var dismiss
    @State private var step:    ReviewStep = .form
    @State private var stars:   Int        = 0
    @State private var text:    String     = ""
    @State private var sending: Bool       = false

    var body: some View {
        ZStack {
            Color.seilSurface.ignoresSafeArea()

            Group {
                switch step {
                case .form:    formView
                case .success: successView
                }
            }
            .transition(.opacity.combined(with: .scale(scale: 0.97)))
            .animation(.easeOut(duration: 0.3), value: step)
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MARK: Form
    // ═══════════════════════════════════════════════════════════════════════

    private var formView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {

                // Handle
                Capsule()
                    .fill(Color.seilBorder)
                    .frame(width: 36, height: 4)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 12)
                    .padding(.bottom, 22)

                // ── Cabecera del negocio ─────────────────────────────
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(card.stampColor.opacity(0.12))
                            .frame(width: 48, height: 48)
                        Image(systemName: card.icon)
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundColor(card.stampColor)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text(card.bizName)
                            .font(.system(size: 17, weight: .heavy, design: .rounded))
                            .foregroundColor(.seilText)

                        // Badge verificado — clave diferenciadora de Sello
                        HStack(spacing: 5) {
                            ZStack {
                                Circle()
                                    .fill(Color.seilGreen.opacity(0.15))
                                    .frame(width: 14, height: 14)
                                Image(systemName: "checkmark")
                                    .font(.system(size: 7, weight: .heavy))
                                    .foregroundColor(.seilGreen)
                            }
                            Text("Reseña verificada · \(card.filledStamps) sello\(card.filledStamps != 1 ? "s" : "") acumulado\(card.filledStamps != 1 ? "s" : "")")
                                .font(SeillFont.caption(11))
                                .foregroundColor(.seilMuted2)
                        }
                    }

                    Spacer()
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 28)

                // ── Selector de estrellas ────────────────────────────
                VStack(spacing: 10) {
                    HStack(spacing: 10) {
                        ForEach(1...5, id: \.self) { i in
                            Button {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(SeillAnimation.chrome) {
                                    stars = i
                                }
                            } label: {
                                Image(systemName: i <= stars ? "star.fill" : "star")
                                    .font(.system(size: i <= stars ? 42 : 36))
                                    .foregroundColor(i <= stars ? .seilGold : Color.seilBorder)
                                    .scaleEffect(i <= stars ? 1.0 : 0.92)
                                    .animation(SeillAnimation.buttonPress, value: stars)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    // Texto descriptivo según estrellas
                    Text(starHint)
                        .font(.system(size: 13, weight: stars > 0 ? .bold : .regular, design: .rounded))
                        .foregroundColor(stars > 0 ? .seilText : .seilMuted)
                        .animation(.easeOut(duration: 0.18), value: stars)
                }
                .frame(maxWidth: .infinity)
                .padding(.bottom, 26)

                // ── Campo de texto ───────────────────────────────────
                ZStack(alignment: .topLeading) {
                    TextEditor(text: $text)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilText)
                        .scrollContentBackground(.hidden)
                        .frame(minHeight: 110)
                        .padding(14)

                    if text.isEmpty {
                        Text("Cuéntales a otros clientes tu experiencia...")
                            .font(SeillFont.body(13))
                            .foregroundColor(.seilMuted)
                            .padding(.top, 22)
                            .padding(.leading, 18)
                            .allowsHitTesting(false)
                    }

                    // Contador de caracteres
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            Text("\(text.count)/300")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(.seilMuted)
                                .padding(.trailing, 14)
                                .padding(.bottom, 10)
                        }
                    }
                }
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.seilBorder, lineWidth: 1)
                )
                .onChange(of: text) { _, new in
                    if new.count > 300 { text = String(new.prefix(300)) }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 16)

                // ── Info verificación ────────────────────────────────
                HStack(spacing: 10) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 14))
                        .foregroundColor(.seilGreen)

                    Text("Solo clientes con sellos en este local pueden reseñar")
                        .font(SeillFont.caption(11))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(2)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.seilGreen.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .stroke(Color.seilGreen.opacity(0.15), lineWidth: 1)
                )
                .padding(.horizontal, 16)
                .padding(.bottom, 22)

                // ── Botón publicar ───────────────────────────────────
                Button {
                    guard canSend else { return }
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    sending = true

                    Task {
                        do {
                            try await APIClient.shared.post(
                                "api/negocios/\(card.negocioId)/resenas",
                                body: CrearResenaRequest(estrellas: stars, texto: text)
                            )
                        } catch { }
                        await MainActor.run {
                            sending = false
                            onSubmit?(stars, text)
                            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                            withAnimation { step = .success }
                        }
                    }
                } label: {
                    Group {
                        if sending {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                .scaleEffect(0.9)
                        } else {
                            Text("Publicar reseña")
                                .font(SeillFont.headline(15))
                        }
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        canSend
                            ? Color.seilAccent
                            : Color.seilAccent.opacity(0.25)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(
                        color: canSend ? Color.seilAccent.opacity(0.35) : .clear,
                        radius: 14, y: 6
                    )
                }
                .buttonStyle(.plain)
                .disabled(!canSend)
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MARK: Success
    // ═══════════════════════════════════════════════════════════════════════

    private var successView: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .padding(.top, 12)

            Spacer()

            // Ícono animado
            ZStack {
                Circle()
                    .fill(Color.seilGold.opacity(0.12))
                    .frame(width: 80, height: 80)
                    .overlay(
                        Circle().stroke(Color.seilGold.opacity(0.28), lineWidth: 1.5)
                    )
                Image(systemName: "star.fill")
                    .font(.system(size: 34))
                    .foregroundColor(.seilGold)
            }

            Spacer().frame(height: 20)

            Text("¡Gracias por tu reseña!")
                .font(.system(size: 20, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)

            Spacer().frame(height: 8)

            Text("Tu opinión ayuda a otros clientes\na descubrir este local.")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .lineSpacing(3)

            // Estrellas dadas
            HStack(spacing: 6) {
                ForEach(1...5, id: \.self) { i in
                    Image(systemName: i <= stars ? "star.fill" : "star")
                        .font(.system(size: 18))
                        .foregroundColor(i <= stars ? .seilGold : Color.seilBorder)
                }
            }
            .padding(.top, 20)

            Spacer()

            Button { dismiss() } label: {
                Text("Listo")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 20)
            .padding(.bottom, 32)
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private var canSend: Bool { stars > 0 && !sending }

    private var starHint: String {
        switch stars {
        case 0: return "Toca una estrella para calificar"
        case 1: return "Muy malo"
        case 2: return "Malo"
        case 3: return "Regular"
        case 4: return "Bueno"
        default: return "Excelente"
        }
    }
}
