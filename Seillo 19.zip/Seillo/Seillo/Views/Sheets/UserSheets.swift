import SwiftUI
import CoreImage
import CoreImage.CIFilterBuiltins

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - QRSheetView
// ═══════════════════════════════════════════════════════════════════════════════

struct QRSheetView: View {
    @Environment(\.dismiss) var dismiss

    // Tarjetas actuales del usuario — usadas para detectar sellos nuevos
    var currentCards: [LoyaltyCard] = []
    // Callback cuando el negocio escanea y acredita un sello
    var onStampReceived: ((LoyaltyCard, Int) -> Void)? = nil

    @State private var secondsLeft   = 300
    // MEDIO: antes usaba Timer.scheduledTimer mezclado con async/await.
    // Ahora el countdown corre en un Task estructurado — un único lugar
    // de control, cancelable automáticamente con .onDisappear.
    @State private var countdownTask: Task<Void, Never>? = nil
    @State private var pollingTask:   Task<Void, Never>? = nil  // detecta sellos nuevos
    @State private var qrCode        = ""
    @State private var expired       = false
    @State private var isLoading     = true

    private let service: ClientServiceProtocol = APIClientService()

    private var progress: Double { Double(secondsLeft) / 300.0 }
    private var timerColor: Color {
        if expired           { return .seilRose }
        if secondsLeft <= 30 { return .seilRose }
        if secondsLeft <= 60 { return .seilGold }
        return .seilGreen
    }
    private var timeLabel: String {
        if expired { return "Expirado" }
        let m = secondsLeft / 60
        let s = secondsLeft % 60
        return String(format: "%02d:%02d", m, s)
    }

    // En iPad el QR puede ser más grande — se ve mejor a distancia en mostrador
    private var qrSize: CGFloat { isIPad ? 290 : 236 }

    var body: some View {
        SeillSheetBox {
            VStack(spacing: 0) {
                Capsule().fill(Color.seilBorder).frame(width: 36, height: 4).padding(.top, 12)
                Spacer().frame(height: 22)

                Text("Mi código QR")
                    .font(SeillFont.title(20)).foregroundColor(.seilText)
                Spacer().frame(height: 5)
                Text("Muéstraselo al negocio para recibir tu sello")
                    .font(SeillFont.body(12)).foregroundColor(.seilMuted2)

                Spacer().frame(height: 28)

                // ── QR + ring ────────────────────────────────────────────
                ZStack {
                    // Countdown ring
                    Circle()
                        .stroke(timerColor.opacity(0.12), lineWidth: 3.5)
                        .frame(width: qrSize, height: qrSize)
                    Circle()
                        .trim(from: 0, to: progress)
                        .stroke(timerColor, style: StrokeStyle(lineWidth: 3.5, lineCap: .round))
                        .frame(width: qrSize, height: qrSize)
                        .rotationEffect(.degrees(-90))
                        .animation(.linear(duration: 1), value: secondsLeft)
                    // Timer badge
                    VStack {
                        HStack {
                            Spacer()
                            HStack(spacing: 5) {
                                Circle().fill(timerColor).frame(width: 6, height: 6)
                                Text(timeLabel)
                                    .font(.system(size: 11, weight: .heavy)).foregroundColor(timerColor)
                            }
                            .padding(.horizontal, 10).padding(.vertical, 5)
                            .background(timerColor.opacity(0.15))
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(timerColor.opacity(0.4), lineWidth: 1))
                        }
                        Spacer()
                    }
                    .frame(width: qrSize - 16, height: qrSize - 16)

                    // QR box
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(.white)
                            .frame(width: qrSize - 18, height: qrSize - 18)
                            .shadow(color: timerColor.opacity(0.2), radius: 28, y: 4)

                        if isLoading {
                            // ALTO: antes isLoading existía pero el ZStack
                            // mostraba QRCodeView(content: "") — un QR vacío.
                            // Ahora muestra un placeholder con shimmer.
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.seilCard)
                                .frame(width: qrSize - 48, height: qrSize - 48)
                                .shimmer()
                        } else if expired {
                            VStack(spacing: 10) {
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 32)).foregroundColor(.seilRose)
                                Text("QR expirado")
                                    .font(SeillFont.headline(14)).foregroundColor(.seilRose)
                                Text("Toca \"Renovar\" para\ngenerar uno nuevo")
                                    .font(.system(size: 11)).foregroundColor(.gray).multilineTextAlignment(.center)
                            }
                        } else {
                            QRCodeView(content: qrCode)
                        }
                    }
                }
                // MEDIO: el ring animado es decorativo pero VoiceOver
                // lo exploraba como elemento interactivo sin descripción.
                // accessibilityElement(children: .ignore) lo oculta y
                // accessibilityLabel describe el estado de forma útil.
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(
                    expired
                        ? "QR expirado. Toca Renovar para generar uno nuevo."
                        : isLoading
                            ? "Generando código QR"
                            : "Código QR activo. Tiempo restante: \(timeLabel)"
                )
                .accessibilityValue(expired ? "" : "\(Int(progress * 100)) por ciento del tiempo restante")

                Spacer().frame(height: 20)

                if !expired {
                    HStack(spacing: 6) {
                        Image(systemName: "fingerprint").font(.system(size: 12)).foregroundColor(.seilMuted)
                        Text(String(qrCode.prefix(8)).uppercased())
                            .font(.system(size: 11, weight: .semibold, design: .monospaced))
                            .foregroundColor(.seilMuted2)
                            .tracking(1.2)
                    }
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.seilBorder, lineWidth: 1))

                    Spacer().frame(height: 14)
                }

                if expired {
                    Button { renewQR() } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "arrow.clockwise").font(.system(size: 16, weight: .semibold))
                            Text("Renovar QR").font(SeillFont.headline(15))
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 32).padding(.vertical, 14)
                        .background(Color.seilAccent)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .shadow(color: Color.seilAccent.opacity(0.45), radius: 14, y: 4)
                    }
                    .buttonStyle(.plain)
                } else {
                    Text(secondsLeft <= 30
                         ? "Renueva pronto para no perder el sello"
                         : "Este QR se renueva automáticamente al expirar")
                        .font(.system(size: 11))
                        .foregroundColor(secondsLeft <= 30 ? timerColor : .seilMuted)
                        .multilineTextAlignment(.center)
                        .animation(.easeOut, value: secondsLeft)
                }

                Spacer().frame(height: 20)
            }
        }
        .task {
            await loadQR()
            startCountdown()
            startStampPolling()
        }
        .onDisappear {
            countdownTask?.cancel()
            pollingTask?.cancel()
        }
    }

    private func startCountdown() {
        countdownTask?.cancel()
        countdownTask = Task {
            while secondsLeft > 0 {
                // Task.sleep lanza CancellationError si el Task es cancelado
                // (p.ej. al cerrar el sheet) — el guard lo captura limpiamente.
                do {
                    try await Task.sleep(for: .seconds(1))
                } catch {
                    return  // Task cancelado — salir sin tocar estado
                }
                guard !Task.isCancelled else { return }
                secondsLeft -= 1
            }
            expired = true
        }
    }

    private func renewQR() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        Task {
            await loadQR()
            secondsLeft = 300
            expired     = false
            startCountdown()
        }
    }

    private func loadQR() async {
        if case .success(let code) = await service.getQR() {
            qrCode = code
        }
        isLoading = false
    }

    // ── Polling de sellos ────────────────────────────────────────────────────
    // El backend escribe sellos_actuales en la misma transacción del escaneo,
    // así que GET /api/cliente/tarjetas devuelve el valor actualizado de inmediato.
    // Polling cada 3s es suficiente — latencia percibida < 3s en el caso normal.
    //
    // No usamos FCM porque la app nunca registra su token (falta integración
    // Firebase en el target iOS). Cuando se integre, este polling puede eliminarse.
    private func startStampPolling() {
        guard !currentCards.isEmpty else { return }

        // Snapshot: id → filledStamps en el momento de abrir el QR
        let snapshot = Dictionary(
            uniqueKeysWithValues: currentCards.map { ($0.id, $0.filledStamps) }
        )

        pollingTask?.cancel()
        pollingTask = Task {
            while !Task.isCancelled && !expired {
                do {
                    try await Task.sleep(for: .seconds(3))
                } catch {
                    return // cancelado al cerrar sheet
                }
                guard !Task.isCancelled else { return }

                if case .success(let fresh) = await service.getTarjetas() {
                    for card in fresh {
                        let prev = snapshot[card.id] ?? 0
                        if card.filledStamps > prev {
                            // Sello confirmado por el backend
                            Haptics.success()
                            let newIndex = card.filledStamps - 1
                            onStampReceived?(card, newIndex)
                            dismiss()
                            return
                        }
                    }
                }
            }
        }
    }
}

// Mock QR visual usando Path
// MARK: - QRCodeView — generación real con CoreImage

/// Genera un QR escaneable a partir de un string.
/// Usa `CIFilter(name: "CIQRCodeGenerator")` — nativo de iOS, sin dependencias.
/// El resultado es blanco/negro puro escalado con interpolación `none`
/// para que los módulos queden nítidos (sin blur).

struct QRCodeView: View {
    let content: String
    var size   : CGFloat = 180

    var body: some View {
        if let img = generateQR(from: content, size: size) {
            Image(uiImage: img)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
                .frame(width: size, height: size)
                .clipShape(RoundedRectangle(cornerRadius: 8))
        } else {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.white)
                .frame(width: size, height: size)
                .overlay(
                    Text("QR\nerror")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                )
        }
    }

    private func generateQR(from string: String, size: CGFloat) -> UIImage? {
        guard
            let data   = string.data(using: .utf8),
            let filter = CIFilter(name: "CIQRCodeGenerator")
        else { return nil }

        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M",  forKey: "inputCorrectionLevel")

        guard let ciImage = filter.outputImage else { return nil }

        let scaleX = size / ciImage.extent.width
        let scaleY = size / ciImage.extent.height
        let scaled = ciImage.transformed(by: CGAffineTransform(scaleX: scaleX, y: scaleY))

        let context = CIContext()
        guard let cgImage = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - StampReceivedSheet
// ═══════════════════════════════════════════════════════════════════════════════

struct StampReceivedSheet: View {
    let card: LoyaltyCard
    let newStampIndex: Int
    @Environment(\.dismiss) var dismiss

    @State private var circleScale:    CGFloat = 0
    @State private var contentOpacity: Double  = 0
    @State private var glowIntensity:  Double  = 0.25
    @State private var counter = 0
    @State private var burstProgress:  CGFloat = 0   // 0→1 en 680ms, keyframed

    private var isRewardReady: Bool { newStampIndex + 1 >= card.totalStamps }
    private var color: Color { isRewardReady ? .seilGold : card.stampColor }
    private var remaining: Int { card.totalStamps - (newStampIndex + 1) }

    var body: some View {
        ZStack {
            Color(hex: "#0F0C0A").ignoresSafeArea()  // negro cálido intencional — diferente de seilBg

            // Confetti (simplified)
            ConfettiOverlay()

            // Burst de partículas al impacto (16 puntos radiales)
            BurstOverlay(progress: burstProgress, color: color)

            VStack(spacing: 0) {
                Capsule().fill(Color.seilBorder).frame(width: 40, height: 4)
                    .padding(.top, 12).padding(.bottom, 24)

                // Main circle
                ZStack {
                    Circle()
                        .fill(color.opacity(glowIntensity * 0.45))
                        .frame(width: 130, height: 130)

                    Circle()
                        .fill(color.opacity(0.12))
                        .frame(width: 106, height: 106)
                        .overlay(Circle().stroke(color.opacity(0.45), lineWidth: 2.5))

                    if isRewardReady {
                        Image(systemName: "trophy.fill")
                            .font(.system(size: 46)).foregroundColor(.seilGold)
                    } else {
                        VStack(spacing: 2) {
                            Text("\(counter)")
                                .font(.system(size: 42, weight: .heavy))
                                .foregroundColor(color)
                                .lineLimit(1)
                                .contentTransition(.numericText(countsDown: false))
                                .animation(SeillAnimation.chrome, value: counter)
                            Text("de \(card.totalStamps)").font(.system(size: 11)).foregroundColor(.seilMuted)
                        }
                    }
                }
                .scaleEffect(circleScale)

                Spacer().frame(height: 18)

                Text(isRewardReady ? "¡Premio completo!" : "¡Sello recibido!")
                    .font(.system(size: 22, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .opacity(contentOpacity)

                Spacer().frame(height: 6)

                Text(isRewardReady
                     ? "Completaste tu tarjeta de \(card.bizName).\n¡Ve a Premios para canjearlo!"
                     : "En \(card.bizName).\n\(remaining == 1 ? "¡Solo falta 1 sello más!" : "Faltan \(remaining) sellos para tu premio.")")
                    .font(SeillFont.body(13)).foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center).lineSpacing(3)
                    .padding(.horizontal, 32)
                    .opacity(contentOpacity)

                Spacer().frame(height: 22)

                // Mini card
                VStack(alignment: .leading, spacing: 10) {
                    Text(card.bizName).font(SeillFont.headline(13)).foregroundColor(.white)
                    StampReceivedRow(card: card, newStampIndex: newStampIndex, accentColor: color)
                }
                .padding(14)
                .background(LinearGradient(colors: card.gradientColors, startPoint: .topLeading, endPoint: .bottomTrailing))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
                .padding(.horizontal, 24)
                .opacity(contentOpacity)

                Spacer().frame(height: 22)

                Button { dismiss() } label: {
                    Text(isRewardReady ? "Ver mi premio" : "¡Genial!")
                        .font(SeillFont.headline(15)).foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding(.vertical, 15)
                        .background(color).clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 28)
                .opacity(contentOpacity)

                Spacer().frame(height: 8)
            }
        }
        .task {
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
            // Burst scale con keyframes: 0 → 1.08 → 0.96 → 1.00
            withAnimation(SeillAnimation.screenTransition.delay(0.1)) { circleScale = 1.08 }
            // Burst de partículas — dispara al mismo tiempo que el impacto
            withAnimation(.easeOut(duration: 0.68).delay(0.1)) { burstProgress = 1.0 }
            try? await Task.sleep(nanoseconds: 400_000_000)
            withAnimation(.easeOut(duration: 0.12)) { circleScale = 0.96 }
            try? await Task.sleep(nanoseconds: 120_000_000)
            withAnimation(SeillAnimation.chrome) { circleScale = 1.00 }

            withAnimation(.easeOut(duration: 0.4)) { contentOpacity = 1 }

            // U-3 fix: incrementamos el contador paso a paso en vez de
            // asignar el valor final de golpe (los Int no interpolan con withAnimation).
            let target = newStampIndex + 1
            for step in 1...max(1, target) {
                try? await Task.sleep(nanoseconds: UInt64(300_000_000 / max(1, target)))
                counter = step
            }

            // Haptic al settle
            try? await Task.sleep(nanoseconds: 180_000_000)
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()

            // Glow pulsante asimétrico (sube rápido, baja lento — como Android keyframes)
            await runGlowPulse()
        }
    }

    private func runGlowPulse() async {
        while !Task.isCancelled {
            withAnimation(.easeOut(duration: 0.55)) { glowIntensity = 0.85 }
            try? await Task.sleep(nanoseconds: 900_000_000)
            withAnimation(.easeIn(duration: 0.90)) { glowIntensity = 0.25 }
            try? await Task.sleep(nanoseconds: 1_300_000_000)
        }
    }
}

// ─── BurstOverlay ─────────────────────────────────────────────────────────────
// 16 puntos que radian desde el centro al momento del impacto del sello.
// Simula las físicas de Android: easing inicial snap, pull-back, settle.
private struct BurstOverlay: View {
    let progress: CGFloat
    let color:    Color

    var body: some View {
        GeometryReader { geo in
            let cx = geo.size.width  / 2
            let cy = geo.size.height * 0.30   // centrado sobre el círculo

            Canvas { ctx, size in
                guard progress > 0 && progress < 1 else { return }

                let eased  = 1 - pow(1 - Double(progress), 2.5)  // easeOut fuerte
                let maxR   = min(size.width, size.height) * 0.44
                let alpha  = Double(1 - progress)

                for i in 0..<16 {
                    let angle  = Double(i) / 16.0 * .pi * 2
                    // Radios distintos por mod 3 — igual que Android
                    let dist   = eased * maxR * (0.70 + Double(i % 3) * 0.15)
                    let px     = cx + CGFloat(cos(angle) * dist)
                    let py     = cy + CGFloat(sin(angle) * dist)
                    let radius = CGFloat((1 - progress) * 6 + 1.5)

                    ctx.fill(
                        Path(ellipseIn: CGRect(
                            x: px - radius, y: py - radius,
                            width: radius * 2, height: radius * 2
                        )),
                        with: .color(color.opacity(alpha))
                    )
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// ─── StampReceivedRow ─────────────────────────────────────────────────────────
// Igual que StampsRowView pero destaca el sello recién recibido (newStampIndex).
private struct StampReceivedRow: View {
    let card:          LoyaltyCard
    let newStampIndex: Int
    let accentColor:   Color

    private let total: Int
    init(card: LoyaltyCard, newStampIndex: Int, accentColor: Color) {
        self.card          = card
        self.newStampIndex = newStampIndex
        self.accentColor   = accentColor
        self.total         = min(card.totalStamps, 10)
    }

    var body: some View {
        HStack(spacing: 5) {
            ForEach(0..<total, id: \.self) { i in
                let filled  = i < newStampIndex + 1
                let isNew   = i == newStampIndex
                StampDot(
                    filled:      filled,
                    isNew:       isNew,
                    accentColor: accentColor
                )
            }
        }
    }
}

private struct StampDot: View {
    let filled:      Bool
    let isNew:       Bool
    let accentColor: Color

    @State private var appeared = false

    var body: some View {
        ZStack {
            Circle()
                .fill(
                    isNew   ? accentColor.opacity(0.30) :
                    filled  ? accentColor.opacity(0.18) :
                              Color.white.opacity(0.04)
                )
                .overlay(
                    Circle().stroke(
                        isNew   ? accentColor.opacity(0.80) :
                        filled  ? accentColor.opacity(0.50) :
                                  Color.white.opacity(0.12),
                        lineWidth: isNew ? 1.8 : 1.2
                    )
                )

            if filled {
                Image(systemName: "checkmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(accentColor)
            }
        }
        .frame(width: 24, height: 24)
        .scaleEffect(appeared ? 1 : (isNew ? 0 : 0.85))
        .onAppear {
            withAnimation(
                .spring(response: 0.40, dampingFraction: isNew ? 0.55 : 0.72)
                    .delay(isNew ? 0.28 : 0.05 * Double(filled ? 1 : 0))
            ) {
                appeared = true
            }
        }
    }
}

// ─── Confetti con física real ─────────────────────────────────────────────────
// Cada pieza tiene: posición X, velocidad, rotación, oscilación lateral, forma.
// El Canvas dibuja todo en un solo pass — sin SwiftUI views individuales.

private struct ConfettiPiece {
    let x:        CGFloat   // posición X normalizada 0-1
    let delay:    Double    // fracción de progreso en que empieza 0-0.4
    let speed:    CGFloat   // multiplicador de velocidad 0.6-1.4
    let rotation: Double    // rotación inicial en radianes
    let rotSpeed: Double    // velocidad de rotación
    let color:    Color
    let size:     CGFloat
    let isRect:   Bool      // true = rectángulo plano, false = círculo
    let phase:    Double    // fase de la oscilación lateral (seno)
}

// Pre-generamos las piezas una sola vez (seed fija para reproducibilidad)
private let confettiPieces: [ConfettiPiece] = {
    let colors: [Color] = [.seilAccent, .seilGold, .seilBlue,
                            .seilGreen, .seilPurple, .seilRose]  // antes: Color(hex:) inline
    var pieces: [ConfettiPiece] = []
    // Usamos índices como seed determinista
    for i in 0..<60 {
        let fi = Double(i)
        pieces.append(ConfettiPiece(
            x:        CGFloat((fi * 0.618033).truncatingRemainder(dividingBy: 1.0)),
            delay:    (fi * 0.0137).truncatingRemainder(dividingBy: 0.40),
            speed:    CGFloat(0.6 + (fi * 0.0731).truncatingRemainder(dividingBy: 0.8)),
            rotation: (fi * 1.309).truncatingRemainder(dividingBy: .pi * 2),
            rotSpeed: 2.0 + (fi * 0.317).truncatingRemainder(dividingBy: 4.0),
            color:    colors[i % colors.count],
            size:     CGFloat(5 + (fi * 0.413).truncatingRemainder(dividingBy: 7)),
            isRect:   i % 3 == 0,
            phase:    (fi * 0.719).truncatingRemainder(dividingBy: .pi * 2)
        ))
    }
    return pieces
}()

struct ConfettiOverlay: View {
    // progress 0→1 a lo largo de ~2.8s
    @State private var progress: Double = 0

    var body: some View {
        TimelineView(.animation) { tl in
            Canvas { ctx, size in
                guard progress > 0 && progress < 1 else { return }
                for p in confettiPieces {
                    let t = max(0, (progress - p.delay) / (1.0 - p.delay))
                    guard t > 0 else { continue }
                    let eased  = 1 - pow(1 - t, 2)          // easeOut cuadrático
                    let py     = -20 + eased * (size.height + 40) * Double(p.speed)
                    // Oscilación sinusoidal lateral — cada pieza tiene fase distinta
                    let swing  = sin(t * .pi * 3.5 + p.phase) * 28.0
                    let px     = Double(p.x) * Double(size.width) + swing
                    // Fade-out en el último 30% del recorrido
                    let opacity: Double = t < 0.70 ? 1.0 : (1.0 - (t - 0.70) / 0.30)
                    guard opacity > 0 else { continue }
                    _ = (p.rotation + t * p.rotSpeed) * (180 / .pi)

                    var transform = CGAffineTransform(translationX: px, y: py)
                    transform = transform.rotated(by: CGFloat(p.rotation + t * p.rotSpeed))

                    let color = p.color.opacity(opacity)
                    if p.isRect {
                        let rect = CGRect(x: -p.size / 2, y: -p.size / 4,
                                          width: p.size, height: p.size * 0.5)
                        var path = Path(rect)
                        path = path.applying(transform)
                        ctx.fill(path, with: .color(color))
                    } else {
                        let center = CGPoint(x: px, y: py)
                        ctx.fill(Path(ellipseIn: CGRect(
                            x: center.x - p.size/2, y: center.y - p.size/2,
                            width: p.size, height: p.size
                        )), with: .color(color))
                    }
                }
            }
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeOut(duration: 2.8).delay(0.15)) {
                progress = 1.0
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - RedeemSheetView
// ═══════════════════════════════════════════════════════════════════════════════
//
// Lote 3: Flujo de canje mejorado (3 pasos como Android):
//   LOADING  → pide token al backend
//   QR       → muestra QR con token + confetti + icono de celebración
//   ERROR    → si el token falla, muestra error con retry
//
// El negocio escanea el QR para validar el canje. Solo puede usarse una vez.
// ─────────────────────────────────────────────────────────────────────────────

private enum RedeemStep { case loading, qr, error }

struct RedeemSheetView: View {
    let card: LoyaltyCard
    @Environment(\.dismiss) var dismiss

    @State private var step:       RedeemStep = .loading
    @State private var canjeToken  = ""
    @State private var errorMsg    = ""
    @State private var pulseScale: CGFloat = 1
    @State private var showConfetti = false

    var body: some View {
        ZStack {
            // ALTO: antes era Color(hex: "#0F0C0A") hardcodeado —
            // rompía el theme y no respondía a cambios de apariencia.
            Color.seilBg.ignoresSafeArea()

            // ── Confetti overlay ────────────────────────────────
            if showConfetti {
                ConfettiOverlay()
                    .allowsHitTesting(false)
            }

            Group {
                switch step {
                case .loading: loadingContent
                case .qr:      qrContent
                case .error:   errorContent
                }
            }
            .transition(.opacity)
            .animation(.easeOut(duration: 0.3), value: step)
        }
        .task {
            await fetchCanjeToken()
        }
    }

    // ── Loading ─────────────────────────────────────────────────────────────
    private var loadingContent: some View {
        VStack(spacing: 20) {
            Spacer()
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: .seilGreen))
                .scaleEffect(1.4)
            Text("Preparando tu premio...")
                .font(SeillFont.headline(14))
                .foregroundColor(.seilMuted2)
            Spacer()
        }
    }

    // ── QR con token real ───────────────────────────────────────────────────
    private var qrContent: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                handle

                Spacer().frame(height: 16)

                // Icono celebración con pulse
                ZStack {
                    Circle()
                        .fill(Color.seilGreen.opacity(0.12))
                        .frame(width: 72, height: 72)
                        .overlay(
                            Circle().stroke(Color.seilGreen.opacity(0.4), lineWidth: 2)
                        )
                        .scaleEffect(pulseScale)

                    Image(systemName: "trophy.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.seilGreen)
                }
                .onAppear {
                    withAnimation(
                        .easeInOut(duration: 1.8)
                        .repeatForever(autoreverses: true)
                    ) {
                        pulseScale = 1.04
                    }
                }

                Spacer().frame(height: 12)

                Text("¡Premio listo!")
                    .font(SeillFont.display(22))
                    .foregroundColor(.seilText)

                Spacer().frame(height: 4)

                Text(card.rewardText)
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .fontWeight(.medium)

                Spacer().frame(height: 20)

                // ── QR Box ────────────────────────────────────────
                VStack(spacing: 16) {
                    Text("MUESTRA ESTE QR AL NEGOCIO")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.2)

                    // QR generado con CoreImage
                    QRCodeView(content: canjeToken, size: 200)

                    // Token truncado
                    if canjeToken.count > 12 {
                        Text("Token: \(String(canjeToken.prefix(8)))...\(String(canjeToken.suffix(4)))")
                            .font(.system(size: 10))
                            .foregroundColor(.seilMuted.opacity(0.5))
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(Color.seilGreen.opacity(0.3), lineWidth: 1)
                )
                .padding(.horizontal, 24)

                Spacer().frame(height: 16)

                // Info box
                HStack(spacing: 8) {
                    Image(systemName: "info.circle.fill")
                        .font(.system(size: 13))
                        .foregroundColor(.seilGreen.opacity(0.7))

                    Text("El negocio escaneará este QR para validar tu premio. Solo puede usarse una vez.")
                        .font(SeillFont.caption(10))
                        .foregroundColor(.seilMuted2)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.seilGreen.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.seilGreen.opacity(0.2), lineWidth: 1)
                )
                .padding(.horizontal, 24)

                Spacer().frame(height: 24)

                // Botón Listo
                Button {
                    Haptics.success()
                    dismiss()
                } label: {
                    Text("Listo")
                        .font(SeillFont.headline(15))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.seilGreen)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: Color.seilGreen.opacity(0.4), radius: 12, y: 4)
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 24)

                Spacer().frame(height: 24)
            }
        }
    }

    // ── Error ───────────────────────────────────────────────────────────────
    private var errorContent: some View {
        VStack(spacing: 0) {
            handle

            Spacer()

            ZStack {
                Circle()
                    .fill(Color.seilDanger.opacity(0.10))
                    .frame(width: 72, height: 72)
                Image(systemName: "exclamationmark.circle")
                    .font(.system(size: 36))
                    .foregroundColor(.seilDanger)
            }

            Spacer().frame(height: 16)

            Text("No se pudo obtener el premio")
                .font(SeillFont.title(16))
                .foregroundColor(.seilText)

            Spacer().frame(height: 8)

            Text(errorMsg)
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)

            Spacer().frame(height: 24)

            // Reintentar
            Button {
                Haptics.tap()
                Task { await fetchCanjeToken() }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold))
                    Text("Reintentar")
                        .font(SeillFont.label(14))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 24)

            Spacer().frame(height: 12)

            Button {
                dismiss()
            } label: {
                Text("Cerrar")
                    .font(SeillFont.label(13))
                    .foregroundColor(.seilMuted)
            }

            Spacer()
        }
    }

    private var handle: some View {
        Capsule().fill(Color.seilBorder).frame(width: 36, height: 4).padding(.top, 12)
    }

    // ── Fetch token real desde el backend ────────────────────────────────────
    private func fetchCanjeToken() async {
        withAnimation { step = .loading }
        let result = await APIClientService().getCanjeToken(tarjetaId: card.id)
        switch result {
        case .success(let token):
            canjeToken = token
            Haptics.success()
            withAnimation(.easeOut(duration: 0.3)) { step = .qr }
            withAnimation { showConfetti = true }
        case .failure(let error):
            errorMsg = error.localizedDescription
            withAnimation { step = .error }
        }
    }
}
