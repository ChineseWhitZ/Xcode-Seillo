import SwiftUI

// MARK: - UpgradeModal

struct UpgradeModal: View {

    let result    : GateResult
    let onUpgrade : () -> Void
    let onDismiss : () -> Void

    /// Sobreescribe el título si se quiere un mensaje distinto ("Límite alcanzado", etc.)
    var titulo: String? = nil

    @State private var iconScale: CGFloat = 0.4

    private var accentColor: Color {
        planColor(for: result.requiredTier ?? .starter)
    }

    private var planLabel: String {
        switch result.requiredTier {
        case .starter:    return "Starter"
        case .growth:     return "Growth"
        case .pro:        return "Pro"
        case .enterprise: return "Enterprise"
        default:          return "superior"
        }
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.55).ignoresSafeArea()
                .onTapGesture { onDismiss() }

            VStack(spacing: 0) {
                Spacer()

                VStack(spacing: 22) {

                    // ── Ícono animado ─────────────────────────────────────────
                    ZStack {
                        Circle()
                            .fill(accentColor.opacity(0.15))
                            .frame(width: 72, height: 72)
                            .overlay(Circle().stroke(accentColor.opacity(0.30), lineWidth: 1.5))
                        Image(systemName: "lock.fill")
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(accentColor)
                    }
                    .scaleEffect(iconScale)
                    .onAppear {
                        withAnimation(.interpolatingSpring(stiffness: 220, damping: 18).delay(0.05)) {
                            iconScale = 1.0
                        }
                    }

                    // ── Título ────────────────────────────────────────────────
                    Text(titulo ?? "Disponible en el plan \(planLabel)")
                        .font(SeillFont.display(20))
                        .foregroundColor(.seilText)
                        .multilineTextAlignment(.center)

                    // ── Mensaje ───────────────────────────────────────────────
                    if !result.upgradeMessage.isEmpty {
                        Text(result.upgradeMessage)
                            .font(SeillFont.body(14))
                            .foregroundColor(.seilMuted2)
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    // ── Badge del plan requerido ──────────────────────────────
                    Text("Plan \(planLabel)")
                        .font(SeillFont.label(12))
                        .foregroundColor(accentColor)
                        .padding(.horizontal, 14).padding(.vertical, 6)
                        .background(accentColor.opacity(0.14))
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(accentColor.opacity(0.30), lineWidth: 1))

                    // ── Botones ───────────────────────────────────────────────
                    VStack(spacing: 10) {
                        Button {
                            Haptics.success()
                            onUpgrade()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "bolt.fill")
                                    .font(.system(size: 14, weight: .semibold))
                                Text("Ver planes")
                                    .font(SeillFont.headline(15))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(
                                LinearGradient(
                                    colors: [accentColor, accentColor.opacity(0.80)],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .shadow(color: accentColor.opacity(0.35), radius: 10, y: 3)
                        }
                        .buttonStyle(.plain)

                        Button {
                            Haptics.tap()
                            onDismiss()
                        } label: {
                            Text("Ahora no")
                                .font(SeillFont.label(14))
                                .foregroundColor(.seilMuted2)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 13)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 28)
                .padding(.top, 32)
                .padding(.bottom, 28)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 28))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.seilBorder, lineWidth: 1))
                .padding(.horizontal, 20)
                .padding(.bottom, 32)
            }
        }
    }
}

// MARK: - UpgradeBanner

/// Banner inline para mostrar dentro de listas/pantallas con features bloqueados.
/// Más compacto que UpgradeModal — no interrumpe el flujo.
struct UpgradeBanner: View {

    let mensaje     : String
    let planLabel   : String
    let accentColor : Color
    let onUpgrade   : () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "lock.fill")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(accentColor)

            VStack(alignment: .leading, spacing: 3) {
                Text("Disponible en \(planLabel)")
                    .font(SeillFont.label(12))
                    .foregroundColor(accentColor)
                Text(mensaje)
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer()

            Button {
                Haptics.tap()
                onUpgrade()
            } label: {
                Text("Upgrade")
                    .font(SeillFont.label(12))
                    .foregroundColor(accentColor)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(accentColor.opacity(0.14))
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .background(accentColor.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(accentColor.opacity(0.20), lineWidth: 1))
    }
}
