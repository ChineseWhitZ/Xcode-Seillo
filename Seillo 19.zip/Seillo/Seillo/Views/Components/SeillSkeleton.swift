import SwiftUI

// ─── Seillo Skeleton System ───────────────────────────────────────────────────
//
// Componentes de skeleton loading con shimmer animation.
// Mejora la percepción de velocidad mientras la data carga.
//
// Correcciones v2:
//   · ShimmerModifier usa GeometryReader para escalar el offset al ancho
//     real del view — el valor mágico de 300pt no escalaba en iPad ni en
//     elementos muy anchos o muy estrechos.
//   · Los primitivos aplican clipShape DESPUÉS de .shimmer() para que el
//     gradiente no escape los bordes redondeados.
//
// Uso:
//   SkeletonRect(width: 120, height: 16)
//   CardSkeleton()
//   ListRowSkeleton()
//
// Ruta: Seillo/Views/Components/SeillSkeleton.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Shimmer Modifier

struct ShimmerModifier: ViewModifier {
    @State private var phase: CGFloat = 0

    func body(content: Content) -> some View {
        content
            .overlay(
                GeometryReader { geometry in
                    // Gradiente 2× ancho del view — entra y sale limpio
                    // sin cortes en los extremos.
                    LinearGradient(
                        colors: [
                            .clear,
                            Color.white.opacity(0.07),
                            Color.white.opacity(0.13),
                            Color.white.opacity(0.07),
                            .clear,
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .frame(width: geometry.size.width * 2)
                    // phase 0 → empieza fuera a la izquierda
                    // phase 1 → termina fuera a la derecha
                    .offset(x: -geometry.size.width + phase * geometry.size.width * 2)
                    .clipped()
                }
                .allowsHitTesting(false)
            )
            .onAppear {
                phase = 0
                withAnimation(
                    .linear(duration: SeillDuration.shimmer)
                    .repeatForever(autoreverses: false)
                ) {
                    phase = 1
                }
            }
    }
}

extension View {
    func shimmer() -> some View {
        modifier(ShimmerModifier())
    }
}

// MARK: - Primitives

/// Rectángulo skeleton con shimmer correctamente recortado al cornerRadius.
/// clipShape se aplica después de .shimmer() para que el gradiente
/// no escape los bordes redondeados.
struct SkeletonRect: View {
    let width: CGFloat?
    let height: CGFloat
    var cornerRadius: CGFloat = 8

    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .fill(Color.seilCard2)
            .frame(width: width, height: height)
            .shimmer()
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
    }
}

/// Círculo skeleton con shimmer correctamente recortado a la circunferencia.
struct SkeletonCircle: View {
    let size: CGFloat

    var body: some View {
        Circle()
            .fill(Color.seilCard2)
            .frame(width: size, height: size)
            .shimmer()
            .clipShape(Circle())
    }
}

// MARK: - Card Skeleton

/// Esqueleto de una LoyaltyCard para TabCardsView
struct CardSkeleton: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 12) {
                SkeletonCircle(size: 36)
                VStack(alignment: .leading, spacing: 6) {
                    SkeletonRect(width: 140, height: 14)
                    SkeletonRect(width: 90, height: 10)
                }
                Spacer()
                SkeletonRect(width: 50, height: 24, cornerRadius: 12)
            }
            .padding(16)

            // Stamps row placeholder
            HStack(spacing: 6) {
                ForEach(0..<8, id: \.self) { _ in
                    SkeletonCircle(size: 28)
                }
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)

            // Progress bar
            SkeletonRect(width: nil, height: 4, cornerRadius: 2)
                .padding(.horizontal, 16)
                .padding(.bottom, 16)
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

// MARK: - List Row Skeleton

/// Esqueleto de una fila de lista genérica
struct ListRowSkeleton: View {
    var showAvatar: Bool = true
    var lineCount: Int = 2

    var body: some View {
        HStack(spacing: 12) {
            if showAvatar {
                SkeletonCircle(size: 40)
            }
            VStack(alignment: .leading, spacing: 8) {
                SkeletonRect(width: 160, height: 13)
                if lineCount > 1 {
                    SkeletonRect(width: 100, height: 10)
                }
            }
            Spacer()
            SkeletonRect(width: 44, height: 13)
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 16)
    }
}

// MARK: - Stat Badges Skeleton

/// Esqueleto para las métricas de perfil (sellos, tarjetas, premios)
struct StatBadgesSkeleton: View {
    var body: some View {
        HStack(spacing: 10) {
            ForEach(0..<3, id: \.self) { _ in
                VStack(spacing: 8) {
                    SkeletonCircle(size: 16)
                    SkeletonRect(width: 30, height: 18, cornerRadius: 4)
                    SkeletonRect(width: 50, height: 9, cornerRadius: 4)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Color.seilBorder, lineWidth: 1)
                )
            }
        }
    }
}

// MARK: - Dashboard Metric Skeleton

/// Esqueleto para las métricas del dashboard de negocio
struct MetricCardSkeleton: View {
    var body: some View {
        VStack(spacing: 8) {
            SkeletonRect(width: 36, height: 22, cornerRadius: 6)
            SkeletonRect(width: 52, height: 10, cornerRadius: 4)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

// MARK: - Full Screen Skeleton

/// Esqueleto de pantalla completa con varias cards
struct FullScreenSkeleton: View {
    var cardCount: Int = 3

    var body: some View {
        VStack(spacing: 14) {
            ForEach(0..<cardCount, id: \.self) { _ in
                CardSkeleton()
            }
        }
        .padding(.horizontal, 16)
    }
}
