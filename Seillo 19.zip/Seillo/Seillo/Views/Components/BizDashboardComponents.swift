import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// BizDashboardComponents.swift
//
// Ruta: Seillo/Seillo/Views/Components/BizDashboardComponents.swift
//
// Componentes de la pestaña Dashboard del negocio:
//   · OnboardingChecklist — guía de primeros pasos, se oculta al llegar a 100%
//   · PlanUsageCard       — uso del plan: clientes / locales vs límite
//
// Equivalente a:
//   OnboardingChecklist.kt + PlanUsageCard.kt (com.example.seillo.ui.components)
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - ChecklistDestino

enum ChecklistDestino {
    case crearLocal
    case crearTarjeta
    case configurarRecompensa
    case activarQr
    case invitarStaff
}

// MARK: - ChecklistItem

private struct ChecklistItem {
    let titulo    : String
    let subtitulo : String
    let completado: Bool
    let destino   : ChecklistDestino
}

private func buildChecklistItems(_ sub: BusinessSubscription) -> [ChecklistItem] {
    var items: [ChecklistItem] = [
        ChecklistItem(
            titulo    : "Crear tu local",
            subtitulo : "Define el nombre y dirección de tu negocio",
            completado: sub.creoLocal,
            destino   : .crearLocal
        ),
        ChecklistItem(
            titulo    : "Crear tu primera tarjeta",
            subtitulo : "Configura tu programa de sellos",
            completado: sub.creoTarjeta,
            destino   : .crearTarjeta
        ),
        ChecklistItem(
            titulo    : "Configurar la recompensa",
            subtitulo : "Define qué gana el cliente al completar la tarjeta",
            completado: sub.configuroRecompensa,
            destino   : .configurarRecompensa
        ),
        ChecklistItem(
            titulo    : "Activar el QR",
            subtitulo : "Genera el código que tus clientes van a escanear",
            completado: sub.activoQr,
            destino   : .activarQr
        ),
    ]
    if sub.plan.tieneStaff {
        items.append(ChecklistItem(
            titulo    : "Invitar a tu equipo",
            subtitulo : "Agrega staff para operar desde distintos turnos",
            completado: sub.invitóStaff,
            destino   : .invitarStaff
        ))
    }
    return items
}

// MARK: - OnboardingChecklist

/// Card de primeros pasos del negocio.
/// Se oculta automáticamente cuando `subscription.progresoOnboarding >= 1.0`.
struct OnboardingChecklist: View {

    let subscription: BusinessSubscription
    let onNavigate  : (ChecklistDestino) -> Void

    @State private var animProgress: Double = 0

    private var progreso: Double { subscription.progresoOnboarding }

    var body: some View {
        // No mostrar si ya completó todo
        if progreso >= 1.0 { return AnyView(EmptyView()) }

        let items       = buildChecklistItems(subscription)
        let completados = items.filter(\.completado).count
        let total       = items.count

        return AnyView(
            VStack(alignment: .leading, spacing: 16) {

                // ── Header ────────────────────────────────────────────────
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Primeros pasos")
                            .font(SeillFont.headline(15))
                            .foregroundColor(.seilText)
                        Text("\(completados) de \(total) completados")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                    }
                    Spacer()
                    ChecklistProgressBadge(progreso: progreso, animated: animProgress)
                }

                // ── Barra de progreso ─────────────────────────────────────
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.seilBorder)
                            .frame(height: 6)
                        Capsule()
                            .fill(Color.seilGreen)
                            .frame(width: geo.size.width * animProgress, height: 6)
                    }
                }
                .frame(height: 6)
                .animation(.easeOut(duration: 0.7), value: animProgress)

                // ── Items ─────────────────────────────────────────────────
                VStack(spacing: 10) {
                    ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                        ChecklistRow(item: item) {
                            if !item.completado { onNavigate(item.destino) }
                        }
                    }
                }
            }
            .padding(18)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.seilBorder, lineWidth: 1))
            .onAppear {
                withAnimation(.easeOut(duration: 0.7).delay(0.15)) {
                    animProgress = progreso
                }
            }
            .onChange(of: progreso) { _, new in
                withAnimation(.easeOut(duration: 0.5)) { animProgress = new }
            }
        )
    }
}

// MARK: - ChecklistRow

private struct ChecklistRow: View {
    let item   : ChecklistItem
    let onTap  : () -> Void

    var body: some View {
        Button(action: { Haptics.tap(); onTap() }) {
            HStack(spacing: 12) {
                Image(systemName: item.completado ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(item.completado ? .seilGreen : .seilMuted.opacity(0.5))

                VStack(alignment: .leading, spacing: 2) {
                    Text(item.titulo)
                        .font(SeillFont.label(13))
                        .foregroundColor(item.completado ? .seilMuted2 : .seilText)
                        .strikethrough(item.completado, color: .seilMuted)
                    if !item.subtitulo.isEmpty && !item.completado {
                        Text(item.subtitulo)
                            .font(SeillFont.body(11))
                            .foregroundColor(.seilMuted)
                    }
                }

                Spacer()

                if !item.completado {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.seilMuted)
                }
            }
            .padding(.vertical, 2)
            .opacity(item.completado ? 0.55 : 1.0)
        }
        .buttonStyle(.plain)
        .disabled(item.completado)
    }
}

// MARK: - ChecklistProgressBadge

private struct ChecklistProgressBadge: View {
    let progreso : Double
    let animated : Double

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.seilBorder, lineWidth: 3)
                .frame(width: 44, height: 44)
            Circle()
                .trim(from: 0, to: animated)
                .stroke(Color.seilGreen, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                .frame(width: 44, height: 44)
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.7).delay(0.15), value: animated)
            Text("\(Int(progreso * 100))%")
                .font(.system(size: 10, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)
        }
    }
}

// MARK: - PlanUsageCard

/// Card de uso del plan SaaS — muestra clientes y locales usados vs límite.
/// Incluye alerta cuando se llega al 80 % del límite.
struct PlanUsageCard: View {

    let subscription: BusinessSubscription
    let onUpgrade   : () -> Void

    @State private var animClientes: Double = 0
    @State private var animLocales : Double = 0

    private var plan     : SubscriptionPlan { subscription.plan }
    private var hayAlerta: Bool { subscription.cercaLimiteClientes || subscription.cercaLimiteLocales }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {

            // ── Header: plan actual ───────────────────────────────────────
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Tu plan")
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted2)
                    Text(plan.nombre)
                        .font(SeillFont.headline(16))
                        .foregroundColor(plan.color)
                }

                Spacer()

                if plan.tier != .enterprise {
                    Button {
                        Haptics.tap()
                        onUpgrade()
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: "bolt.fill")
                                .font(.system(size: 11, weight: .semibold))
                            Text("Upgrade")
                                .font(SeillFont.label(12))
                        }
                        .foregroundColor(plan.color)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(plan.color.opacity(0.13))
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(plan.color.opacity(0.28), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }

            Divider().background(Color.seilBorder)

            // ── Métricas de uso ───────────────────────────────────────────
            VStack(spacing: 12) {
                UsageRow(
                    icon       : "person.2.fill",
                    label      : "Clientes",
                    valor      : subscription.textoLimiteClientes(),
                    progress   : animClientes,
                    color      : subscription.cercaLimiteClientes ? .seilDanger : plan.color,
                    esIlimitado: plan.maxClientes <= 0
                )
                UsageRow(
                    icon       : "mappin.circle.fill",
                    label      : "Locales",
                    valor      : subscription.textoLimiteLocales(),
                    progress   : animLocales,
                    color      : subscription.cercaLimiteLocales ? .seilDanger : plan.color,
                    esIlimitado: plan.maxLocales <= 0
                )
            }

            // ── Alerta de límite próximo ──────────────────────────────────
            if hayAlerta {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 13))
                        .foregroundColor(.seilDanger)
                    Text(alertMessage)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilDanger)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 12).padding(.vertical, 10)
                .background(Color.seilDanger.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.seilDanger.opacity(0.20), lineWidth: 1))
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.seilBorder, lineWidth: 1))
        .onAppear {
            withAnimation(.easeOut(duration: 0.8).delay(0.2)) {
                animClientes = subscription.porcentajeClientes
                animLocales  = subscription.porcentajeLocales
            }
        }
    }

    private var alertMessage: String {
        if subscription.cercaLimiteClientes && subscription.cercaLimiteLocales {
            return "Estás cerca del límite de clientes y locales."
        } else if subscription.cercaLimiteClientes {
            return "Estás cerca del límite de clientes. Considera hacer upgrade."
        } else {
            return "Estás cerca del límite de locales. Considera hacer upgrade."
        }
    }
}

// MARK: - UsageRow

private struct UsageRow: View {
    let icon       : String
    let label      : String
    let valor      : String
    let progress   : Double
    let color      : Color
    let esIlimitado: Bool

    var body: some View {
        VStack(spacing: 6) {
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: icon)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                    Text(label)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                }
                Spacer()
                Text(valor)
                    .font(SeillFont.label(12))
                    .foregroundColor(esIlimitado ? .seilMuted2 : color)
            }

            if !esIlimitado {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.seilBorder)
                            .frame(height: 5)
                        Capsule()
                            .fill(color)
                            .frame(width: geo.size.width * progress, height: 5)
                            .animation(.easeOut(duration: 0.8).delay(0.2), value: progress)
                    }
                }
                .frame(height: 5)
            }
        }
    }
}
