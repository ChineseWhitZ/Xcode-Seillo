import SwiftUI

// ─── Stagger Animation System ─────────────────────────────────────────────────
//
// Helper para animar la entrada escalonada de elementos en listas.
// Equivalente a StaggerItem.kt de Android.
//
// Uso:
//   ForEach(items.indices, id: \.self) { i in
//       ItemView(item: items[i])
//           .staggerIn(index: i, appear: animProgress)
//   }
//
//   // En .onAppear:
//   withAnimation(.easeOut(duration: 0.6)) { animProgress = 1 }
//
// Ruta: Seillo/Views/Components/StaggerItem.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Stagger Modifier

struct StaggerModifier: ViewModifier {
    let index: Int
    let appear: Double
    var offset: CGFloat = 16
    var stagger: Double = 0.08

    /// Calcula la opacidad basada en el progreso global y el índice del item
    private var alpha: Double {
        let start = min(Double(index) * stagger, 0.6)
        let end   = min(start + 0.4, 1.0)
        return max(0, min(1, (appear - start) / (end - start)))
    }

    /// Offset vertical que disminuye conforme alpha aumenta
    private var yOffset: CGFloat {
        offset * CGFloat(1 - alpha)
    }

    func body(content: Content) -> some View {
        content
            .opacity(alpha)
            .offset(y: yOffset)
    }
}

// MARK: - View Extension

extension View {
    /// Aplica animación de entrada escalonada.
    ///
    /// - Parameters:
    ///   - index: Posición del item en la lista (0, 1, 2, ...)
    ///   - appear: Progreso de la animación global (0.0 → 1.0)
    ///   - offset: Distancia vertical de entrada en puntos (default: 16)
    ///   - stagger: Retraso entre items (default: 0.08)
    func staggerIn(
        index: Int,
        appear: Double,
        offset: CGFloat = 16,
        stagger: Double = 0.08
    ) -> some View {
        modifier(StaggerModifier(
            index: index,
            appear: appear,
            offset: offset,
            stagger: stagger
        ))
    }
}

// MARK: - Convenience for sections

extension View {
    /// Stagger para secciones que usan franjas de progreso.
    /// Calcula alpha y offset usando un rango [start, end] dentro del progreso global.
    ///
    /// Uso:
    ///   mySection
    ///       .sectionAppear(progress: enterProgress, start: 0.0, end: 0.4)
    func sectionAppear(progress: Double, start: Double, end: Double) -> some View {
        let alpha = max(0, min(1, (progress - start) / (end - start)))
        let offset = CGFloat(18 * (1 - alpha))
        return self
            .opacity(alpha)
            .offset(y: offset)
    }
}
