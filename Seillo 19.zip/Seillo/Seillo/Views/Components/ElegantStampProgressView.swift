import SwiftUI

struct ElegantStampProgressView: View {
    let card: LoyaltyCard
    /// Índice del sello que recibe LowBouncy (el más nuevo). -1 = todos MediumBouncy.
    var highlightIndex: Int = -1
    @State private var revealed = 0

    var body: some View {
        let columns = Array(
            repeating: GridItem(.flexible(), spacing: 10),
            count: min(card.totalStamps, 5)
        )

        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(0..<card.totalStamps, id: \.self) { index in
                let filled  = index < card.filledStamps
                let isLast  = card.isComplete && index == card.totalStamps - 1
                let isNew   = index == highlightIndex
                // LowBouncy para el sello nuevo, MediumBouncy para el resto
                let response:     Double = isNew ? 0.28 : 0.32
                let damping:      Double = isNew ? 0.50 : 0.62

                ZStack {
                    Circle()
                        .fill(filled ? card.stampColor.opacity(0.16) : Color.white.opacity(0.04))
                        .overlay(
                            Circle()
                                .stroke(
                                    filled ? card.stampColor.opacity(0.95) : Color.white.opacity(0.10),
                                    lineWidth: 1.3
                                )
                        )

                    if filled {
                        Image(systemName: isLast ? "sparkles" : "checkmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(card.stampColor)
                            // Escala extra en el sello nuevo
                            .scaleEffect(isNew && revealed > index ? 1.15 : 1.0)
                            .animation(SeillAnimation.buttonPress.delay(Double(index) * 0.045 + 0.18), value: revealed)
                    } else {
                        Circle()
                            .fill(Color.white.opacity(0.08))
                            .frame(width: 6, height: 6)
                    }
                }
                .frame(height: SeillLayout.stampCellHeight)
                .shadow(
                    color: filled ? card.stampColor.opacity(isNew ? 0.30 : 0.16) : .clear,
                    radius: isNew ? 14 : 8,
                    y: 2
                )
                .scaleEffect(revealed > index ? 1.0 : 0.55)
                .opacity(revealed > index ? 1.0 : 0.0)
                .animation(
                    .spring(response: response, dampingFraction: damping)  // dinámico por diseño — no tokenizable
                        .delay(Double(index) * 0.035),
                    value: revealed
                )
            }
        }
        .task {
            // Task estructurado — se cancela automáticamente si el view desaparece,
            // eliminando la mutación de estado en un view ya descartado que ocurría
            // con DispatchQueue.main.asyncAfter.
            try? await Task.sleep(for: .seconds(0.12))
            revealed = card.totalStamps
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(card.filledStamps) de \(card.totalStamps) sellos completados")
    }
}
