import SwiftUI
import AVFoundation

// ─── QRScannerView ────────────────────────────────────────────────────────────
// UIViewRepresentable que envuelve AVCaptureSession con AVCaptureMetadataOutput.
// Uso:
//   QRScannerView(isActive: $isScanning) { code in
//       // code es el string del QR decodificado
//   }
//
// NOTA: Requiere en Info.plist:
//   NSCameraUsageDescription → "Seillo necesita la cámara para escanear el QR del cliente."
// ─────────────────────────────────────────────────────────────────────────────

struct QRScannerView: UIViewRepresentable {

    /// Controla si la sesión está activa. Poner en false pausa sin destruir la sesión.
    @Binding var isActive: Bool

    /// Callback invocado una sola vez por QR detectado (evita duplicados).
    var onCode: (String) -> Void

    // MARK: - UIViewRepresentable

    func makeUIView(context: Context) -> ScannerPreviewView {
        let view = ScannerPreviewView()
        view.delegate = context.coordinator
        view.setup()
        return view
    }

    func updateUIView(_ uiView: ScannerPreviewView, context: Context) {
        // Siempre rutear start/stop por sessionQueue — misma queue serial que
        // configureSession, evita race condition si updateUIView llega mientras
        // la sesión está entre beginConfiguration y commitConfiguration.
        if isActive {
            uiView.startIfNeeded()
        } else {
            uiView.stopIfNeeded()
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(onCode: onCode)
    }

    // MARK: - Coordinator

    final class Coordinator: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        private let onCode: (String) -> Void
        /// Previene llamadas múltiples por el mismo frame de QR
        private var lastCode: String = ""
        private var cooldown  = false

        init(onCode: @escaping (String) -> Void) {
            self.onCode = onCode
        }

        func metadataOutput(
            _ output: AVCaptureMetadataOutput,
            didOutput metadataObjects: [AVMetadataObject],
            from connection: AVCaptureConnection
        ) {
            guard !cooldown,
                  let obj  = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
                  let code = obj.stringValue,
                  !code.isEmpty,
                  code != lastCode
            else { return }

            lastCode = code
            cooldown = true

            DispatchQueue.main.async {
                UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                self.onCode(code)
            }

            // Resetear cooldown tras 2s para permitir un nuevo escaneo
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
                self?.cooldown  = false
                self?.lastCode  = ""
            }
        }
    }
}

// MARK: - ScannerPreviewView

/// UIView que aloja AVCaptureSession + AVCaptureVideoPreviewLayer.
final class ScannerPreviewView: UIView {

    let session = AVCaptureSession()
    weak var delegate: AVCaptureMetadataOutputObjectsDelegate?

    private var previewLayer: AVCaptureVideoPreviewLayer?
    private let sessionQueue = DispatchQueue(label: "seillo.scanner.session", qos: .userInitiated)

    // MARK: Layout

    override func layoutSubviews() {
        super.layoutSubviews()
        previewLayer?.frame = bounds
    }

    // MARK: Start / Stop

    /// Inicia la sesión en sessionQueue. Seguro llamarlo en cualquier momento.
    func startIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if !self.session.isRunning { self.session.startRunning() }
        }
    }

    /// Detiene la sesión en sessionQueue. Seguro llamarlo en cualquier momento.
    func stopIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    // MARK: Setup

    func setup() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            sessionQueue.async { self.configureSession() }
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted { self.sessionQueue.async { self.configureSession() } }
            }
        default:
            break  // Denegado — la UI muestra el estado de permiso
        }
    }

    private func configureSession() {
        session.beginConfiguration()

        // Input — cámara trasera
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input  = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input)
        else {
            session.commitConfiguration()
            return
        }

        session.addInput(input)

        // Output — metadata QR
        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else {
            session.commitConfiguration()
            return
        }

        session.addOutput(output)
        output.setMetadataObjectsDelegate(delegate, queue: .main)

        // Tipos de códigos a detectar
        output.metadataObjectTypes = [.qr, .ean13, .ean8, .code128, .dataMatrix]

        // NOTA: commitConfiguration DEBE ir antes de startRunning —
        // AVFoundation no permite startRunning entre begin y commit.
        session.commitConfiguration()

        // Preview layer — añadir en main thread
        DispatchQueue.main.async {
            let layer = AVCaptureVideoPreviewLayer(session: self.session)
            layer.videoGravity = .resizeAspectFill
            layer.frame = self.bounds
            self.layer.insertSublayer(layer, at: 0)
            self.previewLayer = layer
        }

        // startRunning fuera del bloque de configuración
        session.startRunning()
    }
}


// ─── QRScannerContainerView ──────────────────────────────────────────────────
// Wrapper listo para usar que incluye: preview real, corners de Seillo,
// overlay de permiso denegado, y estado de detección.
// ─────────────────────────────────────────────────────────────────────────────

struct QRScannerContainerView: View {

    @Binding var isActive: Bool
    var onCode: (String) -> Void

    @State private var permissionStatus: AVAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
    @State private var detected = false

    var body: some View {
        ZStack {
            // ── Background cuando no hay permisos ────────────────────────
            Color.black

            switch permissionStatus {
            case .authorized:
                // ── Preview real ─────────────────────────────────────────
                QRScannerView(isActive: $isActive) { code in
                    guard !detected else { return }
                    detected = true

                    // Flash de confirmación
                    withAnimation(.easeOut(duration: 0.12)) { }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                        onCode(code)
                        // Reset para siguiente escaneo
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            detected = false
                        }
                    }
                }

                // ── Overlay: línea de escaneo ─────────────────────────────
                ScanLineOverlay(detected: detected)

                // ── Overlay: esquinas ─────────────────────────────────────
                ScannerCorners()
                    .padding(32)

                // ── Flash de detección ────────────────────────────────────
                if detected {
                    Color.seilGreen.opacity(0.18)
                        .transition(.opacity)
                }

            case .denied, .restricted:
                PermissionDeniedOverlay()
                    .onTapGesture { openSettings() }

            default:
                // notDetermined — esperando respuesta del sistema
                VStack(spacing: 12) {
                    ProgressView().tint(.white)
                    Text("Solicitando acceso a cámara…")
                        .font(SeillFont.body(12))
                        .foregroundColor(.white.opacity(0.7))
                }
                .onAppear {
                    // Refrescar estado tras la petición del sistema
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        permissionStatus = AVCaptureDevice.authorizationStatus(for: .video)
                    }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .onAppear {
            permissionStatus = AVCaptureDevice.authorizationStatus(for: .video)
        }
    }

    private func openSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }
}

// ─── ScanLineOverlay ──────────────────────────────────────────────────────────

private struct ScanLineOverlay: View {
    let detected: Bool
    @State private var position: CGFloat = 0.1

    var body: some View {
        GeometryReader { geo in
            Rectangle()
                .fill(
                    LinearGradient(
                        colors: [
                            .clear,
                            (detected ? Color.seilGreen : Color.seilAccent).opacity(0.95),
                            .clear
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(height: 2.5)
                .offset(y: position * geo.size.height)
                .animation(
                    detected
                        ? .none
                        : .easeInOut(duration: 1.8).repeatForever(autoreverses: true),
                    value: position
                )
        }
        .onAppear {
            position = 0.9
        }
        .onChange(of: detected) { _, isDetected in
            if !isDetected { position = 0.9 }
        }
    }
}

// ─── PermissionDeniedOverlay ──────────────────────────────────────────────────

private struct PermissionDeniedOverlay: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "camera.fill.badge.ellipsis")
                .font(.system(size: 42))
                .foregroundColor(.white.opacity(0.6))

            VStack(spacing: 6) {
                Text("Cámara desactivada")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.white)

                Text("Seillo necesita acceso a la cámara\npara escanear el QR del cliente.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }

            HStack(spacing: 6) {
                Image(systemName: "gear")
                    .font(.system(size: 12))
                Text("Abrir Ajustes")
                    .font(SeillFont.label(13))
            }
            .foregroundColor(.seilAccent)
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            .background(Color.seilAccent.opacity(0.14))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.seilAccent.opacity(0.3), lineWidth: 1))
        }
        .padding(24)
    }
}
