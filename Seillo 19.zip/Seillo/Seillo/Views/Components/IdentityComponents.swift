import SwiftUI

// ─── IdentityComponents ───────────────────────────────────────────────────────
//
// Componentes reutilizables del sistema de identidad visual:
//   · SeilloAvatarWithFrame — avatar con marco activo (rings, accents, etc.)
//   · SeilloTitlePill       — píldora de título con icono y color
//   · SeilloBadgeChip       — badge individual (normal y mini)
//   · SeilloBadgesRow       — fila de hasta 3 badges
//
// Ruta:   Seillo/Views/Components/IdentityComponents.swift
// Fuente: IdentityCatalog.swift provee los estilos por ID.
//
// Uso:
//   SeilloAvatarWithFrame(avatarId: 3, frameId: "founder", size: 72)
//   SeilloTitlePill(tituloId: "og_member", tituloTexto: "OG Member")
//   SeilloBadgeChip(badge: myBadge)
//   SeilloBadgesRow(badges: user.badgesVisiblesInfo)
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - SeilloAvatarWithFrame

/// Avatar circular con el sistema de marcos de identidad.
/// Soporta: anillo principal, segundo anillo interior, acentos cardinales (Founder),
/// ticks (Leyenda), y colores personalizados de avatar según el frame.
struct SeilloAvatarWithFrame: View {
    let avatarId : Int
    let frameId  : String?
    var size     : CGFloat = 72

    private var avatarOption: (icon: String, color: Color) {
        UserProfile.avatarOptions[avatarId % UserProfile.avatarOptions.count]
    }

    private var frameStyle: FrameStyle? {
        guard let frameId else { return nil }
        return frameStyleFor(frameId)
    }

    private var innerSize: CGFloat { size * 0.83 }

    var body: some View {
        ZStack {
            // ── Frame rings ──────────────────────────────────────
            if let style = frameStyle {
                // Anillo exterior principal
                if let dash = style.dashPattern {
                    Circle()
                        .stroke(style.ringColor, style: StrokeStyle(
                            lineWidth: style.strokeWidth,
                            dash: dash
                        ))
                        .frame(width: size, height: size)
                } else {
                    Circle()
                        .stroke(style.ringColor, lineWidth: style.strokeWidth)
                        .frame(width: size, height: size)
                }

                // Segundo anillo interior (Founder, Backer)
                if let ring2 = style.ringColor2 {
                    Circle()
                        .stroke(ring2.opacity(0.6), lineWidth: 0.5)
                        .frame(width: size * 0.87, height: size * 0.87)
                }

                // Acentos cardinales — diamantes en N/S/E/W (Founder)
                if style.hasAccents {
                    cardinalAccents(color: style.ringColor)
                }

                // Ticks cardinales (Leyenda)
                if style.hasTicks {
                    cardinalTicks(color: style.ringColor)
                }
            }

            // ── Avatar circle ────────────────────────────────────
            let bg = frameStyle?.avatarBg ?? avatarOption.color
            let fg = frameStyle?.avatarFg ?? Color.white

            ZStack {
                Circle()
                    .fill(bg)
                    .frame(width: innerSize, height: innerSize)
                    .shadow(color: bg.opacity(0.35), radius: 10, y: 3)

                Image(systemName: avatarOption.icon)
                    .font(.system(size: innerSize * 0.42))
                    .foregroundColor(fg)
            }
        }
        .frame(width: size, height: size)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Avatar de perfil")
    }

    // MARK: - Cardinal Accents (Founder)

    private func cardinalAccents(color: Color) -> some View {
        let dotSize = size * 0.085

        return ZStack {
            // Top
            Circle().fill(color)
                .frame(width: dotSize, height: dotSize)
                .offset(y: -(size / 2 - dotSize / 2))
            // Bottom
            Circle().fill(color)
                .frame(width: dotSize, height: dotSize)
                .offset(y: size / 2 - dotSize / 2)
            // Left
            Circle().fill(color)
                .frame(width: dotSize, height: dotSize)
                .offset(x: -(size / 2 - dotSize / 2))
            // Right
            Circle().fill(color)
                .frame(width: dotSize, height: dotSize)
                .offset(x: size / 2 - dotSize / 2)
        }
    }

    // MARK: - Cardinal Ticks (Leyenda)

    private func cardinalTicks(color: Color) -> some View {
        let tickLen: CGFloat = size * 0.06
        let radius = size / 2

        return ZStack {
            ForEach([0.0, 90.0, 180.0, 270.0], id: \.self) { angle in
                Rectangle()
                    .fill(color)
                    .frame(width: 1.5, height: tickLen)
                    .offset(y: -(radius - tickLen / 2))
                    .rotationEffect(.degrees(angle))
            }
        }
    }
}

// MARK: - SeilloTitlePill

/// Píldora de título con icono y colores del catálogo.
/// Modes: normal (11sp) y compact (10sp) para uso en filas compactas.
struct SeilloTitlePill: View {
    let tituloId   : String
    let tituloTexto: String
    var compact    : Bool = false

    private var style: TituloStyle { tituloStyleFor(tituloId) }

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: style.icon)
                .font(.system(size: compact ? 9 : 10))

            Text(tituloTexto)
                .font(.system(size: compact ? 10 : 11, weight: .semibold))
        }
        .foregroundColor(style.fg)
        .padding(.horizontal, compact ? 8 : 10)
        .padding(.vertical, compact ? 3 : 4)
        .background(style.bg)
        .clipShape(Capsule())
        .overlay(
            Capsule().stroke(style.stroke.opacity(0.4), lineWidth: 0.5)
        )
    }
}

// MARK: - SeilloBadgeChip

/// Badge individual con icono y colores del catálogo.
/// Soporta estados: normal, selected (borde accent), disabled (opacidad reducida).
struct SeilloBadgeChip: View {
    let badge    : BadgeInfo
    var size     : CGFloat = 48
    var selected : Bool = false
    var disabled : Bool = false

    private var style: BadgeStyle { badgeStyleFor(badge.id) }
    private var alpha: Double { disabled ? 0.38 : 1.0 }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(style.bg.opacity(alpha))
                .frame(width: size, height: size)
                .overlay(
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .stroke(
                            selected ? Color.seilAccent : style.stroke.opacity(alpha),
                            lineWidth: selected ? 1.5 : 0.5
                        )
                )

            Image(systemName: style.icon)
                .font(.system(size: size * 0.42))
                .foregroundColor(style.stroke.opacity(alpha))
        }
        .accessibilityLabel(badge.nombre)
    }
}

// MARK: - SeilloBadgeMini

/// Versión compacta del badge para filas de perfil (28pt).
struct SeilloBadgeMini: View {
    let badge: BadgeInfo

    var body: some View {
        SeilloBadgeChip(badge: badge, size: 28)
    }
}

// MARK: - SeilloBadgesRow

/// Fila horizontal de hasta 3 badges visibles (versión mini).
/// Si la lista está vacía, no renderiza nada.
struct SeilloBadgesRow: View {
    let badges: [BadgeInfo]

    var body: some View {
        if !badges.isEmpty {
            HStack(spacing: 6) {
                ForEach(badges.prefix(3)) { badge in
                    SeilloBadgeMini(badge: badge)
                }
            }
        }
    }
}
