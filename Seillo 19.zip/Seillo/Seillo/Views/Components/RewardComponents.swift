import SwiftUI

struct PremioStatBadge: View {
    let label: String
    let value: String
    let color: Color
    let icon: String

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 14))
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 18, weight: .heavy))
                .foregroundColor(color)

            Text(label)
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(.seilMuted)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

struct RewardCard: View {
    let card: LoyaltyCard
    let buttonTitle: String
    let actionColor: Color
    let action: () -> Void

    @State private var animProgress: Double = 0
    @State private var btnScale: CGFloat = 1

    private var isReady: Bool { card.isComplete }
    private var color: Color { isReady ? .seilGreen : card.stampColor }
    private var remaining: Int { card.totalStamps - card.filledStamps }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(color.opacity(0.12))
                        .frame(width: 44, height: 44)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(color.opacity(0.25), lineWidth: 1)
                        )

                    Image(systemName: isReady ? "gift.fill" : "storefront.fill")
                        .font(.system(size: 18))
                        .foregroundColor(color)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(card.bizName)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.seilText)
                        .lineLimit(1)

                    Text(card.rewardText)
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }

                Spacer()

                if isReady {
                    Text("Listo")
                        .font(.system(size: 10, weight: .black))
                        .foregroundColor(.seilGreen)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.seilGreen.opacity(0.12))
                        .clipShape(Capsule())
                        .overlay(
                            Capsule()
                                .stroke(Color.seilGreen.opacity(0.3), lineWidth: 1)
                        )
                } else {
                    Text("\(card.filledStamps)/\(card.totalStamps)")
                        .font(.system(size: 13, weight: .heavy))
                        .foregroundColor(color)
                }
            }
            .padding(.horizontal, 14)
            .padding(.top, 14)

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 100)
                        .fill(Color.white.opacity(0.06))
                        .frame(height: 5)

                    RoundedRectangle(cornerRadius: 100)
                        .fill(color)
                        .frame(width: geo.size.width * animProgress, height: 5)
                        .animation(.easeOut(duration: 0.9), value: animProgress)
                }
            }
            .frame(height: 5)
            .padding(.horizontal, 14)
            .padding(.top, 12)

            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    if isReady {
                        Text("Ya puedes canjear este premio")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilGreen)
                    } else {
                        Text("Te faltan \(remaining) sellos")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted)
                    }
                }

                Spacer()

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()

                    withAnimation(SeillAnimation.buttonPress) {
                        btnScale = 0.94
                    }

                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                        withAnimation(SeillAnimation.buttonPress) {
                            btnScale = 1
                        }
                        action()
                    }
                } label: {
                    Text(buttonTitle)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(actionColor)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .shadow(
                            color: actionColor.opacity(0.4),
                            radius: 8,
                            y: 2
                        )
                }
                .buttonStyle(.plain)
                .scaleEffect(btnScale)
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 14)
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(isReady ? Color.seilGreen.opacity(0.35) : Color.seilBorder, lineWidth: 1)
        )
        .shadow(color: isReady ? Color.seilGreen.opacity(0.1) : .clear, radius: 14, y: 4)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(card.bizName), \(card.rewardText), \(isReady ? "premio listo para canjear" : "\(remaining) sellos restantes")")
        .accessibilityHint(isReady ? "Toca para canjear" : "Toca para ver detalle")
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
        .onAppear {
            withAnimation(.easeOut(duration: 0.9).delay(0.2)) {
                animProgress = card.progress
            }
        }
    }
}

struct RewardCardStatic: View {
    let card: LoyaltyCard
    let buttonTitle: String
    let actionColor: Color

    @State private var animProgress: Double = 0

    private var remaining: Int { card.totalStamps - card.filledStamps }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(card.stampColor.opacity(0.12))
                        .frame(width: 44, height: 44)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(card.stampColor.opacity(0.25), lineWidth: 1)
                        )

                    Image(systemName: "storefront.fill")
                        .font(.system(size: 18))
                        .foregroundColor(card.stampColor)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(card.bizName)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.seilText)
                        .lineLimit(1)

                    Text(card.rewardText)
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }

                Spacer()

                Text("\(card.filledStamps)/\(card.totalStamps)")
                    .font(.system(size: 13, weight: .heavy))
                    .foregroundColor(card.stampColor)
            }
            .padding(.horizontal, 14)
            .padding(.top, 14)

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 100)
                        .fill(Color.white.opacity(0.06))
                        .frame(height: 5)

                    RoundedRectangle(cornerRadius: 100)
                        .fill(card.stampColor)
                        .frame(width: geo.size.width * animProgress, height: 5)
                        .animation(.easeOut(duration: 0.9), value: animProgress)
                }
            }
            .frame(height: 5)
            .padding(.horizontal, 14)
            .padding(.top, 12)

            HStack {
                Text("Te faltan \(remaining) sellos")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)

                Spacer()

                Text(buttonTitle)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(actionColor)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(
                        color: actionColor.opacity(0.4),
                        radius: 8,
                        y: 2
                    )
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 14)
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
        .onAppear {
            withAnimation(.easeOut(duration: 0.9).delay(0.2)) {
                animProgress = card.progress
            }
        }
    }
}
