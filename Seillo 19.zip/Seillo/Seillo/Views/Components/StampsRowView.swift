import SwiftUI

struct StampsRowView: View {
    let card: LoyaltyCard
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }

    var body: some View {
        let rows = balancedRows(total: card.totalStamps)

        VStack(alignment: .leading, spacing: 10) {
            ForEach(Array(rows.enumerated()), id: \.offset) { rowIndex, count in
                HStack(spacing: 10) {
                    ForEach(0..<count, id: \.self) { i in
                        let absoluteIndex = rows.prefix(rowIndex).reduce(0, +) + i
                        let filled = absoluteIndex < card.filledStamps

                        ZStack {
                            Circle()
                                .fill(filled
                                    ? card.stampColor.opacity(isDark ? 0.16 : 0.18)
                                    : (isDark ? Color.white.opacity(0.04) : card.stampColor.opacity(0.10)))
                                .overlay(
                                    Circle()
                                        .stroke(
                                            filled
                                                ? card.stampColor.opacity(0.95)
                                                : (isDark ? Color.white.opacity(0.12) : card.stampColor.opacity(0.35)),
                                            lineWidth: 1.6
                                        )
                                )

                            if filled {
                                Image(systemName: "checkmark")
                                    .font(.system(size: SeillLayout.stampSize * 0.38, weight: .bold))
                                    .foregroundColor(card.stampColor)
                            }
                        }
                        .frame(width: SeillLayout.stampSize, height: SeillLayout.stampSize)
                        .shadow(
                            color: filled ? card.stampColor.opacity(0.15) : .clear,
                            radius: 6,
                            y: 2
                        )
                    }
                }
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(card.filledStamps) de \(card.totalStamps) sellos completados")
    }

    private func balancedRows(total: Int) -> [Int] {
        guard total > 5 else { return [total] }

        switch total {
        case 6: return [3, 3]
        case 7: return [4, 3]
        case 8: return [4, 4]
        case 9: return [5, 4]
        case 10: return [5, 5]
        default:
            let top = Int(ceil(Double(total) / 2.0))
            let bottom = total - top
            return [top, bottom]
        }
    }
}
