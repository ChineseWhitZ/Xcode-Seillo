import SwiftUI

// ─── FriendsActivityBanner ────────────────────────────────────────────────────
// Módulo inline que muestra la actividad reciente de amigos directamente
// en TabCardsView, entre el section label y las tarjetas.
//
// Comportamiento:
//   • Colapsado: header con avatars apilados + último evento en preview
//   • Expandido: lista de hasta 5 eventos con animación spring
//   • El estado se mantiene durante la sesión (no persiste)
//
// Ruta: Seillo/Views/Components/FriendsActivityBanner.swift
// Uso en TabCardsView: FriendsActivityBanner(listProgress: listProgress)
// ─────────────────────────────────────────────────────────────────────────────

struct FriendsActivityBanner: View {
    let listProgress: Double

    @State private var isExpanded:  Bool = false
    @State private var showFriends: Bool = false
    @State private var activities: [FriendActivity] = []

    private let friendService: FriendServiceProtocol = APIFriendService()

    // Alpha de entrada — mapea la misma franja que usa el section label
    private var entryAlpha: Double {
        ((listProgress - 0.04) / 0.32).clamped(to: 0...1)
    }
    private var entryOffset: CGFloat {
        CGFloat(14 * (1 - entryAlpha))
    }

    var body: some View {
        VStack(spacing: 0) {
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.38, dampingFraction: 0.72)) {
                    isExpanded.toggle()
                }
            } label: {
                headerRow
            }
            .buttonStyle(.plain)

            if isExpanded {
                expandedContent
                    .transition(
                        .asymmetric(
                            insertion: .move(edge: .top).combined(with: .opacity),
                            removal:   .move(edge: .top).combined(with: .opacity)
                        )
                    )
            }
        }
        .padding(.vertical, 14)
        .padding(.horizontal, 16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .opacity(entryAlpha)
        .offset(y: entryOffset)
        .animation(SeillAnimation.listEntrance, value: listProgress)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Actividad de amigos")
        .accessibilityHint(isExpanded ? "Toca para contraer" : "Toca para ver actividad reciente")
        .task {
            // Carga al aparecer el banner — no esperar a que el usuario expanda
            if case .success(let a) = await friendService.getActividadAmigos() {
                activities = a
            }
        }
    }

    // MARK: - Header (siempre visible)

    private var headerRow: some View {
        HStack(spacing: 14) {
            // Avatars apilados de los primeros 3 amigos
            stackedAvatars

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 5) {
                    Text("AMIGOS")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.4)

                    Circle()
                        .fill(Color.seilAccent)
                        .frame(width: 5, height: 5)
                }

                // Último evento en preview
                if let latest = activities.first {
                    previewText(latest)
                }
            }

            Spacer()

            // Chevron con rotación animada
            Image(systemName: "chevron.down")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.seilMuted)
                .rotationEffect(.degrees(isExpanded ? 180 : 0))
                .animation(.spring(response: 0.32, dampingFraction: 0.75), value: isExpanded)
        }
    }

    // MARK: - Avatars apilados

    private var stackedAvatars: some View {
        let friends = Array(activities.prefix(3))
        let overlap: CGFloat = 10
        let size:    CGFloat = 26
        // +4 para que el stroke del último avatar no quede cortado
        let totalWidth = size + CGFloat(friends.count - 1) * (size - overlap) + 4

        return ZStack(alignment: .leading) {
            ForEach(Array(friends.enumerated()), id: \.offset) { i, activity in
                avatarCircle(
                    initial: activity.friendInitial,
                    color:   activity.friendColor,
                    size:    size
                )
                .offset(x: CGFloat(i) * (size - overlap))
                .zIndex(Double(friends.count - i))  // el primero queda encima
            }
        }
        .frame(width: totalWidth, height: size)
    }

    private func avatarCircle(initial: String, color: Color, size: CGFloat) -> some View {
        ZStack {
            Circle()
                .fill(color)
                .frame(width: size, height: size)
                .overlay(Circle().stroke(Color.seilBg, lineWidth: 2))

            Text(initial)
                .font(.system(size: size * 0.40, weight: .heavy))
                .foregroundColor(.white)
        }
    }

    // MARK: - Texto preview (colapsado)

    private func previewText(_ activity: FriendActivity) -> some View {
        HStack(spacing: 4) {
            Text(activity.friendName)
                .font(.system(size: 11, weight: .bold))
                .foregroundColor(.seilText)

            Text(activity.detail)
                .font(.system(size: 11))
                .foregroundColor(.seilMuted)
                .lineLimit(1)

            Spacer(minLength: 0)

            Text(activity.timeAgo)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(.seilMuted)
        }
    }

    // MARK: - Lista expandida

    private var expandedContent: some View {
        VStack(spacing: 0) {
            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
                .padding(.top, 12)
                .padding(.bottom, 0)

            VStack(spacing: 0) {
                ForEach(Array(activities.enumerated()), id: \.element.id) { i, activity in
                    activityRow(activity, isLast: i == activities.count - 1)
                }
            }
            .padding(.top, 4)

            // ── CTA gestionar amigos ───────────────────────────────────
            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
                .padding(.top, 8)

            Button {
                Haptics.tap()
                showFriends = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "person.2.fill")
                        .font(.system(size: 12, weight: .semibold))
                    Text("Gestionar amigos")
                        .font(.system(size: 12, weight: .bold))
                    Spacer()
                    Image(systemName: "arrow.right")
                        .font(.system(size: 11, weight: .semibold))
                }
                .foregroundColor(.seilAccent)
                .padding(.vertical, 12)
            }
            .buttonStyle(.plain)
            .sheet(isPresented: $showFriends) {
                FriendsView()
                    .presentationDragIndicator(.hidden)
                    .presentationBackground(Color.seilBg)
            }
        }
    }

    // MARK: - Fila de evento

    private func activityRow(_ activity: FriendActivity, isLast: Bool) -> some View {
        HStack(alignment: .center, spacing: 10) {

            // Avatar del amigo
            avatarCircle(
                initial: activity.friendInitial,
                color:   activity.friendColor,
                size:    32
            )

            // Texto del evento
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 4) {
                    Text(activity.friendName)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.seilText)

                    Text(activity.detail)
                        .font(.system(size: 12))
                        .foregroundColor(.seilMuted2)
                        .lineLimit(1)
                }

                // Línea secundaria: negocio o nivel
                eventTag(activity)
            }

            Spacer()

            Text(activity.timeAgo)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(.seilMuted)
        }
        .padding(.vertical, 10)
        .overlay(alignment: .bottom) {
            if !isLast {
                Rectangle()
                    .fill(Color.seilBorder.opacity(0.6))
                    .frame(height: 1)
                    .padding(.leading, 42)
            }
        }
    }

    // MARK: - Tag secundario (negocio o nivel)

    @ViewBuilder
    private func eventTag(_ activity: FriendActivity) -> some View {
        switch activity.type {
        case .stamp, .reward:
            if let bizName = activity.bizName,
               let bizIcon = activity.bizIcon,
               let bizColor = activity.bizColor {
                HStack(spacing: 4) {
                    Image(systemName: bizIcon)
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(bizColor)

                    Text(bizName)
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(bizColor)
                }
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(bizColor.opacity(0.10))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(bizColor.opacity(0.20), lineWidth: 1))
            }

        case .levelUp:
            if let levelName = activity.levelName {
                HStack(spacing: 4) {
                    Image(systemName: "diamond.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.seilGold)

                    Text("Nivel \(levelName)")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilGold)
                }
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(Color.seilGold.opacity(0.10))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.seilGold.opacity(0.20), lineWidth: 1))
            }

        case .joined:
            HStack(spacing: 4) {
                Image(systemName: "person.badge.plus")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(.seilAccent)

                Text("Nuevo en Seillo")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.seilAccent)
            }
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .background(Color.seilAccent.opacity(0.10))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.seilAccent.opacity(0.20), lineWidth: 1))
        }
    }
}
