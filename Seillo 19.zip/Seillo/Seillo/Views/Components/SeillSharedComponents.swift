import SwiftUI

// ─── Seillo Shared Components ─────────────────────────────────────────────────
//
// Componentes reutilizables para consistencia visual.
// Complementa los que ya existen en AuthComponents.swift
// (SeillTextField, SeillButton, Haptics, etc.)
//
// Ruta: Seillo/Views/Components/SeillSharedComponents.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Section Header

/// Header de sección con tracking y color muted.
/// Uso: SeillSectionHeader("MI ACTIVIDAD")
///      SeillSectionHeader("CUENTA", trailing: AnyView(Image(...)))
struct SeillSectionHeader: View {
    let title: String
    var trailing: AnyView? = nil

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.2)

            Spacer()

            if let trailing { trailing }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
    }
}

// MARK: - Status Badge

/// Cápsula de estado con color de fondo.
/// Uso: SeillStatusBadge("Activa", color: .seilGreen)
///      SeillStatusBadge("Expirada", color: .seilDanger)
struct SeillStatusBadge: View {
    let text: String
    let color: Color
    var size: BadgeSize = .regular

    enum BadgeSize {
        case small, regular

        var fontSize: CGFloat {
            switch self {
            case .small:   return 9
            case .regular: return 10
            }
        }

        var hPadding: CGFloat {
            switch self {
            case .small:   return 6
            case .regular: return 8
            }
        }

        var vPadding: CGFloat {
            switch self {
            case .small:   return 3
            case .regular: return 4
            }
        }
    }

    var body: some View {
        Text(text)
            .font(.system(size: size.fontSize, weight: .bold))
            .foregroundColor(color)
            .padding(.horizontal, size.hPadding)
            .padding(.vertical, size.vPadding)
            .background(color.opacity(0.12))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(color.opacity(0.25), lineWidth: 1))
    }
}

// MARK: - Surface Card

/// Card con fondo, borde y corner radius estándar Seillo.
/// Uso: SeillSurfaceCard { VStack { ... } }
struct SeillSurfaceCard<Content: View>: View {
    var cornerRadius: CGFloat = 18
    var padding: CGFloat = 16
    @ViewBuilder let content: () -> Content

    var body: some View {
        content()
            .padding(padding)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
    }
}

// MARK: - Metric Card

/// Tarjeta de métrica reutilizable (valor + label + icono).
/// Uso: SeillMetricCard(value: "24", label: "Sellos", icon: "star.fill", color: .seilAccent)
struct SeillMetricCard: View {
    let value: String
    let label: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 20, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)

            Text(label)
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

// MARK: - Search Field

/// Campo de búsqueda standalone con lupa, clear button y estilo Seillo.
/// Diferente de SeillTextField (que tiene label y es para formularios).
struct SeillSearchField: View {
    let placeholder: String
    @Binding var text: String
    var onSubmit: (() -> Void)? = nil
    @FocusState private var focused: Bool

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(focused ? .seilAccent : .seilMuted)

            TextField(placeholder, text: $text)
                .focused($focused)
                .font(SeillFont.body(14))
                .foregroundColor(.seilText)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                .onSubmit { onSubmit?() }

            if !text.isEmpty {
                Button {
                    Haptics.tap()
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 15))
                        .foregroundColor(.seilMuted)
                }
                .buttonStyle(.plain)
                .transition(.opacity.combined(with: .scale))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(focused ? Color.seilAccent.opacity(0.40) : Color.seilBorder, lineWidth: 1)
                .animation(.easeOut(duration: 0.18), value: focused)
        )
        .animation(.easeOut(duration: 0.15), value: text.isEmpty)
    }
}

// MARK: - Danger Button

/// Botón de acción destructiva. Complementa SeillButton que no tiene variant .danger.
struct SeillDangerButton: View {
    let title: String
    var icon: String? = nil
    var isLoading: Bool = false
    let action: () -> Void

    @State private var isPressed = false

    var body: some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            HStack(spacing: 8) {
                if isLoading {
                    ProgressView().tint(.white).scaleEffect(0.8)
                } else {
                    if let icon {
                        Image(systemName: icon)
                            .font(.system(size: 15, weight: .semibold))
                    }
                    Text(title)
                        .font(SeillFont.label(15))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .foregroundColor(.white)
            .background(Color.seilDanger)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .shadow(color: Color.seilDanger.opacity(0.28), radius: 12, y: 6)
            .scaleEffect(isPressed ? 0.98 : 1)
            .animation(SeillAnimation.buttonPress, value: isPressed)
        }
        .buttonStyle(.plain)
        .disabled(isLoading)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in isPressed = true }
                .onEnded { _ in isPressed = false }
        )
    }
}

// MARK: - Empty State

/// Vista de estado vacío reutilizable.
/// Uso: SeillEmptyState(icon: "creditcard", title: "Sin tarjetas", message: "...")
struct SeillEmptyState: View {
    let icon: String
    let title: String
    let message: String
    var buttonTitle: String? = nil
    var buttonAction: (() -> Void)? = nil

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.08))
                    .frame(width: 72, height: 72)
                Image(systemName: icon)
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundColor(.seilAccent)
            }

            VStack(spacing: 6) {
                Text(title)
                    .font(SeillFont.headline(16))
                    .foregroundColor(.seilText)

                Text(message)
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let buttonTitle, let buttonAction {
                Button {
                    Haptics.tap()
                    buttonAction()
                } label: {
                    Text(buttonTitle)
                        .font(SeillFont.label(13))
                        .foregroundColor(.seilAccent)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(Color.seilAccent.opacity(0.12))
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 40)
        .padding(.vertical, 32)
        .frame(maxWidth: .infinity)
    }
}
