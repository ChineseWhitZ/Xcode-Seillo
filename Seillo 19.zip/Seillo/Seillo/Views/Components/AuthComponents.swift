import SwiftUI

// ─── Microinteractions ───────────────────────────────────────────────────────
// CRÍTICO: antes los métodos disparaban siempre, ignorando el toggle de Settings.
// Ahora leen "haptic_on" de UserDefaults antes de cada llamada.
// UserDefaults retorna false cuando la clave no existe → usamos ?? true
// para que el comportamiento por defecto sea haptics activados (paridad con
// el valor inicial del @AppStorage en SettingsView).
enum Haptics {
    private static var isEnabled: Bool {
        // object(forKey:) devuelve nil si la clave nunca fue escrita;
        // en ese caso asumimos true (activado por defecto).
        UserDefaults.standard.object(forKey: "haptic_on") == nil
            ? true
            : UserDefaults.standard.bool(forKey: "haptic_on")
    }

    static func tap() {
        guard isEnabled else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func success() {
        guard isEnabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    static func error() {
        guard isEnabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }
}

// ─── Glass Card ───────────────────────────────────────────────────────────────
// MEDIO: antes usaba Color.seilCard.opacity(0.95) — sin blur, solo color plano.
// Ahora usa .ultraThinMaterial como fondo para el efecto glass real,
// con la capa de color encima para mantener el tono oscuro del tema.
struct GlassCard<Content: View>: View {
    var padding: CGFloat = 16
    var cornerRadius: CGFloat = 20
    var borderOpacity: Double = 0.10
    @ViewBuilder let content: Content

    var body: some View {
        content
            .padding(padding)
            .background {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(Color.seilCard.opacity(0.55))
                    }
                    .overlay {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .stroke(Color.white.opacity(borderOpacity), lineWidth: 1)
                    }
            }
            .shadow(color: .black.opacity(0.18), radius: 16, y: 8)
    }
}

// ─── SeillTextField ───────────────────────────────────────────────────────────
struct SeillTextField: View {
    let label: String
    let placeholder: String
    let icon: String
    @Binding var text: String
    var isSecure: Bool = false
    var keyboardType: UIKeyboardType = .default
    var trailingIcon: String? = nil
    var trailingAction: (() -> Void)? = nil

    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(SeillFont.label(12))
                .foregroundColor(.seilMuted2)

            HStack(spacing: 10) {
                Image(systemName: icon)
                    .foregroundColor(focused ? .seilAccent : .seilMuted)
                    .font(.system(size: 16))
                    .frame(width: 20)

                if isSecure {
                    SecureField(placeholder, text: $text)
                        .focused($focused)
                        .font(SeillFont.body(14))
                        .foregroundColor(.seilText)
                } else {
                    TextField(placeholder, text: $text)
                        .focused($focused)
                        .font(SeillFont.body(14))
                        .foregroundColor(.seilText)
                        .keyboardType(keyboardType)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                if let trailingIcon, let trailingAction {
                    Button(action: {
                        Haptics.tap()
                        trailingAction()
                    }) {
                        Image(systemName: trailingIcon)
                            .foregroundColor(.seilMuted)
                            .font(.system(size: 16))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(focused ? Color.seilAccent.opacity(0.50) : Color.seilBorder, lineWidth: 1)
                    // NOTA: Animación SOLO en el borde — nunca en el contenedor del TextField.
                    // Animar el HStack padre hace que UIKit no pueda asignar el
                    // first responder correctamente y el teclado no abre.
                    .animation(.easeOut(duration: 0.18), value: focused)
            )
            .shadow(
                color: focused ? Color.seilAccent.opacity(0.10) : .clear,
                radius: 10, y: 2
            )
            .animation(.easeOut(duration: 0.18), value: focused)
        }
    }
}

// ─── New premium button ───────────────────────────────────────────────────────
struct SeillButton: View {
    let title: String
    var icon: String? = nil
    var isLoading: Bool = false
    var disabled: Bool = false
    var style: Variant = .primary
    let action: () -> Void

    enum Variant { case primary, secondary, ghost }

    @State private var isPressed = false

    var body: some View {
        Button(action: {
            Haptics.tap()
            action()
        }) {
            HStack(spacing: 8) {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                        .scaleEffect(0.8)
                } else {
                    if let icon {
                        Image(systemName: icon)
                            .font(.system(size: 15, weight: .semibold))
                    }
                    Text(title)
                        .font(SeillFont.label(15))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .foregroundStyle(foregroundColor)
            .background(backgroundView)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(style == .secondary ? Color.seilBorder : .clear, lineWidth: 1)
            )
            .shadow(color: style == .primary ? Color.seilAccent.opacity(0.28) : .clear, radius: 12, y: 6)
            .scaleEffect(isPressed ? 0.98 : 1)
            .opacity(disabled ? 0.55 : 1)
            .animation(SeillAnimation.buttonPress, value: isPressed)
        }
        .buttonStyle(.plain)
        .disabled(disabled || isLoading)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in isPressed = true }
                .onEnded { _ in isPressed = false }
        )
    }

    @ViewBuilder
    private var backgroundView: some View {
        switch style {
        case .primary:
            LinearGradient(colors: [.seilAccent, .seilAccent2], startPoint: .leading, endPoint: .trailing)
        case .secondary:
            Color.seilCard
        case .ghost:
            Color.clear
        }
    }

    private var foregroundColor: Color {
        switch style {
        case .primary: return .white
        case .secondary: return .seilText
        case .ghost: return .seilAccent
        }
    }
}

// ─── Backwards-compatible button alias ───────────────────────────────────────
struct SeillPrimaryButton: View {
    let title: String
    var isLoading: Bool = false
    var disabled: Bool  = false
    let action: () -> Void

    var body: some View {
        SeillButton(title: title, isLoading: isLoading, disabled: disabled, style: .primary, action: action)
    }
}

// ─── SeillLogo ────────────────────────────────────────────────────────────────
struct SeillLogo: View {
    var size: CGFloat = 26

    var body: some View {
        HStack(spacing: 0) {
            Text("seillo")
                .font(.system(size: size, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)
                .tracking(-1.5)
            Text(".")
                .font(.system(size: size, weight: .heavy, design: .rounded))
                .foregroundColor(.seilAccent)
        }
    }
}

// ─── TestCredentialsBanner ────────────────────────────────────────────────────
/// Solo visible en builds DEBUG. En Release se reemplaza por EmptyView
/// para que las credenciales de prueba no aparezcan en producción.
struct TestCredentialsBanner: View {
    var body: some View {
        #if DEBUG
        GlassCard(padding: 14, cornerRadius: 16, borderOpacity: 0.08) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "flask.fill")
                        .font(.system(size: 10))
                        .foregroundColor(.seilGold)
                    Text("Cuentas de prueba")
                        .font(SeillFont.label(10))
                        .foregroundColor(.seilGold)
                }

                Group {
                    Text("Cliente: cliente@gmail.com")
                    Text("Negocio: negocio@gmail.com")
                    Text("Contraseña: 12345678")
                        .italic()
                        .foregroundColor(.seilMuted)
                }
                .font(SeillFont.body(11))
                .foregroundColor(.seilMuted2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        #endif
    }
}

// ─── AuthDivider ─────────────────────────────────────────────────────────────
struct AuthDivider: View {
    var body: some View {
        HStack(spacing: 12) {
            Rectangle().fill(Color.seilBorder).frame(height: 1)
            Text("o continúa con")
                .font(SeillFont.body(12))
                .foregroundColor(.seilMuted)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
    }
}

// ─── GoogleSignInButton ───────────────────────────────────────────────────────
// HIGH: Añadido isLoading — muestra spinner mientras el flujo OAuth está en vuelo.
// Antes el botón no tenía estado de carga, lo que dejaba la UI sin feedback.
struct GoogleSignInButton: View {
    var title = "Continuar con Google"
    var isLoading: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: {
            guard !isLoading else { return }
            Haptics.tap()
            action()
        }) {
            HStack(spacing: 10) {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.seilText)
                        .scaleEffect(0.78)
                        .frame(width: 22, height: 22)
                } else {
                    ZStack {
                        Circle().fill(Color.white).frame(width: 22, height: 22)
                        Text("G")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(Color(hex: "#4285F4"))  // Google brand blue — no tokenizable
                    }
                }

                Text(isLoading ? "Conectando..." : title)
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilText)
                    .animation(.easeOut(duration: 0.15), value: isLoading)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
            .opacity(isLoading ? 0.80 : 1.0)
            .animation(.easeOut(duration: 0.15), value: isLoading)
        }
        .buttonStyle(.plain)
        .disabled(isLoading)
    }
}


// ─── AppleSignInButton ────────────────────────────────────────────────────────
// HIGH: Añadido isLoading — muestra spinner mientras espera respuesta del framework.
struct AppleSignInButton: View {
    var title = "Continuar con Apple"
    var isLoading: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: {
            guard !isLoading else { return }
            Haptics.tap()
            action()
        }) {
            HStack(spacing: 10) {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.seilText)
                        .scaleEffect(0.78)
                        .frame(width: 22, height: 22)
                } else {
                    Image(systemName: "apple.logo")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.seilText)
                }

                Text(isLoading ? "Conectando..." : title)
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilText)
                    .animation(.easeOut(duration: 0.15), value: isLoading)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
            .opacity(isLoading ? 0.80 : 1.0)
            .animation(.easeOut(duration: 0.15), value: isLoading)
        }
        .buttonStyle(.plain)
        .disabled(isLoading)
    }
}

// ─── AuthBottomLink ───────────────────────────────────────────────────────────
struct AuthBottomLink: View {
    let prefix: String
    let action: String
    let destination: AnyView

    var body: some View {
        HStack(spacing: 4) {
            Text(prefix)
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
            NavigationLink(destination: destination) {
                Text(action)
                    .font(SeillFont.label(13))
                    .foregroundColor(.seilAccent)
            }
        }
    }
}

// ─── SectionDivider ───────────────────────────────────────────────────────────
struct SectionDividerLabel: View {
    let label: String
    var color: Color = .seilAccent

    var body: some View {
        HStack(spacing: 12) {
            Rectangle().fill(Color.seilBorder).frame(height: 1)
            Text(label)
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(color)
                .tracking(1.2)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
    }
}

// ─── SeillSectionLabel ────────────────────────────────────────────────────────
/// Label de sección en CAPS con tracking. Reemplaza funciones locales en
/// SearchView y ReferralView.
struct SeillSectionLabel: View {
    let text: String
    var tracking: CGFloat = 1.3

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.seilMuted)
            .tracking(tracking)
    }
}

// ─── SeillDetailRow ───────────────────────────────────────────────────────────
/// Fila de detalle con ícono, título y valor. Reemplaza la función privada
/// duplicada en CardDetailScreen y BizProfileScreen.
struct SeillDetailRow: View {
    let icon: String
    let title: String
    let value: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.seilAccent)
                .frame(width: 18)

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.seilMuted)
                Text(value)
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilText)
            }

            Spacer()
        }
    }
}

// ─── Clamped (fuente única) ───────────────────────────────────────────────────
/// Extensión única. Elimina las 5 copias privadas esparcidas por TabCardsView,
/// TabPremiosView, TabPerfilView, WelcomeView y BusinessViews.
extension Comparable {
    func clamped(to range: ClosedRange<Self>) -> Self {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}
