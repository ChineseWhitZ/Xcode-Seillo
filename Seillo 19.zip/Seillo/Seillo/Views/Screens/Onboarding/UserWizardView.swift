import SwiftUI

// ─── UserWizardView ───────────────────────────────────────────────────────────
//
// Onboarding de cliente post-registro. 4 pasos:
//   1. Género
//   2. Cumpleaños (DD / MM / AAAA con auto-avance)
//   3. Preferencias de categorías (mínimo 3)
//   4. Resumen
//
// Ruta: Seillo/Views/Screens/Onboarding/UserWizardView.swift
// Integración: SeillApp.swift → se muestra antes de UserTutorialView
// ─────────────────────────────────────────────────────────────────────────────

private let TOTAL_STEPS = 4
private let MIN_PREFS   = 3

// ── Categorías disponibles para preferencias ──────────────────────────────────
private struct PrefCategory: Identifiable {
    let id = UUID()
    let key:   String
    let label: String
    let icon:  String
}

private let prefCategories: [PrefCategory] = [
    .init(key: "cafe",        label: "Café",        icon: "cup.and.saucer.fill"),
    .init(key: "restaurante", label: "Restaurante", icon: "fork.knife"),
    .init(key: "polleria",    label: "Pollería",    icon: "flame.fill"),
    .init(key: "cevicheria",  label: "Cevichería",  icon: "fish.fill"),
    .init(key: "sangucheria", label: "Sanguchería", icon: "bag.fill"),
    .init(key: "jugueria",    label: "Juguería",    icon: "drop.fill"),
    .init(key: "chifa",       label: "Chifa",       icon: "fork.knife.circle.fill"),
    .init(key: "barberia",    label: "Barbería",    icon: "scissors"),
    .init(key: "panaderia",   label: "Panadería",   icon: "leaf.fill"),
    .init(key: "heladeria",   label: "Heladería",   icon: "snowflake"),
    .init(key: "gym",         label: "Gimnasio",    icon: "dumbbell.fill"),
    .init(key: "pasteleria",  label: "Pastelería",  icon: "birthday.cake.fill"),
    .init(key: "estetica",    label: "Estética",    icon: "comb.fill"),
    .init(key: "veterinaria", label: "Veterinaria", icon: "pawprint.fill"),
    .init(key: "farmacia",    label: "Farmacia",    icon: "cross.case.fill"),
    .init(key: "tienda",      label: "Tienda",      icon: "basket.fill"),
]

// ── Opciones de género ────────────────────────────────────────────────────────
private struct GenderOption: Identifiable {
    let id = UUID()
    let key:   String
    let label: String
    let icon:  String
}

private let genderOptions: [GenderOption] = [
    .init(key: "masculino",          label: "Masculino",           icon: "person.fill"),
    .init(key: "femenino",           label: "Femenino",            icon: "person.fill"),
    .init(key: "no_binario",         label: "No binario",          icon: "person.2.fill"),
    .init(key: "prefiero_no_decir",  label: "Prefiero no decir",   icon: "hand.raised.fill"),
]

// ═══ Main View ═══════════════════════════════════════════════════════════════

struct UserWizardView: View {
    let onComplete: () -> Void

    @State private var step     = 1
    @State private var gender   = ""
    @State private var birthDD  = ""
    @State private var birthMM  = ""
    @State private var birthYY  = ""
    @State private var selectedPrefs: Set<String> = []
    @State private var saving   = false

    // Focus para auto-avance en cumpleaños
    @FocusState private var focusDD: Bool
    @FocusState private var focusMM: Bool
    @FocusState private var focusYY: Bool

    private var canAdvance: Bool {
        switch step {
        case 1: return !gender.isEmpty
        case 2: return true   // cumpleaños es opcional
        case 3: return selectedPrefs.count >= MIN_PREFS
        case 4: return true
        default: return false
        }
    }

    private var birthString: String {
        guard !birthDD.isEmpty, !birthMM.isEmpty, !birthYY.isEmpty else { return "" }
        return "\(birthYY)-\(birthMM)-\(birthDD)"
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                // ── Progress bar ─────────────────────────────────────
                progressBar
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    .padding(.bottom, 24)

                // ── Step content ─────────────────────────────────────
                TabView(selection: $step) {
                    genderStep.tag(1)
                    birthdayStep.tag(2)
                    preferencesStep.tag(3)
                    summaryStep.tag(4)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(SeillAnimation.screenTransition, value: step)

                // ── Bottom button ────────────────────────────────────
                bottomButton
                    .padding(.horizontal, 24)
                    .padding(.bottom, 40)
            }
        }
    }

    // MARK: - Progress Bar

    private var progressBar: some View {
        HStack(spacing: 6) {
            ForEach(1...TOTAL_STEPS, id: \.self) { i in
                Capsule()
                    .fill(i <= step ? Color.seilAccent : Color.seilCard)
                    .frame(height: 4)
                    .animation(.easeOut(duration: 0.25), value: step)
            }
        }
    }

    // MARK: - Step 1: Género

    private var genderStep: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                stepHeader(title: "Cuéntanos sobre ti", subtitle: "Esto nos ayuda a personalizar tu experiencia")

                VStack(spacing: 10) {
                    ForEach(genderOptions) { option in
                        Button {
                            Haptics.tap()
                            withAnimation(.easeOut(duration: 0.15)) { gender = option.key }
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: option.icon)
                                    .font(.system(size: 18))
                                    .foregroundColor(gender == option.key ? .seilAccent : .seilMuted)
                                    .frame(width: 24)
                                Text(option.label)
                                    .font(SeillFont.headline(15))
                                    .foregroundColor(.seilText)
                                Spacer()
                                Circle()
                                    .fill(gender == option.key ? Color.seilAccent : Color.clear)
                                    .frame(width: 20, height: 20)
                                    .overlay(
                                        Circle().stroke(gender == option.key ? Color.seilAccent : Color.seilBorder, lineWidth: 2)
                                    )
                                    .overlay(
                                        gender == option.key
                                        ? Image(systemName: "checkmark").font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                                        : nil
                                    )
                            }
                            .padding(16)
                            .background(gender == option.key ? Color.seilAccent.opacity(0.06) : Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(gender == option.key ? Color.seilAccent.opacity(0.4) : Color.seilBorder, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 24)
        }
    }

    // MARK: - Step 2: Cumpleaños

    private var birthdayStep: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                stepHeader(title: "Tu fecha de nacimiento", subtitle: "Opcional. Los negocios podrían enviarte algo especial")

                HStack(spacing: 12) {
                    dateField("DD", text: $birthDD, focused: $focusDD, maxLength: 2) {
                        if birthDD.count == 2 { focusMM = true }
                    }
                    dateField("MM", text: $birthMM, focused: $focusMM, maxLength: 2) {
                        if birthMM.count == 2 { focusYY = true }
                    }
                    dateField("AAAA", text: $birthYY, focused: $focusYY, maxLength: 4) {
                        if birthYY.count == 4 { focusYY = false }
                    }
                }

                if !birthDD.isEmpty || !birthMM.isEmpty || !birthYY.isEmpty {
                    Button {
                        Haptics.tap()
                        birthDD = ""; birthMM = ""; birthYY = ""
                    } label: {
                        Text("Limpiar fecha")
                            .font(SeillFont.caption(12))
                            .foregroundColor(.seilMuted2)
                    }
                    .buttonStyle(.plain)
                }

                Text("Puedes saltar este paso si prefieres")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
            }
            .padding(.horizontal, 24)
        }
        .onAppear { focusDD = true }
    }

    private func dateField(_ placeholder: String, text: Binding<String>, focused: FocusState<Bool>.Binding, maxLength: Int, onFull: @escaping () -> Void) -> some View {
        TextField(placeholder, text: text)
            .focused(focused)
            .keyboardType(.numberPad)
            .multilineTextAlignment(.center)
            .font(.system(size: 24, weight: .heavy, design: .rounded))
            .foregroundColor(.seilText)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 18)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(focused.wrappedValue ? Color.seilAccent.opacity(0.5) : Color.seilBorder, lineWidth: 1)
            )
            .onChange(of: text.wrappedValue) { _, newVal in
                if newVal.count > maxLength {
                    text.wrappedValue = String(newVal.prefix(maxLength))
                }
                if newVal.count == maxLength { onFull() }
            }
    }

    // MARK: - Step 3: Preferencias

    private var preferencesStep: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                stepHeader(
                    title: "Tus favoritos",
                    subtitle: "Elige al menos \(MIN_PREFS) categorías que te interesen"
                )

                Text("\(selectedPrefs.count) de \(MIN_PREFS) mínimo")
                    .font(SeillFont.label(12))
                    .foregroundColor(selectedPrefs.count >= MIN_PREFS ? .seilGreen : .seilMuted2)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach(prefCategories) { cat in
                        let selected = selectedPrefs.contains(cat.key)
                        Button {
                            Haptics.tap()
                            withAnimation(.easeOut(duration: 0.15)) {
                                if selected {
                                    selectedPrefs.remove(cat.key)
                                } else {
                                    selectedPrefs.insert(cat.key)
                                }
                            }
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: cat.icon)
                                    .font(.system(size: 16))
                                    .foregroundColor(selected ? .seilAccent : .seilMuted)
                                Text(cat.label)
                                    .font(SeillFont.label(13))
                                    .foregroundColor(.seilText)
                                Spacer()
                                if selected {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 16))
                                        .foregroundColor(.seilAccent)
                                        .transition(.scale.combined(with: .opacity))
                                }
                            }
                            .padding(14)
                            .background(selected ? Color.seilAccent.opacity(0.06) : Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .stroke(selected ? Color.seilAccent.opacity(0.35) : Color.seilBorder, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
        }
    }

    // MARK: - Step 4: Resumen

    private var summaryStep: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                stepHeader(title: "Todo listo", subtitle: "Confirma tus datos para empezar")

                VStack(spacing: 12) {
                    summaryRow(icon: "person.fill", label: "Género",
                               value: genderOptions.first { $0.key == gender }?.label ?? "No especificado")

                    summaryRow(icon: "calendar", label: "Cumpleaños",
                               value: birthString.isEmpty ? "No especificado" : "\(birthDD)/\(birthMM)/\(birthYY)")

                    summaryRow(icon: "heart.fill", label: "Preferencias",
                               value: "\(selectedPrefs.count) categorías")
                }
            }
            .padding(.horizontal, 24)
        }
    }

    private func summaryRow(icon: String, label: String, value: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.10))
                    .frame(width: 36, height: 36)
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.seilAccent)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(SeillFont.caption(11))
                    .foregroundColor(.seilMuted)
                Text(value)
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilText)
            }
            Spacer()
        }
        .padding(14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }

    // MARK: - Bottom Button

    private var bottomButton: some View {
        VStack(spacing: 12) {
            Button {
                Haptics.tap()
                if step < TOTAL_STEPS {
                    withAnimation(SeillAnimation.screenTransition) { step += 1 }
                } else {
                    saving = true
                    Task {
                        // Construir fecha de nacimiento si el usuario la ingresó
                        var fechaNac: String? = nil
                        let dd = birthDD.trimmingCharacters(in: .whitespaces)
                        let mm = birthMM.trimmingCharacters(in: .whitespaces)
                        let yy = birthYY.trimmingCharacters(in: .whitespaces)
                        if dd.count == 2, mm.count == 2, yy.count == 4 {
                            fechaNac = "\(yy)-\(mm)-\(dd)"
                        }

                        _ = await APIClientService().updateWizard(
                            genero          : gender.isEmpty ? nil : gender,
                            fechaNacimiento : fechaNac,
                            preferencias    : Array(selectedPrefs)
                        )

                        await MainActor.run {
                            saving = false
                            onComplete()
                        }
                    }
                }
            } label: {
                HStack(spacing: 8) {
                    if saving {
                        ProgressView().tint(.white).scaleEffect(0.8)
                    } else {
                        Text(step == TOTAL_STEPS ? "Empezar" : "Continuar")
                            .font(SeillFont.label(15))
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .foregroundColor(.white)
                .background(canAdvance ? Color.seilAccent : Color.seilAccent.opacity(0.35))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .shadow(color: canAdvance ? Color.seilAccent.opacity(0.28) : .clear, radius: 12, y: 6)
            }
            .buttonStyle(.plain)
            .disabled(!canAdvance || saving)

            if step > 1 && step < TOTAL_STEPS {
                Button {
                    Haptics.tap()
                    withAnimation(SeillAnimation.screenTransition) { step -= 1 }
                } label: {
                    Text("Volver")
                        .font(SeillFont.label(13))
                        .foregroundColor(.seilMuted2)
                }
                .buttonStyle(.plain)
            }

            if step == 2 {
                Button {
                    Haptics.tap()
                    withAnimation(SeillAnimation.screenTransition) { step += 1 }
                } label: {
                    Text("Saltar")
                        .font(SeillFont.caption(12))
                        .foregroundColor(.seilMuted)
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: - Helpers

    private func stepHeader(title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(SeillFont.display(24))
                .foregroundColor(.seilText)
            Text(subtitle)
                .font(SeillFont.body(14))
                .foregroundColor(.seilMuted2)
        }
    }
}
