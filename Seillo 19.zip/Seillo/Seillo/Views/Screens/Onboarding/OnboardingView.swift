import SwiftUI

// ─── Modelo de página ─────────────────────────────────────────────────────────
private struct OnboardPage {
    let icon:        String
    let color:       Color
    let title:       String
    let titleAccent: String
    let body:        String
}

private let onboardPages: [OnboardPage] = [
    .init(
        icon:        "seal.fill",
        color:       Color.seilAccent,
        title:       "Sellos digitales,",
        titleAccent: "sin papel.",
        body:        "Cada visita a tu negocio favorito suma un sello en tu tarjeta digital. Sin tarjetas físicas, sin perder nada."
    ),
    .init(
        icon:        "location.fill",
        color:       Color.seilBlue,
        title:       "Descubre negocios",
        titleAccent: "cerca de ti.",
        body:        "Explora cafés, restaurantes y más que usan Seillo en tu zona. Empieza a acumular desde tu primera visita."
    ),
    .init(
        icon:        "trophy.fill",
        color:       Color.seilGold,
        title:       "Llena tu tarjeta,",
        titleAccent: "canjea tu premio.",
        body:        "Cuando completes tus sellos, muestra tu QR y canjea tu recompensa al instante. Sin trámites."
    ),
]

// ─── OnboardingView ───────────────────────────────────────────────────────────
struct OnboardingView: View {
    var onDone: () -> Void

    @State private var currentPage = 0
    @State private var appear      = false
    // Crossfade del texto al cambiar página (Android: AnimatedContent tween 380ms)
    @State private var textAlpha:  Double  = 1
    @State private var textOffset: CGFloat = 0

    private let pageCount = onboardPages.count

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            // Glow de fondo dinámico
            RadialGradient(
                colors: [
                    onboardPages[currentPage].color.opacity(0.18),
                    .clear
                ],
                center: .init(x: 0.5, y: 0.22),
                startRadius: 0,
                endRadius: 420
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.55), value: currentPage)

            VStack(spacing: 0) {

                // ── Pager ──────────────────────────────────────────────────
                TabView(selection: $currentPage) {
                    ForEach(Array(onboardPages.enumerated()), id: \.offset) { i, page in
                        OnboardPageView(page: page, pageIndex: i, appear: appear,
                                           textAlpha: textAlpha, textOffset: textOffset)
                            .tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                // NOTA: .animation() sobre TabView con .page style es ignorado por UIKit.
                // La transición de página usa la física del scroll nativo del sistema.
                // El crossfade del texto se maneja manualmente en triggerTextCrossfade.

                // ── Dots ───────────────────────────────────────────────────
                HStack(spacing: 7) {
                    ForEach(0..<pageCount, id: \.self) { i in
                        Capsule()
                            .fill(i == currentPage
                                  ? onboardPages[currentPage].color
                                  : Color.white.opacity(0.14))
                            .frame(width: i == currentPage ? 22 : 7, height: 7)
                            .animation(SeillAnimation.screenTransition, value: currentPage)
                    }
                }
                .padding(.bottom, 28)

                // ── Botones CTA ────────────────────────────────────────────
                VStack(spacing: 12) {
                    // CTA con color animado — igual que Android animateColorAsState tween(300)
                    Button {
                        Haptics.tap()
                        if currentPage < pageCount - 1 {
                            triggerTextCrossfade { currentPage += 1 }
                        } else {
                            Haptics.success(); onDone()
                        }
                    } label: {
                        HStack(spacing: 8) {
                            if currentPage == pageCount - 1 {
                                Image(systemName: "sparkles")
                                    .font(.system(size: 14, weight: .semibold))
                            }
                            Text(currentPage == pageCount - 1 ? "Empezar ahora" : "Siguiente")
                                .font(SeillFont.headline(15))
                                .contentTransition(.numericText())
                            if currentPage < pageCount - 1 {
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 14, weight: .semibold))
                            }
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(onboardPages[currentPage].color)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: onboardPages[currentPage].color.opacity(0.40), radius: 14, y: 4)
                        .animation(.easeInOut(duration: 0.30), value: currentPage)
                    }
                    .buttonStyle(.plain)

                    if currentPage < pageCount - 1 {
                        Button { Haptics.tap(); onDone() } label: {
                            Text("Omitir")
                                .font(SeillFont.body(14))
                                .foregroundColor(.seilMuted)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 44)
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.3), value: appear)
            }
        }
        .task { await runEntrance() }
    }

    private func runEntrance() async {
        try? await Task.sleep(for: .seconds(0.10))
        withAnimation(SeillAnimation.chrome) { appear = true }
    }

    private func triggerTextCrossfade(_ change: @escaping () -> Void) {
        withAnimation(.easeOut(duration: 0.15)) { textAlpha = 0; textOffset = -8 }
        // Task estructurado reemplaza DispatchQueue.main.asyncAfter — cancelable.
        Task {
            try? await Task.sleep(for: .seconds(0.15))
            change()
            textOffset = 16
            withAnimation(.easeOut(duration: 0.30)) { textAlpha = 1; textOffset = 0 }
        }
    }
}

// ─── Página individual ────────────────────────────────────────────────────────
private struct OnboardPageView: View {
    let page:      OnboardPage
    let pageIndex: Int
    let appear:    Bool
    var textAlpha:  Double  = 1
    var textOffset: CGFloat = 0

    @State private var iconScale:  CGFloat = 0.7
    @State private var iconOpacity: Double = 0

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            // Ilustración por página.
            // .id(page.icon) fuerza SwiftUI a destruir y recrear la vista cuando
            // cambia el ícono — garantiza que .onAppear se re-ejecuta al volver
            // a una página ya visitada, reanimando la ilustración correctamente.
            OnboardIllustration(page: page, pageIndex: pageIndex)
                .id(page.icon)
                .scaleEffect(iconScale)
                .opacity(iconOpacity)
                .frame(height: 220)
                .onAppear {
                    iconScale   = 0.7
                    iconOpacity = 0
                    withAnimation(SeillAnimation.chrome.delay(0.08)) {
                        iconScale   = 1.0
                        iconOpacity = 1.0
                    }
                }

            Spacer().frame(height: 40)

            // Título
            VStack(spacing: 6) {
                Group {
                    Text("\(Text(page.title + " ").foregroundColor(.seilText))\(Text(page.titleAccent).foregroundColor(page.color))")
                }
                .font(SeillFont.display(28))
                .multilineTextAlignment(.center)
                .lineSpacing(4)
            }
            .padding(.horizontal, 32)
            .opacity(appear ? textAlpha : 0)
            .offset(y: appear ? textOffset : 16)

            Spacer().frame(height: 16)

            // Descripción
            Text(page.body)
                .font(SeillFont.body(15))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .lineSpacing(5)
                .padding(.horizontal, 34)
                .opacity(appear ? textAlpha : 0)
                .offset(y: appear ? textOffset : 12)

            Spacer()
        }
    }
}


// ─── Ilustraciones por página ─────────────────────────────────────────────────
private struct OnboardIllustration: View {
    let page:      OnboardPage
    let pageIndex: Int

    var body: some View {
        switch pageIndex {
        case 0:  StampGridIllustration(color: page.color)
        case 1:  IconRingsIllustration(page: page)
        default: IconRingsIllustration(page: page)
        }
    }
}

// Página 0 — Mini tarjeta con sellos stagger (DampingRatioLowBouncy)
private struct StampGridIllustration: View {
    let color: Color
    private let filled = [true, true, true, true, true, true, true, true, false, false]
    @State private var scales: [CGFloat] = Array(repeating: 0, count: 10)

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Café Inti")
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundColor(.seilText)
                Text("Premio: Café gratis")
                    .font(.system(size: 10))
                    .foregroundColor(.seilMuted)
            }
            .padding(.horizontal, 2)

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 5),
                      spacing: 8) {
                ForEach(0..<10, id: \.self) { i in
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(filled[i] ? color.opacity(0.16) : Color.seilCard2)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(filled[i] ? color.opacity(0.50) : Color.seilBorder, lineWidth: 1)
                            )
                        if filled[i] {
                            Image(systemName: "checkmark")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(color)
                        }
                    }
                    .frame(height: 38)
                    .scaleEffect(scales[i])
                    .opacity(Double(scales[i]))
                }
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
        .shadow(color: .black.opacity(0.18), radius: 16, y: 6)
        .padding(.horizontal, 28)
        .task {
            // Cancelación automática garantizada si la vista desaparece.
            for i in 0..<10 {
                try? await Task.sleep(for: .seconds(0.055))
                withAnimation(SeillAnimation.screenTransition) {
                    scales[i] = 1.0
                }
            }
        }
    }
}

// Páginas 1,2 — Ícono con anillos concéntricos
private struct IconRingsIllustration: View {
    let page: OnboardPage

    var body: some View {
        ZStack {
            Circle().fill(page.color.opacity(0.07)).frame(width: 200, height: 200)
            Circle().fill(page.color.opacity(0.10)).frame(width: 150, height: 150)
                .overlay(Circle().stroke(page.color.opacity(0.15), lineWidth: 1))
            ZStack {
                Circle().fill(page.color.opacity(0.16)).frame(width: 100, height: 100)
                    .overlay(Circle().stroke(page.color.opacity(0.30), lineWidth: 1.5))
                Image(systemName: page.icon)
                    .font(.system(size: 44, weight: .semibold))
                    .foregroundColor(page.color)
                    .shadow(color: page.color.opacity(0.50), radius: 18, y: 6)
            }
        }
    }
}
