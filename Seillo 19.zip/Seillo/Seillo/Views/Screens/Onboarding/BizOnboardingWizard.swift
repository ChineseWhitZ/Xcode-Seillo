import SwiftUI

// ─── BizOnboardingWizard ──────────────────────────────────────────────────────
// Wizard de 6 pasos que se muestra a negocios recién registrados antes de entrar
// al BusinessHomeView.
//
// Paso 0 — Perfil:      descripción del negocio
// Paso 1 — Horarios:    selección de horario de atención
// Paso 2 — Programa:    nombre, texto del premio, cantidad de sellos
// Paso 3 — Menú:        items del negocio (opcional)
// Paso 4 — Invitar:     QR y link para invitar clientes
// Paso 5 — ¡Listo!:     resumen y botón para empezar
//
// Usa HorarioDia de Models/HorarioDia.swift — NO redeclarar aquí.
// ─────────────────────────────────────────────────────────────────────────────

// ── Presets de horario ───────────────────────────────────────────────────────

private struct HorarioPreset: Identifiable {
    let id = UUID()
    let label: String
    let value: String
}

private let horarioPresets: [HorarioPreset] = [
    .init(label: "Lun–Sáb · 8am–8pm",  value: "Lunes a Sábado, 8:00 AM – 8:00 PM"),
    .init(label: "Lun–Dom · 8am–8pm",  value: "Lunes a Domingo, 8:00 AM – 8:00 PM"),
    .init(label: "Lun–Dom · 8am–11pm", value: "Lunes a Domingo, 8:00 AM – 11:00 PM"),
    .init(label: "Personalizado",       value: "Personalizado"),
]

// ═══════════════════════════════════════════════════════════════════════════════

struct BizOnboardingWizard: View {
    var onDone: () -> Void

    @EnvironmentObject var bizStore: BizProfileStore

    @State private var step = 0
    private let totalSteps = 6

    // Paso 0 — Perfil
    @State private var descripcion = ""

    // Paso 1 — Horarios (usa HorarioDia del modelo global)
    @State private var horarioIdx = 0
    @State private var horariosDia: [HorarioDia] = (0..<7).map {
        HorarioDia(dia: $0, abierto: $0 < 6)
    }

    // Paso 2 — Programa
    @State private var programaNombre = ""
    @State private var premioTexto    = ""
    @State private var sellosCount    = 10

    private let sellosOptions = [5, 7, 10, 12, 15]

    // Paso 3 — Menú y servicios (opcional)
    @State private var menuItems:    [BizMenuItem] = []
    @State private var showAddMenu   = false

    // Paso 4 — Invitar
    @State private var copied = false

    // Animación
    @State private var appear = false

    private var inviteLink: String {
        "https://seillo.site/biz/\(bizStore.profile.nombre.lowercased().replacingOccurrences(of: " ", with: "-"))"
    }

    // Validaciones
    private var step0Valid: Bool { !descripcion.trimmingCharacters(in: .whitespaces).isEmpty }
    private var step2Valid: Bool {
        !programaNombre.trimmingCharacters(in: .whitespaces).isEmpty &&
        !premioTexto.trimmingCharacters(in: .whitespaces).isEmpty
    }
    private var canProceed: Bool {
        switch step {
        case 0: return step0Valid
        case 2: return step2Valid
        default: return true
        }
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilGold.opacity(0.12), .clear],
                center: .init(x: 0.5, y: 0.14),
                startRadius: 0,
                endRadius: 380
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    Group {
                        switch step {
                        case 0: stepPerfil
                        case 1: stepHorarios
                        case 2: stepPrograma
                        case 3: stepMenu
                        case 4: stepInvitar
                        default: stepListo
                        }
                    }
                    .transition(
                        .asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal:   .move(edge: .leading).combined(with: .opacity)
                        )
                    )
                    .animation(SeillAnimation.screenTransition, value: step)
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                    .padding(.bottom, 140)
                }

                Spacer()
            }

            VStack {
                Spacer()
                ctaButton
                    .padding(.horizontal, 24)
                    .padding(.bottom, 36)
            }
        }
        .sheet(isPresented: $showAddMenu) {
            BizMenuItemForm(existingItem: nil) { newItem in
                menuItems.append(newItem)
            }
            .presentationDetents([.large])
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 16) {
            HStack {
                if step > 0 {
                    Button {
                        Haptics.tap()
                        withAnimation(SeillAnimation.screenTransition) { step -= 1 }
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 36, height: 36)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                } else {
                    Spacer().frame(width: 36)
                }

                Spacer()

                HStack(spacing: 6) {
                    ForEach(0..<totalSteps, id: \.self) { i in
                        let active = i == step
                        let done   = i < step
                        ZStack {
                            Capsule()
                                .fill(done ? Color.seilGold
                                           : active ? Color.seilGold.opacity(0.85)
                                           : Color.white.opacity(0.12))
                                .frame(width: active ? 28 : done ? 22 : 8, height: 8)
                            if done {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 5, weight: .heavy))
                                    .foregroundColor(.black.opacity(0.6))
                                    .transition(.opacity.combined(with: .scale(scale: 0.5)))
                            }
                        }
                        .animation(SeillAnimation.chrome, value: step)
                    }
                }

                Spacer()

                Text("\(step + 1)/\(totalSteps)")
                    .font(SeillFont.caption(12))
                    .foregroundColor(.seilMuted)
                    .frame(width: 36)
            }
            .padding(.horizontal, 20)
            .padding(.top, 18)

            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Paso 0: Perfil

    private var stepPerfil: some View {
        VStack(alignment: .leading, spacing: 28) {
            stepHeader(
                icon: "storefront.fill", color: .seilGold,
                title: "Cuéntanos sobre\ntu negocio",
                subtitle: "Tu descripción ayuda a los clientes a conocerte antes de visitarte."
            )

            VStack(alignment: .leading, spacing: 10) {
                Text("DESCRIPCIÓN DEL NEGOCIO")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)

                ZStack(alignment: .topLeading) {
                    if descripcion.isEmpty {
                        Text("Ej. Somos una cafetería especializada en café de origen peruano. Ofrecemos desayunos y brunchs en un ambiente tranquilo.")
                            .font(SeillFont.body(14)).foregroundColor(.seilMuted)
                            .padding(.horizontal, 14).padding(.vertical, 14)
                    }
                    TextEditor(text: $descripcion)
                        .font(SeillFont.body(14)).foregroundColor(.seilText)
                        .scrollContentBackground(.hidden)
                        .frame(minHeight: 120, maxHeight: 160)
                        .padding(.horizontal, 10).padding(.vertical, 10)
                }
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(descripcion.isEmpty ? Color.seilBorder : Color.seilGold.opacity(0.35), lineWidth: 1)
                )

                HStack {
                    Spacer()
                    Text("\(descripcion.count)/200")
                        .font(SeillFont.caption(11))
                        .foregroundColor(descripcion.count > 180 ? Color.seilRose : .seilMuted)
                }
            }

            tipBox(text: "Una buena descripción atrae más clientes a tu perfil público.")
        }
        .padding(.top, 24)
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 16)
    }

    // MARK: - Paso 1: Horarios

    private var stepHorarios: some View {
        VStack(alignment: .leading, spacing: 28) {
            stepHeader(
                icon: "clock.fill", color: .seilBlue,
                title: "Horario de\natención",
                subtitle: "Tus clientes verán cuándo estás abierto."
            )

            VStack(spacing: 8) {
                Text("ELIGE UN HORARIO")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)

                VStack(spacing: 8) {
                    ForEach(Array(horarioPresets.enumerated()), id: \.element.id) { i, preset in
                        let selected = horarioIdx == i
                        Button {
                            Haptics.tap()
                            withAnimation(.easeOut(duration: 0.2)) { horarioIdx = i }
                            applyHorarioPreset(i)
                        } label: {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(selected ? Color.seilBlue : Color.seilCard)
                                        .frame(width: 20, height: 20)
                                        .overlay(
                                            Circle().stroke(selected ? Color.seilBlue : Color.seilBorder, lineWidth: 1.5)
                                        )
                                    if selected {
                                        Circle().fill(Color.white).frame(width: 8, height: 8)
                                    }
                                }

                                Text(preset.label)
                                    .font(SeillFont.headline(13))
                                    .foregroundColor(selected ? .seilText : .seilMuted2)

                                Spacer()
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 14)
                            .background(selected ? Color.seilBlue.opacity(0.06) : Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .stroke(selected ? Color.seilBlue.opacity(0.35) : Color.seilBorder, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            // Horario personalizado
            if horarioIdx == 3 {
                VStack(alignment: .leading, spacing: 10) {
                    Text("CONFIGURA POR DÍA")
                        .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)

                    VStack(spacing: 0) {
                        ForEach(Array(horariosDia.enumerated()), id: \.offset) { idx, dia in
                            HStack(spacing: 10) {
                                Toggle("", isOn: Binding(
                                    get: { horariosDia[idx].abierto },
                                    set: { horariosDia[idx].abierto = $0 }
                                ))
                                .labelsHidden()
                                .tint(.seilBlue)

                                Text(dia.diaShort)
                                    .font(.system(size: 12, weight: dia.abierto ? .bold : .regular))
                                    .foregroundColor(dia.abierto ? .seilText : .seilMuted)
                                    .frame(width: 36, alignment: .leading)

                                if dia.abierto {
                                    HStack(spacing: 4) {
                                        miniTimeField(
                                            text: Binding(
                                                get: { horariosDia[idx].horaInicio },
                                                set: { horariosDia[idx].horaInicio = $0 }
                                            )
                                        )
                                        Text("–").font(.system(size: 11)).foregroundColor(.seilMuted)
                                        miniTimeField(
                                            text: Binding(
                                                get: { horariosDia[idx].horaCierre },
                                                set: { horariosDia[idx].horaCierre = $0 }
                                            )
                                        )
                                    }
                                } else {
                                    Text("Cerrado")
                                        .font(.system(size: 11))
                                        .foregroundColor(.seilMuted.opacity(0.5))
                                }

                                Spacer()
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 14)

                            if idx < 6 {
                                Rectangle().fill(Color.seilBorder.opacity(0.5)).frame(height: 1).padding(.leading, 14)
                            }
                        }
                    }
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }

            tipBox(text: "Puedes cambiar tu horario después desde tu perfil de negocio.")
        }
        .padding(.top, 24)
    }

    private func miniTimeField(text: Binding<String>) -> some View {
        TextField("08:00", text: text)
            .font(.system(size: 12, weight: .semibold, design: .monospaced))
            .foregroundColor(.seilText)
            .multilineTextAlignment(.center)
            .keyboardType(.numbersAndPunctuation)
            .frame(width: 56)
            .padding(.vertical, 6)
            .background(Color.seilCard2)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.seilBorder, lineWidth: 1))
    }

    private func applyHorarioPreset(_ idx: Int) {
        switch idx {
        case 0:
            horariosDia = (0..<7).map { HorarioDia(dia: $0, abierto: $0 < 6, horaInicio: "08:00", horaCierre: "20:00") }
        case 1:
            horariosDia = (0..<7).map { HorarioDia(dia: $0, abierto: true, horaInicio: "08:00", horaCierre: "20:00") }
        case 2:
            horariosDia = (0..<7).map { HorarioDia(dia: $0, abierto: true, horaInicio: "08:00", horaCierre: "23:00") }
        default: break
        }
    }

    // MARK: - Paso 2: Programa

    private var stepPrograma: some View {
        VStack(alignment: .leading, spacing: 28) {
            stepHeader(
                icon: "star.fill", color: Color.seilAccent,
                title: "Configura tu\nprograma",
                subtitle: "Define cómo quieres premiar a tus clientes."
            )

            VStack(alignment: .leading, spacing: 10) {
                Text("NOMBRE DEL PROGRAMA")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                SeillTextField(label: "", placeholder: "Ej. Tarjeta Café Inti", icon: "textformat", text: $programaNombre)
            }

            VStack(alignment: .leading, spacing: 10) {
                Text("DESCRIPCIÓN DEL PREMIO")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                SeillTextField(label: "", placeholder: "Ej. Café a elección gratis", icon: "gift.fill", text: $premioTexto)
            }

            VStack(alignment: .leading, spacing: 12) {
                Text("SELLOS PARA EL PREMIO")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)

                HStack(spacing: 8) {
                    ForEach(sellosOptions, id: \.self) { n in
                        Button {
                            Haptics.tap()
                            sellosCount = n
                        } label: {
                            Text("\(n)")
                                .font(.system(size: 15, weight: .heavy))
                                .foregroundColor(sellosCount == n ? .white : .seilMuted2)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(
                                    sellosCount == n
                                    ? AnyShapeStyle(LinearGradient(colors: [Color.seilAccent, Color.seilAccent2], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    : AnyShapeStyle(Color.seilCard)
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(sellosCount == n ? Color.clear : Color.seilBorder, lineWidth: 1)
                                )
                                .shadow(color: sellosCount == n ? Color.seilAccent.opacity(0.35) : .clear, radius: 8, y: 3)
                        }
                        .buttonStyle(.plain)
                        .animation(SeillAnimation.chrome, value: sellosCount)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("VISTA PREVIA").font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                    HStack(spacing: 6) {
                        ForEach(0..<min(sellosCount, 10), id: \.self) { i in
                            Circle()
                                .fill(i < 3 ? Color.seilGold.opacity(0.30) : Color.white.opacity(0.07))
                                .frame(width: 22, height: 22)
                                .overlay(Circle().stroke(i < 3 ? Color.seilGold.opacity(0.50) : Color.white.opacity(0.10), lineWidth: 1.5))
                        }
                        if sellosCount > 10 {
                            Text("+\(sellosCount - 10)").font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted)
                        }
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilBorder, lineWidth: 1))
                    .animation(SeillAnimation.screenTransition, value: sellosCount)
                }
            }
        }
        .padding(.top, 24)
    }

    // MARK: - Paso 3: Menú

    private var stepMenu: some View {
        VStack(alignment: .leading, spacing: 24) {
            stepHeader(
                icon: "menucard.fill", color: .seilGreen,
                title: "Menú y servicios",
                subtitle: "Opcional · Muéstrale a tus clientes qué ofreces. Puedes agregar esto ahora o más tarde desde tu perfil."
            )

            if !menuItems.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("LO QUE OFRECES").font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.4)
                        Spacer()
                        Text("\(menuItems.count) ítem\(menuItems.count == 1 ? "" : "s")")
                            .font(.system(size: 10, weight: .semibold)).foregroundColor(.seilGreen)
                    }

                    VStack(spacing: 0) {
                        ForEach(Array(menuItems.enumerated()), id: \.element.id) { i, item in
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack(spacing: 6) {
                                        Text(item.nombre).font(SeillFont.headline(13)).foregroundColor(.seilText)
                                        if let badge = item.badge, !badge.isEmpty {
                                            Text(badge).font(.system(size: 9, weight: .bold)).foregroundColor(.seilGold)
                                                .padding(.horizontal, 6).padding(.vertical, 2)
                                                .background(Color.seilGold.opacity(0.12)).clipShape(Capsule())
                                        }
                                    }
                                    HStack(spacing: 8) {
                                        Text(item.categoria).font(.system(size: 10)).foregroundColor(.seilMuted)
                                        if !item.precio.isEmpty {
                                            Text("·  \(item.precio)").font(.system(size: 10, weight: .semibold)).foregroundColor(.seilGreen)
                                        }
                                    }
                                }
                                Spacer()
                                Button { Haptics.tap(); _ = withAnimation { menuItems.remove(at: i) } } label: {
                                    Image(systemName: "trash").font(.system(size: 12)).foregroundColor(.seilRose).padding(8)
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 12)
                            if i < menuItems.count - 1 { Rectangle().fill(Color.seilBorder.opacity(0.6)).frame(height: 1).padding(.leading, 14) }
                        }
                    }
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
                }
            }

            Button { Haptics.tap(); showAddMenu = true } label: {
                HStack(spacing: 10) {
                    ZStack {
                        Circle().fill(Color.seilGreen.opacity(0.14)).frame(width: 36, height: 36)
                        Image(systemName: "plus").font(.system(size: 15, weight: .bold)).foregroundColor(.seilGreen)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(menuItems.isEmpty ? "Añadir primer ítem" : "Añadir otro ítem").font(SeillFont.headline(13)).foregroundColor(.seilText)
                        Text("Producto, plato, bebida o servicio").font(.system(size: 11)).foregroundColor(.seilMuted)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundColor(.seilAccent)
                }
                .padding(14).background(Color.seilCard).clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)

            tipBox(text: "Los clientes ven tu menú antes de visitarte. Ayuda a que decidan venir.")
        }
        .padding(.top, 24)
    }

    // MARK: - Paso 4: Invitar clientes

    private var stepInvitar: some View {
        VStack(spacing: 24) {
            stepHeader(
                icon: "person.badge.plus", color: .seilPurple,
                title: "Invita a tus\nprimeros clientes",
                subtitle: "Comparte tu QR o link para que se unan al instante."
            )

            ZStack {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Color.seilCard)
                    .frame(width: 180, height: 180)
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .stroke(Color.seilPurple.opacity(0.3), lineWidth: 1)
                    )

                VStack(spacing: 8) {
                    Image(systemName: "qrcode")
                        .font(.system(size: 80))
                        .foregroundColor(.seilText)
                    Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted2)
                }
            }

            Text("QR de invitación")
                .font(.system(size: 11)).foregroundColor(.seilMuted)

            Button {
                Haptics.tap()
                UIPasteboard.general.string = inviteLink
                withAnimation { copied = true }
                Task {
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    withAnimation { copied = false }
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: copied ? "checkmark.circle.fill" : "link")
                        .font(.system(size: 14))
                        .foregroundColor(copied ? .seilGreen : .seilMuted2)

                    Text(inviteLink)
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(copied ? .seilGreen : .seilText)
                        .lineLimit(1)

                    Spacer()

                    Text(copied ? "¡Copiado!" : "Copiar")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(copied ? .seilGreen : .seilAccent)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(Color.seilBorder, lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 12) {
                Text("¿CÓMO FUNCIONA PARA TU CLIENTE?")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(.seilPurple)
                    .tracking(1.1)

                howItWorksRow(icon: "qrcode.viewfinder",  text: "Escanea el QR o abre el link")
                howItWorksRow(icon: "person.badge.plus",  text: "Se crea su cuenta gratis en Seillo")
                howItWorksRow(icon: "creditcard.fill",    text: "Tu tarjeta aparece directo en su app")
                howItWorksRow(icon: "trophy.fill",        text: "Acumula sellos y canjea premios")
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.seilPurple.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Color.seilPurple.opacity(0.15), lineWidth: 1)
            )
        }
        .padding(.top, 24)
    }

    private func howItWorksRow(icon: String, text: String) -> some View {
        HStack(spacing: 10) {
            ZStack {
                Circle().fill(Color.seilPurple.opacity(0.12)).frame(width: 28, height: 28)
                Image(systemName: icon).font(.system(size: 12)).foregroundColor(.seilPurple)
            }
            Text(text).font(SeillFont.body(12)).foregroundColor(.seilMuted2)
        }
    }

    // MARK: - Paso 5: ¡Listo!

    private var stepListo: some View {
        VStack(spacing: 28) {
            ZStack {
                Circle().fill(Color.seilGreen.opacity(0.08)).frame(width: 140, height: 140)
                    .overlay(Circle().stroke(Color.seilGreen.opacity(0.14), lineWidth: 1.5))
                Circle().fill(Color.seilGreen.opacity(0.14)).frame(width: 100, height: 100)
                    .overlay(Circle().stroke(Color.seilGreen.opacity(0.22), lineWidth: 1.5))
                Image(systemName: "checkmark.circle.fill").font(.system(size: 52)).foregroundColor(.seilGreen)
                    .shadow(color: Color.seilGreen.opacity(0.45), radius: 18, y: 6)
            }
            .padding(.top, 32)

            VStack(spacing: 8) {
                Text("¡Todo listo para\nempezar!")
                    .font(SeillFont.display(26)).foregroundColor(.seilText).multilineTextAlignment(.center).lineSpacing(3)
                Text("Tu programa de fidelidad está configurado.\nAhora puedes empezar a sumar clientes.")
                    .font(SeillFont.body(14)).foregroundColor(.seilMuted2).multilineTextAlignment(.center).lineSpacing(4)
            }

            VStack(spacing: 0) {
                resumenRow(icon: "storefront.fill", color: .seilGold, label: "Negocio", value: bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "clock.fill", color: .seilBlue, label: "Horario", value: horarioPresets[horarioIdx].label)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "star.fill", color: Color.seilAccent, label: "Programa", value: programaNombre.isEmpty ? "Tarjeta de sellos" : programaNombre)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "gift.fill", color: Color.seilBlue, label: "Premio", value: premioTexto.isEmpty ? "Premio de fidelidad" : premioTexto)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "seal.fill", color: .seilGreen, label: "Sellos requeridos", value: "\(sellosCount) sellos")
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.seilBorder, lineWidth: 1))

            HStack(spacing: 10) {
                Image(systemName: "qrcode.viewfinder").font(.system(size: 16)).foregroundColor(.seilAccent)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Próximo paso").font(SeillFont.label(12)).foregroundColor(.seilText)
                    Text("Escanea el QR de tus primeros clientes desde la pestaña \"Escanear\".")
                        .font(SeillFont.body(11)).foregroundColor(.seilMuted2).lineSpacing(3)
                }
            }
            .padding(14)
            .background(Color.seilAccent.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilAccent.opacity(0.18), lineWidth: 1))
        }
        .padding(.top, 24)
    }

    // MARK: - CTA flotante

    private var ctaButton: some View {
        Group {
            if step < totalSteps - 1 {
                Button {
                    Haptics.tap()
                    withAnimation(SeillAnimation.screenTransition) { step += 1 }
                } label: {
                    HStack(spacing: 8) {
                        Text(ctaLabel)
                            .font(SeillFont.headline(15))
                        Image(systemName: "arrow.right")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .foregroundColor(canProceed ? .white : .seilMuted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        canProceed
                        ? LinearGradient(colors: [Color.seilGold, Color.seilGold.opacity(0.80)], startPoint: .leading, endPoint: .trailing)
                        : LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .leading, endPoint: .trailing)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: canProceed ? Color.seilGold.opacity(0.35) : .clear, radius: 14, y: 4)
                    .animation(.easeInOut(duration: 0.25), value: canProceed)
                }
                .buttonStyle(.plain)
                .disabled(!canProceed)
            } else {
                Button {
                    Haptics.success()
                    if !menuItems.isEmpty {
                        var updated = bizStore.profile
                        updated.menu = menuItems
                        bizStore.update(updated)
                    }
                    onDone()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "sparkles").font(.system(size: 14, weight: .semibold))
                        Text("Ir a mi panel").font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(LinearGradient(colors: [Color.seilAccent, Color.seilAccent2], startPoint: .leading, endPoint: .trailing))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: Color.seilAccent.opacity(0.40), radius: 14, y: 4)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var ctaLabel: String {
        switch step {
        case 0: return "Continuar"
        case 1: return "Siguiente: Programa"
        case 3: return menuItems.isEmpty ? "Continuar sin menú" : "Siguiente"
        case 4: return "Casi listo"
        default: return "Siguiente"
        }
    }

    // MARK: - Helpers

    private func stepHeader(icon: String, color: Color, title: String, subtitle: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(color.opacity(0.14))
                    .frame(width: 56, height: 56)
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(color.opacity(0.25), lineWidth: 1))
                Image(systemName: icon).font(.system(size: 24, weight: .semibold)).foregroundColor(color)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(SeillFont.display(22)).foregroundColor(.seilText).lineSpacing(2)
                Text(subtitle).font(SeillFont.body(13)).foregroundColor(.seilMuted2).lineSpacing(3)
            }
        }
    }

    private func resumenRow(icon: String, color: Color, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 9).fill(color.opacity(0.12)).frame(width: 30, height: 30)
                Image(systemName: icon).font(.system(size: 13)).foregroundColor(color)
            }
            Text(label).font(SeillFont.body(13)).foregroundColor(.seilMuted2)
            Spacer()
            Text(value).font(SeillFont.label(13)).foregroundColor(.seilText).lineLimit(1)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
    }

    private func tipBox(text: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: "lightbulb.fill").font(.system(size: 13)).foregroundColor(.seilGold)
            Text(text).font(SeillFont.body(12)).foregroundColor(.seilMuted2).lineSpacing(3)
        }
        .padding(14)
        .background(Color.seilGold.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilGold.opacity(0.18), lineWidth: 1))
    }
}
