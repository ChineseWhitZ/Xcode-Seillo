import SwiftUI

// ─── Modelo de página ─────────────────────────────────────────────────────────
private struct TutorialPage {
    let icon:        String
    let color:       Color
    let title:       String
    let titleAccent: String
    let body:        String
}

private let tutorialPages: [TutorialPage] = [
    .init(
        icon:        "creditcard.fill",
        color:       Color.seilAccent,
        title:       "Tus tarjetas",
        titleAccent: "en un lugar.",
        body:        "Cada negocio que te une te da una tarjeta digital. Sin papel, sin perderla nunca."
    ),
    .init(
        icon:        "qrcode.viewfinder",
        color:       Color.seilBlue,
        title:       "Sellos por",
        titleAccent: "cada visita.",
        body:        "El negocio escanea tu QR y te añade un sello. Así de simple. Sin filas, sin papelitos."
    ),
    .init(
        icon:        "trophy.fill",
        color:       Color.seilGold,
        title:       "Premio cuando",
        titleAccent: "llenes todo.",
        body:        "Completa la tarjeta y muestra tu QR para canjear tu recompensa al instante."
    ),
    .init(
        icon:        "map.fill",
        color:       Color.seilGreen,
        title:       "Descubre más",
        titleAccent: "cerca de ti.",
        body:        "Encuentra negocios con Seillo en tu zona y empieza a acumular desde hoy mismo."
    ),
    .init(
        icon:        "rectangle.stack.fill",
        color:       Color.seilPurple,
        title:       "Tu progreso,",
        titleAccent: "siempre visible.",
        body:        "Agrega el widget de Seillo a tu pantalla de inicio y ve tus sellos sin abrir la app. Desde iOS 17."
    ),
]

// ─── UserTutorialView ─────────────────────────────────────────────────────────
struct UserTutorialView: View {
    var onDone: () -> Void

    @State private var currentPage  = 0
    @State private var appear       = false
    @State private var textAlpha:   Double  = 1
    @State private var textOffset:  CGFloat = 0

    private let pageCount = tutorialPages.count

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            // Glow dinámico por página
            RadialGradient(
                colors: [
                    tutorialPages[currentPage].color.opacity(0.14),
                    .clear
                ],
                center: .init(x: 0.5, y: 0.18),
                startRadius: 0,
                endRadius: 380
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.5), value: currentPage)

            VStack(spacing: 0) {

                // ── Header: número de paso ─────────────────────────────────
                HStack {
                    Spacer()
                    Text("\(currentPage + 1) / \(pageCount)")
                        .font(SeillFont.caption(12))
                        .foregroundColor(.seilMuted)
                        .padding(.top, 18)
                        .padding(.trailing, 24)
                        .opacity(appear ? 1 : 0)
                }

                // ── Pager ──────────────────────────────────────────────────
                TabView(selection: $currentPage) {
                    ForEach(Array(tutorialPages.enumerated()), id: \.offset) { i, page in
                        TutorialPageView(page: page, pageIndex: i,
                                            textAlpha: textAlpha, textOffset: textOffset)
                            .tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut(duration: 0.38), value: currentPage)

                // ── Dots ───────────────────────────────────────────────────
                HStack(spacing: 7) {
                    ForEach(0..<pageCount, id: \.self) { i in
                        Capsule()
                            .fill(i == currentPage
                                  ? tutorialPages[currentPage].color
                                  : Color.white.opacity(0.13))
                            .frame(width: i == currentPage ? 22 : 7, height: 7)
                            .animation(SeillAnimation.screenTransition, value: currentPage)
                    }
                }
                .padding(.bottom, 28)

                // ── CTA ────────────────────────────────────────────────────
                VStack(spacing: 12) {
                    if currentPage < pageCount - 1 {
                        // Botón principal
                        Button {
                            Haptics.tap()
                            triggerCrossfade { currentPage += 1 }
                        } label: {
                            HStack(spacing: 8) {
                                Text("Siguiente")
                                    .font(SeillFont.headline(15))
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 14, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(
                                    colors: [tutorialPages[currentPage].color, tutorialPages[currentPage].color.opacity(0.80)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .shadow(color: tutorialPages[currentPage].color.opacity(0.38), radius: 14, y: 4)
                            .animation(.easeInOut(duration: 0.3), value: currentPage)
                        }
                        .buttonStyle(.plain)

                        // Omitir
                        Button {
                            Haptics.tap()
                            onDone()
                        } label: {
                            Text("Omitir")
                                .font(SeillFont.body(14))
                                .foregroundColor(.seilMuted)
                        }
                        .buttonStyle(.plain)
                    } else {
                        // Última página → ir al home
                        Button {
                            Haptics.success()
                            onDone()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "sparkles")
                                    .font(.system(size: 14, weight: .semibold))
                                Text("¡Empezar ahora!")
                                    .font(SeillFont.headline(15))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(
                                    colors: [Color.seilAccent, Color.seilAccent2],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .shadow(color: Color.seilAccent.opacity(0.40), radius: 14, y: 4)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 44)
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.25), value: appear)
            }
        }
        .task { await runEntrance() }
    }

    private func runEntrance() async {
        try? await Task.sleep(nanoseconds: 80_000_000)
        withAnimation(SeillAnimation.chrome) { appear = true }
    }

    private func triggerCrossfade(_ change: @escaping () -> Void) {
        withAnimation(.easeOut(duration: 0.15)) { textAlpha = 0; textOffset = -8 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            change()
            textOffset = 16
            withAnimation(.easeOut(duration: 0.30)) { textAlpha = 1; textOffset = 0 }
        }
    }
}

// ─── Página individual ────────────────────────────────────────────────────────
private struct TutorialPageView: View {
    let page:      TutorialPage
    var pageIndex:  Int     = 0
    var textAlpha:  Double  = 1
    var textOffset: CGFloat = 0

    @State private var iconBounce: CGFloat = 0.72
    @State private var iconOpacity: Double = 0

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            // Ilustración por página
            TutorialIllustration(page: page, pageIndex: pageIndex)
                .scaleEffect(iconBounce)
                .opacity(iconOpacity)
                .frame(height: 220)
                .onAppear {
                    withAnimation(SeillAnimation.chrome.delay(0.05)) {
                        iconBounce  = 1.0
                        iconOpacity = 1.0
                    }
                }

            Spacer().frame(height: 38)

            // Título + descripción con crossfade por página
            Group {
                Text("\(Text(page.title + "\n").foregroundColor(.seilText))\(Text(page.titleAccent).foregroundColor(page.color))")
            }
            .font(SeillFont.display(28))
            .multilineTextAlignment(.center)
            .lineSpacing(2)
            .padding(.horizontal, 30)
            .opacity(textAlpha)
            .offset(y: textOffset)

            Spacer().frame(height: 16)

            // Descripción
            Text(page.body)
                .font(SeillFont.body(15))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .lineSpacing(5)
                .padding(.horizontal, 34)
                .opacity(textAlpha)
                .offset(y: textOffset)

            Spacer()
        }
    }
}


// ─── Tutorial illustrations ───────────────────────────────────────────────────
private struct TutorialIllustration: View {
    let page:      TutorialPage
    let pageIndex: Int

    var body: some View {
        switch pageIndex {
        case 0:  TutorialCardStackIllustration(color: page.color)
        case 4:  WidgetIllustration(color: page.color)
        default: TutorialIconRingsIllustration(page: page)
        }
    }
}

// Página 0 — Stack de 3 tarjetas con spring stagger 100ms (Android DampingRatioMediumBouncy)
private struct TutorialCardStackIllustration: View {
    let color: Color
    @State private var scales: [CGFloat] = [0, 0, 0]

    var body: some View {
        ZStack {
            // Carta fondo
            RoundedRectangle(cornerRadius: 16)
                .fill(LinearGradient(colors: [color.opacity(0.25), color.opacity(0.10)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 240, height: 130)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(color.opacity(0.20), lineWidth: 1))
                .offset(x: -14, y: -10).rotationEffect(.degrees(-6))
                .scaleEffect(scales[0])

            // Carta media
            RoundedRectangle(cornerRadius: 16)
                .fill(LinearGradient(colors: [color.opacity(0.40), color.opacity(0.20)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 240, height: 130)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(color.opacity(0.25), lineWidth: 1))
                .offset(x: 10, y: 6).rotationEffect(.degrees(4))
                .scaleEffect(scales[1])

            // Carta frontal
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "cup.and.saucer.fill")
                        .font(.system(size: 14)).foregroundColor(color)
                    Text("Café Inti").font(.system(size: 12, weight: .bold)).foregroundColor(.seilText)
                    Spacer()
                }
                HStack(spacing: 6) {
                    ForEach(0..<8, id: \.self) { i in
                        Circle()
                            .fill(i < 6 ? color.opacity(0.85) : color.opacity(0.15))
                            .frame(width: 18, height: 18)
                            .overlay(Circle().stroke(color.opacity(0.40), lineWidth: 1))
                    }
                }
                Text("6/8 sellos · Café gratis")
                    .font(.system(size: 9)).foregroundColor(.seilMuted)
            }
            .padding(16)
            .frame(width: 240, height: 130, alignment: .leading)
            .background(LinearGradient(colors: [color.opacity(0.18), Color.seilCard],
                                        startPoint: .topLeading, endPoint: .bottomTrailing))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(color.opacity(0.30), lineWidth: 1))
            .shadow(color: .black.opacity(0.22), radius: 14, y: 6)
            .scaleEffect(scales[2])
        }
        .task {
            for i in 0..<3 {
                try? await Task.sleep(nanoseconds: 100_000_000)
                withAnimation(SeillAnimation.screenTransition) {
                    scales[i] = 1.0
                }
            }
        }
    }
}

// Demás páginas — ícono con anillos concéntricos
private struct TutorialIconRingsIllustration: View {
    let page: TutorialPage

    var body: some View {
        ZStack {
            Circle().stroke(page.color.opacity(0.06), lineWidth: 1).frame(width: 210, height: 210)
            Circle().stroke(page.color.opacity(0.10), lineWidth: 1).frame(width: 165, height: 165)
            Circle()
                .fill(RadialGradient(
                    colors: [page.color.opacity(0.20), page.color.opacity(0.06)],
                    center: .center, startRadius: 0, endRadius: 56))
                .frame(width: 116, height: 116)
                .overlay(Circle().stroke(page.color.opacity(0.28), lineWidth: 1.5))
            Image(systemName: page.icon)
                .font(.system(size: 46, weight: .semibold))
                .foregroundColor(page.color)
                .shadow(color: page.color.opacity(0.55), radius: 20, y: 6)
        }
    }
}

// ─── WidgetIllustration ──────────────────────────────────────────────────────
// Simula un widget de Seillo en una pantalla de iPhone.
// Muestra: marco del teléfono + fondo de pantalla + widget small de Seillo.

private struct WidgetIllustration: View {
    let color: Color

    @State private var phoneScale:   CGFloat = 0.72
    @State private var phoneOpacity: Double  = 0
    @State private var widgetPulse:  Bool    = false
    @State private var badgeScale:   CGFloat = 0

    var body: some View {
        ZStack {
            // ── Marco del iPhone ──────────────────────────────────────────
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(Color(hex: "#1A1A1A"))
                .frame(width: 148, height: 210)
                .overlay(
                    RoundedRectangle(cornerRadius: 32, style: .continuous)
                        .stroke(Color.white.opacity(0.10), lineWidth: 2)
                )
                .shadow(color: .black.opacity(0.45), radius: 20, y: 8)

            // ── Pantalla ──────────────────────────────────────────────────
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color(hex: "#0D0B1A"), Color(hex: "#1A1030")],
                        startPoint: .top, endPoint: .bottom
                    )
                )
                .frame(width: 134, height: 196)

            // ── Notch ─────────────────────────────────────────────────────
            Capsule()
                .fill(Color(hex: "#1A1A1A"))
                .frame(width: 44, height: 10)
                .offset(y: -88)

            // ── Iconos de app simulados (fondo) ───────────────────────────
            VStack(spacing: 8) {
                Spacer().frame(height: 16)

                // Fila de iconos pequeños arriba
                HStack(spacing: 8) {
                    ForEach(0..<3, id: \.self) { _ in
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.white.opacity(0.05))
                            .frame(width: 28, height: 28)
                    }
                }

                // ── Widget de Seillo ──────────────────────────────────────
                widgetCard

                // Fila de iconos abajo
                HStack(spacing: 8) {
                    ForEach(0..<3, id: \.self) { _ in
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.white.opacity(0.05))
                            .frame(width: 28, height: 28)
                    }
                }

                Spacer()
            }
            .frame(width: 118)
            .offset(y: 6)

            // ── Badge "NUEVO" ─────────────────────────────────────────────
            Text("WIDGET")
                .font(.system(size: 7, weight: .heavy))
                .foregroundColor(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(color)
                .clipShape(Capsule())
                .scaleEffect(badgeScale)
                .offset(x: 52, y: -80)
        }
        .scaleEffect(phoneScale)
        .opacity(phoneOpacity)
        .task {
            withAnimation(SeillAnimation.chrome.delay(0.05)) {
                phoneScale   = 1.0
                phoneOpacity = 1.0
            }
            try? await Task.sleep(nanoseconds: 500_000_000)
            withAnimation(.spring(response: 0.38, dampingFraction: 0.58)) {
                badgeScale = 1.0
            }
            try? await Task.sleep(nanoseconds: 200_000_000)
            widgetPulse = true
        }
    }

    // Widget small simulado
    private var widgetCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            // Header del widget
            HStack(spacing: 5) {
                Image(systemName: "seal.fill")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(color)
                Text("Seillo")
                    .font(.system(size: 9, weight: .heavy))
                    .foregroundColor(.white.opacity(0.90))
                Spacer()
            }

            // Nombre del negocio
            Text("Café Inti")
                .font(.system(size: 10, weight: .heavy))
                .foregroundColor(.white)
                .lineLimit(1)

            // Sellos en miniatura
            HStack(spacing: 3) {
                ForEach(0..<6, id: \.self) { i in
                    Circle()
                        .fill(i < 4 ? color : color.opacity(0.15))
                        .frame(width: 9, height: 9)
                        .overlay(
                            Circle().stroke(color.opacity(0.40), lineWidth: 0.5)
                        )
                }
            }

            // Progreso textual
            Text("4 / 6 · Faltan 2")
                .font(.system(size: 8))
                .foregroundColor(.white.opacity(0.55))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 9)
        .frame(width: 108)
        .background(
            LinearGradient(
                colors: [color.opacity(0.22), color.opacity(0.08)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(color.opacity(0.30), lineWidth: 1)
        )
        .shadow(color: color.opacity(0.25), radius: widgetPulse ? 10 : 4, y: 3)
        .animation(
            .easeInOut(duration: 1.4).repeatForever(autoreverses: true),
            value: widgetPulse
        )
    }
}
