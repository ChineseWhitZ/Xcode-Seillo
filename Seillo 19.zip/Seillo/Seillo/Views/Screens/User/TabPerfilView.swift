import SwiftUI

// UserLevel y levelFor definidos en Models.swift — no se redefinen aquí

// ─── TabPerfilView ─────────────────────────────────────────────────────────────
struct TabPerfilView: View {
    @EnvironmentObject var profileStore: ProfileStore
    @EnvironmentObject var auth: AuthManager

    @State private var cards: [LoyaltyCard] = []
    @State private var showEditProfile = false

    private let service: ClientServiceProtocol = APIClientService()
    @State private var showLogoutSheet = false
    @AppStorage("seillo_member_since") private var memberSinceTimestamp: Double = 0
    @State private var showQR = false
    @State private var showHistory = false
    @State private var showFAQ = false
    @State private var showSettings = false
    @State private var showAbout = false
    @State private var showReferral  = false
    @State private var showFriends   = false
    @State private var showIdentity  = false
    @State private var showLevelUp   = false
    @State private var levelUpTarget: UserLevel? = nil
    // enterProgress 0→1 global — cada sección mapea su propia franja
    @State private var enterProgress: Double = 0
    @State private var animLevelProgress: Double = 0
    @State private var animCardProgress:  Double = 0

    // Fracción [start, end] dentro de enterProgress para cada sección
    private func sAlpha(_ start: Double, _ end: Double) -> Double {
        ((enterProgress - start) / (end - start)).clamped(to: 0...1)
    }
    private func sOffset(_ start: Double, _ end: Double) -> CGFloat {
        CGFloat(18 * (1 - sAlpha(start, end)))
    }

    private var totalStamps: Int { cards.reduce(0) { $0 + $1.filledStamps } }

    private var memberSinceLabel: String {
        let df = DateFormatter()
        df.dateFormat = "MMM yyyy"
        df.locale = Locale(identifier: "es_PE")
        let date = memberSinceTimestamp > 0
            ? Date(timeIntervalSince1970: memberSinceTimestamp)
            : Date()
        return df.string(from: date)
    }
    private var premiosListos: Int { cards.filter { $0.isComplete }.count }
    private var level: UserLevel { UserLevel.level(for: totalStamps) }

    private var topPending: LoyaltyCard? {
        cards.filter { !$0.isComplete }.max { $0.progress < $1.progress }
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
              SeillContentBox {
                LazyVStack(spacing: 0) {
                    profileHeader
                    levelBanner
                    statsSection
                    rankingBanner
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                        .opacity(sAlpha(0.20, 0.58))
                        .offset(y: sOffset(0.20, 0.58))

                    if let card = topPending {
                        progressCard(card)
                    }

                    // Separador de sección estandarizado a 16
                    Spacer().frame(height: 16)

                    menuSection(label: "MI ACTIVIDAD", items: [
                        ProfileMenuItem(icon: "clock.arrow.circlepath", label: "Historial de premios") {
                            showHistory = true
                        },
                        ProfileMenuItem(icon: "qrcode", label: "Mi código QR") {
                            showQR = true
                        },
                        ProfileMenuItem(icon: "person.2.fill", label: "Mis amigos") {
                            showFriends = true
                        },
                        ProfileMenuItem(icon: "sparkles", label: "Mi identidad") {
                            showIdentity = true
                        },
                        ProfileMenuItem(icon: "person.2.wave.2.fill", label: "Invitar amigos") {
                            showReferral = true
                        }
                    ])

                    Spacer().frame(height: 16)

                    menuSection(label: "AYUDA", items: [
                        ProfileMenuItem(icon: "questionmark.circle", label: "Preguntas frecuentes") {
                            showFAQ = true
                        },
                        ProfileMenuItem(icon: "info.circle", label: "Acerca de Seillo") {
                            showAbout = true
                        }
                    ])

                    Spacer().frame(height: 16)

                    logoutButton

                    Spacer().frame(height: 16)

                    Text("Seillo v\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0") · Hecho en Perú")
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted)
                        .opacity(sAlpha(0.56, 0.90))

                    // SeillLayout.tabBarScrollReserve — antes: height: 100

                }
              } // SeillContentBox
            }
            .ignoresSafeArea(.all, edges: .bottom)
            .contentMargins(.bottom, 32, for: .scrollContent)
            .refreshable {
                if case .success(let c) = await service.getTarjetas() {
                    cards = c
                }
                profileStore.refreshFromLocal()
                await profileStore.loadIdentity()
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showEditProfile) {
            EditProfileView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showLogoutSheet) {
            LogoutConfirmSheet {
                auth.logout()
            }
            .presentationDetents(adaptiveDetents(height: 320))
            .presentationDragIndicator(.hidden)
            .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showQR) {
            QRSheetView()
                .presentationDetents(adaptiveDetents(height: 520))
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showHistory) {
            HistoryView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showFAQ) {
            FAQView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(profileStore)
                .environmentObject(auth)
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showAbout) {
            AboutSeilloView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showReferral) {
            ReferralView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilBg)
                .environmentObject(profileStore)
        }
        .sheet(isPresented: $showFriends) {
            FriendsView()
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilBg)
        }
        .sheet(isPresented: $showIdentity) {
            IdentityView()
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilBg)
        }
        .sheet(isPresented: $showLevelUp) {
            if let lvl = levelUpTarget {
                LevelUpView(
                    newLevel:    lvl,
                    userName:    profileStore.profile.firstName,
                    totalStamps: totalStamps
                )
                .presentationDetents(adaptiveDetents(height: 680))
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
            }
        }
        .task {
            // Guardar fecha de primer acceso como miembro
            if memberSinceTimestamp == 0 {
                memberSinceTimestamp = Date().timeIntervalSince1970
            }

            // Cargar tarjetas del backend
            if case .success(let c) = await service.getTarjetas() {
                cards = c
            }

            // Cargar identidad del usuario (Lote 1)
            await profileStore.loadIdentity()

            // enterProgress 0→1 con curva EmphasizedDecel (iOS equivalente)
            withAnimation(SeillAnimation.chrome) {
                enterProgress = 1.0
            }
            // Barras de progreso con delay para que ya estén visibles
            let lvl = UserLevel.level(for: totalStamps)
            let levelRange = Double(lvl.nextSellos - lvl.minSellos)
            try? await Task.sleep(nanoseconds: 250_000_000)
            withAnimation(.easeOut(duration: 0.9)) {
                animLevelProgress = levelRange > 0
                    ? Double(totalStamps - lvl.minSellos) / levelRange
                    : 1.0
            }
            if let card = topPending {
                try? await Task.sleep(nanoseconds: 100_000_000)
                withAnimation(.easeOut(duration: 0.9)) {
                    animCardProgress = card.progress
                }
            }

            // ── Detectar si el usuario acaba de subir de nivel ──────────────
            // En producción: comparar contra el nivel guardado en UserDefaults/API.
            // Por ahora dispara si el nivel es VIP o Leyenda (demo).
            let currentLvl = UserLevel.level(for: totalStamps)
            let savedLvlName = UserDefaults.standard.string(forKey: "seillo_last_level") ?? "Nuevo"
            if currentLvl.name != savedLvlName && savedLvlName != "" {
                try? await Task.sleep(nanoseconds: 600_000_000)
                levelUpTarget = currentLvl
                showLevelUp   = true
                UserDefaults.standard.set(currentLvl.name, forKey: "seillo_last_level")
            } else if savedLvlName == "" {
                // Primera vez: guardar sin mostrar
                UserDefaults.standard.set(currentLvl.name, forKey: "seillo_last_level")
            }
        }
    }

    // MARK: - Sections

    private var profileHeader: some View {
        let glow = UserProfile.avatarOptions[profileStore.profile.avatarId % UserProfile.avatarOptions.count].color

        return HStack(spacing: 16) {
            Button {
                showEditProfile = true
            } label: {
                ZStack(alignment: .bottomTrailing) {
                    SeilloAvatarWithFrame(
                        avatarId: profileStore.profile.avatarId,
                        frameId:  profileStore.identidad.frameActivo,
                        size:     72
                    )

                    ZStack {
                        Circle()
                            .fill(Color.seilSurface)
                            .frame(width: 24, height: 24)
                            .overlay(
                                Circle().stroke(Color.seilBorder, lineWidth: 1.5)
                            )

                        Image(systemName: "pencil")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.seilAccent)
                    }
                }
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 4) {
                Text(profileStore.profile.nombre)
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .tracking(-0.4)

                Text(profileStore.profile.email)
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)

                HStack(spacing: 4) {
                    Image(systemName: "calendar")
                        .font(.system(size: 9))
                        .foregroundColor(.seilMuted)

                    Text("Miembro desde \(memberSinceLabel)")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.seilMuted)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 7))
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.seilBorder, lineWidth: 0.5)
                )

                // ── Título de identidad (Lote 1) ─────────────────
                if let tituloId = profileStore.identidad.tituloActivo,
                   let tituloTexto = profileStore.identidad.tituloActivoTexto {
                    SeilloTitlePill(
                        tituloId:    tituloId,
                        tituloTexto: tituloTexto,
                        compact:     true
                    )
                }

                // ── Badges visibles (Lote 1) ─────────────────────
                if !profileStore.identidad.badgesVisiblesInfo.isEmpty {
                    SeilloBadgesRow(badges: profileStore.identidad.badgesVisiblesInfo)
                }
            }

            Spacer()

            VStack(spacing: 8) {
                Button {
                    showSettings = true
                } label: {
                    Image(systemName: "gearshape")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .padding(10)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)

                Button {
                    showEditProfile = true
                } label: {
                    Text(SeillStrings.action.edit)
                        .font(SeillFont.label(11))
                        .foregroundColor(.seilMuted2)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(20)
        .background(
            LinearGradient(
                colors: [glow.opacity(0.18), .clear],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
        }
        .opacity(sAlpha(0.00, 0.38))
        .offset(y: sOffset(0.00, 0.38))
    }

    private var levelBanner: some View {
        let lvl = level
        let nextLvl = UserLevel.levels.first { $0.minSellos > lvl.minSellos }

        return HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(lvl.color.opacity(0.15))
                    .frame(width: 54, height: 54)
                    .overlay(
                        Circle().stroke(lvl.color.opacity(0.35), lineWidth: 1.5)
                    )

                Image(systemName: lvl.icon)
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundColor(lvl.color)
            }

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Nivel \(lvl.name)")
                        .font(.system(size: 14, weight: .heavy))
                        .foregroundColor(lvl.color)

                    Spacer()

                    Text("\(totalStamps) sellos")
                        .font(SeillFont.label(11))
                        .foregroundColor(.seilMuted2)
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 6)

                        Capsule()
                            .fill(lvl.color)
                            .frame(width: geo.size.width * animLevelProgress, height: 6)
                    }
                }
                .frame(height: 6)

                if let n = nextLvl {
                    Text("Faltan \(n.minSellos - totalStamps) sellos para nivel \(n.name)")
                        .font(.system(size: 10))
                        .foregroundColor(.seilMuted)
                } else {
                    Text("Nivel máximo alcanzado")
                        .font(.system(size: 10))
                        .foregroundColor(.seilMuted)
                }
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [lvl.color.opacity(0.12), lvl.color.opacity(0.04)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(lvl.color.opacity(0.25), lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .opacity(sAlpha(0.08, 0.46))
        .offset(y: sOffset(0.08, 0.46))
    }

    private var statsSection: some View {
        HStack(spacing: 8) {
            ProfileStatCard(
                number: "\(cards.count)",
                label: "Tarjetas",
                icon: "creditcard.fill",
                color: .seilAccent
            )

            ProfileStatCard(
                number: "\(totalStamps)",
                label: "Sellos",
                icon: "checkmark.circle.fill",
                color: .seilBlue  // antes: Color.seilBlue
            )

            ProfileStatCard(
                number: "\(premiosListos)",
                label: "Premios",
                icon: "trophy.fill",
                color: .seilGold
            )
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .opacity(sAlpha(0.16, 0.54))
        .offset(y: sOffset(0.16, 0.54))
    }

    // ── Ranking contextual ─────────────────────────────────────────────────
    // Calcula el percentil del usuario basándose en totalStamps vs una
    // distribución simulada de Lima. En producción: dato del servidor.
    private var userPercentile: Int {
        // Distribución realista de sellos en Lima (mock):
        // 60% tiene < 10 sellos, 25% entre 10-50, 10% entre 50-100, 5% > 100
        switch totalStamps {
        case 0..<5:   return 15
        case 5..<10:  return 35
        case 10..<20: return 52
        case 20..<35: return 65
        case 35..<50: return 74
        case 50..<75: return 82
        case 75..<100: return 88
        case 100..<150: return 93
        case 150..<200: return 96
        default:      return 99
        }
    }

    private var rankingBanner: some View {
        let pct     = userPercentile
        let isTop   = pct >= 90
        let color: Color = isTop ? .seilGold : (pct >= 70 ? .seilAccent : .seilBlue)

        return HStack(spacing: 14) {
            // Icono
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(color.opacity(0.12))
                    .frame(width: 44, height: 44)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(color.opacity(0.22), lineWidth: 1)
                    )

                Image(systemName: isTop ? "medal.fill" : "chart.bar.fill")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundColor(color)
            }

            // Texto
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text("Top \(100 - pct)% en Lima")
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .foregroundColor(.seilText)

                    if isTop {
                        Image(systemName: "trophy.fill")
                            .font(.system(size: 12))
                            .foregroundColor(.seilGold)
                    }
                }

                Text(rankingSubtitle(pct))
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted)
                    .lineSpacing(2)
            }

            Spacer()

            // Percentil visual — barra vertical
            VStack(spacing: 3) {
                Text("\(pct)%")
                    .font(.system(size: 13, weight: .heavy))
                    .foregroundColor(color)

                Text("activo")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(.seilMuted)
                    .tracking(0.5)
            }
        }
        .padding(14)
        .background(
            LinearGradient(
                colors: [color.opacity(0.07), color.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(color.opacity(0.18), lineWidth: 1)
        )
    }

    private func rankingSubtitle(_ pct: Int) -> String {
        switch pct {
        case 90...:  return "Estás entre los usuarios más activos de Lima."
        case 75..<90: return "Acumulas más sellos que la mayoría de Lima."
        case 60..<75: return "Estás por encima del promedio limeño."
        case 40..<60: return "Sigue acumulando para subir en el ranking."
        default:     return "Empieza a visitar negocios y sube posiciones."
        }
    }

    @ViewBuilder
    private func progressCard(_ card: LoyaltyCard) -> some View {
        let remaining = card.totalStamps - card.filledStamps

        NavigationLink {
            CardDetailScreen(card: card)
        } label: {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: card.icon)
                        .font(.system(size: 13))
                        .foregroundColor(card.stampColor)

                    Text("\(card.bizName) · próximo premio")
                        .font(SeillFont.label(12))
                        .foregroundColor(.seilText)

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.32))
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 6)

                        Capsule()
                            .fill(card.stampColor)
                            .frame(width: geo.size.width * animCardProgress, height: 6)
                    }
                }
                .frame(height: 6)

                HStack(spacing: 6) {
                    Image(systemName: "gift.fill")
                        .font(.system(size: 10))
                        .foregroundColor(card.stampColor)

                    Text("Faltan \(remaining) \(remaining == 1 ? "sello" : "sellos") para tu premio")
                        .font(.system(size: 11))
                        .foregroundColor(.seilMuted)

                    Spacer()

                    Text(SeillStrings.action.viewDetail)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(card.stampColor)
                        .clipShape(RoundedRectangle(cornerRadius: 9))
                }
            }
            .padding(16)
            .background(
                LinearGradient(
                    colors: [Color.white.opacity(0.035), Color.white.opacity(0.02)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .background(.ultraThinMaterial.opacity(0.14))
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(
                // seilBorderGlass
                RoundedRectangle(cornerRadius: 18)
                    .stroke(Color.seilBorderGlass, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .opacity(sAlpha(0.24, 0.62))
        .offset(y: sOffset(0.24, 0.62))
    }

    @ViewBuilder
    private func menuSection(label: String, items: [ProfileMenuItem]) -> some View {
        VStack(spacing: 0) {
            HStack {
                Text(label)
                    .font(SeillFont.micro())
                    .foregroundColor(.seilMuted)
                    .tracking(1.5)

                Spacer()
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 8)

            VStack(spacing: 0) {
                ForEach(Array(items.enumerated()), id: \.offset) { i, item in
                    Button(action: item.action) {
                        HStack(spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.seilCard2)
                                    .frame(width: 34, height: 34)

                                Image(systemName: item.icon)
                                    .font(.system(size: 15))
                                    .foregroundColor(.seilMuted2)
                            }

                            Text(item.label)
                                .font(SeillFont.label(13))
                                .foregroundColor(.seilText)

                            Spacer()

                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(.seilMuted)
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 13)
                    }
                    // MEDIO: antes .plain — sin ningún feedback visual al tocar.
                    // MenuItemPressStyle escala a 0.97 igual que CardPressStyle.
                    .buttonStyle(MenuItemPressStyle())

                    if i < items.count - 1 {
                        Rectangle()
                            .fill(Color.seilBorder)
                            .frame(height: 1)
                            .padding(.leading, 60)
                    }
                }
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
            .padding(.horizontal, 16)
        }
        .opacity(sAlpha(0.32, 0.70))
        .offset(y: sOffset(0.32, 0.70))
    }

    private var logoutButton: some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            showLogoutSheet = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 14))

                Text(SeillStrings.action.signOut)
                    .font(SeillFont.headline(14))
            }
            .foregroundColor(.seilRose)  // antes: Color.seilRose
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.seilRose.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.seilRose.opacity(0.3), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
        .opacity(sAlpha(0.48, 0.84))
        .offset(y: sOffset(0.48, 0.84))
    }
}

// ─── Helper types ─────────────────────────────────────────────────────────────
struct ProfileMenuItem {
    let icon: String
    let label: String
    let action: () -> Void
}

struct ProfileStatCard: View {
    let number: String
    let label: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(SeillFont.headline(16))
                .foregroundColor(color)

            Text(number)
                .font(SeillFont.display(22))
                .foregroundColor(color)

            Text(label)
                .font(SeillFont.micro(9))
                .foregroundColor(.seilMuted)
                .tracking(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(number) \(label)")
    }
}


// ─── LogoutConfirmSheet ───────────────────────────────────────────────────────
struct LogoutConfirmSheet: View {
    let onConfirm: () -> Void
    @Environment(\.dismiss) var dismiss

    var body: some View {
        SeillSheetBox {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .padding(.top, 12)

            Spacer().frame(height: 20)

            ZStack {
                Circle()
                    .fill(Color.seilRose.opacity(0.12))
                    .frame(width: 52, height: 52)

                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 22))
                    .foregroundColor(.seilRose)
            }

            Spacer().frame(height: 14)

            Text(SeillStrings.action.signOutQuestion)
                .font(SeillFont.title(16))
                .foregroundColor(.seilText)

            Spacer().frame(height: 6)

            Text("Podrás volver a ingresar con tu cuenta\nen cualquier momento.")
                .font(SeillFont.body(12))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)

            Spacer().frame(height: 20)

            HStack(spacing: 10) {
                Button {
                    dismiss()
                } label: {
                    Text(SeillStrings.action.cancel)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.seilMuted)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)

                Button {
                    dismiss()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        onConfirm()
                    }
                } label: {
                    Text(SeillStrings.action.signOut)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.seilRose)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 24)

            Spacer().frame(height: 8)
        }
        } // SeillSheetBox
    }
}

// ─── MenuItemPressStyle ───────────────────────────────────────────────────────
// MEDIO: los items del menú de perfil usaban .plain — sin feedback visual.
// Este ButtonStyle añade scale 0.97 consistente con CardPressStyle.
private struct MenuItemPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                configuration.isPressed
                    ? Color.seilCard2.opacity(0.6)
                    : Color.clear
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.spring(response: 0.20, dampingFraction: 0.75), value: configuration.isPressed)
    }
}
