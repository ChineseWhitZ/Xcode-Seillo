import SwiftUI
import WidgetKit

// ─── CardGroup ────────────────────────────────────────────────────────────────
/// Agrupa tarjetas del mismo negocio. Si un negocio tiene una sola tarjeta se
/// sigue mostrando como tarjeta individual (comportamiento anterior intacto).

private struct CardGroup: Identifiable {
    let negocioId: String
    let cards: [LoyaltyCard]

    var id: String { negocioId }
    var isSingle: Bool { cards.count == 1 }
    var primary: LoyaltyCard { cards[0] }
}

private extension Array where Element == LoyaltyCard {
    func toGroups() -> [CardGroup] {
        let dict = Dictionary(grouping: self) { $0.negocioId }
        // Mantener el orden de aparición del primer card de cada grupo
        var seen = Set<String>()
        var ordered: [String] = []
        for card in self {
            if !seen.contains(card.negocioId) {
                seen.insert(card.negocioId)
                ordered.append(card.negocioId)
            }
        }
        return ordered.compactMap { nid in
            guard let cards = dict[nid] else { return nil }
            return CardGroup(negocioId: nid, cards: cards)
        }
    }
}

// ─── TabCardsView ─────────────────────────────────────────────────────────────

struct TabCardsView: View {
    @EnvironmentObject var profileStore: ProfileStore
    @State private var showQRSheet: Bool = false

    @State private var cards: [LoyaltyCard] = []
    @State private var notifications: [NotificationItem] = []
    @State private var showNotifications = false
    @State private var bellBounce: CGFloat = 1

    @State private var hasError: Bool = false
    @State private var isLoading: Bool = true

    // Sello recibido — presentado cuando QRSheetView detecta el escaneo
    @State private var stampReceivedCard:  LoyaltyCard? = nil
    @State private var stampReceivedIndex: Int          = 0
    @State private var showStampReceived:  Bool         = false

    private let service: ClientServiceProtocol = APIClientService()

    // Wave stagger — un Animatable global 0→1, cada card mapea su franja
    @State private var listProgress: Double = 0

    private var unreadCount: Int { notifications.filter { !$0.isRead }.count }

    // Agrupación por negocio (Lote 2)
    private var groups: [CardGroup] { cards.toGroups() }

    // Calcula alpha y offset para el card i en función del progress global
    private func waveAlpha(_ i: Int) -> Double {
        let start = min(Double(i) * 0.13, 0.65)
        let end   = min(start + 0.38, 1.0)
        return ((listProgress - start) / (end - start)).clamped(to: 0...1)
    }
    private func waveOffset(_ i: Int) -> CGFloat {
        CGFloat(28 * (1 - waveAlpha(i)))
    }

    var body: some View {
        ZStack {
            Color.seilBg
                .ignoresSafeArea()

            ScrollView {
                SeillContentBox {
                LazyVStack(spacing: 0) {
                    // ── Header ────────────────────────────────────
                    headerRow
                        .padding(.horizontal, 22)
                        .padding(.top, 14)
                        .padding(.bottom, 10)

                    // ── Activity de amigos ────────────────────────
                    FriendsActivityBanner(listProgress: listProgress)
                        .padding(.bottom, 16)

                    // ── Section label ─────────────────────────────
                    HStack(spacing: 8) {
                        Text(SeillStrings.cards.myCards)
                            .font(SeillFont.micro())
                            .foregroundColor(.seilMuted)
                            .tracking(1.5)

                        // Pill contador — muestra negocios (grupos), no tarjetas
                        if !groups.isEmpty {
                            Text("\(groups.count)")
                                .font(SeillFont.micro())
                                .foregroundColor(.seilMuted2)
                                .padding(.horizontal, 7)
                                .padding(.vertical, 2)
                                .background(Color.seilCard2)
                                .clipShape(Capsule())
                                .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
                        }

                        Spacer()
                    }
                    .padding(.horizontal, 22)
                    .padding(.bottom, 10)
                    .opacity(listProgress > 0.05 ? 1 : 0)
                    .offset(y: listProgress > 0.05 ? 0 : 12)
                    .animation(SeillAnimation.listEntrance, value: listProgress)

                    // ── Cards ─────────────────────────────────────
                    // .animation envuelve el bloque condicional para que la
                    // transición skeleton → content sea un crossfade suave
                    // en lugar de un corte abrupto en el mismo frame.
                    Group {
                        if isLoading {
                            FullScreenSkeleton(cardCount: 3)
                                .transition(SeillTransitions.skeletonFade)
                        } else if hasError {
                            CardsErrorState {
                                hasError = false
                                Task { await refreshCards() }
                            }
                            .padding(.horizontal, 16)
                            .transition(SeillTransitions.skeletonFade)
                        } else if cards.isEmpty {
                            EmptyCardsState()
                                .padding(.horizontal, 16)
                                .transition(SeillTransitions.emptyState)
                        } else {
                            AdaptiveCardsGrid(
                                groups: groups,
                                listProgress: listProgress,
                                waveAlpha: waveAlpha,
                                waveOffset: waveOffset
                            )

                            // ExploreButton integrado al wave system
                            ExploreButton()
                                .padding(.horizontal, 16)
                                .padding(.top, 4)
                                .opacity(waveAlpha(groups.count))
                                .offset(y: waveOffset(groups.count))
                                .animation(SeillAnimation.listEntrance, value: listProgress)
                        }
                    }
                    .animation(.seillFade, value: isLoading)
                    .animation(.seillFade, value: hasError)

                    Spacer()
                }
                } // SeillContentBox
            }
            .ignoresSafeArea(.all, edges: .bottom)
            .contentMargins(.bottom, 32, for: .scrollContent)
            .refreshable {
                await refreshCards()
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    showNotifications = true
                } label: {
                    Image(systemName: unreadCount > 0 ? "bell.badge" : "bell")
                        .font(SeillFont.icon())
                        .foregroundColor(unreadCount > 0 ? .seilDanger : .primary)
                }
                .buttonStyle(.plain)
                .scaleEffect(bellBounce)

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    showQRSheet = true
                } label: {
                    Image(systemName: "qrcode.viewfinder")
                        .font(SeillFont.icon())
                }
                .buttonStyle(.plain)
            }
        }
        .sheet(isPresented: $showNotifications) {
            NotificationsView(notifications: $notifications)
                .presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showQRSheet) {
            QRSheetView(
                currentCards: cards,
                onStampReceived: { card, index in
                    // Actualizar tarjeta localmente sin esperar re-fetch
                    if let i = cards.firstIndex(where: { $0.id == card.id }) {
                        cards[i] = card
                    } else {
                        cards.append(card)
                    }
                    stampReceivedCard  = card
                    stampReceivedIndex = index
                    showStampReceived  = true
                }
            )
            .presentationDetents(adaptiveDetents(height: 560))
            .presentationDragIndicator(.hidden)
            .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showStampReceived) {
            if let card = stampReceivedCard {
                StampReceivedSheet(card: card, newStampIndex: stampReceivedIndex)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.hidden)
                    .presentationBackground(.ultraThinMaterial)
            }
        }
        .task {
            await runEntrance()
        }
    }

    // MARK: - Header
    private var headerRow: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(greeting)
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted)

                Text(profileStore.profile.firstName)
                    .font(SeillFont.display(24))
                    .foregroundColor(.seilText)
            }

            Spacer()

            AvatarView(avatarId: profileStore.profile.avatarId, size: 42)
        }
        .opacity(waveAlpha(-1))
        .offset(y: waveOffset(-1))
        .animation(SeillAnimation.panelCascade, value: listProgress)
    }

    // MARK: - Helpers
    private var greeting: String {
        SeillStrings.greeting.current
    }

    private func runEntrance() async {
        // ALTO: sin timeout el spinner/skeleton podía quedar infinito
        // si el backend no respondía. Ahora un Task paralelo activa
        // hasError a los 10s si isLoading sigue en true.
        let timeoutTask = Task {
            try? await Task.sleep(for: .seconds(10))
            guard !Task.isCancelled else { return }
            if isLoading {
                isLoading = false
                hasError  = true
            }
        }
        defer { timeoutTask.cancel() }

        // Cargar datos del backend
        async let cardsResult = service.getTarjetas()
        async let notifsResult = service.getNotificaciones()

        if case .success(let c) = await cardsResult {
            cards = c
        } else {
            hasError = true
        }
        if case .success(let n) = await notifsResult {
            notifications = n
        }
        isLoading = false

        let duration = 0.4 + Double(groups.count) * 0.08
        withAnimation(.easeOut(duration: duration)) {
            listProgress = 1.0
        }

        if unreadCount > 0 {
            try? await Task.sleep(for: .seconds(0.95))
            await tripleBellBounce()
        }
    }

    private func tripleBellBounce() async {
        withAnimation(SeillAnimation.microBounce) { bellBounce = 1.20 }
        try? await Task.sleep(for: .seconds(0.12))
        withAnimation(.spring(response: 0.16, dampingFraction: 0.55)) { bellBounce = 0.90 }
        try? await Task.sleep(for: .seconds(0.10))
        withAnimation(.spring(response: 0.16, dampingFraction: 0.60)) { bellBounce = 1.06 }
        try? await Task.sleep(for: .seconds(0.08))
        withAnimation(.spring(response: 0.20, dampingFraction: 0.70)) { bellBounce = 1.00 }
    }

    private func refreshCards() async {
        // Resetear el wave para que las tarjetas actualizadas re-animen la entrada.
        withAnimation(.easeOut(duration: 0.15)) { listProgress = 0 }

        if case .success(let c) = await service.getTarjetas() {
            cards = c
            hasError = false
        }
        if case .success(let n) = await service.getNotificaciones() {
            notifications = n
        }
        syncWidget()

        let duration = 0.4 + Double(groups.count) * 0.08
        withAnimation(.easeOut(duration: duration)) { listProgress = 1.0 }
    }

    private func syncWidget() {
        let widgetCards = cards.map { card in
            WidgetCard(
                id:           card.id,
                bizName:      card.bizName,
                rewardText:   card.rewardText,
                filledStamps: card.filledStamps,
                totalStamps:  card.totalStamps,
                icon:         card.icon,
                colorHex:     card.stampColorHex,
                location:     card.location
            )
        }
        AppGroupStore.write(cards: widgetCards)
        WidgetCenter.shared.reloadAllTimelines()
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - AdaptiveCardsGrid (actualizado para grupos — Lote 2)
// ═══════════════════════════════════════════════════════════════════════════════

private struct AdaptiveCardsGrid: View {
    let groups: [CardGroup]
    let listProgress: Double
    let waveAlpha: (Int) -> Double
    let waveOffset: (Int) -> CGFloat

    @Environment(\.horizontalSizeClass) private var hSizeClass

    // Namespace compartido para la transición de zoom card → detalle.
    // Vive aquí — no necesita propagarse fuera de esta struct.
    // iOS 18+: la card se expande para llenar la pantalla, el tab bar
    // se desvanece dentro del movimiento del zoom. Al volver, la card
    // colapsa de vuelta a su posición y el tab bar reaparece en el mismo
    // arco — sin el frame separado que causaba el pop brusco.
    @Namespace private var cardZoom

    var body: some View {
        if hSizeClass == .regular {
            // iPad: grid
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible())],
                spacing: 14
            ) {
                ForEach(Array(groups.enumerated()), id: \.element.id) { i, group in
                    if group.isSingle {
                        NavigationLink {
                            CardDetailScreen(card: group.primary)
                                .navigationTransition(.zoom(sourceID: group.id, in: cardZoom))
                        } label: {
                            LoyaltyCardRow(card: group.primary)
                                .matchedTransitionSource(id: group.id, in: cardZoom)
                        }
                        .buttonStyle(CardPressStyle())
                        .opacity(waveAlpha(i))
                        .offset(y: waveOffset(i))
                        .animation(SeillAnimation.listEntrance, value: listProgress)
                    } else {
                        GroupedLoyaltyCardRow(group: group)
                            .opacity(waveAlpha(i))
                            .offset(y: waveOffset(i))
                            .animation(SeillAnimation.listEntrance, value: listProgress)
                    }
                }
            }
            .padding(.horizontal, 16)
        } else {
            // iPhone: lista vertical
            ForEach(Array(groups.enumerated()), id: \.element.id) { i, group in
                if group.isSingle {
                    NavigationLink {
                        CardDetailScreen(card: group.primary)
                            .navigationTransition(.zoom(sourceID: group.id, in: cardZoom))
                    } label: {
                        LoyaltyCardRow(card: group.primary)
                            .matchedTransitionSource(id: group.id, in: cardZoom)
                    }
                    .buttonStyle(CardPressStyle())
                    .opacity(waveAlpha(i))
                    .offset(y: waveOffset(i))
                    .animation(SeillAnimation.listEntrance, value: listProgress)
                } else {
                    GroupedLoyaltyCardRow(group: group)
                        .opacity(waveAlpha(i))
                        .offset(y: waveOffset(i))
                        .animation(SeillAnimation.listEntrance, value: listProgress)
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - GroupedLoyaltyCardRow (NUEVO — Lote 2)
// ═══════════════════════════════════════════════════════════════════════════════
/// Tarjeta agrupada que muestra múltiples programas de un mismo negocio.
/// Expandida por defecto. Tap en el header colapsa/expande.
/// Tap en cada ProgramRow navega al detalle de esa tarjeta.

private struct GroupedLoyaltyCardRow: View {
    let group: CardGroup

    @State private var expanded = true
    @State private var pressed  = false

    // Namespace propio para los ProgramRow dentro del grupo.
    // Independiente del namespace de AdaptiveCardsGrid — cada nivel
    // de navegación maneja su propia transición.
    @Namespace private var programZoom

    private var primary: LoyaltyCard { group.primary }

    // CRÍTICO: antes todo el texto era .white hardcodeado.
    // En modo claro los gradientes son pasteles muy suaves (opacity 0.10–0.22)
    // → el blanco tiene contraste ~1.2:1, ilegible.
    // Mismo patrón que gradientForCategory: leer userInterfaceStyle.
    private var isDark: Bool {
        UITraitCollection.current.userInterfaceStyle == .dark
    }
    private var textPrimary: Color {
        isDark ? .white : primary.stampColor.opacity(0.92)
    }
    private var textSecondary: Color {
        isDark ? .white.opacity(0.50) : primary.stampColor.opacity(0.60)
    }
    private var textTertiary: Color {
        isDark ? .white.opacity(0.40) : primary.stampColor.opacity(0.45)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // ── Header del negocio (tap = expand/collapse) ───────────
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    expanded.toggle()
                }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: primary.icon)
                        .font(.system(size: 16))
                        .foregroundColor(primary.stampColor)

                    Text(primary.bizName)
                        .font(SeillFont.headline(15))
                        .foregroundColor(textPrimary)
                        .lineLimit(1)

                    Spacer()

                    // Pill con conteo de programas
                    Text("\(group.cards.count) programas")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(primary.stampColor)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(primary.stampColor.opacity(0.15))
                        .clipShape(Capsule())
                        .overlay(
                            Capsule().stroke(primary.stampColor.opacity(0.3), lineWidth: 1)
                        )

                    // Chevron animado
                    Image(systemName: "chevron.right")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(textSecondary)
                        .rotationEffect(.degrees(expanded ? 90 : 0))
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: expanded)
                }
            }
            .buttonStyle(.plain)

            Spacer().frame(height: 2)

            Text(primary.location)
                .font(SeillFont.caption(10))
                .foregroundColor(textSecondary)

            // ── Filas de programas (expandibles) ─────────────────────
            if expanded {
                VStack(spacing: 8) {
                    Spacer().frame(height: 6)

                    // Separador
                    Rectangle()
                        .fill(textSecondary.opacity(0.20))
                        .frame(height: 1)

                    Spacer().frame(height: 4)

                    ForEach(group.cards) { card in
                        NavigationLink {
                            CardDetailScreen(card: card)
                                .navigationTransition(.zoom(sourceID: card.id, in: programZoom))
                        } label: {
                            ProgramRow(card: card)
                                .matchedTransitionSource(id: card.id, in: programZoom)
                        }
                        .buttonStyle(ProgramRowPressStyle())
                    }
                }
                .transition(
                    .asymmetric(
                        insertion: .opacity.combined(with: .move(edge: .top)).animation(.easeOut(duration: 0.25)),
                        removal: .opacity.animation(.easeIn(duration: 0.15))
                    )
                )
            } else {
                // Hint colapsado
                Text("Toca para ver los \(group.cards.count) programas")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(textTertiary)
                    .padding(.top, 10)
            }
        }
        .padding(18)
        .background(
            LinearGradient(
                colors: primary.gradientColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        // Glass highlight — igual que LoyaltyCardRow
        .overlay(alignment: .top) {
            LinearGradient(
                colors: [.clear, .white.opacity(0.20), .white.opacity(0.20), .clear],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(height: 1)
        }
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(primary.stampColor.opacity(isDark ? 0.08 : 0.15), lineWidth: 1)
        )
        .shadow(color: primary.stampColor.opacity(0.08), radius: 16, y: 8)
        .padding(.horizontal, 16)
        .padding(.bottom, 14)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - ProgramRow (NUEVO — Lote 2)
// ═══════════════════════════════════════════════════════════════════════════════
/// Fila compacta de un programa dentro de la tarjeta agrupada.
/// Muestra: nombre del programa, sellos compactos, conteo, chevron.

private struct ProgramRow: View {
    let card: LoyaltyCard

    private var isDark: Bool {
        UITraitCollection.current.userInterfaceStyle == .dark
    }
    private var textPrimary: Color {
        isDark ? .white : card.stampColor.opacity(0.90)
    }
    private var textSecondary: Color {
        isDark ? .white.opacity(0.45) : card.stampColor.opacity(0.55)
    }

    var body: some View {
        HStack(spacing: 10) {
            // Nombre del programa
            VStack(alignment: .leading, spacing: 2) {
                Text(card.rewardText)
                    .font(SeillFont.label(12))
                    .foregroundColor(textPrimary)
                    .lineLimit(1)

                if card.isComplete {
                    Text("¡Premio listo!")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(card.stampColor)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Sellos compactos (máx 8)
            CompactStampsRow(card: card, maxVisible: 8)

            // Conteo numérico
            HStack(spacing: 0) {
                Text("\(card.filledStamps)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(card.stampColor)
                Text("/\(card.totalStamps)")
                    .font(.system(size: 11))
                    .foregroundColor(textSecondary)
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 10))
                .foregroundColor(textSecondary.opacity(0.60))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            LinearGradient(
                colors: card.gradientColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(card.stampColor.opacity(0.25), lineWidth: 1)
        )
    }
}

// ── ProgramRow press style ────────────────────────────────────────────────────
private struct ProgramRowPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.spring(response: 0.2, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - CompactStampsRow (NUEVO — Lote 2)
// ═══════════════════════════════════════════════════════════════════════════════
/// Sellos compactos (16pt) para las filas de programa dentro de grupos.

private struct CompactStampsRow: View {
    let card: LoyaltyCard
    var maxVisible: Int = 8
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }

    var body: some View {
        HStack(spacing: 3) {
            let visible = min(card.totalStamps, maxVisible)
            ForEach(0..<visible, id: \.self) { i in
                let filled = i < card.filledStamps
                ZStack {
                    Circle()
                        .fill(filled
                              ? card.stampColor.opacity(isDark ? 0.25 : 0.20)
                              : (isDark ? Color.white.opacity(0.06) : card.stampColor.opacity(0.12)))
                        .frame(width: 16, height: 16)
                        .overlay(
                            Circle().stroke(
                                filled
                                    ? card.stampColor.opacity(isDark ? 0.6 : 0.5)
                                    : (isDark ? Color.white.opacity(0.10) : card.stampColor.opacity(0.30)),
                                lineWidth: 1
                            )
                        )

                    if filled {
                        Image(systemName: "checkmark")
                            .font(.system(size: 7, weight: .bold))
                            .foregroundColor(card.stampColor)
                    }
                }
            }

            if card.totalStamps > maxVisible {
                ZStack {
                    Circle()
                        .fill(isDark ? Color.white.opacity(0.06) : card.stampColor.opacity(0.12))
                        .frame(width: 16, height: 16)
                    Text("+\(card.totalStamps - maxVisible)")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundColor(isDark ? .white.opacity(0.45) : card.stampColor.opacity(0.70))
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - LoyaltyCardRow (sin cambios funcionales)
// ═══════════════════════════════════════════════════════════════════════════════

struct LoyaltyCardRow: View {
    let card: LoyaltyCard
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }
    private var textMain:  Color { isDark ? .white                 : card.stampColor }
    private var textSub:   Color { isDark ? .white.opacity(0.50)   : card.stampColor.opacity(0.70) }
    private var textHint:  Color { isDark ? .white.opacity(0.35)   : card.stampColor.opacity(0.55) }
    private var borderClr: Color { isDark ? .white.opacity(0.08)   : card.stampColor.opacity(0.35) }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: 8) {
                Image(systemName: card.icon)
                    .font(.system(size: 16))
                    .foregroundColor(card.stampColor)

                Text(card.bizName)
                    .font(SeillFont.headline(15))
                    .foregroundColor(textMain)
                    .lineLimit(1)

                if card.isComplete {
                    Text(SeillStrings.cards.rewardReady)
                        .font(SeillFont.badge())
                        .foregroundColor(.seilGreen)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.seilGreen.opacity(0.14))
                        .clipShape(Capsule())
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(SeillFont.label(12))
                    .foregroundColor(textHint)
            }

            Spacer().frame(height: 2)

            Text(card.location)
                .font(SeillFont.caption(10))
                .foregroundColor(textSub)

            Spacer().frame(height: 14)

            StampsRowView(card: card)

            Spacer().frame(height: 12)

            HStack {
                cardProgressText
                    .font(SeillFont.label(11))

                Spacer()

                Text(card.isComplete ? "Toca para canjear" : "Toca para ver detalle")
                    .font(SeillFont.headline(10))
                    .foregroundColor(textHint)
                    .lineLimit(1)
            }
        }
        .padding(18)
        .background(
            LinearGradient(
                colors: card.gradientColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(borderClr, lineWidth: 1)
        )
        .contentShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: card.stampColor.opacity(isDark ? 0.08 : 0.22), radius: 20, y: 6)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(card.bizName), \(card.filledStamps) de \(card.totalStamps) sellos, \(card.isComplete ? "premio listo para canjear" : "\(card.remainingStamps) sellos restantes")")
        .accessibilityHint(card.isComplete ? "Toca para canjear tu premio" : "Toca para ver detalle de la tarjeta")
        .padding(.horizontal, 16)
        .padding(.bottom, 14)
    }

    private var cardProgressText: Text {
        Text("\(Text("\(card.filledStamps)").foregroundColor(card.stampColor))\(Text("/\(card.totalStamps)").foregroundColor(textSub))\(Text(card.remainingStamps <= 2 && !card.isComplete ? " · ¡Casi listo!" : "").foregroundColor(textSub))")
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - EmptyCardsState (sin cambios)
// ═══════════════════════════════════════════════════════════════════════════════

struct EmptyCardsState: View {
    @State private var iconVisible:  Bool   = false
    @State private var textVisible:  Bool   = false
    @State private var dotsVisible:  Bool   = false
    @State private var pulse:        Bool   = false

    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .stroke(Color.seilAccent.opacity(0.18), lineWidth: 1.5)
                    .frame(width: pulse ? 96 : 72, height: pulse ? 96 : 72)
                    .animation(
                        .easeInOut(duration: 1.4).repeatForever(autoreverses: true),
                        value: pulse
                    )

                Circle()
                    .fill(Color.seilAccent.opacity(0.12))
                    .frame(width: 68, height: 68)
                    .overlay(Circle().stroke(Color.seilAccent, lineWidth: 2.5))

                Image(systemName: "sparkles")
                    .font(SeillFont.icon(28))
                    .foregroundColor(.seilAccent)
            }
            .scaleEffect(iconVisible ? 1 : 0)
            .opacity(iconVisible ? 1 : 0)

            VStack(spacing: 8) {
                Text(SeillStrings.cards.emptyTitle)
                    .font(SeillFont.title(17))
                    .foregroundColor(.seilText)

                Text("Encuentra un negocio, escanea tu QR\ny empieza a coleccionar sellos.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }
            .opacity(textVisible ? 1 : 0)
            .offset(y: textVisible ? 0 : 20)

            VStack(spacing: 6) {
                EmptyStateDots(visible: dotsVisible)

                Text("Así se verá tu tarjeta al acumular sellos")
                    .font(SeillFont.caption(10))
                    .foregroundColor(.seilMuted)
                    .opacity(dotsVisible ? 1 : 0)
            }

            NavigationLink(destination: ExploreView()) {
                HStack(spacing: 8) {
                    Image(systemName: "safari.fill")
                        .font(.system(size: 14))
                    Text(SeillStrings.cards.findFirst)
                        .font(SeillFont.headline(14))
                    Image(systemName: "arrow.right")
                        .font(.system(size: 13))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .shadow(color: Color.seilAccent.opacity(0.35), radius: 12, y: 4)
            }
            .buttonStyle(.plain)
            .opacity(textVisible ? 1 : 0)
        }
        .padding(28)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.seilBorder, lineWidth: 1))
        .onAppear {
            withAnimation(.spring(response: 0.50, dampingFraction: 0.58).delay(0.12)) {
                iconVisible = true
            }
            withAnimation(.easeOut(duration: 0.38).delay(0.55)) {
                textVisible = true
            }
            // BAJO: DispatchQueue mezclado con SwiftUI animation system.
            // Reemplazado por Task.sleep — consistente con el resto del proyecto.
            Task {
                try? await Task.sleep(for: .milliseconds(450))
                pulse = true
                try? await Task.sleep(for: .milliseconds(300))
                dotsVisible = true
            }
        }
    }
}

// ─── EmptyStateDots ───────────────────────────────────────────────────────────
private struct EmptyStateDots: View {
    let visible: Bool

    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<8, id: \.self) { i in
                EmptyDot(index: i, visible: visible)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.seilCard2)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilBorder, lineWidth: 1))
    }
}

private struct EmptyDot: View {
    let index: Int
    let visible: Bool

    var body: some View {
        Circle()
            .fill(index == 0
                  ? Color.seilAccent.opacity(0.25)
                  : Color.seilBorder.opacity(0.5))
            .frame(width: 22, height: 22)
            .overlay(
                Circle().stroke(
                    index == 0 ? Color.seilAccent.opacity(0.6) : Color.seilBorder,
                    lineWidth: 1.5
                )
            )
            .overlay(
                Group {
                    if index == 0 {
                        Image(systemName: "star.fill")
                            .font(.system(size: 9))
                            .foregroundColor(.seilAccent)
                    }
                }
            )
            .scaleEffect(visible ? 1 : 0)
            .animation(
                .spring(response: 0.40, dampingFraction: 0.60)
                    .delay(Double(index) * 0.055),
                value: visible
            )
    }
}

// ─── AvatarView ───────────────────────────────────────────────────────────────
struct AvatarView: View {
    let avatarId: Int
    let size: CGFloat

    private var option: (icon: String, color: Color) {
        UserProfile.avatarOptions[avatarId % UserProfile.avatarOptions.count]
    }

    var body: some View {
        ZStack {
            Circle()
                .fill(option.color)
                .frame(width: size, height: size)
                .shadow(color: option.color.opacity(0.38), radius: 10, y: 3)

            Image(systemName: option.icon)
                .font(.system(size: size * 0.42))
                .foregroundColor(.white)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Avatar de perfil")
    }
}

// ─── CardPressStyle ───────────────────────────────────────────────────────────
struct CardPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.965 : 1.0)
            .animation(SeillAnimation.buttonPress, value: configuration.isPressed)
    }
}

// ─── ExploreButton ────────────────────────────────────────────────────────────
private struct ExploreButton: View {
    @State private var arrowOffset: CGFloat = 0

    var body: some View {
        NavigationLink(destination: ExploreView()) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.seilAccent.opacity(0.12))
                        .frame(width: 32, height: 32)
                    Image(systemName: "safari.fill")
                        .font(.system(size: 13))
                        .foregroundColor(.seilAccent)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("Explorar negocios")
                        .font(SeillFont.label(13))
                        .foregroundColor(.seilText)
                    Text("Encuentra locales con programas activos")
                        .font(SeillFont.caption(10))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                Image(systemName: "arrow.right")
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilAccent)
                    .offset(x: arrowOffset)
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 16)
            .background(
                LinearGradient(
                    colors: [Color.seilAccent.opacity(0.06), Color.seilAccent.opacity(0.03)],
                    startPoint: .leading, endPoint: .trailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.seilAccent.opacity(0.18), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .onAppear {
            withAnimation(.easeInOut(duration: 0.80).repeatForever(autoreverses: true)) {
                arrowOffset = 4
            }
        }
    }
}

// ─── CardsErrorState ──────────────────────────────────────────────────────────
private struct CardsErrorState: View {
    let onRetry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.seilDanger.opacity(0.08))
                    .frame(width: 60, height: 60)
                    .overlay(Circle().stroke(Color.seilDanger.opacity(0.20), lineWidth: 1))
                Image(systemName: "wifi.slash")
                    .font(SeillFont.icon(22))
                    .foregroundColor(.seilDanger)
            }

            VStack(spacing: 6) {
                Text("No pudimos cargar tus tarjetas")
                    .font(SeillFont.title(16))
                    .foregroundColor(.seilText)

                Text("Revisa tu conexión e inténtalo de nuevo.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
            }

            Button(action: {
                // BAJO: el botón de retry no tenía haptic — el usuario
                // no sabía si el tap fue registrado durante una carga lenta.
                Haptics.tap()
                onRetry()
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "arrow.clockwise")
                        .font(SeillFont.headline(13))
                    Text("Reintentar")
                        .font(SeillFont.label(14))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 32)
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .stroke(Color.seilDanger.opacity(0.20), lineWidth: 1)
        )
    }
}
