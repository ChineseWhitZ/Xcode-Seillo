import SwiftUI

struct TabPremiosView: View {
    @State private var cards: [LoyaltyCard] = []
    @State private var showHistory = false
    @State private var redeemCard: LoyaltyCard? = nil
    @State private var hasError:              Bool   = false
    @State private var listProgress:          Double = 0
    @State private var animHighlightProgress: Double = 0
    @State private var animRachaProgress:     Double = 0

    private let service: ClientServiceProtocol = APIClientService()

    // Fechas reales del historial para calcular la racha
    @State private var rachaDates: [Date] = []
    private var racha: RachaData { calcularRacha(from: rachaDates) }

    private func wAlpha(_ i: Int) -> Double {
        let s = min(Double(i) * 0.12, 0.60)
        let e = min(s + 0.40, 1.0)
        return ((listProgress - s) / (e - s)).clamped(to: 0...1)
    }
    private func wOffset(_ i: Int) -> CGFloat { CGFloat(18 * (1 - wAlpha(i))) }

    private var ready: [LoyaltyCard] {
        cards.filter { $0.isComplete }
    }

    private var pending: [LoyaltyCard] {
        cards
            .filter { !$0.isComplete }
            .sorted { $0.progress > $1.progress }
    }

    private var totalStamps: Int {
        cards.reduce(0) { $0 + $1.filledStamps }
    }

    private var nextRewardCard: LoyaltyCard? {
        pending.max { $0.progress < $1.progress }
    }

    var body: some View {
        ZStack {
            Color.seilBg
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
              SeillContentBox {
                LazyVStack(spacing: 0) {
                    headerSection
                        .padding(.horizontal, 22)
                        .padding(.top, 18)
                        .padding(.bottom, 18)

                    statsSection
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)

                    if totalStamps > 0 {
                        rachaCard
                            .padding(.horizontal, 16)
                            .padding(.bottom, 20)
                            .opacity(listProgress > 0.10 ? 1 : 0)
                            .offset(y: listProgress > 0.10 ? 0 : 12)
                    }

                    if hasError {
                        PremiosErrorState {
                            hasError = false
                            withAnimation(SeillAnimation.listEntrance) { listProgress = 1.0 }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                        .transition(.opacity)
                    } else if cards.isEmpty {
                        emptyState
                            .padding(.horizontal, 16)
                            .padding(.top, 18)
                    } else {
                        if let nextRewardCard {
                            nextRewardHighlight(card: nextRewardCard)
                                .padding(.horizontal, 16)
                                .padding(.bottom, 22)
                        }

                        if !ready.isEmpty {
                            sectionLabel("LISTOS PARA CANJEAR")
                                .opacity(listProgress > 0.05 ? 1 : 0)
                                .offset(y: listProgress > 0.05 ? 0 : 10)

                            ForEach(Array(ready.enumerated()), id: \.element.id) { i, card in
                                RewardCard(
                                    card: card,
                                    buttonTitle: "Canjear",
                                    actionColor: .seilGreen
                                ) {
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                    redeemCard = card
                                }
                                .opacity(wAlpha(i))
                                .offset(y: wOffset(i))
                            }

                            Spacer().frame(height: 8)
                        }

                        if !pending.isEmpty {
                            sectionLabel("EN PROGRESO")
                                .opacity(listProgress > 0.05 ? 1 : 0)
                                .offset(y: listProgress > 0.05 ? 0 : 10)

                            ForEach(Array(pending.enumerated()), id: \.element.id) { i, card in
                                NavigationLink {
                                    CardDetailScreen(card: card)
                                } label: {
                                    RewardCardStatic(
                                        card: card,
                                        buttonTitle: "Ver detalle",
                                        actionColor: card.stampColor
                                    )
                                }
                                .buttonStyle(CardPressStyle())
                                .opacity(wAlpha(ready.count + i))
                                .offset(y: wOffset(ready.count + i))
                            }
                        }
                    }

                }
              } // SeillContentBox
            }
            .ignoresSafeArea(.all, edges: .bottom)
            .contentMargins(.bottom, 32, for: .scrollContent)
            .refreshable {
                async let tarjetasResult  = service.getTarjetas()
                async let historialResult = service.getHistorial()

                if case .success(let c) = await tarjetasResult {
                    cards = c
                    hasError = false
                }
                if case .success(let h) = await historialResult {
                    rachaDates = h.compactMap { entry in
                        parseISODate(entry.date)
                    }
                }
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    showHistory = true
                } label: {
                    Label("Historial", systemImage: "clock.arrow.circlepath")
                        .labelStyle(.iconOnly)
                        .font(.system(size: 18, weight: .semibold))
                }
                .buttonStyle(.plain)
            }
        }
        .sheet(isPresented: $showHistory) {
            HistoryView()
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(item: $redeemCard) { card in
            RedeemSheetView(card: card)
                .presentationDetents(adaptiveDetents(height: 480))
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .task {
            // Cargar tarjetas e historial en paralelo
            async let tarjetasResult  = service.getTarjetas()
            async let historialResult = service.getHistorial()

            if case .success(let c) = await tarjetasResult {
                cards = c
            }

            // Extraer fechas del historial para la racha
            if case .success(let h) = await historialResult {
                rachaDates = h.compactMap { entry in
                    parseISODate(entry.date)
                }
            }

            withAnimation(SeillAnimation.listEntrance) { listProgress = 1.0 }
            try? await Task.sleep(nanoseconds: 180_000_000)
            withAnimation(.easeOut(duration: 0.85)) {
                let r = racha
                let record = Double(r.diasRecord)
                animRachaProgress = (record > 0 && r.diasActuales > 0) ? min(Double(r.diasActuales) / record, 1.0) : (r.diasActuales > 0 ? 1.0 : 0.0)
            }

            if let card = nextRewardCard {
                try? await Task.sleep(nanoseconds: 280_000_000)
                withAnimation(.easeOut(duration: 0.72)) { animHighlightProgress = card.progress }
            }
        }
    }

    private var headerSection: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Mis Premios")
                    .font(SeillFont.display(24))
                    .foregroundColor(.seilText)

                Text("Sigue tus recompensas y canjea lo que ya desbloqueaste")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
            }

            Spacer()
        }
        .opacity(listProgress > 0.02 ? 1 : 0)
        .offset(y: listProgress > 0.02 ? 0 : 10)
    }

    private var statsSection: some View {
        HStack(spacing: 10) {
            PremioStatBadge(
                label: "Listos",
                value: "\(ready.count)",
                color: .seilGreen,
                icon: "trophy.fill"
            )

            PremioStatBadge(
                label: "En progreso",
                value: "\(pending.count)",
                color: .seilAccent,
                icon: "hourglass"
            )

            PremioStatBadge(
                label: "Total sellos",
                value: "\(totalStamps)",
                color: .seilBlue,  // antes: Color(hex: "#4F9FFF")
                icon: "checkmark.circle.fill"
            )
        }
        .opacity(listProgress > 0.08 ? 1 : 0)
        .offset(y: listProgress > 0.08 ? 0 : 12)
    }

    // MARK: - Racha card

    private var rachaCard: some View {
        let rachaData = racha
        let dias      = rachaData.diasActuales
        let record    = rachaData.diasRecord
        let isOnFire  = dias >= 3

        return VStack(spacing: 14) {

            // ── Header ────────────────────────────────────────────────────
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(isOnFire ? Color.seilRose.opacity(0.14) : Color.seilAccent.opacity(0.12))
                        .frame(width: 40, height: 40)
                    Image(systemName: isOnFire ? "flame.fill" : "calendar.badge.checkmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(isOnFire ? .seilRose : .seilAccent)
                }

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(isOnFire ? "¡Racha activa!" : "Racha de visitas")
                            .font(SeillFont.display(14))
                            .foregroundColor(.seilText)
                        if isOnFire {
                            Text("")
                                .font(.system(size: 13))
                        }
                    }
                    Text("\(dias) día\(dias == 1 ? "" : "s") seguidos · Récord: \(record) días")
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                // Número grande de días
                VStack(spacing: 0) {
                    Text("\(dias)")
                        .font(SeillFont.display(28))
                        .foregroundColor(isOnFire ? .seilRose : .seilAccent)
                        .contentTransition(.numericText())
                    Text("días")
                        .font(SeillFont.micro(9))
                        .foregroundColor(.seilMuted)
                        .tracking(0.5)
                }
            }

            // ── Círculos de la semana ─────────────────────────────────────
            let dayLabels = ["L", "M", "Mi", "J", "V", "S", "Hoy"]
            HStack(spacing: 0) {
                ForEach(Array(zip(dayLabels, rachaData.actividadSemana)), id: \.0) { label, active in
                    VStack(spacing: 5) {
                        ZStack {
                            Circle()
                                .fill(active
                                      ? (isOnFire ? Color.seilRose : Color.seilAccent)
                                      : Color.white.opacity(0.06))
                                .frame(width: 30, height: 30)
                            if active {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 10, weight: .heavy))
                                    .foregroundColor(.white)
                            }
                        }
                        Text(label)
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(active ? (isOnFire ? .seilRose : .seilAccent) : .seilMuted)
                    }
                    .frame(maxWidth: .infinity)
                }
            }

            // ── Barra de progreso hacia récord ────────────────────────────
            VStack(alignment: .leading, spacing: 6) {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 6)
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: isOnFire
                                        ? [Color.seilRose.opacity(0.7), Color.seilRose]
                                        : [Color.seilAccent.opacity(0.7), Color.seilAccent],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: geo.size.width * animRachaProgress, height: 6)
                            .animation(.easeOut(duration: 0.85), value: animRachaProgress)
                    }
                }
                .frame(height: 6)

                HStack {
                    Text(dias >= record ? "¡Igualaste tu récord!" : "Faltan \(record - dias) días para tu récord")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.seilMuted)
                    Spacer()
                    Text("Récord: \(record) días")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(isOnFire ? .seilRose : .seilAccent)
                }
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: isOnFire
                    ? [Color.seilRose.opacity(0.07), Color.seilRose.opacity(0.02)]
                    : [Color.seilAccent.opacity(0.06), Color.seilAccent.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(
                    isOnFire ? Color.seilRose.opacity(0.20) : Color.seilAccent.opacity(0.18),
                    lineWidth: 1
                )
        )
    }

    private var emptyState: some View {
        VStack(spacing: 18) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.10))
                    .frame(width: 76, height: 76)
                    .overlay(
                        Circle()
                            .stroke(Color.seilAccent.opacity(0.18), lineWidth: 1.5)
                    )

                Image(systemName: "gift")
                    .font(SeillFont.icon(28))
                    .foregroundColor(.seilAccent)
            }

            VStack(spacing: 8) {
                Text("Aún no tienes premios")
                    .font(SeillFont.headline(16))
                    .foregroundColor(.seilText)

                Text("Visita un negocio, acumula sellos y aquí verás tus recompensas listas y en progreso.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }
        }
        .padding(28)
        .frame(maxWidth: .infinity)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(listProgress > 0.14 ? 1 : 0)
        .offset(y: listProgress > 0.14 ? 0 : 16)
    }

    @ViewBuilder
    private func nextRewardHighlight(card: LoyaltyCard) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("MÁS CERCA DE DESBLOQUEARSE")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)

                Spacer()
            }

            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(card.stampColor.opacity(0.12))
                        .frame(width: 50, height: 50)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(card.stampColor.opacity(0.22), lineWidth: 1)
                        )

                    Image(systemName: card.icon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(card.stampColor)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(card.bizName)
                        .font(SeillFont.headline(15))
                        .foregroundColor(.seilText)

                    Text(card.rewardText)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }

                Spacer()
            }

            VStack(alignment: .leading, spacing: 8) {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 8)

                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [card.stampColor.opacity(0.7), card.stampColor],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: geo.size.width * animHighlightProgress, height: 8)
                    }
                }
                .frame(height: 8)

                HStack {
                    Text("Te faltan \(card.remainingStamps) sello\(card.remainingStamps == 1 ? "" : "s")")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.seilMuted2)

                    Spacer()

                    NavigationLink {
                        CardDetailScreen(card: card)
                    } label: {
                        Text("Ver detalle")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 9)
                            .background(card.stampColor)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(18)
        .background(
            LinearGradient(
                colors: [
                    Color.white.opacity(0.035),
                    Color.white.opacity(0.018)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .background(.ultraThinMaterial.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 22))
        // seilBorderGlass
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorderGlass, lineWidth: 1)
        )
        .shadow(color: card.stampColor.opacity(0.10), radius: 14, y: 6)
        .opacity(listProgress > 0.10 ? 1 : 0)
        .offset(y: listProgress > 0.10 ? 0 : 14)
    }

    @ViewBuilder
    private func sectionLabel(_ text: String) -> some View {
        HStack {
            Text(text)
                .font(SeillFont.micro())
                .foregroundColor(.seilMuted)
                .tracking(1.5)

            Spacer()
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 10)
    }
}

// ─── calcularRacha ────────────────────────────────────────────────────────────
// Acepta un array de Date (fechas de actividad del usuario).
// Con mock: se pasan fechas aproximadas derivadas del historial.
// Con datos reales: pasar historialReal.map { parseISO($0.created_at) }
func calcularRacha(from fechas: [Date]) -> RachaData {
    let empty = RachaData(diasActuales: 0, diasRecord: 0, actividadSemana: Array(repeating: false, count: 7))
    guard !fechas.isEmpty else { return empty }

    let cal   = Calendar.current
    let today = cal.startOfDay(for: Date())

    let diasConActividad = Set(fechas.map { cal.startOfDay(for: $0) })
    let sorted = diasConActividad.sorted(by: >)

    // ── Racha actual ─────────────────────────────────────────────────────
    var rachaActual = 0
    var check = today

    if !diasConActividad.contains(today) {
        check = cal.date(byAdding: .day, value: -1, to: today)!
        guard diasConActividad.contains(check) else {
            return buildRachaData(actual: 0, sorted: sorted, cal: cal, today: today, diasSet: diasConActividad)
        }
    }
    rachaActual = 1
    check = cal.date(byAdding: .day, value: -1, to: check)!
    while diasConActividad.contains(check) {
        rachaActual += 1
        check = cal.date(byAdding: .day, value: -1, to: check)!
    }

    return buildRachaData(actual: rachaActual, sorted: sorted, cal: cal, today: today, diasSet: diasConActividad)
}

private func buildRachaData(
    actual:  Int,
    sorted:  [Date],
    cal:     Calendar,
    today:   Date,
    diasSet: Set<Date>
) -> RachaData {
    // ── Récord histórico ─────────────────────────────────────────────────
    var record  = max(actual, 1)
    var current = 1
    for i in 1..<sorted.count {
        let diff = cal.dateComponents([.day], from: sorted[i], to: sorted[i - 1]).day ?? 0
        if diff == 1 {
            current += 1
            record = max(record, current)
        } else {
            current = 1
        }
    }
    record = max(record, actual)

    // ── Actividad de la semana (Lun=0 … Dom=6) ──────────────────────────
    let weekday      = cal.component(.weekday, from: today)
    let daysFromMon  = (weekday + 5) % 7
    let monday       = cal.date(byAdding: .day, value: -daysFromMon, to: today)!
    let actividadSemana: [Bool] = (0..<7).map { offset in
        let day = cal.date(byAdding: .day, value: offset, to: monday)!
        return diasSet.contains(day)
    }

    return RachaData(diasActuales: actual, diasRecord: record, actividadSemana: actividadSemana)
}

// ─── parseISODate ─────────────────────────────────────────────────────────────
// Convierte el string de fecha relativa que devuelve HistoryEntry.date
// (ej. "Hoy · 10:42") a un Date aproximado para calcular la racha.
// Convierte los strings que produce formatRelativeDate() a un Date para calcular la racha.
// formatRelativeDate produce: "Ahora", "Hace Xmin", "Hace Xh", "Hace Xd", "DD MMM"
private func parseISODate(_ relativeDate: String) -> Date? {
    let cal   = Calendar.current
    let today = cal.startOfDay(for: Date())
    let lower = relativeDate.lowercased().trimmingCharacters(in: .whitespaces)

    // "Ahora" — ocurrió hace segundos → hoy
    if lower == "ahora" { return today }

    // "Hace Xmin" — ocurrió hace minutos → hoy
    if lower.hasSuffix("min") { return today }

    // "Hace Xh" — ocurrió hace horas → hoy (siempre < 24h)
    if lower.hasSuffix("h"), let digits = lower.components(separatedBy: " ").last?.dropLast() {
        if Int(digits) != nil { return today }
    }

    // "Hace Xd" — ocurrió hace X días
    if lower.hasSuffix("d"), let parts = Optional(lower.components(separatedBy: " ")),
       parts.count >= 2, let n = Int(parts[1].dropLast()) {
        return cal.date(byAdding: .day, value: -n, to: today)
    }

    // Formatos heredados por compatibilidad
    if lower.hasPrefix("hoy")  { return today }
    if lower.hasPrefix("ayer") { return cal.date(byAdding: .day, value: -1, to: today) }

    // "DD MMM" — formato de fecha corta (ej. "15 mar")
    let df = DateFormatter()
    df.locale = Locale(identifier: "es_PE")
    df.dateFormat = "dd MMM"
    // Asumimos el año actual; si el mes es mayor al actual, asumimos año anterior
    let currentYear = cal.component(.year, from: Date())
    df.defaultDate = cal.date(from: DateComponents(year: currentYear, month: 1, day: 1))
    if let date = df.date(from: relativeDate) {
        let parsed = cal.startOfDay(for: date)
        // Si la fecha parseada es futura, retroceder un año
        if parsed > today {
            return cal.date(byAdding: .year, value: -1, to: parsed)
        }
        return parsed
    }

    return nil
}

// ─── PremiosErrorState ────────────────────────────────────────────────────────
private struct PremiosErrorState: View {
    let onRetry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.seilDanger.opacity(0.08))
                    .frame(width: 60, height: 60)
                    .overlay(Circle().stroke(Color.seilDanger.opacity(0.20), lineWidth: 1))
                Image(systemName: "wifi.slash")
                    .font(SeillFont.icon(22))
                    .foregroundColor(.seilDanger)
            }

            VStack(spacing: 6) {
                Text("No se pudo cargar los premios")
                    .font(SeillFont.title(16))
                    .foregroundColor(.seilText)

                Text("Revisa tu conexión e inténtalo de nuevo.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
            }

            Button(action: onRetry) {
                HStack(spacing: 6) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold))
                    Text("Reintentar")
                        .font(SeillFont.label(14))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 32)
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .stroke(Color.seilDanger.opacity(0.20), lineWidth: 1)
        )
    }
}
