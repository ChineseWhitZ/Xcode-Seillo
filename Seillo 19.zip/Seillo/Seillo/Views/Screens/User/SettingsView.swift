import SwiftUI

// ─── SettingsView ─────────────────────────────────────────────────────────────
// Sheet presentado desde TabPerfilView → showSettings
// Extrae el stub de TabPerfilView a su propio archivo.
// Añade: profile card en el header, email real desde ProfileStore,
// sheet de eliminación de cuenta (en lugar de alert), textos legales actualizados.
// ─────────────────────────────────────────────────────────────────────────────

struct SettingsView: View {
    @EnvironmentObject var auth:         AuthManager
    @EnvironmentObject var profileStore: ProfileStore

    @AppStorage("notif_sellos")  private var notifSellos  = true
    @AppStorage("notif_premios") private var notifPremios = true
    @AppStorage("notif_promos")  private var notifPromos  = false

    private let api = APIClient.shared
    @AppStorage("haptic_on")      private var hapticOn    = true
    @AppStorage("app_appearance") private var appearance  = "amoled"
    @AppStorage("app_language")   private var language    = "es"

    @State private var showChangePass  = false
    @State private var showExport      = false
    @State private var showAyuda       = false
    @State private var showSoporte     = false
    @State private var showPrivacy     = false
    @State private var showTerms       = false
    @State private var showLogout      = false
    @State private var showDelete      = false
    @State private var showEditProfile = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                List {

                    // ── Profile card ────────────────────────────────────
                    Section {
                        Button {
                            Haptics.tap()
                            showEditProfile = true
                        } label: {
                            HStack(spacing: 14) {
                                AvatarView(avatarId: profileStore.profile.avatarId, size: 52)

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(profileStore.profile.nombre.isEmpty
                                         ? "Mi cuenta"
                                         : profileStore.profile.nombre)
                                        .font(SeillFont.headline(15))
                                        .foregroundColor(.seilText)

                                    if !profileStore.profile.email.isEmpty {
                                        Text(profileStore.profile.email)
                                            .font(SeillFont.body(12))
                                            .foregroundColor(.seilMuted2)
                                    }

                                    HStack(spacing: 4) {
                                        Image(systemName: "checkmark.seal.fill")
                                            .font(.system(size: 10))
                                            .foregroundColor(.seilAccent)
                                        Text("Miembro activo")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(.seilAccent)
                                    }
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 3)
                                    .background(Color.seilAccent.opacity(0.10))
                                    .clipShape(Capsule())
                                    .padding(.top, 2)
                                }

                                Spacer()

                                Image(systemName: "chevron.right")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(.seilMuted)
                            }
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(.plain)
                    }
                    .listRowBackground(Color.seilCard)

                    // ── Cuenta ──────────────────────────────────────────
                    Section {
                        SettingsNavRow(
                            icon: "lock.fill", iconColor: .seilPurple,
                            label: "Cambiar contraseña"
                        ) { showChangePass = true }

                        SettingsNavRow(
                            icon: "envelope.fill", iconColor: .seilMuted2,
                            label: "Correo electrónico",
                            trailingText: profileStore.profile.email.isEmpty
                                ? "—"
                                : profileStore.profile.email
                        )
                    } header: { sectionHeader("CUENTA") }
                    .listRowBackground(Color.seilCard)

                    // ── Notificaciones ──────────────────────────────────
                    Section {
                        SettingsToggleRow(icon: "star.fill",      iconColor: .seilAccent, label: "Sellos recibidos",       value: $notifSellos)
                        SettingsToggleRow(icon: "trophy.fill",    iconColor: .seilGold,   label: "Premios listos",         value: $notifPremios)
                        SettingsToggleRow(icon: "megaphone.fill", iconColor: .seilBlue,   label: "Campañas y promociones", value: $notifPromos)
                    } header: { sectionHeader("NOTIFICACIONES") }
                    .listRowBackground(Color.seilCard)
                    .onChange(of: notifSellos)  { _, _ in syncNotifPrefs() }
                    .onChange(of: notifPremios) { _, _ in syncNotifPrefs() }
                    .onChange(of: notifPromos)  { _, _ in syncNotifPrefs() }

                    // ── Apariencia ──────────────────────────────────────
                    Section {
                        HStack(spacing: 12) {
                            iconBox("circle.lefthalf.filled", color: .seilPurple)
                            Text("Apariencia")
                                .font(SeillFont.label(13))
                                .foregroundColor(.seilText)
                            Spacer()
                            Picker("", selection: $appearance) {
                                Text("AMOLED").tag("amoled")
                                Text("Claro").tag("light")
                            }
                            .pickerStyle(.segmented)
                            .frame(width: 150)
                        }
                        SettingsToggleRow(
                            icon: "hand.tap.fill", iconColor: .seilGreen,
                            label: "Vibración háptica",
                            value: $hapticOn
                        )
                        HStack(spacing: 12) {
                            iconBox("globe", color: .seilBlue)
                            Text(SeillStrings.settings.language)
                                .font(SeillFont.label(13))
                                .foregroundColor(.seilText)
                            Spacer()
                            Picker("", selection: $language) {
                                Text("Español").tag("es")
                                Text("English").tag("en")
                            }
                            .pickerStyle(.segmented)
                            .frame(width: 140)
                        }
                    } header: { sectionHeader("APARIENCIA") }
                    .listRowBackground(Color.seilCard)

                    // ── Privacidad y datos ──────────────────────────────
                    Section {
                        SettingsNavRow(icon: "lock.shield.fill",  iconColor: .seilBlue,    label: "Política de privacidad") { showPrivacy = true }
                        SettingsNavRow(icon: "doc.text.fill",     iconColor: .seilMuted2,  label: "Términos de uso")        { showTerms  = true }
                        SettingsNavRow(icon: "arrow.down.circle.fill", iconColor: .seilGreen, label: "Exportar mis datos")  { showExport = true }
                        SettingsNavRow(
                            icon: "person.crop.circle.badge.minus",
                            iconColor: .seilDanger,
                            label: "Eliminar cuenta",
                            labelColor: .seilDanger
                        ) { showDelete = true }
                    } header: { sectionHeader("PRIVACIDAD Y DATOS") }
                    .listRowBackground(Color.seilCard)

                    // ── Soporte ─────────────────────────────────────────
                    Section {
                        SettingsNavRow(icon: "questionmark.circle.fill", iconColor: .seilAccent, label: "Centro de ayuda")   { showAyuda   = true }
                        SettingsNavRow(icon: "message.fill",             iconColor: .seilBlue,   label: "Contactar soporte") { showSoporte = true }
                        SettingsNavRow(icon: "star.bubble.fill",         iconColor: .seilGold,   label: "Calificar la app") {
                            // Abrir App Store review
                            if let url = URL(string: "itms-apps://itunes.apple.com/app/idXXXXXXXXXX?action=write-review") {
                                UIApplication.shared.open(url)
                            }
                        }
                    } header: { sectionHeader("SOPORTE") }
                    .listRowBackground(Color.seilCard)

                    // ── Versión ─────────────────────────────────────────
                    Section {
                        SettingsNavRow(icon: "info.circle.fill", iconColor: .seilMuted2, label: "Versión de la app", trailingText: "v\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0")")
                    }
                    .listRowBackground(Color.seilCard)

                    // ── Cerrar sesión ───────────────────────────────────
                    Section {
                        Button {
                            Haptics.tap()
                            showLogout = true
                        } label: {
                            HStack(spacing: 12) {
                                iconBox("rectangle.portrait.and.arrow.right", color: .seilDanger)
                                Text("Cerrar sesión")
                                    .font(SeillFont.label(13))
                                    .foregroundColor(.seilDanger)
                                Spacer()
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    .listRowBackground(Color.seilCard)

                    // ── Footer ──────────────────────────────────────────
                    Section {
                        Text("seillo · Hecho con amor en Perú")
                            .font(SeillFont.caption(11))
                            .foregroundColor(.seilMuted)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .listRowBackground(Color.clear)
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Ajustes")
            .navigationBarTitleDisplayMode(.large)
            // ── Sheets ────────────────────────────────────────────────
            .sheet(isPresented: $showEditProfile) {
                EditProfileView()
                    .environmentObject(profileStore)
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showChangePass) {
                ChangePasswordSheet()
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showExport) {
                ExportDataSheet()
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showAyuda) {
                AyudaSheet()
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showSoporte) {
                SoporteSheet()
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showPrivacy) {
                SettingsLegalSheet(titulo: "Política de privacidad", contenido: settingsPrivacyText)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showTerms) {
                SettingsLegalSheet(titulo: "Términos de uso", contenido: settingsTermsText)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showDelete) {
                DeleteAccountSheet { auth.logout() }
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .confirmationDialog("¿Cerrar sesión?", isPresented: $showLogout, titleVisibility: .visible) {
                Button("Cerrar sesión", role: .destructive) { auth.logout() }
                Button("Cancelar", role: .cancel) {}
            } message: {
                Text("Podrás volver a ingresar con tu cuenta en cualquier momento.")
            }
        }
    }

    // MARK: - Helpers

    private func sectionHeader(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.seilMuted)
            .tracking(1.2)
    }

    private func iconBox(_ icon: String, color: Color) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(color.opacity(0.12))
                .frame(width: 30, height: 30)
            Image(systemName: icon)
                .font(.system(size: 14))
                .foregroundColor(color)
        }
    }
}

// ─── Helpers privados ─────────────────────────────────────────────────────────

extension SettingsView {
    /// Sincroniza preferencias de notificaciones con el backend.
    /// El backend usa un solo bool "activas" — true si al menos una categoría está activa.
    func syncNotifPrefs() {
        let activas = notifSellos || notifPremios || notifPromos
        Task {
            struct NotifRequest: Encodable { let activas: Bool }
            struct NotifResponse: Decodable { let ok: Bool? }
            _ = try? await api.patch(
                "api/usuario/notificaciones",
                body: NotifRequest(activas: activas)
            ) as NotifResponse
        }
    }
}

// ─── SettingsToggleRow ────────────────────────────────────────────────────────
private struct SettingsToggleRow: View {
    let icon     : String
    let iconColor: Color
    let label    : String
    var subtitle : String? = nil
    @Binding var value: Bool

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(iconColor.opacity(0.12))
                    .frame(width: 30, height: 30)
                Image(systemName: icon)
                    .font(.system(size: 14))
                    .foregroundColor(iconColor)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(SeillFont.label(13))
                    .foregroundColor(.seilText)
                if let sub = subtitle {
                    Text(sub)
                        .font(SeillFont.caption(10))
                        .foregroundColor(.seilMuted)
                }
            }
            Spacer()
            Toggle("", isOn: $value)
                .tint(.seilAccent)
                .labelsHidden()
        }
    }
}

// ─── SettingsNavRow ───────────────────────────────────────────────────────────
private struct SettingsNavRow: View {
    let icon        : String
    let iconColor   : Color
    let label       : String
    var labelColor  : Color? = nil
    var trailingText: String? = nil
    var action      : (() -> Void)? = nil

    var body: some View {
        Button {
            Haptics.tap()
            action?()
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(iconColor.opacity(0.12))
                        .frame(width: 30, height: 30)
                    Image(systemName: icon)
                        .font(.system(size: 14))
                        .foregroundColor(iconColor)
                }
                Text(label)
                    .font(SeillFont.label(13))
                    .foregroundColor(labelColor ?? .seilText)
                Spacer()
                if let trailing = trailingText {
                    Text(trailing)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                } else if action != nil {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12))
                        .foregroundColor(.seilMuted)
                }
            }
        }
        .buttonStyle(.plain)
        .disabled(action == nil)
    }
}

// ─── ChangePasswordSheet ──────────────────────────────────────────────────────
private struct ChangePasswordSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var actual    = ""
    @State private var nueva     = ""
    @State private var confirmar = ""
    @State private var showActual    = false
    @State private var showNueva     = false
    @State private var showConfirmar = false
    @State private var errorMsg  : String? = nil
    @State private var success   = false

    private var canSave: Bool {
        !actual.isEmpty && nueva.count >= 6 && nueva == confirmar
    }

    var body: some View {
        VStack(spacing: 0) {
            handle
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Cambiar contraseña")
                            .font(SeillFont.display(20))
                            .foregroundColor(.seilText)
                        Text("Tu nueva contraseña debe tener al menos 6 caracteres.")
                            .font(SeillFont.body(13))
                            .foregroundColor(.seilMuted2)
                    }

                    passwordField("Contraseña actual",          text: $actual,    show: $showActual)
                    passwordField("Nueva contraseña",           text: $nueva,     show: $showNueva)
                    passwordField("Confirmar nueva contraseña", text: $confirmar, show: $showConfirmar)

                    // Validaciones inline
                    if !nueva.isEmpty && nueva.count < 6 {
                        inlineError("Mínimo 6 caracteres")
                    } else if !confirmar.isEmpty && nueva != confirmar {
                        inlineError("Las contraseñas no coinciden")
                    } else if let err = errorMsg {
                        inlineError(err)
                    }

                    if success {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Contraseña actualizada")
                                .font(SeillFont.headline(14))
                        }
                        .foregroundColor(.seilGreen)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.seilGreen.opacity(0.10))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilGreen.opacity(0.25), lineWidth: 1))
                        .transition(.opacity)
                    } else {
                        Button {
                            guard canSave else { return }
                            Haptics.tap()
                            Task {
                                do {
                                    try await APIClient.shared.patch(
                                        "api/usuario/cambiar-password",
                                        body: CambiarPasswordRequest(passwordActual: actual, passwordNueva: nueva)
                                    )
                                    await MainActor.run {
                                        withAnimation { success = true }
                                    }
                                    try? await Task.sleep(for: .seconds(1.2))
                                    dismiss()
                                } catch let err as APIError {
                                    errorMsg = err.localizedDescription
                                } catch {
                                    errorMsg = "Error al cambiar la contraseña"
                                }
                            }
                        } label: {
                            Text("Guardar contraseña")
                                .font(SeillFont.headline(15))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 15)
                                .background(canSave ? Color.seilAccent : Color.seilAccent.opacity(0.35))
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .shadow(color: canSave ? Color.seilAccent.opacity(0.35) : .clear, radius: 10, y: 3)
                        }
                        .buttonStyle(.plain)
                        .disabled(!canSave)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 8)
                .padding(.bottom, 36)
            }
        }
    }

    private func passwordField(_ placeholder: String, text: Binding<String>, show: Binding<Bool>) -> some View {
        HStack(spacing: 10) {
            Group {
                if show.wrappedValue {
                    TextField(placeholder, text: text)
                } else {
                    SecureField(placeholder, text: text)
                }
            }
            .font(SeillFont.body(13))
            .foregroundColor(.seilText)
            .autocorrectionDisabled()
            .textInputAutocapitalization(.never)

            Button { show.wrappedValue.toggle() } label: {
                Image(systemName: show.wrappedValue ? "eye.slash" : "eye")
                    .font(.system(size: 14))
                    .foregroundColor(.seilMuted)
            }
            .buttonStyle(.plain)
        }
        .padding(14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilBorder, lineWidth: 1))
    }

    private func inlineError(_ msg: String) -> some View {
        HStack(spacing: 5) {
            Image(systemName: "exclamationmark.circle.fill")
                .font(.system(size: 11))
            Text(msg)
                .font(SeillFont.caption(11))
        }
        .foregroundColor(.seilDanger)
    }
}

// ─── DeleteAccountSheet ───────────────────────────────────────────────────────
private struct DeleteAccountSheet: View {
    let onConfirm: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var loading = false

    var body: some View {
        VStack(spacing: 0) {
            handle
            VStack(spacing: 0) {
                // Ícono
                ZStack {
                    Circle()
                        .fill(Color.seilDanger.opacity(0.10))
                        .frame(width: 60, height: 60)
                        .overlay(Circle().stroke(Color.seilDanger.opacity(0.22), lineWidth: 1.5))
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.seilDanger)
                }
                .padding(.bottom, 16)

                Text("¿Eliminar tu cuenta?")
                    .font(SeillFont.display(20))
                    .foregroundColor(.seilText)
                    .padding(.bottom, 8)

                Text("Esta acción es permanente. Perderás todos tus sellos y premios acumulados.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 8)
                    .padding(.bottom, 28)

                HStack(spacing: 10) {
                    // Cancelar
                    Button { dismiss() } label: {
                        Text("Cancelar")
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilMuted)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
                    }
                    .buttonStyle(.plain)

                    // Eliminar
                    Button {
                        loading = true
                        Haptics.tap()
                        Task {
                            do {
                                try await APIClient.shared.delete("api/usuario/eliminar")
                            } catch { }
                            dismiss()
                            try? await Task.sleep(for: .seconds(0.3))
                            onConfirm()
                        }
                    } label: {
                        Group {
                            if loading {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text("Eliminar cuenta")
                                    .font(SeillFont.headline(14))
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color.seilDanger)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                    .disabled(loading)
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 36)
        }
    }
}

// ─── ExportDataSheet ──────────────────────────────────────────────────────────
private struct ExportDataSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var requested = false

    var body: some View {
        VStack(spacing: 0) {
            handle
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(Color.seilGreen.opacity(0.13))
                        .frame(width: 64, height: 64)
                        .overlay(Circle().stroke(Color.seilGreen.opacity(0.25), lineWidth: 1.5))
                    Image(systemName: requested ? "checkmark.circle.fill" : "arrow.down.circle.fill")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(.seilGreen)
                }
                .padding(.top, 8)
                .animation(.spring(response: 0.35, dampingFraction: 0.65), value: requested)

                VStack(spacing: 8) {
                    Text(requested ? "¡Solicitud enviada!" : "Exportar mis datos")
                        .font(SeillFont.display(20))
                        .foregroundColor(.seilText)
                    Text(requested
                         ? "Recibirás un correo con tu historial de sellos y premios en menos de 24 horas."
                         : "Recibirás un correo con tu historial completo de sellos y premios canjeados en 24 horas.")
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilMuted2)
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)
                }

                if !requested {
                    Button {
                        Haptics.success()
                        withAnimation { requested = true }
                        Task {
                            _ = try? await APIClient.shared.get("api/cliente/exportar") as [String: String]
                            try? await Task.sleep(for: .seconds(2))
                            dismiss()
                        }
                    } label: {
                        Text("Solicitar exportación")
                            .font(SeillFont.headline(15))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color.seilGreen)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .shadow(color: Color.seilGreen.opacity(0.35), radius: 10, y: 3)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 36)
        }
    }
}

// ─── AyudaSheet ───────────────────────────────────────────────────────────────
private struct AyudaSheet: View {
    private let faqs: [(String, String)] = [
        ("¿Cómo obtengo sellos?",
         "Muestra tu código QR al negocio cuando realices una compra. El encargado escaneará tu código y recibirás el sello automáticamente."),
        ("¿Cómo canjeo un premio?",
         "Cuando completes todos los sellos de una tarjeta, ve a Premios y toca Canjear. Muestra el código al encargado del local."),
        ("¿Los sellos vencen?",
         "Cada negocio puede establecer una vigencia para sus sellos. Revisa los detalles de cada tarjeta para conocer la vigencia."),
        ("¿Puedo tener varias tarjetas?",
         "Sí, puedes acumular sellos en todos los negocios afiliados a Seillo sin límite de tarjetas."),
        ("¿Qué pasa si cambio de teléfono?",
         "Tus sellos están guardados en la nube. Instala Seillo en tu nuevo teléfono, inicia sesión con tu cuenta y todo estará disponible."),
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 10) {
                        ForEach(Array(faqs.enumerated()), id: \.offset) { _, faq in
                            FaqAccordion(pregunta: faq.0, respuesta: faq.1)
                        }
                        Spacer().frame(height: 20)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                }
            }
            .navigationTitle("Centro de ayuda")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

private struct FaqAccordion: View {
    let pregunta : String
    let respuesta: String
    @State private var expanded = false

    var body: some View {
        Button {
            Haptics.tap()
            withAnimation(SeillAnimation.panelCascade) { expanded.toggle() }
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    Text(pregunta)
                        .font(SeillFont.label(13))
                        .foregroundColor(expanded ? .seilAccent : .seilText)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(expanded ? .seilAccent : .seilMuted)
                        .rotationEffect(.degrees(expanded ? 180 : 0))
                }
                .padding(16)

                if expanded {
                    Text(respuesta)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(4)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
        }
        .buttonStyle(.plain)
        .background(expanded ? Color.seilAccent.opacity(0.05) : Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(expanded ? Color.seilAccent.opacity(0.28) : Color.seilBorder, lineWidth: 1)
        )
        .animation(SeillAnimation.panelCascade, value: expanded)
    }
}

// ─── SoporteSheet ─────────────────────────────────────────────────────────────
private struct SoporteSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var mensaje = ""
    @State private var enviado = false

    private var canSend: Bool { !mensaje.trimmingCharacters(in: .whitespaces).isEmpty }

    var body: some View {
        VStack(spacing: 0) {
            handle
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(Color.seilBlue.opacity(0.13))
                            .frame(width: 40, height: 40)
                        Image(systemName: "message.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.seilBlue)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Contactar soporte")
                            .font(SeillFont.headline(16))
                            .foregroundColor(.seilText)
                        Text("Te respondemos en menos de 24 h")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                    }
                }
                .padding(.top, 20)

                // Textarea
                ZStack(alignment: .topLeading) {
                    if mensaje.isEmpty {
                        Text("Describe tu consulta o problema...")
                            .font(SeillFont.body(13))
                            .foregroundColor(.seilMuted)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 12)
                    }
                    TextEditor(text: $mensaje)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilText)
                        .scrollContentBackground(.hidden)
                        .background(Color.clear)
                        .frame(height: 110)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                }
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilBorder, lineWidth: 1))

                // Botón — abre el mail como fallback mientras no hay API
                Button {
                    guard canSend else { return }
                    Haptics.success()
                    let subject = "Consulta desde Seillo"
                    let body    = mensaje.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    let subjectEnc = subject.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    if let url = URL(string: "mailto:soporte@seillo.site?subject=\(subjectEnc)&body=\(body)") {
                        UIApplication.shared.open(url)
                    }
                    withAnimation { enviado = true }
                    Task {
                        try? await Task.sleep(for: .seconds(1.5))
                        dismiss()
                    }
                } label: {
                    HStack(spacing: 8) {
                        if enviado {
                            Image(systemName: "checkmark")
                                .font(.system(size: 14, weight: .bold))
                        }
                        Text(enviado ? "Mensaje enviado" : "Enviar mensaje")
                            .font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(canSend ? Color.seilBlue : Color.seilBlue.opacity(0.35))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .shadow(color: canSend ? Color.seilBlue.opacity(0.35) : .clear, radius: 10, y: 3)
                }
                .buttonStyle(.plain)
                .disabled(!canSend || enviado)
                .animation(.easeInOut(duration: 0.2), value: enviado)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 36)
        }
    }
}

// ─── SettingsLegalSheet ───────────────────────────────────────────────────────
// Nombre prefijado para no colisionar con LegalSheet de AboutSeilloView
private struct SettingsLegalSheet: View {
    let titulo   : String
    let contenido: String

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    Text(contenido)
                        .font(SeillFont.body(14))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(6)
                        .padding(.horizontal, 20)
                        .padding(.top, 8)
                        .padding(.bottom, 40)
                }
            }
            .navigationTitle(titulo)
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

// ─── Handle helper ────────────────────────────────────────────────────────────
private var handle: some View {
    Capsule()
        .fill(Color.seilBorder)
        .frame(width: 36, height: 4)
        .padding(.top, 12)
        .padding(.bottom, 20)
        .frame(maxWidth: .infinity)
}

// ─── Textos legales ───────────────────────────────────────────────────────────
private let settingsPrivacyText = """
Seillo respeta tu privacidad y se compromete a proteger tus datos personales.

Datos que recopilamos
Recopilamos la información que nos proporcionas al registrarte (nombre, correo electrónico), datos de uso (sellos acumulados, premios canjeados, negocios visitados) y datos técnicos del dispositivo.

Datos de ubicación
Si otorgas permiso, accedemos a tu ubicación aproximada únicamente para mostrarte negocios cercanos en el mapa. No almacenamos tu ubicación en nuestros servidores ni la compartimos con terceros. Puedes revocar este permiso en cualquier momento desde los ajustes de tu dispositivo.

Uso de la cámara
Accedemos a la cámara exclusivamente para escanear tu código QR al momento de registrar sellos. No capturamos ni almacenamos imágenes.

Uso de los datos
Utilizamos tus datos para operar el servicio de fidelización, enviarte notificaciones sobre sellos y premios, y mejorar la experiencia de la aplicación. No vendemos ni compartimos tus datos personales con terceros sin tu consentimiento.

Edad mínima
Seillo está dirigido a personas mayores de 13 años.

Tus derechos
Puedes solicitar acceso, corrección o eliminación de tus datos a través de "Exportar mis datos" o escribiéndonos a privacidad@seillo.site.

Última actualización: marzo 2026.
"""

private let settingsTermsText = """
Términos y Condiciones de Uso de Seillo

Al usar Seillo, aceptas los presentes términos.

1. Servicio
Seillo es una plataforma digital de fidelización que conecta clientes con negocios locales mediante tarjetas de sellos digitales.

2. Cuentas
Eres responsable de mantener la confidencialidad de tu contraseña y de todas las actividades bajo tu cuenta.

3. Edad mínima
El uso de Seillo está permitido a personas mayores de 13 años. Al registrarte, confirmas que cumples con este requisito.

4. Sellos y premios
Los sellos son otorgados exclusivamente por los negocios afiliados. Seillo no garantiza la disponibilidad de premios ni la vigencia de las tarjetas, ya que esto depende de cada negocio.

5. Prohibiciones
Está prohibido falsificar sellos, crear cuentas falsas o usar la plataforma para actividades ilegales.

Contacto: soporte@seillo.site
Última actualización: marzo 2026.
"""
