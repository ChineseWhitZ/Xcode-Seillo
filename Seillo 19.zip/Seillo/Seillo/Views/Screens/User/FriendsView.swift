import SwiftUI

// ─── FriendsView ──────────────────────────────────────────────────────────────
// Pantalla completa de gestión de amigos.
//
// Ruta:   Seillo/Views/Screens/User/FriendsView.swift
// Acceso: TabPerfilView → "Mis amigos" (MI ACTIVIDAD)
//         FriendsActivityBanner → botón "Gestionar" (expandido)
//
// Tabs:
//   • Amigos       — lista de amigos actuales con actividad reciente
//   • Solicitudes  — entrantes con badge en el tab
//   • Buscar       — búsqueda por nombre + sugerencias
// ─────────────────────────────────────────────────────────────────────────────

struct FriendsView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var selectedTab:  Int    = 0
    @State private var searchQuery:  String = ""
    @State private var friendCode:   String = ""   // campo SEILLO-XXXX
    @State private var codeSent:     Bool   = false
    @State private var codeLoading:  Bool   = false
    @State private var codeError:    String? = nil
    @State private var codeResult:   FriendSearchResult? = nil
    @State private var appear:       Bool   = false

    // Estado cargado del backend
    @State private var friends:      [Friend] = []
    @State private var requests:     [Friend] = []
    @State private var searchResults: [FriendSearchResult] = []

    private let friendService: FriendServiceProtocol = APIFriendService()

    private var pendingCount: Int { requests.count }

    var body: some View {
        NavigationStack {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                headerBar
                tabSelector
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)

                tabContent
            }
        }
        .navigationBarHidden(true)
        .task {
            // Cargar datos del backend
            async let amigosResult = friendService.getAmigos()
            async let solicitudesResult = friendService.getSolicitudes()

            if case .success(let f) = await amigosResult {
                friends = f
            }
            if case .success(let r) = await solicitudesResult {
                requests = r
            }

            withAnimation(SeillAnimation.chrome.delay(0.04)) {
                appear = true
            }
        }
        } // NavigationStack
    }

    // MARK: - Header

    private var headerBar: some View {
        HStack {
            Button {
                Haptics.tap()
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.seilMuted2)
                    .frame(width: 36, height: 36)
                    .background(Color.seilCard)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)

            Spacer()

            VStack(spacing: 2) {
                Text("Mis amigos")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)

                Text("\(friends.count) amigo\(friends.count == 1 ? "" : "s")")
                    .font(.system(size: 11))
                    .foregroundColor(.seilMuted)
            }

            Spacer()

            // Botón invitar — abre ReferralView (por ahora placeholder)
            Button {
                Haptics.tap()
            } label: {
                Image(systemName: "person.badge.plus")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.seilAccent)
                    .frame(width: 36, height: 36)
                    .background(Color.seilAccent.opacity(0.12))
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilAccent.opacity(0.25), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 14)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Tab selector

    private var tabSelector: some View {
        HStack(spacing: 0) {
            tabButton(label: "Amigos", index: 0, badge: 0)
            tabButton(label: "Solicitudes", index: 1, badge: pendingCount)
            tabButton(label: "Buscar", index: 2, badge: 0)
        }
        .padding(.top, 14)
        .opacity(appear ? 1 : 0)
    }

    private func tabButton(label: String, index: Int, badge: Int) -> some View {
        let isSelected = selectedTab == index

        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.32, dampingFraction: 0.75)) {
                selectedTab = index
            }
        } label: {
            VStack(spacing: 8) {
                HStack(spacing: 5) {
                    Text(label)
                        .font(.system(size: 13, weight: isSelected ? .bold : .semibold))
                        .foregroundColor(isSelected ? .seilText : .seilMuted)

                    if badge > 0 {
                        Text("\(badge)")
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundColor(.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Color.seilAccent)
                            .clipShape(Capsule())
                    }
                }

                Rectangle()
                    .fill(isSelected ? Color.seilAccent : Color.clear)
                    .frame(height: 2)
                    .clipShape(Capsule())
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }

    // MARK: - Tab content

    @ViewBuilder
    private var tabContent: some View {
        switch selectedTab {
        case 0:
            friendsTab
                .transition(.asymmetric(
                    insertion: .move(edge: .trailing).combined(with: .opacity),
                    removal:   .move(edge: .leading).combined(with: .opacity)
                ))
        case 1:
            requestsTab
                .transition(.asymmetric(
                    insertion: .move(edge: .trailing).combined(with: .opacity),
                    removal:   .move(edge: .leading).combined(with: .opacity)
                ))
        default:
            searchTab
                .transition(.asymmetric(
                    insertion: .move(edge: .trailing).combined(with: .opacity),
                    removal:   .move(edge: .leading).combined(with: .opacity)
                ))
        }
    }

    // MARK: - Tab: Amigos

    private var friendsTab: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 0) {
                if friends.isEmpty {
                    emptyFriendsState
                        .padding(.top, 60)
                } else {
                    ForEach(Array(friends.enumerated()), id: \.element.id) { i, friend in
                        NavigationLink(destination: PublicProfileView(userId: friend.id)) {
                            FriendRow(
                                friend: friend,
                                trailingAction: {
                                    // Eliminar amigo
                                    Task {
                                        _ = await friendService.eliminarAmigo(amigoId: friend.id)
                                        withAnimation {
                                            friends.removeAll { $0.id == friend.id }
                                        }
                                    }
                                },
                                trailingLabel: "Eliminar",
                                trailingColor: .seilRose,
                                trailingIcon:  "person.badge.minus"
                            )
                        }
                        .buttonStyle(.plain)
                        .opacity(appear ? 1 : 0)
                        .offset(y: appear ? 0 : 14)
                        .animation(
                            SeillAnimation.chrome.delay(Double(i) * 0.04),
                            value: appear
                        )
                    }
                }
                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
        .refreshable {
            async let amigosResult      = friendService.getAmigos()
            async let solicitudesResult = friendService.getSolicitudes()

            if case .success(let f) = await amigosResult { friends = f }
            if case .success(let r) = await solicitudesResult { requests = r }
        }
    }

    private var emptyFriendsState: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.08))
                    .frame(width: 72, height: 72)
                Image(systemName: "person.2")
                    .font(.system(size: 28))
                    .foregroundColor(.seilMuted)
            }
            VStack(spacing: 6) {
                Text("Aún no tienes amigos")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)
                Text("Busca usuarios por nombre o invita\na tus contactos a unirse a Seillo.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }
            Button {
                withAnimation(.spring(response: 0.32, dampingFraction: 0.75)) {
                    selectedTab = 2
                }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                    Text("Buscar amigos")
                        .font(SeillFont.headline(13))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Tab: Solicitudes

    private var requestsTab: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 0) {
                if requests.isEmpty {
                    VStack(spacing: 14) {
                        Spacer().frame(height: 60)
                        Image(systemName: "checkmark.circle")
                            .font(.system(size: 36))
                            .foregroundColor(.seilMuted)
                        Text("Sin solicitudes pendientes")
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilMuted)
                    }
                    .frame(maxWidth: .infinity)
                } else {
                    HStack {
                        Text("\(requests.count) solicitud\(requests.count == 1 ? "" : "es") pendiente\(requests.count == 1 ? "" : "s")")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilMuted)
                            .tracking(1.2)
                        Spacer()
                    }
                    .padding(.horizontal, 6)
                    .padding(.vertical, 10)

                    ForEach(requests) { request in
                        RequestRow(
                            friend: request,
                            onAccept: {
                                withAnimation {
                                    friends.append(
                                        Friend(
                                            id: request.id, name: request.name,
                                            initial: request.initial,
                                            color: request.color,
                                            level: request.level,
                                            levelIcon: request.levelIcon,
                                            levelColor: request.levelColor,
                                            totalStamps: request.totalStamps,
                                            topBiz: request.topBiz,
                                            status: .friend,
                                            mutualCount: request.mutualCount
                                        )
                                    )
                                    requests.removeAll { $0.id == request.id }
                                }
                            },
                            onDecline: {
                                withAnimation {
                                    requests.removeAll { $0.id == request.id }
                                }
                            }
                        )
                    }
                }
                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
    }

    // MARK: - Tab: Buscar

    private var searchTab: some View {
        VStack(spacing: 0) {

            // ── Campo código SEILLO-XXXX ───────────────────────────────────
            codeInputSection
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 20)

            Divider().background(Color.seilBorder)
                .padding(.bottom, 14)

            // ── Search bar por nombre ──────────────────────────────────────
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.seilMuted)

                TextField("Buscar por nombre...", text: $searchQuery)
                    .font(SeillFont.body(14))
                    .foregroundColor(.seilText)
                    .autocorrectionDisabled()

                if !searchQuery.isEmpty {
                    Button { searchQuery = "" } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.seilMuted)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            .padding(.bottom, 16)

            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    let filtered = friends.filter { f in
                        searchQuery.isEmpty || f.name.lowercased().contains(searchQuery.lowercased())
                    }

                    if filtered.isEmpty {
                        VStack(spacing: 12) {
                            Spacer().frame(height: 40)
                            Image(systemName: "person.fill.questionmark")
                                .font(.system(size: 30))
                                .foregroundColor(.seilMuted)
                            Text("No encontramos \"\(searchQuery)\"")
                                .font(SeillFont.headline(13))
                                .foregroundColor(.seilMuted)
                        }
                        .frame(maxWidth: .infinity)
                    } else {
                        if searchQuery.isEmpty {
                            HStack {
                                Text("SUGERENCIAS PARA TI")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.seilMuted)
                                    .tracking(1.2)
                                Spacer()
                            }
                            .padding(.horizontal, 6)
                            .padding(.bottom, 10)
                        }

                        ForEach(filtered) { suggestion in
                            FriendRow(
                                friend: suggestion,
                                trailingAction: {
                                    Task {
                                        _ = await friendService.enviarSolicitud(destinatarioId: suggestion.id)
                                    }
                                },
                                trailingLabel: "Enviar",
                                trailingColor: .seilAccent,
                                trailingIcon:  "person.badge.plus"
                            )
                        }
                    }
                    Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                }
            }
        }
        .padding(.horizontal, 16)
    }

    // MARK: - Code input section

    private var codeInputSection: some View {
        let upperCode = friendCode.uppercased()
        let isValid   = upperCode.hasPrefix("SEILLO-") && upperCode.count >= 10

        return VStack(alignment: .leading, spacing: 10) {
            Text("AÑADIR POR CÓDIGO")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.2)

            HStack(spacing: 10) {
                // Ícono de estado
                Image(systemName: isValid ? "checkmark.circle.fill" : "person.badge.key.fill")
                    .font(.system(size: 15))
                    .foregroundColor(isValid ? .seilGreen : .seilMuted)
                    .frame(width: 20)
                    .animation(SeillAnimation.chrome, value: isValid)

                // Campo de texto
                TextField("SEILLO-XXXX", text: $friendCode)
                    .font(.system(size: 14, weight: .semibold, design: .monospaced))
                    .foregroundColor(isValid ? .seilGreen : .seilText)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .onChange(of: friendCode) { _, new in
                        // Forzar mayúsculas en tiempo real
                        if new != new.uppercased() { friendCode = new.uppercased() }
                        codeSent = false
                        codeError = nil
                        codeResult = nil
                    }

                if !friendCode.isEmpty {
                    Button { friendCode = ""; codeSent = false; codeError = nil; codeResult = nil } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.seilMuted)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(
                        isValid  ? Color.seilGreen.opacity(0.45) :
                        codeSent ? Color.seilAccent.opacity(0.40) :
                                   Color.seilBorder,
                        lineWidth: 1
                    )
            )
            .animation(SeillAnimation.chrome, value: isValid)

            // Hint / estado
            if isValid {
                Text("Código válido · toca Enviar para conectar")
                    .font(SeillFont.caption(11))
                    .foregroundColor(.seilGreen)
                    .transition(.opacity)
            } else if !friendCode.isEmpty {
                Text("El código debe empezar por SEILLO- y tener al menos 10 caracteres")
                    .font(SeillFont.caption(11))
                    .foregroundColor(.seilMuted)
                    .transition(.opacity)
            }

            // Error de código
            if let error = codeError {
                HStack(spacing: 5) {
                    Image(systemName: "exclamationmark.circle.fill")
                        .font(.system(size: 11))
                    Text(error)
                        .font(SeillFont.caption(11))
                }
                .foregroundColor(.seilDanger)
                .transition(.opacity)
            }

            // Resultado encontrado
            if let result = codeResult {
                HStack(spacing: 12) {
                    AvatarView(avatarId: result.avatarId, size: 36)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(result.nombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)
                        Text("\(result.totalSellos) sellos")
                            .font(SeillFont.caption(11))
                            .foregroundColor(.seilMuted)
                    }

                    Spacer()

                    if result.yaAmigo {
                        Text("Ya son amigos")
                            .font(SeillFont.caption(11))
                            .foregroundColor(.seilGreen)
                    } else if result.solicitudEnviada {
                        Text("Solicitud pendiente")
                            .font(SeillFont.caption(11))
                            .foregroundColor(.seilGold)
                    }
                }
                .padding(12)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
                .transition(.opacity.combined(with: .move(edge: .top)))
            }

            // Botón enviar solicitud
            Button {
                guard isValid else { return }
                Haptics.tap()
                codeError = nil
                codeLoading = true

                Task {
                    // Paso 1: buscar usuario por código
                    let searchResult = await friendService.buscarPorCodigo(codigo: upperCode)

                    switch searchResult {
                    case .success(let found):
                        withAnimation(SeillAnimation.chrome) { codeResult = found }

                        if found.yaAmigo || found.solicitudEnviada {
                            // Ya son amigos o ya hay solicitud pendiente
                            codeLoading = false
                            return
                        }

                        // Paso 2: enviar solicitud con el ID encontrado
                        let sendResult = await friendService.enviarSolicitud(destinatarioId: found.id)

                        switch sendResult {
                        case .success:
                            Haptics.success()
                            withAnimation(SeillAnimation.chrome) {
                                codeSent = true
                                codeResult = nil
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                friendCode = ""
                                codeSent = false
                            }

                        case .failure:
                            withAnimation { codeError = "No se pudo enviar la solicitud" }
                        }

                    case .failure:
                        withAnimation { codeError = "Código no encontrado" }
                        codeResult = nil
                    }

                    codeLoading = false
                }
            } label: {
                HStack(spacing: 7) {
                    if codeLoading {
                        ProgressView()
                            .tint(.white)
                            .scaleEffect(0.8)
                    } else {
                        Image(systemName: codeSent ? "checkmark" : "person.badge.plus")
                            .font(.system(size: 13, weight: .semibold))
                    }
                    Text(codeSent ? "¡Solicitud enviada!" : "Enviar solicitud")
                        .font(SeillFont.headline(14))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background(
                    codeSent ? Color.seilGreen :
                    isValid  ? Color.seilAccent :
                               Color.seilAccent.opacity(0.30)
                )
                .clipShape(RoundedRectangle(cornerRadius: 13))
                .animation(SeillAnimation.chrome, value: codeSent)
                .animation(SeillAnimation.chrome, value: isValid)
            }
            .buttonStyle(.plain)
            .disabled(!isValid || codeSent || codeLoading)
        }
    }
}

// ─── FriendRow ────────────────────────────────────────────────────────────────
/// Fila reutilizable para amigos actuales y sugerencias.
/// El botón trailing cambia según el contexto (eliminar vs enviar solicitud).

private struct FriendRow: View {
    let friend:          Friend
    let trailingAction:  () -> Void
    let trailingLabel:   String
    let trailingColor:   Color
    let trailingIcon:    String

    var body: some View {
        HStack(spacing: 12) {
            // Avatar inicial
            ZStack {
                Circle()
                    .fill(friend.color.opacity(0.18))
                    .frame(width: 44, height: 44)
                    .overlay(Circle().stroke(friend.color.opacity(0.28), lineWidth: 1))
                Text(friend.initial)
                    .font(.system(size: 17, weight: .heavy))
                    .foregroundColor(friend.color)
            }

            // Info
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(friend.name)
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)

                    // Badge de nivel
                    HStack(spacing: 3) {
                        Image(systemName: friend.levelIcon)
                            .font(.system(size: 8, weight: .bold))
                        Text(friend.level)
                            .font(.system(size: 9, weight: .bold))
                    }
                    .foregroundColor(friend.levelColor)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(friend.levelColor.opacity(0.10))
                    .clipShape(Capsule())
                }

                HStack(spacing: 8) {
                    // Sellos totales
                    HStack(spacing: 3) {
                        Image(systemName: "seal.fill")
                            .font(.system(size: 9))
                            .foregroundColor(.seilAccent)
                        Text("\(friend.totalStamps)")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilMuted2)
                    }

                    // Negocios en común
                    if friend.mutualCount > 0 {
                        Text("·")
                            .foregroundColor(.seilMuted)
                            .font(.system(size: 10))

                        Text("\(friend.mutualCount) en común")
                            .font(.system(size: 10))
                            .foregroundColor(.seilMuted)
                    }
                }
            }

            Spacer()

            // Acción trailing
            Button {
                Haptics.tap()
                trailingAction()
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: trailingIcon)
                        .font(.system(size: 11, weight: .semibold))
                    Text(trailingLabel)
                        .font(.system(size: 11, weight: .bold))
                }
                .foregroundColor(trailingColor)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(trailingColor.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(trailingColor.opacity(0.25), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 12)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(Color.seilBorder.opacity(0.6))
                .frame(height: 1)
                .padding(.leading, 56)
        }
    }
}

// ─── RequestRow ───────────────────────────────────────────────────────────────
/// Fila para solicitudes entrantes — muestra Aceptar + Rechazar.

private struct RequestRow: View {
    let friend:    Friend
    let onAccept:  () -> Void
    let onDecline: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                // Avatar
                ZStack {
                    Circle()
                        .fill(friend.color.opacity(0.18))
                        .frame(width: 44, height: 44)
                        .overlay(Circle().stroke(friend.color.opacity(0.28), lineWidth: 1))
                    Text(friend.initial)
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundColor(friend.color)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(friend.name)
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)

                    HStack(spacing: 8) {
                        HStack(spacing: 3) {
                            Image(systemName: "seal.fill")
                                .font(.system(size: 9))
                                .foregroundColor(.seilAccent)
                            Text("\(friend.totalStamps) sellos")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilMuted2)
                        }

                        if friend.mutualCount > 0 {
                            Text("· \(friend.mutualCount) negocios en común")
                                .font(.system(size: 10))
                                .foregroundColor(.seilMuted)
                        }
                    }
                }

                Spacer()
            }

            // Botones Aceptar / Rechazar
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    onDecline()
                } label: {
                    Text("Rechazar")
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilMuted2)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)

                Button {
                    Haptics.tap()
                    onAccept()
                } label: {
                    Text("Aceptar")
                        .font(SeillFont.headline(13))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(Color.seilAccent)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: Color.seilAccent.opacity(0.30), radius: 8, y: 3)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 14)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(Color.seilBorder.opacity(0.6))
                .frame(height: 1)
        }
    }
}
