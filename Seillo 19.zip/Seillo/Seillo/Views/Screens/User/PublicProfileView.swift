import SwiftUI

// ─── PublicProfileView ────────────────────────────────────────────────────────
//
// Perfil público de otro usuario. Se accede desde FriendsView al tocar
// el nombre de un amigo.
//
// Ruta: Seillo/Views/Screens/User/PublicProfileView.swift
//
// Cambios Lote 1:
//   · Usa SeilloAvatarWithFrame en lugar de avatar inline
//   · Usa SeilloTitlePill en lugar de título inline
//   · Usa SeilloBadgesRow en lugar de badges inline
//   · Badges con nombre debajo (label) como en Android
// ─────────────────────────────────────────────────────────────────────────────

struct PublicProfileView: View {
    let userId: String

    @Environment(\.dismiss) private var dismiss
    @State private var profile   : PublicProfile? = nil
    @State private var loading   = true
    @State private var appear    : Double = 0
    @State private var isFriend  = false
    @State private var toggling  = false
    @State private var errorKind : ProfileErrorKind? = nil

    private let service: ClientServiceProtocol = APIClientService()

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            if loading {
                VStack(spacing: 16) {
                    ProgressView().tint(.seilAccent)
                    Text("Cargando perfil...")
                        .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                }
            } else if let p = profile {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        headerSection(p)
                            .sectionAppear(progress: appear, start: 0, end: 0.3)

                        statsSection(p)
                            .padding(.horizontal, 16)
                            .padding(.top, 20)
                            .sectionAppear(progress: appear, start: 0.1, end: 0.4)

                        if !p.tarjetasActivas.isEmpty {
                            cardsSection(p.tarjetasActivas)
                                .padding(.top, 20)
                                .sectionAppear(progress: appear, start: 0.2, end: 0.5)
                        }

                        friendButton(p)
                            .padding(.horizontal, 16)
                            .padding(.top, 24)
                            .padding(.bottom, 40)
                            .sectionAppear(progress: appear, start: 0.3, end: 0.6)
                    }
                }
            } else if let kind = errorKind {
                switch kind {
                case .sessionExpired:
                    SeillEmptyState(
                        icon: "lock.slash",
                        title: "Sesión expirada",
                        message: "Tu sesión venció. Vuelve a iniciar sesión para ver este perfil."
                    )
                case .notFound:
                    SeillEmptyState(
                        icon: "person.slash",
                        title: "Perfil no encontrado",
                        message: "Este usuario no existe o fue eliminado."
                    )
                case .network:
                    SeillEmptyState(
                        icon: "wifi.slash",
                        title: "Sin conexión",
                        message: "Revisa tu internet e intenta de nuevo."
                    )
                case .unknown:
                    SeillEmptyState(
                        icon: "exclamationmark.triangle",
                        title: "Error inesperado",
                        message: "No pudimos cargar este perfil. Intenta de nuevo."
                    )
                }
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            let result = await service.getPerfilPublico(userId: userId)
            switch result {
            case .success(let p):
                profile = p
                isFriend = p.esAmigo
            case .failure(let error):
                if let apiErr = error as? APIError {
                    switch apiErr {
                    case .badStatus(401, _): errorKind = .sessionExpired
                    case .badStatus(404, _): errorKind = .notFound
                    case .networkError:      errorKind = .network
                    default:                 errorKind = .unknown
                    }
                } else {
                    errorKind = .unknown
                }
            }
            loading = false
            withAnimation(.easeOut(duration: 0.7)) { appear = 1 }
        }
    }

    // MARK: - Header

    private func headerSection(_ p: PublicProfile) -> some View {
        VStack(spacing: 12) {
            // Avatar con marco — ahora usa el componente reutilizable
            SeilloAvatarWithFrame(
                avatarId: p.avatarId,
                frameId:  p.identidad.frameActivo,
                size:     96
            )

            // Nombre
            Text(p.nombre)
                .font(SeillFont.display(22))
                .foregroundColor(.seilText)

            // Título — componente reutilizable
            if let titleText = p.identidad.tituloTexto,
               let tituloId = findTituloId(for: titleText, in: p) {
                SeilloTitlePill(
                    tituloId:    tituloId,
                    tituloTexto: titleText
                )
            }

            // Nivel
            HStack(spacing: 6) {
                let level = UserLevel.level(for: p.totalSellos)
                Image(systemName: level.icon)
                    .font(.system(size: 11))
                    .foregroundColor(level.color)
                Text(level.name)
                    .font(SeillFont.label(12))
                    .foregroundColor(level.color)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 5)
            .background(Color.seilCard)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))

            // Badges visibles — componente reutilizable con labels
            if !p.identidad.badgesVisibles.isEmpty {
                badgesWithLabels(p.identidad.badgesVisibles)
                    .padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
        .padding(.horizontal, 16)
    }

    // MARK: - Badges con labels

    private func badgesWithLabels(_ badges: [BadgeInfo]) -> some View {
        HStack(spacing: 12) {
            ForEach(badges.prefix(3)) { badge in
                VStack(spacing: 5) {
                    SeilloBadgeChip(badge: badge, size: 36)

                    Text(badge.nombre)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }
            }
        }
    }

    // MARK: - Stats

    private func statsSection(_ p: PublicProfile) -> some View {
        HStack(spacing: 10) {
            statCard(value: "\(p.totalSellos)",   label: "Sellos",   icon: "star.fill",       color: .seilAccent)
            statCard(value: "\(p.totalTarjetas)", label: "Tarjetas", icon: "creditcard.fill", color: .seilBlue)
            statCard(value: "\(p.totalPremios)",  label: "Premios",  icon: "trophy.fill",     color: .seilGold)
        }
    }

    private func statCard(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 14)).foregroundColor(color)
            Text(value).font(.system(size: 18, weight: .heavy, design: .rounded)).foregroundColor(.seilText)
            Text(label).font(.system(size: 9, weight: .bold)).foregroundColor(.seilMuted).tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
    }

    // MARK: - Active Cards

    private func cardsSection(_ cards: [PublicTarjeta]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("TARJETAS ACTIVAS")
                .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                .padding(.horizontal, 16)

            ForEach(cards) { card in
                HStack(spacing: 14) {
                    ZStack {
                        Circle()
                            .fill(colorForCat(card.categoria).opacity(0.12))
                            .frame(width: 38, height: 38)
                        Image(systemName: iconForCat(card.categoria))
                            .font(.system(size: 15))
                            .foregroundColor(colorForCat(card.categoria))
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text(card.negocioNombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)

                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Color.seilCard2).frame(height: 4)
                                Capsule()
                                    .fill(colorForCat(card.categoria))
                                    .frame(width: geo.size.width * card.progress, height: 4)
                            }
                        }
                        .frame(height: 4)
                    }

                    Text("\(card.sellosActuales)/\(card.sellosMeta)")
                        .font(SeillFont.label(12))
                        .foregroundColor(.seilMuted2)
                }
                .padding(14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(Color.seilBorder, lineWidth: 1)
                )
                .padding(.horizontal, 16)
            }
        }
    }

    // MARK: - Friend Button

    private func friendButton(_ p: PublicProfile) -> some View {
        Button {
            Haptics.tap()
            toggling = true
            Task {
                if isFriend {
                    // Eliminar amigo: DELETE /api/amigos/:id (id = userId)
                    _ = try? await APIClient.shared.delete("api/amigos/\(userId)")
                } else {
                    // Enviar solicitud: POST /api/amigos/solicitud
                    struct SolicitudBody: Encodable { let destinatario_id: String }
                    _ = try? await APIClient.shared.post(
                        "api/amigos/solicitud",
                        body: SolicitudBody(destinatario_id: userId)
                    ) as [String: Bool]
                }
                await MainActor.run {
                    isFriend.toggle()
                    toggling = false
                }
            }
        } label: {
            HStack(spacing: 8) {
                if toggling {
                    ProgressView().tint(isFriend ? .seilDanger : .white).scaleEffect(0.8)
                } else {
                    Image(systemName: isFriend ? "person.badge.minus" : "person.badge.plus")
                        .font(.system(size: 15, weight: .semibold))
                    Text(isFriend ? "Eliminar amigo" : "Agregar amigo")
                        .font(SeillFont.label(15))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .foregroundColor(isFriend ? .seilDanger : .white)
            .background(isFriend ? Color.seilCard : Color.seilAccent)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(isFriend ? Color.seilDanger.opacity(0.3) : Color.clear, lineWidth: 1)
            )
            .shadow(color: isFriend ? .clear : Color.seilAccent.opacity(0.28), radius: 12, y: 6)
        }
        .buttonStyle(.plain)
        .disabled(toggling)
    }

    // MARK: - Helpers

    /// Busca el ID de título basándose en el texto visible.
    /// PublicIdentity solo expone tituloTexto, no el ID. Intentamos mapear.
    private func findTituloId(for text: String, in p: PublicProfile) -> String? {
        // Si el frameActivo tiene un título asociado con el mismo nombre, úsalo.
        // Fallback: busca en el catálogo un título cuyo texto coincida.
        if let frameId = p.identidad.frameActivo {
            return frameId
        }
        // Fallback genérico
        return nil
    }

    private func colorForCat(_ cat: String) -> Color {
        colorForCategory(cat)
    }
    private func iconForCat(_ cat: String) -> String {
        iconForCategory(cat)
    }
}

// MARK: - Error kinds

enum ProfileErrorKind {
    case sessionExpired  // 401 — JWT expirado
    case notFound        // 404 — usuario no existe
    case network         // sin conexión
    case unknown         // cualquier otro error
}
