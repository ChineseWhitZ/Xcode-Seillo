import SwiftUI

private struct BizScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

struct BizProfileScreen: View {
    let card:                LoyaltyCard
    var showCard:            Bool    = true
    // Datos pre-cargados desde TabCercaView/ExploreView para evitar llamada extra
    var preloadedAddress:    String? = nil
    var preloadedDistrict:   String? = nil
    var preloadedDescription:String? = nil
    @Environment(\.dismiss) var dismiss

    @State private var showStampReceived = false
    @State private var showWriteReview   = false
    @State private var showQRSheet       = false
    @State private var appear       = false
    @State private var scrollOffset: CGFloat = 0

    // Datos cargados del backend
    @State private var reviews: [ReviewItem] = []
    @State private var reviewsRefreshed = false
    @State private var items: [NegocioItemDTO] = []
    @State private var horario: [HorarioDiaDTO] = []
    @State private var descripcion: String = ""
    @State private var direccion: String = ""
    @State private var distrito: String = ""
    @State private var rating: Double = 0
    @State private var reviewCount: Int = 0
    @State private var hoursLabel: String = "Abierto"

    private let api = APIClient.shared

    private var business: Business {
        Business(
            name: card.bizName,
            district: distrito,                // vacío si no disponible — no mostrar categoría
            address: direccion,                // vacío si no disponible — no mostrar categoría
            hoursNow: hoursLabel,
            desc: descripcion.isEmpty ? "Disfruta tus sellos, premios y beneficios en este local." : descripcion,
            bannerColors: card.gradientColors,
            rating: rating > 0 ? rating : 4.5,
            reviewCount: reviewCount,
            tags: [card.location],
            menu: items.isEmpty ? [] : groupItemsToMenu(),
            reviews: reviews,
            lat: -12.0464, lon: -77.0428
        )
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    heroSection

                    VStack(spacing: 18) {
                        businessHeaderSection
                        tagsSection
                        if showCard { loyaltyPreviewPanel }
                        aboutSection
                        if !horario.isEmpty { horarioSection }
                        if !items.isEmpty { menuItemsSection }
                        reviewsSection
                        // "También te puede interesar" — pendiente endpoint backend /api/negocios/similares
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 18)

                    Spacer()
                        .frame(height: 120)
                }
                .background(
                    GeometryReader { geo in
                        Color.clear.preference(
                            key: BizScrollOffsetKey.self,
                            value: -geo.frame(in: .named("bizScroll")).minY
                        )
                    }
                )
            }
            .coordinateSpace(name: "bizScroll")
            .onPreferenceChange(BizScrollOffsetKey.self) { scrollOffset = $0 }
            .ignoresSafeArea(edges: .top)

            bottomCTA
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .enableSwipeBack()
        .sheet(isPresented: $showStampReceived) {
            StampReceivedSheet(card: card, newStampIndex: card.filledStamps)
                .presentationDetents([.height(560)])
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showWriteReview) {
            WriteReviewSheet(card: card, onSubmit: { _, _ in
                Task { await loadReviews() }
            })
                .presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showQRSheet) {
            QRSheetView()
                .presentationDetents(adaptiveDetents(height: 560))
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .task {
            // Poblar con datos pre-cargados si están disponibles (evita llamada extra)
            if let a = preloadedAddress    { direccion   = a }
            if let d = preloadedDistrict   { distrito    = d }
            if let s = preloadedDescription { descripcion = s }
            await loadBusinessData()
            withAnimation(SeillAnimation.chrome.delay(0.06)) {
                appear = true
            }
            // Registrar interacción para personalización de Explorar
            await fireEventoPreferencia(categoria: card.location, tipo: "vista_perfil")
        }
    }
}

// MARK: - Preferencias de evento

extension BizProfileScreen {
    /// Notifica al backend que el usuario vio este perfil,
    /// para mejorar la personalización de Explorar.
    func fireEventoPreferencia(categoria: String, tipo: String) async {
        guard !categoria.isEmpty, TokenStore.isLoggedIn else { return }
        struct EventoRequest: Encodable { let categoria: String; let tipo: String }
        struct EventoResponse: Decodable { let ok: Bool? }
        _ = try? await api.post(
            "api/preferencias/evento",
            body: EventoRequest(categoria: categoria, tipo: tipo)
        ) as EventoResponse
    }
}

// MARK: - Backend loading

extension BizProfileScreen {

    func loadReviews() async {
        let negocioId = card.negocioId
        do {
            let dtos: [ResenaDTO] = try await api.getPublic("api/negocios/\(negocioId)/resenas")
            let palette: [Color] = [.seilAccent, .seilBlue, .seilPurple, .seilGreen, .seilGold]
            let newReviews = dtos.enumerated().map { i, dto in
                ReviewItem(
                    name: dto.nombre,
                    date: formatDate(dto.createdAt),
                    text: dto.texto,
                    stars: dto.estrellas,
                    avatarColor: palette[i % palette.count]
                )
            }
            withAnimation(.easeOut(duration: 0.35)) {
                reviews     = newReviews
                reviewCount = newReviews.count
                if !newReviews.isEmpty {
                    rating = Double(newReviews.reduce(0) { $0 + $1.stars }) / Double(newReviews.count)
                }
                reviewsRefreshed.toggle()
            }
        } catch {}
    }

    private func loadBusinessData() async {
        let negocioId = card.negocioId

        // Cargar info del negocio (dirección, descripción, rating)
        // si no vino pre-cargada desde la pantalla anterior
        if direccion.isEmpty || descripcion.isEmpty {
            if let dtos = try? await api.getPublic("api/negocios") as [NegocioDTO],
               let dto = dtos.first(where: { $0.id == negocioId }) {
                if direccion.isEmpty    { direccion   = dto.direccion  ?? "" }
                if distrito.isEmpty     { distrito    = dto.distrito   ?? "" }
                if descripcion.isEmpty  { descripcion = dto.descripcion ?? "" }
                if rating == 0, let r = dto.rating { rating = r }
                if reviewCount == 0, let rc = dto.reviewCount { reviewCount = rc }
            }
        }

        // Cargar reseñas
        await loadReviews()

        // Cargar items/menú
        do {
            items = try await api.getPublic("api/negocios/\(negocioId)/items")
        } catch {}

        // Cargar horario
        do {
            let h: [HorarioDiaDTO] = try await api.getPublic("api/negocios/\(negocioId)/horario")
            horario = h
            updateHoursLabel()
        } catch {}
    }

    private func groupItemsToMenu() -> [MenuCategory] {
        let grouped = Dictionary(grouping: items) { $0.grupo }
        return grouped.map { (grupo, items) in
            MenuCategory(label: grupo, items: items.map { item in
                MenuItem(
                    name: item.nombre,
                    desc: item.descripcion ?? "",
                    price: item.precio.map { "S/ \(String(format: "%.0f", $0))" } ?? "",
                    badge: nil
                )
            })
        }
    }

    private func updateHoursLabel() {
        let weekday = Calendar.current.component(.weekday, from: Date())
        // weekday: 1=Dom, 2=Lun... → nuestro formato: 0=Lun, 6=Dom
        let diaIdx = weekday == 1 ? 6 : weekday - 2

        if let hoy = horario.first(where: { $0.dia == diaIdx }) {
            if hoy.abierto == 1 {
                let cierre = hoy.horaCierre.prefix(5)
                hoursLabel = "Abierto hasta las \(cierre)"
            } else {
                hoursLabel = "Cerrado hoy"
            }
        }
    }

    private func formatDate(_ iso: String) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = formatter.date(from: iso) ?? {
            let f2 = ISO8601DateFormatter()
            f2.formatOptions = [.withInternetDateTime]
            return f2.date(from: iso)
        }() else { return iso }

        let diff = Date().timeIntervalSince(date)
        if diff < 86400 { return "Hoy" }
        if diff < 172800 { return "Ayer" }
        if diff < 604800 { return "Hace \(Int(diff / 86400)) días" }
        let df = DateFormatter()
        df.dateFormat = "dd MMM yyyy"
        df.locale = Locale(identifier: "es_PE")
        return df.string(from: date)
    }
}

private extension BizProfileScreen {
    var heroSection: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(
                colors: business.bannerColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .frame(height: 210)
            .offset(y: min(scrollOffset * 0.38, 50))
            .overlay(
                LinearGradient(
                    colors: [
                        .black.opacity(0.10),
                        .black.opacity(0.18),
                        Color.seilBg.opacity(0.88)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )

            VStack(spacing: 0) {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 38, height: 38)
                            .glassEffect(in: Circle())
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
                .padding(.top, 56)
                .padding(.horizontal, 16)

                Spacer()

                HStack {
                    ZStack {
                        Circle()
                            .fill(Color.seilSurface.opacity(0.92))
                            .frame(width: 72, height: 72)
                            .overlay(
                                Circle().stroke(Color.seilBorder, lineWidth: 1.5)
                            )

                        Image(systemName: card.icon)
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(card.stampColor)
                    }

                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 12)
            }
        }
        .frame(height: 210)
    }

    var businessHeaderSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(business.name)
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundColor(.seilText)

                    HStack(spacing: 6) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 11))
                            .foregroundColor(.seilGold)

                        Text(String(format: "%.1f", business.rating))
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.seilText)

                        Text("(\(business.reviewCount) reseñas)")
                            .font(.system(size: 11))
                            .foregroundColor(.seilMuted)
                    }
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text(business.district)
                        .font(.system(size: 13, weight: .heavy))
                        .foregroundColor(.seilAccent)

                    Text(business.hoursNow)
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.seilGreen)
                }
            }

            VStack(spacing: 10) {
                if !business.address.isEmpty {
                    SeillDetailRow(icon: "location.fill",  title: "Dirección", value: business.address)
                }
                if !business.district.isEmpty {
                    SeillDetailRow(icon: "map.fill",        title: "Distrito",  value: business.district)
                }
                if let cat = business.tags.first, !cat.isEmpty {
                    SeillDetailRow(icon: "storefront.fill", title: "Categoría", value: cat)
                }
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 12)
    }

    var tagsSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(business.tags, id: \.self) { tag in
                    Text(tag)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.seilMuted2)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color.seilCard)
                        .clipShape(Capsule())
                        .overlay(
                            Capsule().stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
            }
            .padding(.horizontal, 2)
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    var loyaltyPreviewPanel: some View {
        NavigationLink {
            CardDetailScreen(card: card)
        } label: {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text("TU TARJETA EN ESTE LOCAL")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.4)

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.white.opacity(0.35))
                }

                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(card.rewardText)
                            .font(.system(size: 14, weight: .heavy, design: .rounded))
                            .foregroundColor(.seilText)
                            .lineLimit(2)

                        Text(card.isComplete
                             ? "Tu premio ya está listo para canjear."
                             : "Llevas \(card.filledStamps) de \(card.totalStamps) sellos.")
                            .font(SeillFont.body(12))
                            .foregroundColor(card.isComplete ? .seilGreen : .seilMuted2)
                    }

                    Spacer()
                }

                StampsRowView(card: card)

                HStack {
                    if card.isComplete {
                        Label("Premio listo", systemImage: "sparkles")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.seilGreen)
                    } else {
                        Text("Toca para ver el detalle de tu tarjeta")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.seilMuted)
                    }

                    Spacer()
                }
            }
            .padding(18)
            .background(
                LinearGradient(
                    colors: [
                        Color.white.opacity(0.035),
                        Color.white.opacity(0.018)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .background(.ultraThinMaterial.opacity(0.16))
            .clipShape(RoundedRectangle(cornerRadius: 22))
            // seilBorderGlass
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.seilBorderGlass, lineWidth: 1)
            )
            .shadow(color: card.stampColor.opacity(0.10), radius: 14, y: 6)
        }
        .buttonStyle(.plain)
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 16)
    }

    var menuItemsSection: some View {
        let grupos = groupItemsToMenu()

        return VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "fork.knife")
                    .font(.system(size: 12))
                    .foregroundColor(.seilAccent)
                Text("MENÚ / SERVICIOS")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)
                Spacer()
                Text("\(items.count) item\(items.count == 1 ? "" : "s")")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.seilMuted)
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(Color.seilCard2)
                    .clipShape(Capsule())
            }

            ForEach(grupos, id: \.label) { category in
                VStack(alignment: .leading, spacing: 0) {
                    Text(category.label.uppercased())
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.seilAccent)
                        .tracking(1.0)
                        .padding(.bottom, 8)

                    VStack(spacing: 0) {
                        let preview = Array(category.items.prefix(3))
                        ForEach(Array(preview.enumerated()), id: \.offset) { i, item in
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name)
                                        .font(SeillFont.headline(13))
                                        .foregroundColor(.seilText)
                                    if !item.desc.isEmpty {
                                        Text(item.desc)
                                            .font(SeillFont.caption(11))
                                            .foregroundColor(.seilMuted)
                                            .lineLimit(1)
                                    }
                                }
                                Spacer()
                                if !item.price.isEmpty {
                                    Text(item.price)
                                        .font(SeillFont.headline(13))
                                        .foregroundColor(.seilAccent)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 11)

                            if i < preview.count - 1 {
                                Divider().background(Color.seilBorder).padding(.horizontal, 14)
                            }
                        }

                        if category.items.count > 3 {
                            Divider().background(Color.seilBorder).padding(.horizontal, 14)
                            Text("+ \(category.items.count - 3) más")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.seilMuted)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                    }
                    .background(Color.seilCard2)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
                }
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 18)
    }

    var horarioSection: some View {
        let dayNames = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
        let cal      = Calendar.current
        let weekday  = cal.component(.weekday, from: Date())
        let hoyIdx   = (weekday + 5) % 7   // 0=Lun … 6=Dom

        return VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "clock.fill")
                    .font(.system(size: 12))
                    .foregroundColor(.seilAccent)
                Text("HORARIO")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)
            }

            VStack(spacing: 0) {
                ForEach(horario.sorted(by: { $0.dia < $1.dia }), id: \.dia) { h in
                    let isToday  = h.dia == hoyIdx
                    let isOpen   = h.abierto == 1
                    let dayLabel = h.dia >= 0 && h.dia < dayNames.count ? dayNames[h.dia] : "—"

                    HStack {
                        Text(dayLabel)
                            .font(.system(size: 13, weight: isToday ? .bold : .regular))
                            .foregroundColor(isToday ? .seilText : .seilMuted2)

                        Spacer()

                        if isOpen {
                            let inicio = String(h.horaInicio.prefix(5))
                            let cierre = String(h.horaCierre.prefix(5))
                            Text("\(formatHourBiz(inicio)) – \(formatHourBiz(cierre))")
                                .font(.system(size: 13, weight: isToday ? .semibold : .regular))
                                .foregroundColor(isToday ? .seilGreen : .seilText)
                        } else {
                            Text("Cerrado")
                                .font(.system(size: 13))
                                .foregroundColor(.seilMuted)
                        }
                    }
                    .padding(.vertical, 7)

                    if h.dia < (horario.map(\.dia).max() ?? 6) {
                        Divider().background(Color.seilBorder)
                    }
                }
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    private func formatHourBiz(_ hhmm: String) -> String {
        let parts = hhmm.split(separator: ":")
        guard parts.count == 2, let h = Int(parts[0]), let m = Int(parts[1]) else { return hhmm }
        let suffix = h < 12 ? "am" : "pm"
        let h12    = h == 0 ? 12 : (h > 12 ? h - 12 : h)
        return m == 0 ? "\(h12)\(suffix)" : "\(h12):\(String(format: "%02d", m))\(suffix)"
    }

    var aboutSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ACERCA DEL LOCAL")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)

            Text(
                business.desc.isEmpty
                ? "Negocio local en tu zona."
                : business.desc
            )
            .font(SeillFont.body(13))
            .foregroundColor(.seilMuted2)
            .lineSpacing(4)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 18)
    }

    var reviewsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            // ── Header ───────────────────────────────────────────────
            HStack {
                Text("RESEÑAS")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)

                Spacer()

                HStack(spacing: 4) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 10))
                        .foregroundColor(.seilGold)
                    Text(String(format: "%.1f", business.rating))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.seilText)
                    Text("(\(business.reviewCount))")
                        .font(.system(size: 11))
                        .foregroundColor(.seilMuted)
                }
            }

            // ── Botón escribir reseña — solo si tiene sellos ─────────
            if card.filledStamps > 0 {
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    showWriteReview = true
                } label: {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color.seilGold.opacity(0.10))
                                .frame(width: 38, height: 38)
                            Image(systemName: "star.bubble.fill")
                                .font(.system(size: 16))
                                .foregroundColor(.seilGold)
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            Text("Escribe una reseña")
                                .font(SeillFont.headline(13))
                                .foregroundColor(.seilText)
                            Text("Tu opinión está verificada por tus sellos")
                                .font(SeillFont.caption(11))
                                .foregroundColor(.seilMuted)
                        }

                        Spacer()

                        Image(systemName: "chevron.right")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(Color.white.opacity(0.25))
                    }
                    .padding(14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.seilGold.opacity(0.22), lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)
            }

            // ── Reseñas existentes ───────────────────────────────────
            if !business.reviews.isEmpty {
                ForEach(business.reviews) { review in
                    ReviewRow(review: review)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
                .id(reviewsRefreshed)
            } else {
                // Estado vacío si no hay reseñas aún
                HStack(spacing: 10) {
                    Image(systemName: "bubble.left.and.bubble.right")
                        .font(.system(size: 18))
                        .foregroundColor(.seilMuted)
                    Text("Sé el primero en reseñar este local")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 8)
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 20)
        // SeillAnimation.listEntrance con delay
        .animation(SeillAnimation.listEntrance.delay(0.18), value: appear)
    }



    var bottomCTA: some View {
        VStack {
            Spacer()

            VStack(spacing: 0) {
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [Color.clear, Color.seilBg.opacity(0.86), Color.seilBg],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(height: 32)

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    showQRSheet = true
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "qrcode.viewfinder")
                            .font(.system(size: 18, weight: .semibold))

                        Text(card.isComplete ? "Mostrar QR para canjear" : "Mostrar QR en tienda")
                            .font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(
                        LinearGradient(
                            colors: card.isComplete
                                ? [Color.seilGreen.opacity(0.95), Color.seilGreen]
                                : [Color.seilAccent.opacity(0.92), Color.seilAccent2.opacity(0.92)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(
                        color: (card.isComplete ? Color.seilGreen : Color.seilAccent).opacity(0.30),
                        radius: 16,
                        y: 6
                    )
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
                .background(Color.seilBg)
            }
        }
    }

}

// ─── ReviewRow ────────────────────────────────────────────────────────────────
private struct ReviewRow: View {
    let review: ReviewItem

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(review.avatarColor.opacity(0.15))
                        .frame(width: 34, height: 34)
                    Text(String(review.name.prefix(1)))
                        .font(.system(size: 13, weight: .heavy, design: .rounded))
                        .foregroundColor(review.avatarColor)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(review.name)
                        .font(SeillFont.headline(12))
                        .foregroundColor(.seilText)
                    Text(review.date)
                        .font(SeillFont.caption(10))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                HStack(spacing: 2) {
                    ForEach(1...5, id: \.self) { i in
                        Image(systemName: i <= review.stars ? "star.fill" : "star")
                            .font(.system(size: 10))
                            .foregroundColor(i <= review.stars ? .seilGold : Color.seilBorder)
                    }
                }
            }

            Text(review.text)
                .font(SeillFont.body(12))
                .foregroundColor(.seilMuted2)
                .lineSpacing(3)
        }
        .padding(.top, 4)
    }
}

// ─── SimilarBizRow ───────────────────────────────────────────────────────────
private struct SimilarBizRow: View {
    let entry: CardEntry

    var body: some View {
        HStack(spacing: 12) {

            // Icono del negocio con color de categoría
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(entry.card.stampColor.opacity(0.12))
                    .frame(width: 44, height: 44)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(entry.card.stampColor.opacity(0.20), lineWidth: 1)
                    )

                Image(systemName: entry.card.icon)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(entry.card.stampColor)
            }

            // Nombre + horario + tags
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.business.name)
                    .font(SeillFont.headline(13))
                    .foregroundColor(.seilText)
                    .lineLimit(1)

                HStack(spacing: 6) {
                    // Rating
                    HStack(spacing: 3) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 9))
                            .foregroundColor(.seilGold)
                        Text(String(format: "%.1f", entry.business.rating))
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilText)
                    }

                    Text("·")
                        .font(.system(size: 10))
                        .foregroundColor(.seilMuted)

                    Text(entry.business.district)
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.seilAccent)
                }
            }

            Spacer()

            // Sellos del usuario en este negocio (si los tiene)
            VStack(alignment: .trailing, spacing: 4) {
                // Premio disponible
                if entry.card.isComplete {
                    Text("PREMIO")
                        .font(.system(size: 8, weight: .black))
                        .foregroundColor(.seilGreen)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color.seilGreen.opacity(0.12))
                        .clipShape(Capsule())
                } else {
                    // Progreso de la tarjeta
                    HStack(spacing: 3) {
                        Text("\(entry.card.filledStamps)/\(entry.card.totalStamps)")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(entry.card.stampColor)
                        Text("sellos")
                            .font(.system(size: 10))
                            .foregroundColor(.seilMuted)
                    }
                }

                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white.opacity(0.28))
            }
        }
        .padding(13)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .shadow(color: entry.card.stampColor.opacity(0.05), radius: 8, y: 3)
    }
}
