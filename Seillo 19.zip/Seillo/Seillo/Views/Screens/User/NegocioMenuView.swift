import SwiftUI

// ─── NegocioMenuView ──────────────────────────────────────────────────────────
//
// Carta/menú de un negocio vista desde el lado del cliente.
// Muestra items agrupados por categoría (Bebidas, Comida, Servicios, etc.)
//
// Ruta: Seillo/Views/Screens/User/NegocioMenuView.swift
// Acceso: BizProfileScreen → botón "Ver carta" o "Servicios"
// ─────────────────────────────────────────────────────────────────────────────

struct NegocioMenuView: View {
    let negocioId: String
    let negocioNombre: String

    @Environment(\.dismiss) private var dismiss

    @State private var items:   [NegocioItem] = []
    @State private var loading  = true
    @State private var hasError = false
    @State private var appear:  Double = 0

    private let service: NegocioServiceProtocol = APINegocioService()

    /// Items agrupados por categoría
    private var grouped: [(String, [NegocioItem])] {
        let dict = Dictionary(grouping: items.filter(\.disponible)) { $0.grupo }
        return dict.sorted { $0.key < $1.key }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                if loading {
                    VStack(spacing: 16) {
                        ProgressView().tint(.seilAccent)
                        Text("Cargando carta...")
                            .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                    }
                } else if hasError || items.isEmpty {
                    SeillEmptyState(
                        icon: "menucard",
                        title: items.isEmpty ? "Sin carta" : "Error al cargar",
                        message: items.isEmpty
                            ? "Este negocio aún no ha publicado su carta."
                            : "No pudimos cargar la carta. Intenta de nuevo."
                    )
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 0) {
                            ForEach(Array(grouped.enumerated()), id: \.element.0) { groupIdx, group in
                                let (category, categoryItems) = group

                                // ── Category header ──────────────────
                                HStack {
                                    Text(category.uppercased())
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundColor(.seilMuted)
                                        .tracking(1.2)
                                    Spacer()
                                    Text("\(categoryItems.count)")
                                        .font(SeillFont.caption(10))
                                        .foregroundColor(.seilMuted)
                                }
                                .padding(.horizontal, 20)
                                .padding(.top, groupIdx == 0 ? 12 : 24)
                                .padding(.bottom, 10)
                                .sectionAppear(progress: appear,
                                               start: Double(groupIdx) * 0.15,
                                               end: Double(groupIdx) * 0.15 + 0.3)

                                // ── Items ────────────────────────────
                                ForEach(Array(categoryItems.enumerated()), id: \.element.id) { itemIdx, item in
                                    menuItemRow(item, isLast: itemIdx == categoryItems.count - 1)
                                        .padding(.horizontal, 16)
                                        .staggerIn(
                                            index: groupIdx * 5 + itemIdx,
                                            appear: appear,
                                            offset: 12,
                                            stagger: 0.05
                                        )
                                }
                            }

                            Spacer().frame(height: 40)
                        }
                    }
                }
            }
            .navigationTitle(negocioNombre)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                }
            }
        }
        .task {
            let result = await service.getItems()
            switch result {
            case .success(let data):
                items = data
            case .failure:
                hasError = true
            }
            loading = false
            withAnimation(.easeOut(duration: 0.7)) { appear = 1 }
        }
    }

    // MARK: - Item Row

    private func menuItemRow(_ item: NegocioItem, isLast: Bool) -> some View {
        VStack(spacing: 0) {
            HStack(alignment: .top, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(item.nombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)

                        if item.fechaInicio != nil || item.fechaFin != nil {
                            SeillStatusBadge(text: "Temporal", color: .seilGold, size: .small)
                        }
                    }

                    if let desc = item.descripcion, !desc.isEmpty {
                        Text(desc)
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                            .lineLimit(2)
                    }

                    if let dur = item.duracionMin {
                        HStack(spacing: 4) {
                            Image(systemName: "clock")
                                .font(.system(size: 9))
                            Text("\(dur) min")
                                .font(SeillFont.caption(10))
                        }
                        .foregroundColor(.seilMuted)
                    }
                }

                Spacer()

                if let precio = item.precio {
                    Text("S/ \(String(format: "%.0f", precio))")
                        .font(.system(size: 15, weight: .heavy, design: .rounded))
                        .foregroundColor(.seilAccent)
                }
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 16)

            if !isLast {
                Rectangle()
                    .fill(Color.seilBorder)
                    .frame(height: 1)
                    .padding(.leading, 16)
            }
        }
        .background(Color.seilCard)
        .clipShape(Rectangle())
    }
}
