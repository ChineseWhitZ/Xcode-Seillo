import SwiftUI

// ─── SearchView ───────────────────────────────────────────────────────────────
// Pantalla de búsqueda dedicada con auto-focus, historial y trending.
// Acceso: TabCercaView → toca el campo de búsqueda
// ─────────────────────────────────────────────────────────────────────────────

private struct SearchCategory: Identifiable {
    let id      = UUID()
    let label:  String
    let icon:   String
    let keyword: String
    let color:  Color
}

private let searchCategories: [SearchCategory] = [
    // ── Lo más peruano — fila 1 ────────────────────────────────────────────
    .init(label: "Café",        icon: "cup.and.saucer.fill",     keyword: "caf",      color: .seilGold),
    .init(label: "Pollería",    icon: "flame.fill",              keyword: "poll",     color: .seilRose),
    .init(label: "Cevichería",  icon: "fish.fill",               keyword: "cevich",   color: Color(hex: "#00B4D8")),
    .init(label: "Sanguchería", icon: "bag.fill",                keyword: "sanguch",  color: Color(hex: "#E8892B")),
    // ── Fila 2 ────────────────────────────────────────────────────────────
    .init(label: "Jugos",       icon: "drop.fill",               keyword: "jug",      color: .seilGreen),
    .init(label: "Chifa",       icon: "fork.knife.circle.fill",  keyword: "chifa",    color: Color(hex: "#FF3B30")),
    .init(label: "Barbería",    icon: "scissors",                keyword: "barber",   color: .seilPurple),
    .init(label: "Restaurante", icon: "fork.knife",              keyword: "restaurante", color: .seilAccent),
    // ── Fila 3 ────────────────────────────────────────────────────────────
    .init(label: "Panadería",   icon: "leaf.fill",               keyword: "panader",  color: Color(hex: "#D4A843")),
    .init(label: "Heladería",   icon: "snowflake",               keyword: "helad",    color: Color(hex: "#5BC8E8")),
    .init(label: "Gimnasio",    icon: "dumbbell.fill",           keyword: "gym",      color: .seilBlue),
    .init(label: "Spa",         icon: "sparkles",                keyword: "spa",      color: .seilPurple),
]

private let trending: [String] = [
    "Pollo a la brasa", "Ceviche Miraflores", "Café especialidad",
    "Barbería Rey", "Jugos naturales", "Sanguchería Barranco"
]

struct SearchView: View {
    let entries: [CardEntry]

    @Environment(\.dismiss) var dismiss

    @State private var query        = ""
    @AppStorage("seillo_recent_searches") private var recentRaw: String = ""
    @State private var appear       = false
    @FocusState private var focused: Bool

    // Easter eggs (Lote 6)
    @State private var easterEggMessage: String? = nil
    @State private var showEasterEgg = false

    private static let easterEggs: [String: String] = [
        "seillo":     "¡Tú sí que sabes buscar!",
        "konami":     "↑↑↓↓←→←→BA — ¡Modo secreto activado!",
        "developer":  "Hecho con pasión en Lima, Perú",
        "cafe":       "Fun fact: Perú es el 7° productor mundial de café",
        "unicornio":  "No encontramos unicornios... pero sí sellos mágicos",
        "42":         "La respuesta a la vida, el universo y todo lo demás",
        "hello":      "¡Hola! ¿Buscas algo especial?",
    ]

    // Convierte el string CSV de AppStorage en array y viceversa
    private var recentSearches: [String] {
        recentRaw.isEmpty ? [] : recentRaw.components(separatedBy: "|||").filter { !$0.isEmpty }
    }
    private func saveRecents(_ list: [String]) {
        recentRaw = list.prefix(6).joined(separator: "|||")
    }

    private var results: [CardEntry] {
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else { return [] }
        let q = query.lowercased()
        return entries.filter {
            $0.business.name.lowercased().contains(q) ||
            $0.business.tags.contains { $0.lowercased().contains(q) }
        }
    }

    private var showResults: Bool { !query.trimmingCharacters(in: .whitespaces).isEmpty }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                // ── Search bar ─────────────────────────────────────────────
                HStack(spacing: 10) {
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(focused ? .seilAccent : .seilMuted)

                        TextField("Buscar cafés, restaurantes...", text: $query)
                            .font(SeillFont.body(15))
                            .foregroundColor(.seilText)
                            .focused($focused)
                            .autocorrectionDisabled()
                            .submitLabel(.search)
                            .onSubmit { addToRecent(query) }

                        if !query.isEmpty {
                            Button {
                                Haptics.tap()
                                query = ""
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 16))
                                    .foregroundColor(.seilMuted)
                            }
                            .buttonStyle(.plain)
                            .transition(.opacity.combined(with: .scale(scale: 0.8)))
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(focused ? Color.seilAccent.opacity(0.45) : Color.seilBorder, lineWidth: 1)
                    )
                    .animation(.easeInOut(duration: 0.22), value: focused)

                    Button {
                        Haptics.tap()
                        focused = false
                        dismiss()
                    } label: {
                        Text("Cancelar")
                            .font(SeillFont.body(14))
                            .foregroundColor(.seilAccent)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .background(Color.seilBg)
                .overlay(alignment: .bottom) {
                    Rectangle().fill(Color.seilBorder).frame(height: 1)
                }

                // ── Contenido ──────────────────────────────────────────────
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        if showResults {
                            resultsSection
                        } else {
                            categoriesSection
                            recentSection
                            trendingSection
                        }
                        // Sin tab bar en fullScreenCover — spacer de cortesía
                        Spacer().frame(height: 40)
                    }
                }
                .animation(.easeOut(duration: 0.22), value: showResults)
            }

            // Easter egg banner (Lote 6)
            easterEggBanner
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { focused = true }
            withAnimation(.easeOut(duration: 0.35)) { appear = true }
        }
    }

    // MARK: - Categorías

    private var categoriesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SeillSectionLabel(text: "EXPLORAR POR CATEGORÍA")
                .padding(.horizontal, 20)

            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 10
            ) {
                ForEach(searchCategories) { cat in
                    Button {
                        Haptics.tap()
                        query = cat.keyword
                        addToRecent(cat.label)
                    } label: {
                        VStack(spacing: 6) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(cat.color.opacity(0.12))
                                    .frame(height: 46)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(cat.color.opacity(0.20), lineWidth: 1)
                                    )
                                Image(systemName: cat.icon)
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(cat.color)
                            }
                            Text(cat.label)
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilMuted2)
                                .lineLimit(1)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
        .padding(.top, 20)
        .padding(.bottom, 24)
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Recientes

    private var recentSection: some View {
        VStack(spacing: 0) {
            if !recentSearches.isEmpty {
                HStack {
                    SeillSectionLabel(text: "BÚSQUEDAS RECIENTES")
                    Spacer()
                    Button {
                        Haptics.tap()
                        withAnimation { saveRecents([]) }
                    } label: {
                        Text("Borrar")
                            .font(SeillFont.caption(11))
                            .foregroundColor(.seilAccent)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 10)

                VStack(spacing: 0) {
                    ForEach(Array(recentSearches.enumerated()), id: \.offset) { i, term in
                        Button {
                            Haptics.tap()
                            query = term
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.system(size: 14))
                                    .foregroundColor(.seilMuted)
                                    .frame(width: 20)
                                Text(term)
                                    .font(SeillFont.body(14))
                                    .foregroundColor(.seilText)
                                Spacer()
                                Image(systemName: "arrow.up.left")
                                    .font(.system(size: 12))
                                    .foregroundColor(.seilMuted)
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 13)
                        }
                        .buttonStyle(.plain)

                        if i < recentSearches.count - 1 {
                            Divider().background(Color.seilBorder).padding(.leading, 52)
                        }
                    }
                }
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.3).delay(0.06), value: appear)
            }
        }
    }

    // MARK: - Trending

    private var trendingSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SeillSectionLabel(text: "TENDENCIAS")
                .padding(.horizontal, 20)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(trending, id: \.self) { term in
                        Button {
                            Haptics.tap()
                            query = term
                            addToRecent(term)
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "flame.fill")
                                    .font(.system(size: 11))
                                    .foregroundColor(.seilAccent)
                                Text(term)
                                    .font(SeillFont.label(12))
                                    .foregroundColor(.seilText)
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 9)
                            .background(Color.seilCard)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.3).delay(0.10), value: appear)
    }

    // MARK: - Resultados

    private var resultsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                SeillSectionLabel(text:
                    results.isEmpty
                    ? "SIN RESULTADOS"
                    : "\(results.count) \(results.count == 1 ? "LOCAL" : "LOCALES") ENCONTRADOS"
                )
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 12)

            if results.isEmpty {
                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16).fill(Color.seilCard)
                            .frame(width: 60, height: 60)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 24)).foregroundColor(.seilMuted)
                    }
                    Text("No encontramos \"\(query)\"")
                        .font(SeillFont.headline(15)).foregroundColor(.seilText)
                    Text("Prueba con otra búsqueda o\nexplora por categoría")
                        .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 48)
            } else {
                ForEach(results, id: \.business.name) { entry in
                    NavigationLink(destination: BizProfileScreen(card: entry.card)) {
                        NearbyBusinessRow(entry: entry)
                    }
                    .buttonStyle(CardPressStyle())
                    .simultaneousGesture(TapGesture().onEnded { addToRecent(query) })
                }
            }
        }
    }

    // MARK: - Helpers

    private func addToRecent(_ term: String) {
        let trimmed = term.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        var list = recentSearches
        list.removeAll { $0.lowercased() == trimmed.lowercased() }
        list.insert(trimmed, at: 0)
        saveRecents(list)

        // Easter eggs (Lote 6)
        if let egg = Self.easterEggs[trimmed.lowercased()] {
            Haptics.success()
            easterEggMessage = egg
            withAnimation(.spring(response: 0.35, dampingFraction: 0.7)) {
                showEasterEgg = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation { showEasterEgg = false }
            }
        }
    }
}

// ─── EasterEggBanner ──────────────────────────────────────────────────────────
// Se muestra como overlay dentro del ZStack del body — añadir al final
extension SearchView {
    var easterEggBanner: some View {
        Group {
            if showEasterEgg, let msg = easterEggMessage {
                VStack {
                    HStack(spacing: 10) {
                        Image(systemName: "sparkles")
                            .font(.system(size: 14))
                            .foregroundColor(.seilGold)
                        Text(msg)
                            .font(SeillFont.headline(13))
                            .foregroundColor(.seilText)
                    }
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.seilGold.opacity(0.3), lineWidth: 1)
                    )
                    .shadow(color: Color.seilGold.opacity(0.2), radius: 12, y: 4)
                    .transition(.move(edge: .top).combined(with: .opacity))

                    Spacer()
                }
                .padding(.top, 60)
            }
        }
    }
}
