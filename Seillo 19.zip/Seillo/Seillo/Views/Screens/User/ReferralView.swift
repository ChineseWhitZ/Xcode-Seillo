import SwiftUI

// ─── ReferralView ─────────────────────────────────────────────────────────────
// El usuario comparte su código SEILLO-XXXX para que sus amigos se unan.
// Acceso: TabPerfilView → "Invitar amigos"
// Nota: el bonus de 2 sellos fue removido — ahora es solo invitación social.
// ─────────────────────────────────────────────────────────────────────────────

struct ReferralView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var profileStore: ProfileStore

    @State private var appear     = false
    @State private var codeCopied = false

    // Código formato SEILLO-XXXX derivado del nombre del usuario
    private var referralCode: String {
        let raw = profileStore.profile.nombre
            .uppercased()
            .filter { $0.isLetter }
            .prefix(4)
        return "SEILLO-\(raw.isEmpty ? "USER" : String(raw))"
    }
    private var referralLink: String { "https://seillo.site/ref/\(referralCode)" }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilPurple.opacity(0.10), .clear],
                center: .init(x: 0.5, y: 0.14),
                startRadius: 0, endRadius: 380
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        Spacer().frame(height: 8)
                        heroSection
                        referralStats
                        howItWorksSection
                        linkSection
                        Spacer().frame(height: 40)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tap(); dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()
                Text("Invitar amigos")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)
                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 14)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Hero

    private var heroSection: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle().fill(Color.seilPurple.opacity(0.08)).frame(width: 130, height: 130)
                Circle().fill(Color.seilPurple.opacity(0.14)).frame(width: 96, height: 96)
                    .overlay(Circle().stroke(Color.seilPurple.opacity(0.22), lineWidth: 1.5))
                Image(systemName: "person.2.wave.2.fill")
                    .font(.system(size: 40, weight: .semibold))
                    .foregroundColor(.seilPurple)
                    .shadow(color: Color.seilPurple.opacity(0.50), radius: 16, y: 5)
            }
            .scaleEffect(appear ? 1 : 0.72)
            .opacity(appear ? 1 : 0)

            VStack(spacing: 6) {
                Text("Invita amigos\na Seillo")
                    .font(SeillFont.display(24))
                    .foregroundColor(.seilText)
                    .multilineTextAlignment(.center)
                    .lineSpacing(2)

                Text("Comparte tu código y que más personas descubran los negocios locales que más te gustan.")
                    .font(SeillFont.body(14))
                    .foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }
            .opacity(appear ? 1 : 0)
            .animation(.easeOut(duration: 0.4).delay(0.12), value: appear)
        }
    }

    // MARK: - Stats de referidos (Lote 6)

    private var referralStats: some View {
        HStack(spacing: 10) {
            statChip(value: "5", label: "Invitados", icon: "person.2.fill", color: .seilPurple)
            statChip(value: "3", label: "Registrados", icon: "checkmark.circle.fill", color: .seilGreen)
            statChip(value: "6", label: "Sellos bonus", icon: "seal.fill", color: .seilAccent)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.10), value: appear)
    }

    private func statChip(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 14)).foregroundColor(color)
            Text(value).font(.system(size: 18, weight: .heavy, design: .rounded)).foregroundColor(color)
            Text(label).font(.system(size: 9, weight: .bold)).foregroundColor(.seilMuted).tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
    }

    // MARK: - How it works

    private var howItWorksSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("CÓMO FUNCIONA")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.2)

            VStack(spacing: 0) {
                stepRow(icon: "square.and.arrow.up", color: .seilPurple,
                        title: "Comparte tu código",
                        subtitle: "Mándalo por WhatsApp, redes o donde quieras")
                Divider().background(Color.seilBorder).padding(.leading, 50)
                stepRow(icon: "person.badge.plus", color: .seilBlue,
                        title: "Tu amigo se registra",
                        subtitle: "Usa tu código \(referralCode) al crear su cuenta")
                Divider().background(Color.seilBorder).padding(.leading, 50)
                stepRow(icon: "storefront.fill", color: .seilAccent,
                        title: "Descubren juntos",
                        subtitle: "Acumulan sellos en los negocios de su ciudad")
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.14), value: appear)
    }

    // MARK: - Link

    private var linkSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("TU CÓDIGO PERSONAL")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.2)

            // Código grande y visible
            VStack(spacing: 8) {
                Text(referralCode)
                    .font(.system(size: 26, weight: .heavy, design: .monospaced))
                    .foregroundColor(.seilPurple)
                    .tracking(2)

                Text(referralLink)
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundColor(.seilMuted2)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 20)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(codeCopied ? Color.seilGreen.opacity(0.35) : Color.seilPurple.opacity(0.22), lineWidth: 1.5)
            )
            .animation(.easeInOut(duration: 0.22), value: codeCopied)

            // Botones
            HStack(spacing: 10) {
                // Copiar código
                Button {
                    UIPasteboard.general.string = referralCode
                    Haptics.success()
                    withAnimation { codeCopied = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                        withAnimation { codeCopied = false }
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: codeCopied ? "checkmark" : "doc.on.doc")
                            .font(.system(size: 13, weight: .semibold))
                        Text(codeCopied ? "¡Copiado!" : "Copiar código")
                            .font(SeillFont.label(14))
                    }
                    .foregroundColor(codeCopied ? .seilGreen : .seilPurple)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(codeCopied ? Color.seilGreen.opacity(0.10) : Color.seilPurple.opacity(0.10))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(codeCopied ? Color.seilGreen.opacity(0.30) : Color.seilPurple.opacity(0.25), lineWidth: 1)
                    )
                    .animation(.easeInOut(duration: 0.22), value: codeCopied)
                }
                .buttonStyle(.plain)

                // Compartir nativo
                ShareLink(
                    item: URL(string: referralLink)!,
                    subject: Text("Únete a Seillo"),
                    message: Text("¡Descarga Seillo y regístrate con mi código \(referralCode)! Acumula sellos en los mejores negocios locales. Descárgala aquí: \(referralLink)")
                ) {
                    HStack(spacing: 6) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 13, weight: .semibold))
                        Text("Compartir")
                            .font(SeillFont.label(14))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.seilPurple)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .shadow(color: Color.seilPurple.opacity(0.35), radius: 10, y: 3)
                }
                .buttonStyle(.plain)
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.18), value: appear)
    }

    // MARK: - Helpers

    private func stepRow(icon: String, color: Color, title: String, subtitle: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color.opacity(0.12))
                    .frame(width: 36, height: 36)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(color.opacity(0.20), lineWidth: 1))
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(color)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(SeillFont.headline(13)).foregroundColor(.seilText)
                Text(subtitle).font(SeillFont.body(11)).foregroundColor(.seilMuted2)
            }
            Spacer()
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
    }
}
