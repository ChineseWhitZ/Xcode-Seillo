import SwiftUI
import UIKit
import Combine

// ─── TabBarState ──────────────────────────────────────────────────────────────
// Mantenido como stub vacío para no romper referencias en la cadena de compilación.
@MainActor
class TabBarState: ObservableObject {
    @Published var isVisible: Bool = true
    func show() {}
    func hide() {}
}

struct HomeView: View {
    @EnvironmentObject var profileStore: ProfileStore

    private enum AppTab: Hashable {
        case cards, rewards, nearby, profile
    }

    @State private var selectedTab: AppTab = .cards
    @AppStorage("app_appearance") private var appearance = "amoled"

    var body: some View {
        TabView(selection: $selectedTab) {
            Tab(SeillStrings.tab.cards, systemImage: "creditcard", value: AppTab.cards) {
                NavigationStack {
                    TabCardsView()
                }
                .environmentObject(profileStore)
            }

            Tab(SeillStrings.tab.rewards, systemImage: "gift", value: AppTab.rewards) {
                NavigationStack {
                    TabPremiosView()
                }
                .environmentObject(profileStore)
            }

            Tab(SeillStrings.tab.nearby, systemImage: "map", value: AppTab.nearby) {
                NavigationStack {
                    TabCercaView()
                }
            }

            Tab(SeillStrings.tab.profile, systemImage: "person", value: AppTab.profile) {
                NavigationStack {
                    TabPerfilView()
                }
                .environmentObject(profileStore)
            }
        }
        .tint(.seilAccent)
        // Garantiza que el glass siempre tenga material — sin esto el bar
        // puede desaparecer en pantallas donde el scroll está en el tope.
        .toolbarBackground(.visible, for: .tabBar)
        .onChange(of: selectedTab) { _, _ in
            // Haptic ligero en cada cambio de tab — idéntico a Music y App Store.
            // La ausencia de este feedback es lo que hace que un tab bar se
            // sienta "genérico" frente a uno nativo.
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        }
        .onAppear {
            configureTabBarAppearance()
        }
        .onChange(of: appearance) { _, _ in
            // Reaplica la apariencia cuando el usuario cambia el tema en Settings.
            configureTabBarAppearance()
        }
    }

    // MARK: - UITabBarAppearance

    /// Configura UITabBarAppearance para que el Liquid Glass funcione correctamente
    /// en ambos modos (AMOLED y Light).
    ///
    /// Sin esta configuración, en AMOLED el sistema usa un background oscuro
    /// semitransparente que combina mal con #000000 — el glass se ve opaco
    /// en lugar de translúcido. Con backgroundColor = .clear el blur tiene
    /// material real (el contenido que scrollea debajo) para refractar.
    private func configureTabBarAppearance() {
        let appearance = UITabBarAppearance()
        appearance.configureWithDefaultBackground()

        // Background transparent — el sistema aplica el glass encima.
        // Sobre AMOLED (#000000) el blur tiene contenido negro para refractar,
        // produciendo el vidrio oscuro que se ve en Music en dark mode.
        // Sobre Light (#F5F2EF) el blur tiene contenido claro, produciendo
        // el efecto frosted glass que se ve en App Store en light mode.
        appearance.backgroundColor = .clear
        appearance.backgroundEffect = UIBlurEffect(style: .systemChromeMaterial)

        // Ícono activo: naranja Seillo
        let activeColor = UIColor(Color.seilAccent)
        let inactiveColor = UIColor.secondaryLabel

        let activeItem = UITabBarItemAppearance()
        activeItem.normal.iconColor    = activeColor
        activeItem.normal.titleTextAttributes = [
            .foregroundColor: activeColor,
            .font: UIFont.systemFont(ofSize: 10, weight: .semibold)
        ]

        let inactiveItem = UITabBarItemAppearance()
        inactiveItem.normal.iconColor    = inactiveColor
        inactiveItem.normal.titleTextAttributes = [
            .foregroundColor: inactiveColor,
            .font: UIFont.systemFont(ofSize: 10, weight: .regular)
        ]

        appearance.stackedLayoutAppearance   = inactiveItem
        appearance.inlineLayoutAppearance    = inactiveItem
        appearance.compactInlineLayoutAppearance = inactiveItem

        // selectedItem no existe en UITabBarAppearance — el tint del TabView
        // (.tint(.seilAccent)) ya maneja el ícono activo en iOS 26.

        UITabBar.appearance().standardAppearance   = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
}
