import SwiftUI

// ─── AboutSeilloView ──────────────────────────────────────────────────────────
// Sheet presentado desde TabPerfilView → showAbout
// Reemplaza el stub anterior — ahora tiene logo hero, stats, features,
// links con sheets legales y footer.
// ─────────────────────────────────────────────────────────────────────────────

struct AboutSeilloView: View {

    @Environment(\.dismiss) private var dismiss

    @State private var progress: Double = 0
    @State private var showPrivacy = false
    @State private var showTerms   = false

    // Fracción [start, end] dentro de progress → alpha / offset
    private func a(_ s: Double, _ e: Double) -> Double {
        ((progress - s) / (e - s)).clamped(to: 0...1)
    }
    private func o(_ s: Double, _ e: Double) -> CGFloat {
        CGFloat(20 * (1 - a(s, e)))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {

                        // ── Logo hero ──────────────────────────────────────
                        heroSection
                            .opacity(a(0.00, 0.30))
                            .offset(y: o(0.00, 0.30))

                        // ── Descripción ────────────────────────────────────
                        descriptionCard
                            .opacity(a(0.10, 0.40))
                            .offset(y: o(0.10, 0.40))

                        // ── Stats row ──────────────────────────────────────
                        statsRow
                            .opacity(a(0.20, 0.50))
                            .offset(y: o(0.20, 0.50))

                        // ── Características ────────────────────────────────
                        featuresCard
                            .opacity(a(0.30, 0.60))
                            .offset(y: o(0.30, 0.60))

                        // ── Links ──────────────────────────────────────────
                        linksCard
                            .opacity(a(0.45, 0.75))
                            .offset(y: o(0.45, 0.75))

                        // ── Footer ─────────────────────────────────────────
                        footerLabel
                            .opacity(a(0.60, 0.90))

                        Spacer().frame(height: 40)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                }
            }
            .navigationTitle("Acerca de Seillo")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 30, height: 30)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                }
            }
            .onAppear {
                withAnimation(.easeOut(duration: 0.72)) {
                    progress = 1
                }
            }
            .sheet(isPresented: $showPrivacy) {
                LegalSheet(title: "Política de privacidad", content: privacyText)
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
            .sheet(isPresented: $showTerms) {
                LegalSheet(title: "Términos de uso", content: termsText)
                    .presentationDragIndicator(.visible)
                    .presentationBackground(Color.seilSurface)
            }
        }
    }

    // MARK: - Sections

    private var heroSection: some View {
        VStack(spacing: 12) {
            // Ícono principal
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.12))
                    .frame(width: 88, height: 88)
                    .overlay(Circle().stroke(Color.seilAccent.opacity(0.25), lineWidth: 1.5))
                Text("S")
                    .font(.system(size: 38, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilAccent)
            }

            // Brand name
            HStack(spacing: 0) {
                Text("seillo")
                    .font(.system(size: 32, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .kerning(-1.5)
                Text(".")
                    .font(.system(size: 32, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilAccent)
                    .kerning(-1.5)
            }

            Text("Tus sellos, siempre contigo")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)

            // Version badge
            Text("Versión 1.0.0")
                .font(SeillFont.label(12))
                .foregroundColor(.seilAccent)
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .background(Color.seilAccent.opacity(0.10))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.seilAccent.opacity(0.22), lineWidth: 1))
        }
        .padding(.vertical, 8)
    }

    private var descriptionCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Sobre Seillo")
                .font(SeillFont.headline(14))
                .foregroundColor(.seilText)

            Text("Seillo es una plataforma de fidelización digital que conecta negocios locales con sus clientes. Reemplazamos las tarjetas de papel por sellos digitales: más convenientes, más ecológicos y más seguros.")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
                .lineSpacing(3)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
    }

    private var statsRow: some View {
        HStack(spacing: 10) {
            AboutStatCell(value: "Local",   label: "Negocios",  color: .seilAccent)
            AboutStatCell(value: "Digital", label: "Sin papel", color: .seilBlue)
            AboutStatCell(value: "100%",    label: "Gratis",    color: .seilGold)
        }
    }

    private var featuresCard: some View {
        let features: [(String, Color, String)] = [
            ("qrcode",               .seilAccent, "QR dinámico con expiración automática"),
            ("bell.badge.fill",      .seilBlue,   "Notificaciones de sellos y premios"),
            ("location.fill",        .seilGreen,  "Descubre negocios cercanos"),
            ("trophy.fill",          .seilGold,   "Canje de premios con código único"),
            ("leaf.fill",            .seilPurple, "Sin papel, sin plástico, 100% digital"),
        ]

        return VStack(spacing: 0) {
            // Header label
            HStack {
                Text("CARACTERÍSTICAS")
                    .font(SeillFont.caption(10))
                    .foregroundColor(.seilMuted)
                    .kerning(1.2)
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)

            Divider().background(Color.seilBorder)

            ForEach(Array(features.enumerated()), id: \.offset) { i, feat in
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(feat.1.opacity(0.12))
                            .frame(width: 32, height: 32)
                        Image(systemName: feat.0)
                            .font(.system(size: 13))
                            .foregroundColor(feat.1)
                    }
                    Text(feat.2)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilText)
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)

                if i < features.count - 1 {
                    Divider()
                        .background(Color.seilBorder)
                        .padding(.leading, 60)
                }
            }
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
    }

    private var linksCard: some View {
        let rows: [(String, Color, String)] = [
            ("globe",            .seilAccent, "Sitio web"),
            ("shield.fill",      .seilBlue,   "Política de privacidad"),
            ("doc.text.fill",    .seilMuted2, "Términos de uso"),
            ("envelope.fill",    .seilGreen,  "Contáctanos"),
        ]

        return VStack(spacing: 0) {
            ForEach(Array(rows.enumerated()), id: \.offset) { i, row in
                Button {
                    switch row.2 {
                    case "Sitio web":
                        if let url = URL(string: "https://seillo.site") {
                            UIApplication.shared.open(url)
                        }
                    case "Política de privacidad": showPrivacy = true
                    case "Términos de uso":         showTerms   = true
                    case "Contáctanos":
                        if let url = URL(string: "mailto:hola@seillo.site") {
                            UIApplication.shared.open(url)
                        }
                    default: break
                    }
                } label: {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(row.1.opacity(0.12))
                                .frame(width: 32, height: 32)
                            Image(systemName: row.0)
                                .font(.system(size: 13))
                                .foregroundColor(row.1)
                        }
                        Text(row.2)
                            .font(SeillFont.body(13))
                            .foregroundColor(.seilText)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.seilMuted)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                }
                .buttonStyle(.plain)

                if i < rows.count - 1 {
                    Divider()
                        .background(Color.seilBorder)
                        .padding(.leading, 60)
                }
            }
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
    }

    private var footerLabel: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                Text("Hecho con")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                Image(systemName: "heart.fill")
                    .font(.system(size: 11))
                    .foregroundColor(.seilRose)
                Text("en Perú")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
            }
            Text("© 2026 Seillo. Todos los derechos reservados.")
                .font(SeillFont.caption(10))
                .foregroundColor(.seilMuted)
        }
    }
}

// MARK: - Subcomponents

private struct AboutStatCell: View {
    let value: String
    let label: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 15, weight: .black, design: .rounded))
                .foregroundColor(color)
            Text(label)
                .font(SeillFont.caption(10))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(color.opacity(0.20), lineWidth: 1)
        )
    }
}

// MARK: - LegalSheet

private struct LegalSheet: View {
    let title:   String
    let content: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilSurface.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    Text(content)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(4)
                        .padding(20)
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 28, height: 28)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                }
            }
        }
    }
}

// MARK: - Legal texts

private let privacyText = """
Seillo respeta tu privacidad y se compromete a proteger tus datos personales.

Datos que recopilamos
Recopilamos la información que nos proporcionas al registrarte (nombre, correo electrónico), datos de uso (sellos acumulados, premios canjeados, negocios visitados) y datos técnicos del dispositivo.

Datos de ubicación
Si otorgas permiso, accedemos a tu ubicación aproximada únicamente para mostrarte negocios cercanos. No almacenamos tu ubicación en nuestros servidores ni la compartimos con terceros.

Uso de la cámara
Accedemos a la cámara exclusivamente para escanear tu código QR al registrar sellos.

Uso de los datos
Utilizamos tus datos para operar el servicio, enviarte notificaciones sobre sellos y premios, y mejorar la experiencia de la aplicación. No vendemos ni compartimos tus datos personales con terceros sin tu consentimiento.

Edad mínima
Seillo está dirigido a personas mayores de 13 años.

Tus derechos
Puedes solicitar acceso, corrección o eliminación de tus datos escribiéndonos a privacidad@seillo.site.

Última actualización: marzo 2026.
"""

private let termsText = """
Términos y Condiciones de Uso de Seillo

Al usar Seillo, aceptas los presentes términos.

1. Servicio
Seillo es una plataforma digital de fidelización que conecta clientes con negocios locales mediante tarjetas de sellos digitales.

2. Cuentas
Eres responsable de mantener la confidencialidad de tu contraseña y de todas las actividades bajo tu cuenta.

3. Edad mínima
El uso de Seillo está permitido a personas mayores de 13 años.

4. Sellos y premios
Los sellos son otorgados exclusivamente por los negocios afiliados. Seillo no garantiza la disponibilidad de premios ni la vigencia de las tarjetas, ya que esto depende de cada negocio.

5. Prohibiciones
Está prohibido falsificar sellos, crear cuentas falsas o usar la plataforma para actividades ilegales.

Contacto: soporte@seillo.site
Última actualización: marzo 2026.
"""

// MARK: - Double clamp helper (scoped — no contamina el namespace global)
private extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}
