import SwiftUI

// ─── LevelUpView ──────────────────────────────────────────────────────────────
// Sheet de celebración que aparece cuando el usuario alcanza un nuevo nivel.
//
// Ruta:   Seillo/Views/Screens/User/LevelUpView.swift
// Acceso: TabPerfilView → .sheet(isPresented: $showLevelUp)
//
// Recibe:
//   • newLevel    — el UserLevel recién alcanzado
//   • userName    — primer nombre del usuario (para personalizar)
//   • totalStamps — total acumulado (para mostrar en contexto)
//
// Comportamiento:
//   1. Entrada: icono escala desde 0 con spring, confetti explota a 0.3s
//   2. Barra de progreso del nuevo nivel anima de 0 a su valor inicial
//   3. Botón "Compartir logro" abre ShareLink nativo
//   4. Botón "Continuar" cierra el sheet
//   El sheet NO tiene drag indicator — requiere acción explícita para cerrarse.
// ─────────────────────────────────────────────────────────────────────────────

struct LevelUpView: View {
    let newLevel:    UserLevel
    let userName:    String
    let totalStamps: Int

    @Environment(\.dismiss) private var dismiss

    // Animaciones escalonadas
    @State private var iconScale:     CGFloat = 0
    @State private var iconOpacity:   Double  = 0
    @State private var contentAlpha:  Double  = 0
    @State private var contentOffset: CGFloat = 16  // interpola suavemente — no compara con == 1
    @State private var barProgress:   Double  = 0
    @State private var particlesOn:   Bool    = false
    @State private var pulseRing:     Bool    = false
    @State private var btnScale:      CGFloat = 1

    // Progreso inicial dentro del nuevo nivel
    private var progressInLevel: Double {
        let next = UserLevel.levels.first { $0.minSellos > newLevel.minSellos }
        guard let next = next else { return 1.0 }
        let range = Double(next.minSellos - newLevel.minSellos)
        guard range > 0 else { return 1.0 }
        return min(Double(totalStamps - newLevel.minSellos) / range, 1.0)
    }

    private var nextLevel: UserLevel? {
        UserLevel.levels.first { $0.minSellos > newLevel.minSellos }
    }

    private var shareText: String {
        "¡Acabo de alcanzar el nivel \(newLevel.name) en Seillo con \(totalStamps) sellos! Descarga la app: seillo.pe"
    }

    var body: some View {
        ZStack {
            // ── Fondo con glow radial del color del nivel ──────────────────
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [newLevel.color.opacity(0.18), .clear],
                center: .init(x: 0.5, y: 0.22),
                startRadius: 0,
                endRadius: 320
            )
            .ignoresSafeArea()

            // ── Partículas ─────────────────────────────────────────────────
            if particlesOn {
                ParticlesBurst(color: newLevel.color)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }

            // ── Contenido ─────────────────────────────────────────────────
            VStack(spacing: 0) {
                Spacer().frame(height: 48)

                heroSection

                Spacer().frame(height: 32)

                infoCard
                    .padding(.horizontal, 28)
                    .opacity(contentAlpha)
                    .offset(y: contentOffset)

                Spacer()

                actionButtons
                    .padding(.horizontal, 28)
                    .padding(.bottom, 48)
                    .opacity(contentAlpha)
            }
        }
        .presentationDragIndicator(.hidden)
        .task { await runEntrance() }
    }

    // MARK: - Hero

    private var heroSection: some View {
        VStack(spacing: 20) {

            // Icono con anillos pulsantes
            ZStack {
                // Anillo exterior pulsante.
                // CORRECCIÓN: antes animaba .frame(width/height) entre 118 y 148 —
                // cada frame forzaba re-layout del contenedor completo.
                // Ahora usa .scaleEffect sobre un tamaño fijo máximo (148pt) —
                // opera en la capa de render sin tocar el layout engine.
                Circle()
                    .stroke(newLevel.color.opacity(0.15), lineWidth: 1.5)
                    .frame(width: 148, height: 148)
                    .scaleEffect(pulseRing ? 1.0 : 0.80)
                    .animation(
                        .easeInOut(duration: 1.4).repeatForever(autoreverses: true),
                        value: pulseRing
                    )

                // Anillo medio
                Circle()
                    .stroke(newLevel.color.opacity(0.22), lineWidth: 1)
                    .frame(width: 108, height: 108)

                // Fondo del icono
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [newLevel.color.opacity(0.28), newLevel.color.opacity(0.10)],
                            center: .center,
                            startRadius: 0,
                            endRadius: 44
                        )
                    )
                    .frame(width: 96, height: 96)
                    .overlay(
                        Circle().stroke(newLevel.color.opacity(0.35), lineWidth: 1.5)
                    )

                Image(systemName: newLevel.icon)
                    .font(.system(size: 42, weight: .semibold))
                    .foregroundColor(newLevel.color)
                    .shadow(color: newLevel.color.opacity(0.60), radius: 18, y: 4)
            }
            .scaleEffect(iconScale)
            .opacity(iconOpacity)

            // Textos
            VStack(spacing: 8) {
                Text("¡Subiste de nivel!")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(newLevel.color)
                    .tracking(1.8)
                    .opacity(contentAlpha)

                Text("Nivel \(newLevel.name)")
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .opacity(contentAlpha)
                    .scaleEffect(0.88 + contentAlpha * 0.12)

                Text("\(userName), llegaste a \(totalStamps) sellos.")
                    .font(SeillFont.body(14))
                    .foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center)
                    .opacity(contentAlpha)
            }
            .animation(SeillAnimation.chrome.delay(0.18), value: contentAlpha)
        }
    }

    // MARK: - Info card (progreso en el nuevo nivel)

    private var infoCard: some View {
        VStack(spacing: 16) {

            // Barra de progreso dentro del nuevo nivel
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Progreso en nivel \(newLevel.name)")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.seilMuted)

                    Spacer()

                    if let next = nextLevel {
                        Text("Siguiente: \(next.name) · \(next.minSellos) sellos")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(.seilMuted)
                    } else {
                        HStack(spacing: 4) {
                            Text("Nivel máximo")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilGold)
                            Image(systemName: "trophy.fill")
                                .font(.system(size: 10))
                                .foregroundColor(.seilGold)
                        }
                    }
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 8)

                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [newLevel.color.opacity(0.7), newLevel.color],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: geo.size.width * barProgress, height: 8)
                            .animation(.easeOut(duration: 1.0).delay(0.6), value: barProgress)
                    }
                }
                .frame(height: 8)
            }

            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)

            // Beneficios del nivel (descriptivo, genérico por ahora)
            levelPerks
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(newLevel.color.opacity(0.20), lineWidth: 1)
        )
        .shadow(color: newLevel.color.opacity(0.08), radius: 14, y: 6)
    }

    @ViewBuilder
    private var levelPerks: some View {
        let perks = perksFor(newLevel.name)

        VStack(spacing: 10) {
            HStack {
                Text("LO QUE DESBLOQUEAS")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.3)
                Spacer()
            }

            ForEach(perks, id: \.0) { perk in
                HStack(spacing: 10) {
                    Image(systemName: perk.1)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(newLevel.color)
                        .frame(width: 20)

                    Text(perk.0)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(2)

                    Spacer()
                }
            }
        }
    }

    // MARK: - Botones

    private var actionButtons: some View {
        VStack(spacing: 12) {

            // Compartir — ShareLink nativo
            ShareLink(
                item: shareText,
                subject: Text("Mi nivel en Seillo"),
                message: Text(shareText)
            ) {
                HStack(spacing: 10) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))

                    Text("Compartir logro")
                        .font(SeillFont.headline(15))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    LinearGradient(
                        colors: [newLevel.color, newLevel.color.opacity(0.80)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: newLevel.color.opacity(0.45), radius: 14, y: 4)
                .scaleEffect(btnScale)
            }
            .buttonStyle(.plain)
            .task {
                // Micro-pulso del botón al aparecer — Task estructurado,
                // cancelable si el sheet se descarta antes del delay.
                try? await Task.sleep(for: .seconds(1.0))
                withAnimation(.spring(response: 0.22, dampingFraction: 0.50)) { btnScale = 1.04 }
                try? await Task.sleep(for: .seconds(0.18))
                withAnimation(.spring(response: 0.22, dampingFraction: 0.65)) { btnScale = 1.0 }
            }

            // Continuar
            Button {
                Haptics.tap()
                dismiss()
            } label: {
                Text("Continuar")
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilMuted2)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - Entrada animada

    private func runEntrance() async {
        // Icono entra con spring
        withAnimation(.spring(response: 0.52, dampingFraction: 0.58)) {
            iconScale   = 1.0
            iconOpacity = 1.0
        }

        // Partículas a 300ms
        try? await Task.sleep(for: .seconds(0.30))
        particlesOn = true
        pulseRing   = true

        // Contenido a 420ms — contentOffset anima junto con contentAlpha
        // para interpolación suave en lugar del salto binario anterior.
        try? await Task.sleep(for: .seconds(0.12))
        withAnimation(SeillAnimation.chrome) {
            contentAlpha  = 1.0
            contentOffset = 0
        }

        // Barra de progreso a 700ms
        try? await Task.sleep(for: .seconds(0.28))
        barProgress = progressInLevel
    }

    // MARK: - Perks por nivel

    private func perksFor(_ levelName: String) -> [(String, String)] {
        switch levelName {
        case "Regular":
            return [
                ("Acceso a sorteos exclusivos de negocios afiliados", "ticket.fill"),
                ("Badge especial en tu perfil Seillo",                "rosette"),
            ]
        case "Fiel":
            return [
                ("Doble sello en días especiales de tu negocio favorito", "seal.fill"),
                ("Prioridad en campañas de beneficios premium",           "crown"),
                ("Badge Fiel visible en tu perfil",                       "checkmark.seal.fill"),
            ]
        case "VIP":
            return [
                ("Sello de bienvenida al registrarte en cualquier negocio nuevo", "gift.fill"),
                ("Acceso anticipado a nuevas funciones de Seillo",                "sparkles"),
                ("Badge VIP dorado en tu perfil",                                 "diamond.fill"),
            ]
        case "Leyenda":
            return [
                ("Premio doble en tu próximo canje",              "trophy.fill"),
                ("Badge Leyenda exclusivo en tu perfil",          "medal.fill"),
                ("Acceso a la lista de negocios Seillo Premium",  "star.circle.fill"),
            ]
        default:  // "Nuevo" — no debería mostrarse LevelUp para este nivel
            return [
                ("Bienvenido a Seillo. ¡Empieza a coleccionar!", "flag.fill"),
            ]
        }
    }
}

// ─── ParticlesBurst ───────────────────────────────────────────────────────────
// Confetti minimalista: 18 círculos pequeños que explotan desde el centro
// y caen con física simple. Sin dependencias externas.

private struct ParticlesBurst: View {
    let color: Color

    // Cada partícula tiene ángulo, distancia y tamaño fijos (seed visual)
    private struct Particle: Identifiable {
        let id:     Int
        let angle:  Double   // grados
        let radius: CGFloat  // distancia máxima
        let size:   CGFloat
        let delay:  Double
        let altColor: Bool   // alterna blanco/color
    }

    private let particles: [Particle] = (0..<22).map { i in
        let angle  = Double(i) * (360.0 / 22.0) + Double(i % 3) * 8.0
        let radius = CGFloat(90 + (i % 4) * 30)
        let size   = CGFloat(4 + (i % 3) * 3)
        let delay  = Double(i % 5) * 0.06
        return Particle(id: i, angle: angle, radius: radius,
                        size: size, delay: delay, altColor: i % 3 == 0)
    }

    @State private var exploded = false

    var body: some View {
        GeometryReader { geo in
            let cx = geo.size.width  / 2
            let cy = geo.size.height * 0.28   // alineado con el icono héroe

            ZStack {
                ForEach(particles) { p in
                    let rad = p.angle * .pi / 180
                    let tx  = exploded ? cos(rad) * p.radius : 0
                    let ty  = exploded ? sin(rad) * p.radius + (exploded ? 40 : 0) : 0

                    Circle()
                        .fill(p.altColor ? Color.white.opacity(0.85) : color.opacity(0.90))
                        .frame(width: p.size, height: p.size)
                        .position(x: cx + tx, y: cy + ty)
                        // CORRECCIÓN CRÍTICA: antes era .opacity(exploded ? 0 : 0) —
                        // las partículas eran siempre invisibles. Las partículas
                        // deben partir opacas y desvanecerse al expandirse.
                        .opacity(exploded ? 0 : 1)
                        .animation(
                            .easeOut(duration: 1.0).delay(p.delay),
                            value: exploded
                        )
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.05)) {
                exploded = true
            }
        }
    }
}
