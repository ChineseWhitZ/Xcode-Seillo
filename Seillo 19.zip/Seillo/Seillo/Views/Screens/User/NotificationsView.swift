import SwiftUI

// ─── NotificationsView ────────────────────────────────────────────────────────
// Pantalla completa de notificaciones del usuario.
//
// Lote 5:
//   + 3 filtros nuevos: Cercanos, Ofertas, Cambios (paridad con Android)
//   + Swipe-to-dismiss individual (deslizar izquierda para eliminar)
//   + Total: 7 filtros (Todas, Sin leer, Sellos, Premios, Cercanos, Ofertas, Cambios)
//
// Acceso: TabCardsView → ícono de campana
// ─────────────────────────────────────────────────────────────────────────────

private enum NotifFilter: String, CaseIterable {
    case all      = "Todas"
    case unread   = "Sin leer"
    case sellos   = "Sellos"
    case premios  = "Premios"
    case cercanos = "Cercanos"
    case ofertas  = "Ofertas"
    case cambios  = "Cambios"

    var icon: String {
        switch self {
        case .all:      return "bell.fill"
        case .unread:   return "envelope.badge.fill"
        case .sellos:   return "seal.fill"
        case .premios:  return "trophy.fill"
        case .cercanos: return "location.fill"
        case .ofertas:  return "tag.fill"
        case .cambios:  return "arrow.triangle.2.circlepath"
        }
    }
    var color: Color {
        switch self {
        case .all:      return .seilAccent
        case .unread:   return .seilAccent
        case .sellos:   return .seilAccent
        case .premios:  return .seilGold
        case .cercanos: return Color.seilBlue
        case .ofertas:  return Color.seilPurple
        case .cambios:  return .seilRose
        }
    }

    /// Filtra una notificación por su icono (mapeamos iconos a categorías)
    // MEDIO: antes usaba .contains() — fragil (ej. "arrow" aparece en iconos de
    // cualquier categoria). Los iconos son deterministas: los asigna
    // iconForNotificationType() en APIClientService con un switch 1-a-1 con tipo.
    func matches(_ notif: NotificationItem) -> Bool {
        switch self {
        case .all:      return true
        case .unread:   return !notif.isRead
        case .sellos:   return notif.icon == "seal.fill"
        case .premios:  return notif.icon == "gift.fill"
        case .cercanos: return notif.icon == "location.fill"
        case .ofertas:  return notif.icon == "megaphone.fill" || notif.icon == "star.fill"
        case .cambios:  return notif.icon == "person.2.fill"  || notif.icon == "bell.fill"
        }
    }
}

struct NotificationsView: View {
    @Binding var notifications: [NotificationItem]
    @Environment(\.dismiss) var dismiss

    @State private var activeFilter: NotifFilter = .all
    @State private var appear = false

    // Pull-to-refresh real — antes era un sleep falso con TODO
    private let service: ClientServiceProtocol = APIClientService()

    private var filtered: [NotificationItem] {
        notifications.filter { activeFilter.matches($0) }
    }

    private var unreadCount: Int { notifications.filter { !$0.isRead }.count }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar
                filterChips
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.seilBg)
                    .overlay(alignment: .bottom) {
                        Rectangle().fill(Color.seilBorder).frame(height: 1)
                    }

                if filtered.isEmpty {
                    emptyState
                } else {
                    notificationsList
                }
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        HStack {
            Button { Haptics.tap(); dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.seilMuted2)
                    .frame(width: 36, height: 36)
                    .background(Color.seilCard)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)

            Spacer()

            VStack(spacing: 2) {
                Text("Notificaciones").font(SeillFont.headline(15)).foregroundColor(.seilText)
                if unreadCount > 0 {
                    Text("\(unreadCount) sin leer")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.seilAccent)
                }
            }

            Spacer()

            Button {
                Haptics.tap()
                withAnimation {
                    for i in notifications.indices { notifications[i].isRead = true }
                }
            } label: {
                Text("Leer todo")
                    .font(SeillFont.label(12))
                    .foregroundColor(unreadCount > 0 ? .seilAccent : .seilMuted)
            }
            .buttonStyle(.plain)
            .disabled(unreadCount == 0)
            .frame(width: 70, alignment: .trailing)
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 14)
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Filter chips (7 filtros — Lote 5)

    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(NotifFilter.allCases, id: \.rawValue) { filter in
                    let isActive = activeFilter == filter
                    let count = notifications.filter { !$0.isRead && filter.matches($0) }.count

                    Button {
                        Haptics.tap()
                        withAnimation(.easeOut(duration: 0.20)) { activeFilter = filter }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: filter.icon)
                                .font(.system(size: 11, weight: .semibold))
                            Text(filter.rawValue)
                                .font(SeillFont.label(12))
                            if count > 0 {
                                Text("\(count)")
                                    .font(.system(size: 10, weight: .heavy))
                                    .foregroundColor(isActive ? .white : filter.color)
                                    .padding(.horizontal, 6).padding(.vertical, 2)
                                    .background(isActive ? Color.white.opacity(0.25) : filter.color.opacity(0.15))
                                    .clipShape(Capsule())
                            }
                        }
                        .foregroundColor(isActive ? .white : .seilMuted2)
                        .padding(.horizontal, 14).padding(.vertical, 9)
                        .background(
                            isActive
                            ? LinearGradient(colors: [filter.color, filter.color.opacity(0.80)], startPoint: .leading, endPoint: .trailing)
                            : LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .leading, endPoint: .trailing)
                        )
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(isActive ? Color.clear : Color.seilBorder, lineWidth: 1))
                        .shadow(color: isActive ? filter.color.opacity(0.30) : .clear, radius: 8, y: 2)
                        .animation(SeillAnimation.chrome, value: activeFilter)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: - List (con swipe-to-dismiss — Lote 5)

    private var notificationsList: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 0) {
                ForEach(Array(filtered.enumerated()), id: \.element.id) { i, notif in
                    SwipeToDismissNotifRow(
                        notif: notif,
                        onTap: {
                            Haptics.tap()
                            withAnimation {
                                if let idx = notifications.firstIndex(where: { $0.id == notif.id }) {
                                    notifications[idx].isRead = true
                                }
                            }
                        },
                        onDismiss: {
                            withAnimation(.easeOut(duration: 0.25)) {
                                notifications.removeAll { $0.id == notif.id }
                            }
                        }
                    )
                    .opacity(appear ? 1 : 0)
                    .offset(y: appear ? 0 : 10)
                    .animation(.easeOut(duration: 0.35).delay(Double(i) * 0.04), value: appear)

                    if i < filtered.count - 1 {
                        Divider().background(Color.seilBorder).padding(.leading, 72)
                    }
                }

                Spacer().frame(height: 100)
            }
        }
        .refreshable {
            // ALTO: antes era un sleep falso (800ms) con TODO.
            // Ahora recarga desde el backend y actualiza el binding.
            if case .success(let fresh) = await service.getNotificaciones() {
                withAnimation { notifications = fresh }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Spacer()
            ZStack {
                Circle().fill(Color.seilCard).frame(width: 80, height: 80)
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "bell.slash")
                    .font(.system(size: 32)).foregroundColor(.seilMuted)
            }
            Text("Sin notificaciones")
                .font(SeillFont.headline(16)).foregroundColor(.seilText)
            Text("Cuando recibas sellos, premios\no campañas aparecerán aquí.")
                .font(SeillFont.body(13)).foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
            Spacer()
        }
        .padding(.horizontal, 40)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - SwipeToDismissNotifRow (NUEVO — Lote 5)
// ═══════════════════════════════════════════════════════════════════════════════
/// Fila de notificación con swipe-to-dismiss hacia la izquierda.
/// Deslizar más de 80pt dispara la eliminación con haptic feedback.

private struct SwipeToDismissNotifRow: View {
    let notif:     NotificationItem
    let onTap:     () -> Void
    let onDismiss: () -> Void

    @State private var offsetX: CGFloat = 0

    var body: some View {
        ZStack(alignment: .trailing) {
            // ── Background rojo al deslizar ──────────────────
            if offsetX < -30 {
                HStack {
                    Spacer()
                    Image(systemName: "trash.fill")
                        .font(.system(size: 16))
                        .foregroundColor(.seilDanger)
                        .padding(.trailing, 20)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.seilDanger.opacity(min(1, (-offsetX - 30) / 80 * 0.3)))
            }

            // ── Contenido de la notificación ─────────────────
            notifContent
                .offset(x: offsetX)
                .gesture(
                    DragGesture(minimumDistance: 20)
                        .onChanged { value in
                            // Solo permitir swipe izquierda
                            if value.translation.width < 0 {
                                offsetX = max(value.translation.width, -140)
                            }
                        }
                        .onEnded { value in
                            if offsetX < -80 {
                                Haptics.tap()
                                // Animar la salida completa
                                withAnimation(.easeOut(duration: 0.2)) {
                                    offsetX = -400
                                }
                                // Delay antes de eliminar para que la animación se vea
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    onDismiss()
                                }
                            } else {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    offsetX = 0
                                }
                            }
                        }
                )
                .onTapGesture { onTap() }
        }
        .clipShape(Rectangle())
    }

    private var notifContent: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(notif.isRead ? notif.color.opacity(0.10) : notif.color.opacity(0.18))
                    .frame(width: 46, height: 46)
                    .overlay(Circle().stroke(notif.color.opacity(notif.isRead ? 0.10 : 0.30), lineWidth: 1))
                Image(systemName: notif.icon)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(notif.color)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(notif.title)
                    .font(notif.isRead ? SeillFont.body(13) : SeillFont.headline(13))
                    .foregroundColor(notif.isRead ? .seilMuted2 : .seilText)
                    .lineLimit(1)
                Text(notif.body)
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                    .lineLimit(2)
                    .lineSpacing(2)
                Text(notif.time)
                    .font(.system(size: 10))
                    .foregroundColor(.seilMuted)
            }

            Spacer()

            if !notif.isRead {
                Circle()
                    .fill(notif.color)
                    .frame(width: 9, height: 9)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(notif.isRead ? Color.seilBg : notif.color.opacity(0.04))
    }
}
