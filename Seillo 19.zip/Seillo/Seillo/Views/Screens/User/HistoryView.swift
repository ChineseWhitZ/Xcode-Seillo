import SwiftUI

// ─── HistoryView ──────────────────────────────────────────────────────────────
// Sheet presentado desde TabPremiosView (botón Historial) y TabPerfilView.
// Dos pestañas: Actividad (timeline) y Cartillas completadas.
// Datos reales desde GET /api/cliente/historial y GET /api/cliente/historial-completadas.
// ─────────────────────────────────────────────────────────────────────────────

struct HistoryView: View {

    @Environment(\.dismiss) private var dismiss

    // Pestaña principal
    @State private var mainTab:     HistoryMainTab = .actividad
    // Filtro activo en Actividad
    @State private var activeFilter: HistoryFilter  = .todos
    // Entrada stagger
    @State private var progress:     Double          = 0

    // Datos cargados del backend
    @State private var historial: [HistoryEntry] = []
    @State private var completadas: [CompletedCard] = []

    private let service: ClientServiceProtocol = APIClientService()

    // ── Datos derivados ───────────────────────────────────────────────────
    private var filtered: [HistoryEntry] {
        switch activeFilter {
        case .todos:   return historial
        case .sellos:  return historial.filter { !$0.isReward }
        case .premios: return historial.filter {  $0.isReward }
        }
    }

    private var groups: [(label: String, entries: [HistoryEntry])] {
        groupByDate(filtered)
    }

    private var totalSellos:   Int { historial.filter { !$0.isReward }.count }
    private var totalPremios:  Int { historial.filter {  $0.isReward }.count }
    private var totalNegocios: Int { Set(historial.map { $0.bizName }).count }

    // Stagger helpers
    private func a(_ s: Double, _ e: Double) -> Double {
        ((progress - s) / (e - s)).clamped(to: 0...1)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                VStack(spacing: 0) {

                    // ── Tab selector ───────────────────────────────────────
                    tabSelector
                        .padding(.horizontal, 16)
                        .padding(.top, 4)
                        .padding(.bottom, 8)
                        .opacity(a(0.00, 0.35))

                    Divider().background(Color.seilBorder)

                    // ── Contenido por tab ──────────────────────────────────
                    TabView(selection: $mainTab) {
                        actividadTab
                            .tag(HistoryMainTab.actividad)
                        cartillasTab
                            .tag(HistoryMainTab.cartillas)
                    }
                    .tabViewStyle(.page(indexDisplayMode: .never))
                    .animation(SeillAnimation.screenTransition, value: mainTab)
                }
            }
            .navigationTitle("Historial")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 30, height: 30)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                }
            }
            .task {
                // Cargar historial del backend
                async let histResult = service.getHistorial()
                async let compResult = service.getHistorialCompletadas()

                if case .success(let h) = await histResult {
                    historial = h
                }
                if case .success(let c) = await compResult {
                    completadas = c
                }

                withAnimation(.easeOut(duration: 0.65)) { progress = 1 }
            }
        }
    }

    // MARK: - Tab Selector

    private var tabSelector: some View {
        HStack(spacing: 8) {
            ForEach(HistoryMainTab.allCases, id: \.self) { tab in
                let selected = mainTab == tab
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(SeillAnimation.chrome) { mainTab = tab }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 11, weight: .bold))
                        Text(tab.label)
                            .font(.system(size: 12, weight: selected ? .heavy : .regular, design: .rounded))
                    }
                    .foregroundColor(selected ? .white : .seilMuted2)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(selected ? Color.seilAccent : Color.seilCard)
                    .clipShape(Capsule())
                    .overlay(
                        Capsule().stroke(
                            selected ? Color.clear : Color.seilBorder,
                            lineWidth: 1
                        )
                    )
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
    }

    // MARK: - Actividad Tab

    private var actividadTab: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {

                // ── Stats row ──────────────────────────────────────────
                summaryRow
                    .padding(.horizontal, 16)
                    .padding(.top, 14)
                    .padding(.bottom, 12)
                    .opacity(a(0.10, 0.45))

                // ── Filter chips ───────────────────────────────────────
                filterChips
                    .padding(.bottom, 8)
                    .opacity(a(0.15, 0.50))

                Divider().background(Color.seilBorder)

                // ── Timeline ───────────────────────────────────────────
                if filtered.isEmpty {
                    emptyActivityState
                        .padding(.top, 48)
                } else {
                    timelineContent
                        .padding(.top, 4)
                }

                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
        }
    }

    private var summaryRow: some View {
        HStack(spacing: 8) {
            HistorySummaryCell(
                value: "\(totalSellos)",
                label: "Sellos totales",
                icon:  "checkmark.circle.fill",
                color: .seilAccent
            )
            HistorySummaryCell(
                value: "\(totalPremios)",
                label: "Premios canjeados",
                icon:  "trophy.fill",
                color: .seilGold
            )
            HistorySummaryCell(
                value: "\(totalNegocios)",
                label: "Negocios",
                icon:  "storefront.fill",
                color: .seilGreen
            )
        }
    }

    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(HistoryFilter.allCases, id: \.self) { filter in
                    let active = activeFilter == filter
                    Button {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(SeillAnimation.chrome) { activeFilter = filter }
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: filter.icon)
                                .font(.system(size: 11, weight: .bold))
                            Text(filter.label)
                                .font(.system(size: 12, weight: active ? .bold : .regular, design: .rounded))
                        }
                        .foregroundColor(active ? .white : .seilMuted2)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(active ? Color.seilAccent : Color.seilCard)
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(active ? Color.clear : Color.seilBorder, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private var timelineContent: some View {
        VStack(spacing: 0) {
            ForEach(Array(groups.enumerated()), id: \.offset) { gi, group in
                // ── Date group header ──────────────────────────────────
                HStack(spacing: 10) {
                    Text(group.label.uppercased())
                        .font(.system(size: 9, weight: .heavy))
                        .foregroundColor(.seilMuted)
                        .tracking(1.2)

                    Rectangle()
                        .fill(Color.seilBorder)
                        .frame(maxWidth: .infinity)
                        .frame(height: 1)

                    Text("\(group.entries.count)")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundColor(.seilMuted)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(Color.seilCard)
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)
                .padding(.bottom, 8)

                // ── Timeline items ─────────────────────────────────────
                ForEach(Array(group.entries.enumerated()), id: \.element.id) { ei, entry in
                    let isLast = ei == group.entries.count - 1 && gi == groups.count - 1
                    TimelineItemRow(entry: entry, isLast: isLast)
                        .opacity(a(0.20, 0.65))
                }
            }
        }
    }

    private var emptyActivityState: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.08))
                    .frame(width: 64, height: 64)
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "clock.arrow.circlepath")
                    .font(.system(size: 24))
                    .foregroundColor(.seilMuted)
            }
            Text("Sin eventos en esta categoría")
                .font(SeillFont.headline(14))
                .foregroundColor(.seilText)
            Text("Acumula sellos y canjea premios\npara verlos aquí")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
                .lineSpacing(3)
        }
        .padding(28)
    }

    // Mapear completadas del API a HVCompletedCard para la UI
    private var hvCompletedCards: [HVCompletedCard] {
        completadas.map { c in
            HVCompletedCard(
                bizName: c.negocioNombre,
                categoria: c.categoria,
                premio: c.premio,
                totalSellos: c.sellosMeta,
                fechaCanje: c.fechaCompletada,
                color: colorForCategory(c.categoria),
                icon: iconForCategory(c.categoria)
            )
        }
    }

    // MARK: - Cartillas Tab

    private var cartillasTab: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                if hvCompletedCards.isEmpty {
                    emptyCartillasState
                        .padding(.top, 48)
                } else {
                    // ── Counter label ──────────────────────────────────────
                    HStack {
                        Text("\(hvCompletedCards.count) CARTILLA\(hvCompletedCards.count == 1 ? "" : "S") COMPLETADA\(hvCompletedCards.count == 1 ? "" : "S")")
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundColor(.seilMuted)
                            .tracking(1.2)
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 8)

                    ForEach(Array(hvCompletedCards.enumerated()), id: \.offset) { i, card in
                        CompletedCardRow(card: card)
                            .padding(.horizontal, 16)
                            .padding(.bottom, 10)
                            .opacity(a(Double(i) * 0.08, Double(i) * 0.08 + 0.40))
                    }
                }
                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
            .padding(.top, 4)
        }
    }

    private var emptyCartillasState: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.seilGold.opacity(0.08))
                    .frame(width: 72, height: 72)
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "trophy.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.seilMuted)
            }
            Text("Aún no completaste ninguna cartilla")
                .font(SeillFont.headline(14))
                .foregroundColor(.seilText)
                .multilineTextAlignment(.center)
            Text("Cuando completes una cartilla\naparecerá aquí archivada.")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
                .lineSpacing(3)
        }
        .padding(28)
    }
}

// ─── HistoryMainTab ───────────────────────────────────────────────────────────
private enum HistoryMainTab: CaseIterable {
    case actividad, cartillas

    var label: String {
        switch self {
        case .actividad:  return "Actividad"
        case .cartillas:  return "Cartillas completas"
        }
    }
    var icon: String {
        switch self {
        case .actividad:  return "clock.fill"
        case .cartillas:  return "trophy.fill"
        }
    }
}

// ─── HistoryFilter ────────────────────────────────────────────────────────────
private enum HistoryFilter: CaseIterable {
    case todos, sellos, premios

    var label: String {
        switch self {
        case .todos:   return "Todos"
        case .sellos:  return "Sellos"
        case .premios: return "Premios"
        }
    }
    var icon: String {
        switch self {
        case .todos:   return "square.grid.2x2.fill"
        case .sellos:  return "checkmark.circle.fill"
        case .premios: return "trophy.fill"
        }
    }
}

// ─── TimelineItemRow ──────────────────────────────────────────────────────────
private struct TimelineItemRow: View {
    let entry:  HistoryEntry
    let isLast: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 0) {

            // ── Left: node + connector ─────────────────────────────────
            VStack(spacing: 0) {
                // Node circle
                ZStack {
                    Circle()
                        .strokeBorder(entry.color.opacity(0.30), lineWidth: 1.5)
                        .background(Circle().fill(entry.color.opacity(0.10)))
                        .frame(width: 36, height: 36)
                    Image(systemName: entry.isReward ? "trophy.fill" : "checkmark.circle.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(entry.color)
                }

                // Connector line
                if !isLast {
                    Rectangle()
                        .fill(
                            LinearGradient(
                                colors: [entry.color.opacity(0.22), Color.seilBorder.opacity(0.18)],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                        .frame(width: 2)
                        .frame(maxHeight: .infinity)
                        .padding(.vertical, 4)
                }
            }
            .frame(width: 44)
            .padding(.leading, 16)

            // ── Right: card ────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top, spacing: 12) {
                    // Dot color
                    Circle()
                        .fill(entry.color)
                        .frame(width: 7, height: 7)
                        .padding(.top, 4)

                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Text(entry.bizName)
                                .font(.system(size: 13, weight: .heavy, design: .rounded))
                                .foregroundColor(.seilText)
                            Spacer()
                            if entry.isReward {
                                Text("Premio")
                                    .font(.system(size: 9, weight: .black))
                                    .foregroundColor(entry.color)
                                    .padding(.horizontal, 7)
                                    .padding(.vertical, 3)
                                    .background(entry.color.opacity(0.14))
                                    .clipShape(Capsule())
                            }
                        }

                        Text(entry.action)
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                            .lineSpacing(2)

                        HStack(spacing: 4) {
                            Image(systemName: "clock")
                                .font(.system(size: 9))
                                .foregroundColor(.seilMuted)
                            Text(entry.date)
                                .font(.system(size: 10))
                                .foregroundColor(.seilMuted)
                        }
                    }
                }
                .padding(12)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14).stroke(
                        entry.isReward
                            ? entry.color.opacity(0.24)
                            : Color.seilBorder,
                        lineWidth: 1
                    )
                )
            }
            .padding(.trailing, 16)
            .padding(.bottom, isLast ? 8 : 14)
            .padding(.leading, 10)
        }
    }
}

// ─── HistorySummaryCell ───────────────────────────────────────────────────────
private struct HistorySummaryCell: View {
    let value: String
    let label: String
    let icon:  String
    let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 14))
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 20, weight: .black, design: .rounded))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(color.opacity(0.20), lineWidth: 1)
        )
    }
}

// ─── CompletedCardRow ─────────────────────────────────────────────────────────
private struct CompletedCardRow: View {
    let card: HVCompletedCard

    var body: some View {
        VStack(spacing: 0) {
            // ── Header ─────────────────────────────────────────────────
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(card.color.opacity(0.12))
                        .frame(width: 46, height: 46)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(card.color.opacity(0.22), lineWidth: 1)
                        )
                    Image(systemName: card.icon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(card.color)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(card.bizName)
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .foregroundColor(.seilText)
                    Text(card.categoria)
                        .font(SeillFont.body(11))
                        .foregroundColor(card.color)
                        .fontWeight(.semibold)
                }

                Spacer()

                // Badge "Canjeada"
                HStack(spacing: 4) {
                    Image(systemName: "trophy.fill")
                        .font(.system(size: 9))
                    Text("Canjeada")
                        .font(.system(size: 9, weight: .black))
                }
                .foregroundColor(.seilGold)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.seilGold.opacity(0.12))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.seilGold.opacity(0.25), lineWidth: 1))
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 12)

            Divider()
                .background(Color.seilBorder)
                .padding(.horizontal, 16)

            // ── Info row ───────────────────────────────────────────────
            HStack(spacing: 0) {
                // Premio
                HStack(spacing: 6) {
                    Image(systemName: "gift.fill")
                        .font(.system(size: 11))
                        .foregroundColor(.seilGold)
                    Text(card.premio)
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.seilText)
                        .lineLimit(1)
                }

                Spacer()

                // Sellos + fecha
                HStack(spacing: 8) {
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 10))
                            .foregroundColor(card.color)
                        Text("\(card.totalSellos)/\(card.totalSellos)")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                    HStack(spacing: 3) {
                        Image(systemName: "calendar")
                            .font(.system(size: 9))
                            .foregroundColor(.seilMuted)
                        Text(card.fechaCanje)
                            .font(.system(size: 10))
                            .foregroundColor(.seilMuted)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(card.color.opacity(0.20), lineWidth: 1)
        )
    }
}

// ─── HVCompletedCard ─────────────────────────────────────────────────────────
private struct HVCompletedCard {
    let bizName:     String
    let categoria:   String
    let premio:      String
    let totalSellos: Int
    let fechaCanje:  String
    let color:       Color
    let icon:        String
}

// ─── Grouping helper ──────────────────────────────────────────────────────────
private func groupByDate(_ entries: [HistoryEntry]) -> [(label: String, entries: [HistoryEntry])] {
    // Extrae el prefijo de fecha del string de display ("Hoy", "Ayer", etc.)
    func dateGroup(_ date: String) -> String {
        if date.lowercased().hasPrefix("hoy")   { return "Hoy" }
        if date.lowercased().hasPrefix("ayer")  { return "Ayer" }
        // "Lun 10 Mar" → "Esta semana"
        let parts = date.components(separatedBy: " ")
        if parts.count >= 2 { return "Esta semana" }
        return "Antes"
    }

    var order:   [String]                       = []
    var buckets: [String: [HistoryEntry]]       = [:]

    for e in entries {
        let key = dateGroup(e.date)
        if buckets[key] == nil {
            order.append(key)
            buckets[key] = []
        }
        buckets[key]!.append(e)
    }

    return order.map { (label: $0, entries: buckets[$0]!) }
}

// ─── Double clamp helper (scoped) ─────────────────────────────────────────────
private extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}
