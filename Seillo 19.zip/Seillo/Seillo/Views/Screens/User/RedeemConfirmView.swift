import SwiftUI

// ─── RedeemConfirmView ────────────────────────────────────────────────────────
// Pantalla celebratoria que aparece tras canjear un premio exitosamente.
// Se presenta como fullScreenCover desde RedeemSheetView.
// ─────────────────────────────────────────────────────────────────────────────

struct RedeemConfirmView: View {
    let bizName:   String
    let rewardText: String
    let nextGoal:  String

    var onDismiss: () -> Void

    @State private var appear      = false
    @State private var badgeScale: CGFloat = 0.4
    @State private var codeVisible = false

    private let redeemCode = String((0..<4).map { _ in "ABCDEFGHJKLMNPQRSTUVWXYZ".randomElement()! })
                           + "-"
                           + String((0..<4).map { _ in "23456789".randomElement()! })

    var body: some View {
        ZStack {
            Color(hex: "#070504").ignoresSafeArea()

            // Confetti
            RedeemConfettiOverlay()

            // Glow de fondo
            RadialGradient(
                colors: [Color.seilGreen.opacity(appear ? 0.22 : 0), .clear],
                center: .init(x: 0.5, y: 0.28),
                startRadius: 0,
                endRadius: 360
            )
            .ignoresSafeArea()
            .animation(.easeOut(duration: 0.9), value: appear)

            VStack(spacing: 0) {
                Spacer()

                // ── Badge animado ──────────────────────────────────────────
                ZStack {
                    Circle()
                        .fill(Color.seilGreen.opacity(0.08))
                        .frame(width: 160, height: 160)

                    Circle()
                        .fill(Color.seilGreen.opacity(0.14))
                        .frame(width: 120, height: 120)
                        .overlay(Circle().stroke(Color.seilGreen.opacity(0.22), lineWidth: 1.5))

                    Circle()
                        .fill(Color.seilGreen.opacity(0.20))
                        .frame(width: 90, height: 90)
                        .overlay(Circle().stroke(Color.seilGreen.opacity(0.35), lineWidth: 2))

                    Image(systemName: "trophy.fill")
                        .font(.system(size: 42, weight: .semibold))
                        .foregroundColor(.seilGreen)
                        .shadow(color: Color.seilGreen.opacity(0.65), radius: 22, y: 6)
                }
                .scaleEffect(badgeScale)

                Spacer().frame(height: 28)

                // ── Título ─────────────────────────────────────────────────
                Text("¡Premio canjeado!")
                    .font(.system(size: 30, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .multilineTextAlignment(.center)
                    .opacity(appear ? 1 : 0)
                    .offset(y: appear ? 0 : 16)

                Spacer().frame(height: 6)

                Text(bizName)
                    .font(SeillFont.body(14))
                    .foregroundColor(.seilMuted2)
                    .opacity(appear ? 1 : 0)

                Spacer().frame(height: 28)

                // ── Premio ─────────────────────────────────────────────────
                HStack(spacing: 10) {
                    Image(systemName: "gift.fill")
                        .font(.system(size: 16))
                        .foregroundColor(.seilGreen)

                    Text(rewardText)
                        .font(SeillFont.headline(15))
                        .foregroundColor(.seilText)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(Color.seilGreen.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.seilGreen.opacity(0.28), lineWidth: 1)
                )
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.20), value: appear)

                Spacer().frame(height: 24)

                // ── Código de canje ────────────────────────────────────────
                VStack(spacing: 8) {
                    Text("CÓDIGO DE CANJE")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.4)

                    Text(redeemCode)
                        .font(.system(size: 28, weight: .heavy, design: .monospaced))
                        .foregroundColor(.seilGreen)
                        .tracking(3)

                    Text("Muéstraselo al negocio si te lo piden")
                        .font(SeillFont.caption(11))
                        .foregroundColor(.seilMuted)
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity)
                .background(
                    LinearGradient(
                        colors: [Color.seilGreen.opacity(0.08), Color.seilGreen.opacity(0.04)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.seilGreen.opacity(0.22), lineWidth: 1)
                )
                .padding(.horizontal, 24)
                .scaleEffect(codeVisible ? 1 : 0.88)
                .opacity(codeVisible ? 1 : 0)

                Spacer().frame(height: 20)

                // ── Próximo objetivo ───────────────────────────────────────
                if !nextGoal.isEmpty {
                    HStack(spacing: 10) {
                        Image(systemName: "arrow.right.circle.fill")
                            .font(.system(size: 16))
                            .foregroundColor(.seilAccent)

                        Text(nextGoal)
                            .font(SeillFont.body(13))
                            .foregroundColor(.seilMuted2)
                            .lineSpacing(3)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.seilAccent.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color.seilAccent.opacity(0.16), lineWidth: 1)
                    )
                    .padding(.horizontal, 24)
                    .opacity(appear ? 1 : 0)
                    .animation(.easeOut(duration: 0.4).delay(0.30), value: appear)
                }

                Spacer()

                // ── Botones ────────────────────────────────────────────────
                VStack(spacing: 12) {
                    // Compartir
                    ShareLink(
                        item: "¡Acabo de canjear mi premio en \(bizName) con Seillo! \(redeemCode)",
                        subject: Text("Premio canjeado en Seillo")
                    ) {
                        HStack(spacing: 8) {
                            Image(systemName: "square.and.arrow.up")
                                .font(.system(size: 14, weight: .semibold))
                            Text("Compartir logro")
                                .font(SeillFont.headline(15))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            LinearGradient(
                                colors: [Color.seilGreen, Color.seilGreen.opacity(0.80)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: Color.seilGreen.opacity(0.40), radius: 14, y: 4)
                    }
                    .buttonStyle(.plain)

                    // Volver al inicio
                    Button {
                        Haptics.tap()
                        onDismiss()
                    } label: {
                        Text("Volver al inicio")
                            .font(SeillFont.body(14))
                            .foregroundColor(.seilMuted)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 44)
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.35), value: appear)
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome.delay(0.1)) {
                badgeScale = 1.0
            }
            withAnimation(.easeOut(duration: 0.45).delay(0.18)) {
                appear = true
            }
            withAnimation(SeillAnimation.chrome.delay(0.38)) {
                codeVisible = true
            }
            Haptics.success()
        }
    }
}

// ─── Confetti para RedeemConfirmView ─────────────────────────────────────────
struct RedeemConfettiOverlay: View {
    @State private var active = false

    private let colors: [Color] = [
        .seilGreen, .seilGold, Color.seilBlue,
        .seilAccent, Color.seilPurple, Color.seilRose
    ]

    var body: some View {
        GeometryReader { geo in
            ForEach(0..<55, id: \.self) { i in
                let color    = colors[i % colors.count]
                let x        = CGFloat.random(in: 0...geo.size.width)
                let size     = CGFloat.random(in: 5...12)
                let delay    = Double(i) * 0.032
                let duration = Double.random(in: 1.1...2.4)
                let isSquare = i % 3 == 0

                Group {
                    if isSquare {
                        RoundedRectangle(cornerRadius: 2)
                            .fill(color)
                            .frame(width: size, height: size * 0.55)
                            .rotationEffect(.degrees(Double.random(in: 0...360)))
                    } else {
                        Circle()
                            .fill(color)
                            .frame(width: size, height: size)
                    }
                }
                .position(x: x, y: active ? geo.size.height + 30 : -20)
                .opacity(active ? 0 : 0.85)
                .animation(.easeIn(duration: duration).delay(delay), value: active)
            }
        }
        .allowsHitTesting(false)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                active = true
            }
        }
    }
}
