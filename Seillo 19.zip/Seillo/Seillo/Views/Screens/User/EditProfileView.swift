import SwiftUI

// ─── EditProfileView ──────────────────────────────────────────────────────────
// Sheet presentado desde TabPerfilView → showEditProfile
// Permite elegir avatar (grid 4×4) y editar el nombre.
// Guarda en backend via PATCH /api/usuario/perfil y sincroniza ProfileStore local.
// ─────────────────────────────────────────────────────────────────────────────

struct EditProfileView: View {

    @EnvironmentObject var profileStore: ProfileStore
    @Environment(\.dismiss) private var dismiss

    private let service: ClientServiceProtocol = APIClientService()

    @State private var nombre:      String  = ""
    @State private var avatarId:    Int     = 0
    @State private var nombreError: String? = nil
    @State private var showSuccess: Bool    = false
    @State private var saving:      Bool    = false
    @State private var progress:    Double  = 0

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 4)
    private var avatarCount: Int { UserProfile.avatarOptions.count }

    // Stagger helpers
    private func a(_ s: Double, _ e: Double) -> Double {
        ((progress - s) / (e - s)).clamped(to: 0...1)
    }
    private func o(_ s: Double, _ e: Double) -> CGFloat {
        CGFloat(16 * (1 - a(s, e)))
    }

    var body: some View {
        SeillSheetBox {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {

                    // Drag handle
                    Capsule()
                        .fill(Color.seilBorder)
                        .frame(width: 36, height: 4)
                        .padding(.top, 12)
                        .padding(.bottom, 20)

                    // ── Título ─────────────────────────────────────────────
                    Text("Editar perfil")
                        .font(SeillFont.title(18))
                        .foregroundColor(.seilText)
                        .opacity(a(0.00, 0.30))
                        .offset(y: o(0.00, 0.30))

                    Spacer().frame(height: 24)

                    // ── Preview del avatar ─────────────────────────────────
                    avatarPreview
                        .opacity(a(0.05, 0.35))
                        .offset(y: o(0.05, 0.35))

                    Spacer().frame(height: 20)

                    // ── Label + contador ───────────────────────────────────
                    HStack {
                        Text("ELIGE TU AVATAR")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilMuted)
                            .tracking(1.2)
                        Spacer()
                        Text("\(avatarId + 1) de \(avatarCount)")
                            .font(SeillFont.caption(10))
                            .foregroundColor(.seilMuted)
                    }
                    .padding(.horizontal, 24)
                    .opacity(a(0.10, 0.40))
                    .offset(y: o(0.10, 0.40))

                    Spacer().frame(height: 12)

                    // ── Grid de avatares ───────────────────────────────────
                    avatarGrid
                        .padding(.horizontal, 24)
                        .opacity(a(0.15, 0.50))
                        .offset(y: o(0.15, 0.50))

                    Spacer().frame(height: 28)

                    // ── Sección nombre ─────────────────────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        Text("INFORMACIÓN PERSONAL")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilMuted)
                            .tracking(1.2)

                        SeillTextField(
                            label:       "Nombre",
                            placeholder: "Tu nombre",
                            icon:        "person",
                            text:        $nombre
                        )
                        .onChange(of: nombre) { _, _ in nombreError = nil }

                        if let err = nombreError {
                            HStack(spacing: 5) {
                                Image(systemName: "exclamationmark.circle.fill")
                                    .font(.system(size: 11))
                                Text(err)
                                    .font(SeillFont.caption(11))
                            }
                            .foregroundColor(.seilRose)
                            .transition(.opacity.combined(with: .move(edge: .top)))
                        }
                    }
                    .padding(.horizontal, 24)
                    .opacity(a(0.30, 0.60))
                    .offset(y: o(0.30, 0.60))

                    Spacer().frame(height: 24)

                    // ── Botón guardar ──────────────────────────────────────
                    saveButton
                        .padding(.horizontal, 24)
                        .opacity(a(0.40, 0.70))

                    Spacer().frame(height: 36)
                }
            }
        }
        .onAppear {
            nombre   = profileStore.profile.nombre
            avatarId = profileStore.profile.avatarId
            withAnimation(.easeOut(duration: 0.55)) { progress = 1 }
        }
    }

    // MARK: - Subviews

    private var avatarPreview: some View {
        let opt = UserProfile.avatarOptions[avatarId % avatarCount]
        return ZStack {
            // Halo exterior
            Circle()
                .fill(opt.color.opacity(0.12))
                .frame(width: 92, height: 92)
                .overlay(Circle().stroke(opt.color.opacity(0.28), lineWidth: 1.5))

            // Círculo principal
            Circle()
                .fill(opt.color)
                .frame(width: 76, height: 76)
                .shadow(color: opt.color.opacity(0.40), radius: 12, y: 4)

            Image(systemName: opt.icon)
                .font(.system(size: 30, weight: .semibold))
                .foregroundColor(.white)
        }
        .animation(.spring(response: 0.30, dampingFraction: 0.65), value: avatarId)
    }

    private var avatarGrid: some View {
        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(0..<avatarCount, id: \.self) { i in
                let opt      = UserProfile.avatarOptions[i]
                let selected = avatarId == i

                Button {
                    withAnimation(.spring(response: 0.26, dampingFraction: 0.62)) {
                        avatarId = i
                    }
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    ZStack {
                        Circle()
                            .fill(selected ? opt.color : opt.color.opacity(0.18))
                            .frame(width: 56, height: 56)
                            .overlay(
                                Circle().stroke(
                                    selected ? Color.white.opacity(0.88) : opt.color.opacity(0.30),
                                    lineWidth: selected ? 2.5 : 1
                                )
                            )
                            .shadow(
                                color: selected ? opt.color.opacity(0.42) : .clear,
                                radius: 8, y: 3
                            )

                        Image(systemName: opt.icon)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(selected ? .white : opt.color)
                    }
                    .scaleEffect(selected ? 1.08 : 1.0)
                    .animation(.spring(response: 0.26, dampingFraction: 0.62), value: avatarId)
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var saveButton: some View {
        if showSuccess {
            // Estado de éxito — breve antes de cerrar
            HStack(spacing: 8) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 16))
                Text("Cambios guardados")
                    .font(SeillFont.headline(14))
            }
            .foregroundColor(.seilGreen)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(Color.seilGreen.opacity(0.10))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.seilGreen.opacity(0.28), lineWidth: 1)
            )
            .transition(.opacity.combined(with: .scale(scale: 0.96)))
        } else {
            SeillPrimaryButton(title: saving ? "Guardando..." : "Guardar cambios") {
                guard validate(), !saving else { return }
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                saving = true
                Task {
                    let trimmed = nombre.trimmingCharacters(in: .whitespaces)
                    // 1. Persistir en backend
                    _ = await service.updatePerfil(nombre: trimmed, avatarId: avatarId)
                    // 2. Actualizar store local (fuente de verdad en UI)
                    profileStore.update(nombre: trimmed, avatarId: avatarId)
                    await MainActor.run {
                        saving = false
                        withAnimation(.easeOut(duration: 0.20)) { showSuccess = true }
                    }
                    try? await Task.sleep(for: .seconds(1.1))
                    dismiss()
                }
            }
        }
    }

    // MARK: - Validation

    private func validate() -> Bool {
        let trimmed = nombre.trimmingCharacters(in: .whitespaces)
        if trimmed.isEmpty {
            withAnimation { nombreError = "Ingresa tu nombre" }
            return false
        }
        if trimmed.count < 2 {
            withAnimation { nombreError = "Nombre muy corto" }
            return false
        }
        if trimmed.count > 50 {
            withAnimation { nombreError = "Nombre muy largo" }
            return false
        }
        return true
    }
}

// MARK: - Double clamp helper (scoped)
private extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}
