import SwiftUI

// ─── IdentityView ─────────────────────────────────────────────────────────────
//
// Pantalla "Mi Identidad" — el usuario personaliza qué marco, título y badges
// muestra en su perfil público.
//
// Ruta: Seillo/Views/Screens/User/IdentityView.swift
// Acceso: TabPerfilView → "Mi identidad" (MI ACTIVIDAD)
//
// Cambios Lote 1:
//   · Preview usa SeilloAvatarWithFrame en lugar de avatar inline
//   · Preview usa SeilloTitlePill en lugar de título inline
//   · Preview usa SeilloBadgesRow para los badges visibles
//   · Frame selector usa SeilloAvatarWithFrame mini
//   · Badge grid usa SeilloBadgeChip en lugar de círculos inline
// ─────────────────────────────────────────────────────────────────────────────

struct IdentityView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var profileStore: ProfileStore

    @State private var identity     : UserIdentity = .empty
    @State private var loading      = true
    @State private var saving       = false
    @State private var saveSuccess  = false

    // Preview en vivo
    @State private var previewFrame   : String? = nil
    @State private var previewTitle   : String? = nil
    @State private var previewBadges  : [String] = []

    @State private var appear: Double = 0

    private let service: ClientServiceProtocol = APIClientService()

    private var hasChanges: Bool {
        previewFrame != identity.frameActivo ||
        previewTitle != identity.tituloActivo ||
        previewBadges != identity.badgesVisibles
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                if loading {
                    VStack(spacing: 16) {
                        ProgressView().tint(.seilAccent)
                        Text("Cargando identidad...")
                            .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                    }
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 0) {
                            // ── Preview ──────────────────────────────
                            previewSection
                                .padding(.horizontal, 16)
                                .padding(.top, 16)
                                .padding(.bottom, 20)
                                .sectionAppear(progress: appear, start: 0, end: 0.3)

                            // ── Marcos ───────────────────────────────
                            framesSection
                                .padding(.bottom, 20)
                                .sectionAppear(progress: appear, start: 0.1, end: 0.4)

                            // ── Títulos ──────────────────────────────
                            titlesSection
                                .padding(.horizontal, 16)
                                .padding(.bottom, 20)
                                .sectionAppear(progress: appear, start: 0.2, end: 0.5)

                            // ── Badges ───────────────────────────────
                            badgesSection
                                .padding(.horizontal, 16)
                                .padding(.bottom, 20)
                                .sectionAppear(progress: appear, start: 0.3, end: 0.6)

                            // ── Guardar ──────────────────────────────
                            saveButton
                                .padding(.horizontal, 16)
                                .padding(.bottom, 40)
                                .sectionAppear(progress: appear, start: 0.4, end: 0.7)
                        }
                    }
                }
            }
            .navigationTitle("Mi identidad")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                }
            }
        }
        .task {
            let result = await service.getIdentidad()
            switch result {
            case .success(let id):
                identity      = id
                previewFrame  = id.frameActivo
                previewTitle  = id.tituloActivo
                previewBadges = id.badgesVisibles
            case .failure:
                break
            }
            loading = false
            withAnimation(.easeOut(duration: 0.7)) { appear = 1 }
        }
    }

    // MARK: - Preview Section (usa componentes reutilizables)

    private var previewSection: some View {
        VStack(spacing: 14) {
            // Avatar con marco — componente reutilizable
            SeilloAvatarWithFrame(
                avatarId: profileStore.profile.avatarId,
                frameId:  previewFrame,
                size:     84
            )

            // Nombre del usuario
            Text(profileStore.profile.nombre)
                .font(SeillFont.headline(16))
                .foregroundColor(.seilText)

            // Título — componente reutilizable
            if let titleId = previewTitle,
               let titleText = identity.titulosGanados.first(where: { $0.id == titleId })?.texto {
                SeilloTitlePill(
                    tituloId:    titleId,
                    tituloTexto: titleText,
                    compact:     true
                )
            }

            // Badges visibles — componente reutilizable
            if !previewBadges.isEmpty {
                let badgeInfos = previewBadges.compactMap { visId in
                    identity.badgesGanados.first { $0.id == visId }
                }
                SeilloBadgesRow(badges: badgeInfos)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }

    // MARK: - Frames Section

    private var framesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("MARCO")
                .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                .padding(.horizontal, 16)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    // Opción "sin marco"
                    frameOption(id: nil, label: "Ninguno")

                    ForEach(identity.framesGanados) { frame in
                        frameOption(id: frame.id, label: frame.nombre)
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    private func frameOption(id: String?, label: String) -> some View {
        let selected = previewFrame == id
        return Button {
            Haptics.tap()
            withAnimation(.easeOut(duration: 0.2)) { previewFrame = id }
        } label: {
            VStack(spacing: 8) {
                if id != nil {
                    SeilloAvatarWithFrame(
                        avatarId: profileStore.profile.avatarId,
                        frameId:  id,
                        size:     48
                    )
                } else {
                    ZStack {
                        Circle().stroke(Color.seilBorder, lineWidth: 1)
                            .frame(width: 48, height: 48)
                        Circle().fill(Color.seilCard).frame(width: 38, height: 38)
                        Image(systemName: "xmark")
                            .font(.system(size: 14)).foregroundColor(.seilMuted)
                    }
                }

                Text(label)
                    .font(SeillFont.caption(10))
                    .foregroundColor(selected ? .seilAccent : .seilMuted2)
                    .lineLimit(1)
            }
            .frame(width: 70)
            .padding(.vertical, 10)
            .background(selected ? Color.seilAccent.opacity(0.06) : Color.clear)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(selected ? Color.seilAccent.opacity(0.4) : Color.clear, lineWidth: 1)
            )
        }
        .buttonStyle(IdentityItemPressStyle())
    }

    // MARK: - Titles Section

    private var titlesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("TITULO")
                .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)

            // Opción "sin título"
            titleRow(id: nil, text: "Sin título")

            ForEach(identity.titulosGanados) { titulo in
                titleRow(id: titulo.id, text: titulo.texto)
            }
        }
    }

    private func titleRow(id: String?, text: String) -> some View {
        let selected = previewTitle == id
        let style = id.map { tituloStyleFor($0) }

        return Button {
            Haptics.tap()
            withAnimation(.easeOut(duration: 0.2)) { previewTitle = id }
        } label: {
            HStack(spacing: 12) {
                if let style {
                    Image(systemName: style.icon)
                        .font(.system(size: 14))
                        .foregroundColor(style.fg)
                } else {
                    Image(systemName: "xmark")
                        .font(.system(size: 14))
                        .foregroundColor(.seilMuted)
                }

                Text(text)
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilText)

                Spacer()

                if selected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 18))
                        .foregroundColor(.seilAccent)
                }
            }
            .padding(14)
            .background(selected ? Color.seilAccent.opacity(0.06) : Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(selected ? Color.seilAccent.opacity(0.35) : Color.seilBorder, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Badges Section (usa SeilloBadgeChip)

    private var badgesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("BADGES")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted).tracking(1.2)
                Spacer()
                Text("\(previewBadges.count)/3")
                    .font(SeillFont.caption(11))
                    .foregroundColor(previewBadges.count == 3 ? .seilAccent : .seilMuted)
            }

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(identity.badgesGanados) { badge in
                    let selected = previewBadges.contains(badge.id)
                    let isMaxed  = previewBadges.count >= 3 && !selected

                    Button {
                        Haptics.tap()
                        withAnimation(.easeOut(duration: 0.2)) {
                            if selected {
                                previewBadges.removeAll { $0 == badge.id }
                            } else if previewBadges.count < 3 {
                                previewBadges.append(badge.id)
                            }
                        }
                    } label: {
                        VStack(spacing: 8) {
                            SeilloBadgeChip(
                                badge:    badge,
                                size:     40,
                                selected: selected,
                                disabled: isMaxed
                            )

                            Text(badge.nombre)
                                .font(SeillFont.caption(9))
                                .foregroundColor(selected ? .seilAccent : .seilMuted2)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(selected ? Color.seilAccent.opacity(0.06) : Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(selected ? Color.seilAccent.opacity(0.4) : Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .buttonStyle(IdentityItemPressStyle())
                    .opacity(isMaxed ? 0.5 : 1)
                    .disabled(isMaxed)
                }
            }
        }
    }

    // MARK: - Save

    private var saveButton: some View {
        VStack(spacing: 8) {
            if saveSuccess {
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                    Text("Identidad actualizada")
                        .font(SeillFont.headline(14))
                }
                .foregroundColor(.seilGreen)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(Color.seilGreen.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .transition(.opacity)
            } else {
                Button {
                    guard hasChanges else { return }
                    Haptics.success()
                    saving = true
                    Task {
                        let request = UpdateIdentityRequest(
                            frameActivo: previewFrame,
                            tituloActivo: previewTitle,
                            badgesVisibles: previewBadges
                        )
                        _ = await service.updateIdentidad(request)
                        saving = false
                        withAnimation { saveSuccess = true }
                        try? await Task.sleep(for: .seconds(1.2))
                        dismiss()
                    }
                } label: {
                    HStack(spacing: 8) {
                        if saving {
                            ProgressView().tint(.white).scaleEffect(0.8)
                        } else {
                            Text("Guardar cambios")
                                .font(SeillFont.label(15))
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .foregroundColor(.white)
                    .background(hasChanges ? Color.seilAccent : Color.seilAccent.opacity(0.35))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: hasChanges ? Color.seilAccent.opacity(0.28) : .clear, radius: 12, y: 6)
                }
                .buttonStyle(.plain)
                .disabled(!hasChanges || saving)
            }
        }
    }
}

// ─── IdentityItemPressStyle ───────────────────────────────────────────────────
// ButtonStyle compartido por frameOption y badge buttons.
// Escala ligera al presionar — confirma visualmente que el tap fue registrado.
private struct IdentityItemPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1.0)
            .animation(SeillAnimation.buttonPress, value: configuration.isPressed)
    }
}
