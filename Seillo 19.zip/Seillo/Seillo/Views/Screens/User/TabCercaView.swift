import SwiftUI
import MapKit
import CoreLocation

// ─── Categorías ────────────────────────────────────────────────────────────────
private struct NearbyCategory: Identifiable {
    let id = UUID()
    let label: String
    let icon: String
    let keyword: String
}

private let nearbyCategories: [NearbyCategory] = [
    .init(label: "Todos",       icon: "square.grid.2x2.fill",          keyword: ""),
    // ── Lo más peruano ────────────────────────────────────────────────────
    .init(label: "Café",        icon: "cup.and.saucer.fill",           keyword: "café"),
    .init(label: "Pollería",    icon: "flame.fill",                    keyword: "pollería"),
    .init(label: "Cevichería",  icon: "fish.fill",                     keyword: "cevich"),
    .init(label: "Sanguchería", icon: "bag.fill",                      keyword: "sanguch"),
    .init(label: "Jugos",       icon: "drop.fill",                     keyword: "jugos"),
    .init(label: "Chifa",       icon: "fork.knife.circle.fill",        keyword: "chifa"),
    .init(label: "Panadería",   icon: "leaf.fill",                     keyword: "panader"),
    // ── Resto de categorías ───────────────────────────────────────────────
    .init(label: "Restaurante", icon: "fork.knife",                    keyword: "restaurante"),
    .init(label: "Barbería",    icon: "scissors",                      keyword: "barbería"),
    .init(label: "Pastelería",  icon: "birthday.cake.fill",            keyword: "pastelería"),
    .init(label: "Heladería",   icon: "snowflake",                     keyword: "helad"),
    .init(label: "Gimnasio",    icon: "dumbbell.fill",                 keyword: "gym"),
    .init(label: "Estética",    icon: "comb.fill",                     keyword: "estétic"),
    .init(label: "Veterinaria", icon: "pawprint.fill",                 keyword: "veterina"),
    .init(label: "Farmacia",    icon: "cross.case.fill",               keyword: "farma"),
    .init(label: "Tienda",      icon: "basket.fill",                   keyword: "tienda"),
    .init(label: "Spa",         icon: "sparkles",                      keyword: "spa"),
    .init(label: "Academia",    icon: "book.fill",                     keyword: "academia"),
]

struct TabCercaView: View {
    @State private var query       = ""
    @State private var selectedCat = 0
    @State private var appear      = false
    @State private var showSearch  = false
    @State private var showExplore = false

    // Ubicación real del usuario
    @StateObject private var locationService = LocationService()
    @State private var cameraPosition: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -12.1191, longitude: -77.0310),
            span: MKCoordinateSpan(latitudeDelta: 0.06, longitudeDelta: 0.06)
        )
    )
    @State private var selectedEntry: CardEntry? = nil
    // Nivel de zoom discreto — solo cambia al cruzar umbrales, no en cada frame
    // Evita parpadeo al recalcular clusters continuamente durante el gesto de zoom
    @State private var zoomLevel: Int = 2   // 0=muy cerca … 4=muy lejos
    @State private var debounceTask: Task<Void, Never>? = nil

    // Negocios cargados del backend
    @State private var entries:   [CardEntry] = []
    @State private var isLoading  = true
    @State private var hasError   = false
    @State private var hoursMap:  [String: String] = [:]  // negocioId → "Abierto · cierra a las 9pm"

    private let api = APIClient.shared

    private var filtered: [CardEntry] {
        let keyword = nearbyCategories[selectedCat].keyword

        return entries.filter { entry in
            let matchCat = keyword.isEmpty || entry.business.tags.contains {
                $0.lowercased().contains(keyword)
            }

            let q = query.lowercased()
            let matchQ = q.isEmpty
                || entry.business.name.lowercased().contains(q)
                || entry.business.tags.contains { $0.lowercased().contains(q) }

            return matchCat && matchQ
        }
    }

    var body: some View {
        ZStack {
            Color.seilBg
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
              SeillContentBox {
                VStack(spacing: 0) {
                    headerSection
                        .padding(.horizontal, 22)
                        .padding(.top, 18)
                        .padding(.bottom, 16)

                    categoriesSection
                        .padding(.bottom, 14)

                    mapSection
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)

                    resultsLabel
                        .padding(.horizontal, 22)
                        .padding(.bottom, 10)

                    // CRÍTICO: antes el catch llenaba entries con mockEntries
                    // silenciosamente. Ahora hasError muestra un estado real.
                    // ALTO: isLoading muestra skeletons en lugar de nada.
                    if isLoading {
                        NearbyLoadingState()
                            .padding(.horizontal, 16)
                    } else if hasError {
                        NearbyErrorState {
                            Task { await loadNegocios() }
                        }
                        .padding(.horizontal, 16)
                    } else if filtered.isEmpty {
                        NearbyEmptyState(query: query)
                            .opacity(appear ? 1 : 0)
                            .offset(y: appear ? 0 : 16)
                    } else {
                        ForEach(Array(filtered.enumerated()), id: \.element.card.id) { i, entry in
                            NavigationLink(destination: BizProfileScreen(
                                    card: entry.card,
                                    showCard: false,
                                    preloadedAddress: entry.business.address,
                                    preloadedDistrict: entry.business.district,
                                    preloadedDescription: entry.business.desc
                                )) {
                                NearbyBusinessRow(entry: entry, hoursOverride: hoursMap[entry.card.negocioId])
                            }
                            .buttonStyle(CardPressStyle())
                        }
                    }

                }
              } // SeillContentBox
            }
            .ignoresSafeArea(.all, edges: .bottom)
            .contentMargins(.bottom, 32, for: .scrollContent)
            .refreshable {
                await loadNegocios()
            }
        }
        .task {
            await loadNegocios()
            withAnimation(SeillAnimation.chrome.delay(0.04)) {
                appear = true
            }
            // Cargar horarios en background para mostrar estado real (Abierto/Cerrado)
            await loadHorarios()
            // Ubicación real — centra el mapa y dispara notificaciones nearby
            await locationService.requestAndFetch()
            if let coord = locationService.coordinate {
                withAnimation {
                    cameraPosition = .region(MKCoordinateRegion(
                        center: coord,
                        span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)
                    ))
                }
                Task { await triggerNearby(coord: coord) }
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: selectedCat) { _, idx in
            let keyword = nearbyCategories[idx].keyword
            guard !keyword.isEmpty else { return }
            Task { await fireEventoFiltro(categoria: keyword) }
        }
    }

    // MARK: - Horarios

    private func loadHorarios() async {
        let snapshot = entries
        await withTaskGroup(of: (String, String)?.self) { group in
            for entry in snapshot {
                let nid = entry.card.negocioId
                guard !nid.isEmpty else { continue }
                group.addTask {
                    guard let dtos = try? await APIClient.shared.getPublic(
                        "api/negocios/\(nid)/horario"
                    ) as [HorarioDiaDTO] else { return nil }
                    let label = hoursLabel(from: dtos)
                    return (nid, label)
                }
            }
            for await result in group {
                if let (nid, label) = result {
                    hoursMap[nid] = label
                }
            }
        }
    }

    /// Calcula "Abierto · cierra a las 9pm" / "Cerrado · abre a las 8am" según hora del dispositivo.
    private func hoursLabel(from dtos: [HorarioDiaDTO]) -> String {
        let cal      = Calendar.current
        let now      = Date()
        let weekday  = cal.component(.weekday, from: now) // 1=Dom … 7=Sáb
        let diaIdx   = (weekday + 5) % 7                  // 0=Lun … 6=Dom

        guard let hoy = dtos.first(where: { $0.dia == diaIdx }) else {
            return "Ver horario"
        }
        guard hoy.abierto == 1 else {
            // Buscar próximo día abierto
            for offset in 1...6 {
                let next = (diaIdx + offset) % 7
                if let d = dtos.first(where: { $0.dia == next }), d.abierto == 1 {
                    let label = diaShortLabel(next)
                    return "Cerrado · abre el \(label)"
                }
            }
            return "Cerrado temporalmente"
        }

        // Comparar hora actual con cierre
        let cierre = hoy.horaCierre.prefix(5) // "20:00"
        let comps  = cierre.split(separator: ":")
        if comps.count == 2,
           let hh = Int(comps[0]), let mm = Int(comps[1]),
           let closeDate = cal.date(bySettingHour: hh, minute: mm, second: 0, of: now) {
            if now < closeDate {
                let display = formatHour(String(cierre))
                return "Abierto · cierra a las \(display)"
            }
        }
        return "Cerrado hoy"
    }

    private func diaShortLabel(_ idx: Int) -> String {
        ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"][safe: idx] ?? "—"
    }

    private func formatHour(_ hhmm: String) -> String {
        let parts = hhmm.split(separator: ":")
        guard parts.count == 2, let h = Int(parts[0]), let m = Int(parts[1]) else { return hhmm }
        let suffix = h < 12 ? "am" : "pm"
        let h12    = h == 0 ? 12 : (h > 12 ? h - 12 : h)
        return m == 0 ? "\(h12)\(suffix)" : "\(h12):\(String(format: "%02d", m))\(suffix)"
    }

    // MARK: - Preferencias de evento

    private func fireEventoFiltro(categoria: String) async {
        guard TokenStore.isLoggedIn else { return }
        struct EventoRequest: Encodable { let categoria: String; let tipo: String }
        struct EventoResponse: Decodable { let ok: Bool? }
        _ = try? await api.post(
            "api/preferencias/evento",
            body: EventoRequest(categoria: categoria, tipo: "filtro")
        ) as EventoResponse
    }

    // MARK: - Load negocios del backend

    private func triggerNearby(coord: CLLocationCoordinate2D) async {
        struct NearbyRequest: Encodable { let lat: Double; let lng: Double }
        struct NearbyResponse: Decodable { let ok: Bool }
        _ = try? await api.post(
            "api/cliente/nearby",
            body: NearbyRequest(lat: coord.latitude, lng: coord.longitude)
        ) as NearbyResponse
    }

    private func loadNegocios() async {
        isLoading = true
        hasError  = false

        do {
            let dtos: [NegocioDTO] = try await api.getPublic("api/negocios")
            entries = dtos.map { dto in
                let biz = Business(
                    name: dto.nombre,
                    district: dto.distrito ?? "",
                    address: dto.direccion ?? "",
                    // CRÍTICO: antes era "Abierto" hardcodeado.
                    // NegocioDTO no incluye horario en este endpoint,
                    // así que mostramos un valor honesto en lugar de mentir.
                    hoursNow: "Ver horario",
                    desc: dto.descripcion ?? "",
                    bannerColors: [colorForCategory(dto.categoria ?? "")],
                    rating: dto.rating ?? 0,
                    reviewCount: dto.reviewCount ?? 0,
                    tags: [dto.categoria ?? ""],
                    menu: [],
                    reviews: [],
                    lat: dto.latitud ?? -12.0464,
                    lon: dto.longitud ?? -77.0428
                )
                let card = LoyaltyCard(
                    id: dto.id,
                    bizName: dto.nombre,
                    location: dto.categoria ?? "",
                    rewardText: "",
                    totalStamps: 10,
                    filledStamps: 0,
                    negocioId: dto.id,
                    programaId: ""
                )
                return CardEntry(business: biz, card: card)
            }
        } catch {
            // CRÍTICO: antes → entries = mockEntries (datos falsos como reales).
            // Ahora marcamos el error para que la UI lo comunique explícitamente.
            hasError = true
        }

        isLoading = false
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Negocios cerca")
                        .font(SeillFont.display(24))
                        .foregroundColor(.seilText)
                    Text("Descubre locales, revisa sus beneficios y usa tu tarjeta en tienda")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted)
                }
                Spacer()
                Button {
                    Haptics.tap()
                    showExplore = true
                } label: {
                    Image(systemName: "square.grid.2x2")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.seilAccent)
                        .frame(width: 36, height: 36)
                        .background(Color.seilAccent.opacity(0.12))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
                .sheet(isPresented: $showExplore) {
                    ExploreView()
                        .presentationDragIndicator(.hidden)
                        .presentationBackground(Color.seilBg)
                }
            }

            // Search tap target
            Button {
                Haptics.tap()
                showSearch = true
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.seilMuted)
                    Text("Buscar cafés, restaurantes...")
                        .font(SeillFont.body(14))
                        .foregroundColor(.seilMuted)
                    Spacer()
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .fullScreenCover(isPresented: $showSearch) {
                NavigationStack { SearchView(entries: entries) }
            }
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 10)
    }

    private var categoriesSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(nearbyCategories.enumerated()), id: \.element.id) { i, cat in
                    Button {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.easeOut(duration: 0.2)) {
                            selectedCat = i
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: cat.icon)
                                .font(.system(size: 12, weight: .semibold))

                            Text(cat.label)
                                .font(SeillFont.label(12))
                        }
                        .foregroundColor(selectedCat == i ? .white : .seilMuted)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .background(
                            selectedCat == i
                            ? LinearGradient(
                                colors: [Color.seilAccent, Color.seilAccent2],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                            : LinearGradient(
                                colors: [Color.seilCard, Color.seilCard],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(Capsule())
                        .overlay(
                            Capsule()
                                .stroke(
                                    selectedCat == i ? Color.clear : Color.seilBorder,
                                    lineWidth: 1
                                )
                        )
                        .shadow(
                            color: selectedCat == i ? Color.seilAccent.opacity(0.28) : .clear,
                            radius: 8,
                            y: 2
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 12)
    }

    private var mapSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            mapSectionHeader
            mapContent
        }
        .padding(16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }

    private var mapSectionHeader: some View {
        HStack {
            Text("VISTA RÁPIDA")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)
            Spacer()
            Text("Tu zona")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.seilAccent)
        }
    }

    // Calcula clusters client-side con un threshold fijo (proporcional al zoomLevel)
    private func buildClusters(threshold: Double) -> [MapClusterItem] {
        var clusters: [MapClusterItem] = []
        var assigned = Set<String>()

        for entry in filtered {
            guard !assigned.contains(entry.card.id) else { continue }
            var group = [entry]
            assigned.insert(entry.card.id)
            let coord = entry.business.coordinate

            for other in filtered where !assigned.contains(other.card.id) {
                let dlat = abs(other.business.coordinate.latitude  - coord.latitude)
                let dlon = abs(other.business.coordinate.longitude - coord.longitude)
                if dlat < threshold && dlon < threshold {
                    group.append(other)
                    assigned.insert(other.card.id)
                }
            }
            clusters.append(MapClusterItem(entries: group))
        }
        return clusters
    }

    // Threshold de agrupación según nivel de zoom discreto
    // Niveles: 0=street, 1=barrio, 2=ciudad, 3=metrópoli, 4=país
    private var clusterThreshold: Double {
        switch zoomLevel {
        case 0: return 0.002   // muy cerca — sin agrupación real
        case 1: return 0.006   // barrio
        case 2: return 0.018   // ciudad (default)
        case 3: return 0.060   // metrópoli
        default: return 0.180  // muy lejos
        }
    }
    // Clusters reactivos — solo se recalcula al cambiar zoomLevel (discreto)
    private var clusters: [MapClusterItem] { buildClusters(threshold: clusterThreshold) }

    private var mapContent: some View {
        VStack(spacing: 0) {
            Map(position: $cameraPosition) {
                UserAnnotation()
                ForEach(clusters) { cluster in
                    if cluster.entries.count == 1, let entry = cluster.entries.first {
                        // Pin individual
                        Annotation(entry.business.name, coordinate: entry.business.coordinate) {
                            mapPin(entry: entry)
                        }
                    } else {
                        // Pin agrupado
                        Annotation("\(cluster.entries.count) negocios", coordinate: cluster.coordinate) {
                            clusterPin(count: cluster.entries.count, color: cluster.entries.first?.card.stampColor ?? .seilAccent)
                        }
                    }
                }
            }
            .onMapCameraChange { context in
                // Deselect callout al mover mapa
                if selectedEntry != nil {
                    withAnimation(.easeOut(duration: 0.2)) { selectedEntry = nil }
                }
                // Debounce: esperar que el gesto de zoom termine antes de recalcular clusters
                // Evita parpadeo por recálculo en cada frame del pinch gesture
                let lat = context.region.span.latitudeDelta
                debounceTask?.cancel()
                debounceTask = Task {
                    try? await Task.sleep(nanoseconds: 180_000_000)  // 180ms
                    guard !Task.isCancelled else { return }
                    let newLevel: Int
                    switch lat {
                    case ..<0.005:  newLevel = 0
                    case ..<0.015:  newLevel = 1
                    case ..<0.045:  newLevel = 2
                    case ..<0.120:  newLevel = 3
                    default:        newLevel = 4
                    }
                    if newLevel != zoomLevel {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            zoomLevel = newLevel
                        }
                    }
                }
            }
            .mapStyle(.standard)
            .mapControls { }
            .frame(height: SeillLayout.mapPreviewHeight)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )

            if let entry = selectedEntry {
                MapCallout(entry: entry) {
                    selectedEntry = nil
                }
                .transition(.asymmetric(
                    insertion: .move(edge: .bottom).combined(with: .opacity),
                    removal:   .opacity
                ))
                .padding(.top, 8)
            }
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
        .animation(.easeInOut(duration: 0.2), value: selectedEntry == nil)
    }

    @ViewBuilder
    private func mapPin(entry: CardEntry) -> some View {
        Button {
            withAnimation(SeillAnimation.buttonPress) {  // antes: response: 0.3, dampingFraction: 0.7
                selectedEntry = entry
            }
        } label: {
            VStack(spacing: 2) {
                ZStack {
                    Circle()
                        .fill(entry.card.stampColor)
                        .frame(width: 30, height: 30)
                        .overlay(Circle().stroke(.white, lineWidth: 2))
                        .shadow(color: .black.opacity(0.35), radius: 4)

                    Image(systemName: entry.card.icon)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.white)
                }
                Circle()
                    .fill(entry.card.stampColor)
                    .frame(width: 5, height: 5)
            }
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func clusterPin(count: Int, color: Color) -> some View {
        ZStack {
            Circle()
                .fill(color)
                .frame(width: 36, height: 36)
                .overlay(Circle().stroke(.white, lineWidth: 2.5))
                .shadow(color: .black.opacity(0.30), radius: 5)

            Text("\(count)")
                .font(.system(size: 13, weight: .black))
                .foregroundColor(.white)
        }
    }

    private var resultsLabel: some View {
        HStack {
            Text(
                filtered.isEmpty
                ? "SIN RESULTADOS"
                : "\(filtered.count) \(filtered.count == 1 ? "LOCAL" : "LOCALES") ENCONTRADOS"
            )
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.seilMuted)
            .tracking(1.5)

            Spacer()
        }
        .animation(.easeOut(duration: 0.2), value: filtered.count)
    }
}


// ─── MapCallout ───────────────────────────────────────────────────────────────
struct MapCallout: View {
    let entry: CardEntry
    let onDismiss: () -> Void

    var body: some View {
        NavigationLink(destination: BizProfileScreen(
                    card: entry.card,
                    showCard: false,
                    preloadedAddress: entry.business.address,
                    preloadedDistrict: entry.business.district,
                    preloadedDescription: entry.business.desc
                )) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(entry.card.stampColor.opacity(0.14))
                        .frame(width: 36, height: 36)

                    Image(systemName: entry.card.icon)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(entry.card.stampColor)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(entry.business.name)
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)
                        .lineLimit(1)

                    Text(entry.business.district + " · " + entry.business.hoursNow)
                        .font(.system(size: 10))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.seilAccent)
            }
            .padding(10)
            .background(Color.seilSurface)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(entry.card.stampColor.opacity(0.30), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.25), radius: 8, y: 3)
        }
        .buttonStyle(CardPressStyle())
        .simultaneousGesture(TapGesture().onEnded { onDismiss() })
    }
}

// ─── NearbyBusinessRow ────────────────────────────────────────────────────────
struct NearbyBusinessRow: View {
    let entry: CardEntry
    var hoursOverride: String? = nil

    private var hoursLabel: String {
        hoursOverride ?? entry.business.hoursNow
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(entry.card.stampColor.opacity(0.12))
                    .frame(width: 50, height: 50)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(entry.card.stampColor.opacity(0.18), lineWidth: 1)
                    )

                Image(systemName: entry.card.icon)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(entry.card.stampColor)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(entry.business.name)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.seilText)
                        .lineLimit(1)

                    if entry.card.isComplete {
                        Text("PREMIO")
                            .font(.system(size: 8, weight: .black))
                            .foregroundColor(.seilGreen)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(Color.seilGreen.opacity(0.12))
                            .clipShape(Capsule())
                    }
                }

                Text(hoursLabel)
                    .font(SeillFont.body(11))
                    .foregroundColor(hoursLabel.hasPrefix("Abierto") ? .seilGreen : .seilMuted)

                HStack(spacing: 5) {
                    ForEach(entry.business.tags.prefix(2), id: \.self) { tag in
                        Text(tag)
                            .font(.system(size: 9, weight: .medium))
                            .foregroundColor(.seilMuted)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 2)
                            .background(Color.seilCard2)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .overlay(
                                RoundedRectangle(cornerRadius: 6)
                                    .stroke(Color.seilBorder, lineWidth: 0.5)
                            )
                    }
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                if entry.business.rating > 0 {
                    HStack(spacing: 4) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 10))
                            .foregroundColor(.seilGold)

                        Text(String(format: "%.1f", entry.business.rating))
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.seilText)
                    }
                } else {
                    Text("Nuevo")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.seilAccent)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.seilAccent.opacity(0.12))
                        .clipShape(Capsule())
                }

                Text(entry.business.district)
                    .font(.system(size: 11, weight: .heavy))
                    .foregroundColor(.seilAccent)

                HStack(spacing: 4) {
                    Text("\(entry.card.filledStamps)/\(entry.card.totalStamps)")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(entry.card.stampColor)

                    Text("sellos")
                        .font(.system(size: 10))
                        .foregroundColor(.seilMuted)
                }

                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white.opacity(0.32))
            }
        }
        .padding(14)
        .background(
            LinearGradient(
                colors: [
                    Color.seilCard,
                    Color.seilCard.opacity(0.96)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .shadow(color: entry.card.stampColor.opacity(0.06), radius: 10, y: 4)
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
    }
}

// ─── NearbyEmptyState ─────────────────────────────────────────────────────────
struct NearbyEmptyState: View {
    let query: String

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color.seilCard)
                    .frame(width: 64, height: 64)
                    .overlay(
                        RoundedRectangle(cornerRadius: 18)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )

                Image(systemName: "magnifyingglass")
                    .font(.system(size: 26))
                    .foregroundColor(.seilMuted)
            }

            Text(query.isEmpty ? "No hay negocios en esta categoría" : "No encontramos \"\(query)\"")
                .font(SeillFont.headline(15))
                .foregroundColor(.seilText)
                .multilineTextAlignment(.center)

            Text("Prueba con otra búsqueda\no cambia el filtro")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
        }
        .padding(.vertical, 48)
        .padding(.horizontal, 32)
    }
}

// ─── NearbyLoadingState ───────────────────────────────────────────────────────
// ALTO: isLoading existía pero nunca mostraba nada. Ahora muestra 4 filas
// skeleton mientras el API responde, usando ListRowSkeleton del sistema.

private struct NearbyLoadingState: View {
    var body: some View {
        VStack(spacing: 0) {
            ForEach(0..<4, id: \.self) { _ in
                VStack(spacing: 0) {
                    ListRowSkeleton(showAvatar: true, lineCount: 2)
                    Rectangle()
                        .fill(Color.seilBorder.opacity(0.5))
                        .frame(height: 1)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

// ─── NearbyErrorState ─────────────────────────────────────────────────────────
// CRÍTICO: antes el catch era silencioso (mockEntries). Ahora hay un estado
// visible con botón de retry para que el usuario sepa que algo falló.

private struct NearbyErrorState: View {
    let onRetry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.seilDanger.opacity(0.08))
                    .frame(width: 58, height: 58)
                    .overlay(Circle().stroke(Color.seilDanger.opacity(0.20), lineWidth: 1))
                Image(systemName: "wifi.slash")
                    .font(.system(size: 22))
                    .foregroundColor(.seilDanger)
            }

            VStack(spacing: 6) {
                Text("No pudimos cargar los negocios")
                    .font(SeillFont.title(15))
                    .foregroundColor(.seilText)

                Text("Revisa tu conexión e inténtalo de nuevo.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
            }

            Button(action: {
                Haptics.tap()
                onRetry()
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold))
                    Text("Reintentar")
                        .font(SeillFont.label(13))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 22)
                .padding(.vertical, 11)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 36)
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.seilDanger.opacity(0.20), lineWidth: 1)
        )
    }
}

// ── MapClusterItem ───────────────────────────────────────────────────────────────
// Representa un grupo de negocios cercanos en el mapa.

private struct MapClusterItem: Identifiable {
    let entries: [CardEntry]

    // ID determinístico basado en los IDs de los negocios — estable entre re-renders
    // Evita que SwiftUI destruya y recree las Annotation al recalcular clusters
    var id: String { entries.map(\.card.negocioId).sorted().joined(separator: "-") }

    var coordinate: CLLocationCoordinate2D {
        let lat = entries.map { $0.business.coordinate.latitude  }.reduce(0, +) / Double(entries.count)
        let lon = entries.map { $0.business.coordinate.longitude }.reduce(0, +) / Double(entries.count)
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }
}

// ── Safe array subscript ──────────────────────────────────────────────────────
private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
