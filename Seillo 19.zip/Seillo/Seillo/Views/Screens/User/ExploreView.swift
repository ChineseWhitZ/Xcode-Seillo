import SwiftUI

// ─── ExploreView ──────────────────────────────────────────────────────────────
//
// Descubrimiento de negocios tipo catálogo.
// Carga real desde GET /api/negocios — sin mockBusinesses.
//
// ─────────────────────────────────────────────────────────────────────────────

private struct ExploreFilter: Identifiable {
    let id      = UUID()
    let label   : String
    let keyword : String
    let icon    : String
}

private let exploreFilters: [ExploreFilter] = [
    .init(label: "Todos",       keyword: "",            icon: "square.grid.2x2.fill"),
    .init(label: "Cafe",        keyword: "caf",         icon: "cup.and.saucer.fill"),
    .init(label: "Polleria",    keyword: "poll",        icon: "flame.fill"),
    .init(label: "Cevicheria",  keyword: "cevich",      icon: "fish.fill"),
    .init(label: "Sangucheria", keyword: "sanguch",     icon: "bag.fill"),
    .init(label: "Jugos",       keyword: "jug",         icon: "drop.fill"),
    .init(label: "Chifa",       keyword: "chifa",       icon: "fork.knife.circle.fill"),
    .init(label: "Barberia",    keyword: "barber",      icon: "scissors"),
    .init(label: "Restaurante", keyword: "restaurante", icon: "fork.knife"),
    .init(label: "Panaderia",   keyword: "panader",     icon: "leaf.fill"),
    .init(label: "Heladeria",   keyword: "helad",       icon: "snowflake"),
    .init(label: "Gimnasio",    keyword: "gym",         icon: "dumbbell.fill"),
    .init(label: "Estetica",    keyword: "estetic",     icon: "comb.fill"),
    .init(label: "Veterinaria", keyword: "veterina",    icon: "pawprint.fill"),
]

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - ExploreView
// ═══════════════════════════════════════════════════════════════════════════════

struct ExploreView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var negocios    : [NegocioDTO] = []
    @State private var loading     = true
    @State private var query       = ""
    @State private var selectedIdx = 0
    @State private var favoriteIds : Set<String> = []
    @State private var appear      : Double = 0

    private let favManager = FavoritesManager.shared
    private let api        = APIClient.shared

    // ── Filtrado ──────────────────────────────────────────────────────────────
    private var filtered: [NegocioDTO] {
        let keyword = exploreFilters[selectedIdx].keyword
        let q       = query.lowercased()

        let matched = negocios.filter { biz in
            let cat       = (biz.categoria ?? "").lowercased()
            let matchCat  = keyword.isEmpty || cat.contains(keyword)
            let matchQ    = q.isEmpty
                || biz.nombre.lowercased().contains(q)
                || cat.contains(q)
            return matchCat && matchQ
        }

        // Favoritos primero
        return matched.sorted { a, b in
            let aFav = favoriteIds.contains(a.id)
            let bFav = favoriteIds.contains(b.id)
            if aFav != bFav { return aFav }
            return false
        }
    }

    // ── Body ──────────────────────────────────────────────────────────────────
    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                VStack(spacing: 0) {
                    SeillSearchField(placeholder: "Buscar negocios...", text: $query)
                        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)

                    categoryChips.padding(.bottom, 14)

                    if loading {
                        Spacer()
                        ProgressView().tint(.seilAccent)
                        Spacer()
                    } else if filtered.isEmpty {
                        Spacer()
                        SeillEmptyState(
                            icon: "magnifyingglass",
                            title: "Sin resultados",
                            message: "No encontramos negocios con esos filtros."
                        )
                        Spacer()
                    } else {
                        ScrollView(showsIndicators: false) {
                            LazyVStack(spacing: 12) {
                                ForEach(Array(filtered.enumerated()), id: \.element.id) { idx, biz in
                                    negocioCard(biz)
                                        .staggerIn(index: idx, appear: appear, offset: 14, stagger: 0.06)
                                }
                            }
                            .padding(.horizontal, 16).padding(.bottom, 40)
                        }
                    }
                }
            }
            .navigationTitle("Explorar")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                }
            }
        }
        .task {
            // Cargar favoritos locales
            favoriteIds = Set(favManager.getAll())

            // Cargar negocios del backend
            if let lista = try? await api.getPublic("api/negocios") as [NegocioDTO] {
                negocios = lista
            }
            loading = false
            withAnimation(.easeOut(duration: 0.6)) { appear = 1 }
        }
    }

    // MARK: - Category Chips

    private var categoryChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(exploreFilters.enumerated()), id: \.element.id) { idx, filter in
                    let selected = idx == selectedIdx
                    Button {
                        Haptics.tap()
                        withAnimation(.easeOut(duration: 0.2)) { selectedIdx = idx }
                        appear = 0
                        withAnimation(.easeOut(duration: 0.5)) { appear = 1 }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: filter.icon).font(.system(size: 12))
                            Text(filter.label).font(SeillFont.label(12))
                        }
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .foregroundColor(selected ? .white : .seilMuted2)
                        .background(selected ? Color.seilAccent : Color.seilCard)
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(selected ? Color.clear : Color.seilBorder, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    // MARK: - Negocio Card

    private func negocioCard(_ biz: NegocioDTO) -> some View {
        let cat        = biz.categoria ?? ""
        let isFav      = favoriteIds.contains(biz.id)
        let cardColors = gradientForCategory(cat)
        let cardIcon   = iconForCategory(cat)

        // Tarjeta mínima para poder abrir BizProfileScreen
        let card = LoyaltyCard(
            id:           biz.id,
            bizName:      biz.nombre,
            location:     cat,
            rewardText:   "",
            totalStamps:  10,
            filledStamps: 0,
            negocioId:    biz.id,
            programaId:   ""
        )

        return NavigationLink(destination: BizProfileScreen(
            card:                 card,
            showCard:             false,
            preloadedAddress:     biz.direccion,
            preloadedDistrict:    biz.distrito,
            preloadedDescription: biz.descripcion
        )) {
            HStack(spacing: 14) {
                // Ícono con gradiente por categoría
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(LinearGradient(colors: cardColors, startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 56, height: 56)
                    Image(systemName: cardIcon)
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(biz.nombre).font(SeillFont.headline(15)).foregroundColor(.seilText).lineLimit(1)

                    Text(biz.distrito ?? biz.direccion ?? cat)
                        .font(SeillFont.body(12)).foregroundColor(.seilMuted2).lineLimit(1)

                    Text(cat)
                        .font(SeillFont.caption(10)).foregroundColor(.seilMuted)
                }

                Spacer()

                // Ícono de flecha — indica navegación
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.seilMuted)

                // Favorito — simultaneousGesture para que coexista con el NavigationLink
                Button {
                    Haptics.tap()
                    withAnimation(.easeOut(duration: 0.2)) {
                        _ = favManager.toggle(biz.id)
                        favoriteIds = Set(favManager.getAll())
                    }
                } label: {
                    Image(systemName: isFav ? "heart.fill" : "heart")
                        .font(.system(size: 18))
                        .foregroundColor(isFav ? .seilRose : .seilMuted)
                        .scaleEffect(isFav ? 1.1 : 1)
                        .animation(SeillAnimation.microBounce, value: isFav)
                        .padding(8) // área de toque más grande sin afectar el link
                }
                .buttonStyle(.plain)
            }
            .padding(14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(isFav ? Color.seilRose.opacity(0.2) : Color.seilBorder, lineWidth: 1)
            )
        }
        .buttonStyle(CardPressStyle())
    }

    // MARK: - Helpers
    // Usa las funciones globales iconForCategory() y colorForCategory()
    // definidas en Models.swift — mapeo completo de todas las categorías peruanas.

    private func gradientForCategory(_ cat: String) -> [Color] {
        let base = colorForCategory(cat)
        return [base.opacity(0.6), base]
    }
}
