import SwiftUI

// ─── FAQView ──────────────────────────────────────────────────────────────────
// Sheet presentado desde TabPerfilView → showFAQ
// Acordeón con 8 preguntas, animación expand/collapse, ícono rotatorio
// y cambio de fondo/borde al expandir. Reemplaza el stub anterior.
// ─────────────────────────────────────────────────────────────────────────────

struct FAQView: View {

    @Environment(\.dismiss) private var dismiss
    @State private var progress: Double = 0

    private func a(_ s: Double, _ e: Double) -> Double {
        ((progress - s) / (e - s)).clamped(to: 0...1)
    }
    private func o(_ s: Double, _ e: Double) -> CGFloat {
        CGFloat(18 * (1 - a(s, e)))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 8) {
                        ForEach(Array(faqItems.enumerated()), id: \.offset) { i, item in
                            let start = Double(i) * 0.08
                            let end   = start + 0.36
                            FAQTile(item: item)
                                .opacity(a(start, end))
                                .offset(y: o(start, end))
                        }

                        Spacer().frame(height: 32)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                }
            }
            .navigationTitle("Preguntas frecuentes")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 30, height: 30)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                }
            }
            .onAppear {
                withAnimation(.easeOut(duration: 0.80)) {
                    progress = 1
                }
            }
        }
    }
}

// MARK: - Tile

private struct FAQTile: View {

    let item: FAQItem
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            // ── Header row (siempre visible) ──────────────────────────────
            Button {
                withAnimation(SeillAnimation.panelCascade) {
                    expanded.toggle()
                }
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            } label: {
                HStack(spacing: 12) {

                    // Ícono
                    ZStack {
                        Circle()
                            .fill(expanded
                                  ? Color.seilAccent.opacity(0.15)
                                  : Color.seilCard2)
                            .frame(width: 34, height: 34)
                        Image(systemName: item.icon)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(expanded ? .seilAccent : .seilMuted2)
                    }

                    // Pregunta
                    Text(item.question)
                        .font(SeillFont.headline(13))
                        .foregroundColor(expanded ? .seilAccent : .seilText)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    // Flecha rotando
                    Image(systemName: "chevron.down")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(expanded ? .seilAccent : .seilMuted)
                        .rotationEffect(.degrees(expanded ? 180 : 0))
                }
                .padding(14)
            }
            .buttonStyle(.plain)

            // ── Respuesta (solo cuando está expandida) ────────────────────
            if expanded {
                Text(item.answer)
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .lineSpacing(4)
                    .padding(.leading, 60)
                    .padding(.trailing, 14)
                    .padding(.bottom, 16)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(
            expanded
                ? Color.seilAccent.opacity(0.05)
                : Color.seilCard
        )
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(
                    expanded
                        ? Color.seilAccent.opacity(0.28)
                        : Color.seilBorder,
                    lineWidth: 1
                )
        )
        .animation(SeillAnimation.panelCascade, value: expanded)
    }
}

// MARK: - Data

private struct FAQItem {
    let icon:     String
    let question: String
    let answer:   String
}

private let faqItems: [FAQItem] = [
    FAQItem(
        icon:     "qrcode.viewfinder",
        question: "¿Cómo recibo un sello?",
        answer:   "Abre tu código QR desde la pantalla principal o desde tu perfil. Muéstraselo al encargado del local después de tu compra o visita. El negocio lo escanea y el sello se registra automáticamente en tu tarjeta."
    ),
    FAQItem(
        icon:     "creditcard.fill",
        question: "¿Qué es una tarjeta de sellos?",
        answer:   "Cada negocio tiene su propia tarjeta de fidelidad. Cada vez que visitas y acumulas un sello, avanzas hacia un premio. Cuando completas todos los sellos, puedes canjear tu recompensa."
    ),
    FAQItem(
        icon:     "trophy.fill",
        question: "¿Cómo canjeo mi premio?",
        answer:   "Cuando completes una tarjeta, aparecerá en la sección \"Premios\" como lista para canjear. Toca \"Canjear\", muestra el código generado al encargado y él lo confirmará."
    ),
    FAQItem(
        icon:     "timer",
        question: "¿El QR expira?",
        answer:   "Sí. Por seguridad, cada código QR tiene una validez de 5 minutos. Si se vence, puedes renovarlo tocando \"Renovar QR\" en pantalla."
    ),
    FAQItem(
        icon:     "location.fill",
        question: "¿Cómo encuentro negocios cerca?",
        answer:   "En la pestaña \"Cerca\" puedes ver los negocios participantes en tu zona. Puedes filtrar por categoría o usar el buscador para encontrar uno en particular."
    ),
    FAQItem(
        icon:     "iphone",
        question: "¿Puedo usar mi cuenta en otro teléfono?",
        answer:   "Sí. Tu cuenta y todos tus sellos están guardados en la nube. Solo tienes que iniciar sesión con tu correo y contraseña en cualquier dispositivo y todo estará disponible."
    ),
    FAQItem(
        icon:     "trash.fill",
        question: "¿Los sellos vencen?",
        answer:   "Depende de la política de cada negocio. Algunos tienen sellos sin vencimiento, mientras que otros los activan por temporada. Revisa los detalles de cada tarjeta."
    ),
    FAQItem(
        icon:     "lock.fill",
        question: "¿Mis datos están seguros?",
        answer:   "Sí. Seillo solo almacena tu nombre, correo y actividad dentro de la app. No compartimos ni vendemos tu información a terceros. Puedes eliminar tu cuenta desde Ajustes en cualquier momento."
    ),
]

// MARK: - Double clamp helper (scoped)
private extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}
