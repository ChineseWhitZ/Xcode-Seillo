import SwiftUI

// ─── ResetPasswordView ────────────────────────────────────────────────────────
// Pantalla de confirmación que aparece tras enviar el correo de recuperación.
// Recibe el email como parámetro para mostrarlo en pantalla.
// Acceso: ForgotPasswordView → al completar el envío exitosamente.
// ─────────────────────────────────────────────────────────────────────────────

struct ResetPasswordView: View {
    let email: String

    @Environment(\.dismiss) var dismiss

    @State private var appear       = false
    @State private var secondsLeft  = 60
    @State private var canResend    = false
    @State private var resendSent   = false
    @State private var timer: Timer? = nil

    private var maskedEmail: String {
        guard let at = email.firstIndex(of: "@") else { return email }
        let local  = String(email[email.startIndex..<at])
        let domain = String(email[at...])
        guard local.count > 2 else { return email }
        let visible = String(local.prefix(2))
        let dots    = String(repeating: "•", count: min(local.count - 2, 5))
        return "\(visible)\(dots)\(domain)"
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilBlue.opacity(0.10), .clear],
                center: .init(x: 0.5, y: 0.18),
                startRadius: 0,
                endRadius: 340
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                // ── Top bar ────────────────────────────────────────────────
                HStack {
                    Button {
                        Haptics.tap()
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                            .frame(width: 38, height: 38)
                            .background(Color.seilCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        Spacer().frame(height: 36)

                        // ── Ícono ──────────────────────────────────────────
                        ZStack {
                            Circle()
                                .fill(Color.seilBlue.opacity(0.08))
                                .frame(width: 130, height: 130)

                            Circle()
                                .fill(Color.seilBlue.opacity(0.12))
                                .frame(width: 100, height: 100)
                                .overlay(Circle().stroke(Color.seilBlue.opacity(0.20), lineWidth: 1.5))

                            Image(systemName: "envelope.badge.fill")
                                .font(.system(size: 44, weight: .semibold))
                                .foregroundColor(Color.seilBlue)
                                .shadow(color: Color.seilBlue.opacity(0.40), radius: 18, y: 6)
                        }
                        .scaleEffect(appear ? 1 : 0.72)
                        .opacity(appear ? 1 : 0)

                        Spacer().frame(height: 30)

                        // ── Título ─────────────────────────────────────────
                        Text("Revisa tu correo")
                            .font(SeillFont.display(26))
                            .foregroundColor(.seilText)
                            .multilineTextAlignment(.center)
                            .opacity(appear ? 1 : 0)
                            .offset(y: appear ? 0 : 14)

                        Spacer().frame(height: 12)

                        // ── Email mascarado ────────────────────────────────
                        HStack(spacing: 6) {
                            Image(systemName: "envelope.fill")
                                .font(.system(size: 12))
                                .foregroundColor(Color.seilBlue)

                            Text(maskedEmail)
                                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                                .foregroundColor(.seilText)
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(Color.seilBlue.opacity(0.10))
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(Color.seilBlue.opacity(0.25), lineWidth: 1))
                        .opacity(appear ? 1 : 0)

                        Spacer().frame(height: 16)

                        Text("Si esa dirección tiene una cuenta en Seillo, recibirás un correo con instrucciones para restablecer tu contraseña.")
                            .font(SeillFont.body(14))
                            .foregroundColor(.seilMuted2)
                            .multilineTextAlignment(.center)
                            .lineSpacing(4)
                            .padding(.horizontal, 32)
                            .opacity(appear ? 1 : 0)
                            .animation(.easeOut(duration: 0.4).delay(0.15), value: appear)

                        Spacer().frame(height: 32)

                        // ── Pasos a seguir ─────────────────────────────────
                        VStack(spacing: 0) {
                            stepRow(
                                number: "1",
                                icon: "envelope.open.fill",
                                color: Color.seilBlue,
                                title: "Abre el correo",
                                subtitle: "Busca un mensaje de noreply@seillo.app"
                            )
                            Divider()
                                .background(Color.seilBorder)
                                .padding(.leading, 58)

                            stepRow(
                                number: "2",
                                icon: "link",
                                color: .seilAccent,
                                title: "Toca el enlace",
                                subtitle: "El link es válido por 30 minutos"
                            )
                            Divider()
                                .background(Color.seilBorder)
                                .padding(.leading, 58)

                            stepRow(
                                number: "3",
                                icon: "lock.rotation",
                                color: .seilGreen,
                                title: "Elige tu nueva contraseña",
                                subtitle: "Mínimo 8 caracteres"
                            )
                        }
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                        .padding(.horizontal, 20)
                        .opacity(appear ? 1 : 0)
                        .animation(.easeOut(duration: 0.4).delay(0.20), value: appear)

                        Spacer().frame(height: 20)

                        // ── Spam tip ───────────────────────────────────────
                        HStack(spacing: 10) {
                            Image(systemName: "folder.fill")
                                .font(.system(size: 13))
                                .foregroundColor(.seilGold)

                            Text("¿No lo ves? Revisa la carpeta de spam o correo no deseado.")
                                .font(SeillFont.body(12))
                                .foregroundColor(.seilMuted2)
                                .lineSpacing(3)
                        }
                        .padding(14)
                        .background(Color.seilGold.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(Color.seilGold.opacity(0.18), lineWidth: 1)
                        )
                        .padding(.horizontal, 20)
                        .opacity(appear ? 1 : 0)
                        .animation(.easeOut(duration: 0.4).delay(0.25), value: appear)

                        Spacer().frame(height: 36)
                    }
                }

                // ── Botones CTA ────────────────────────────────────────────
                VStack(spacing: 12) {
                    // Abrir app de correo
                    Button {
                        Haptics.tap()
                        if let url = URL(string: "message://") {
                            UIApplication.shared.open(url)
                        }
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "envelope.open.fill")
                                .font(.system(size: 14, weight: .semibold))
                            Text("Abrir correo")
                                .font(SeillFont.headline(15))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            LinearGradient(
                                colors: [Color.seilBlue, Color.seilBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: Color.seilBlue.opacity(0.38), radius: 14, y: 4)
                    }
                    .buttonStyle(.plain)

                    // Reenviar
                    Button {
                        guard canResend else { return }
                        Haptics.tap()
                        resendSent  = true
                        canResend   = false
                        secondsLeft = 60
                        startTimer()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation { resendSent = false }
                        }
                    } label: {
                        Group {
                            if resendSent {
                                HStack(spacing: 6) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 13))
                                        .foregroundColor(.seilGreen)
                                    Text("¡Correo reenviado!")
                                        .font(SeillFont.body(14))
                                        .foregroundColor(.seilGreen)
                                }
                            } else if canResend {
                                Text("Reenviar correo")
                                    .font(SeillFont.body(14))
                                    .foregroundColor(.seilAccent)
                            } else {
                                Text("Reenviar en \(secondsLeft)s")
                                    .font(SeillFont.body(14))
                                    .foregroundColor(.seilMuted)
                            }
                        }
                        .animation(.easeOut(duration: 0.25), value: canResend)
                        .animation(.easeOut(duration: 0.25), value: resendSent)
                    }
                    .buttonStyle(.plain)
                    .disabled(!canResend)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
                .opacity(appear ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.30), value: appear)
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) {
                appear = true
            }
            startTimer()
        }
        .onDisappear {
            timer?.invalidate()
        }
    }

    // MARK: - Helpers

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if secondsLeft > 0 {
                secondsLeft -= 1
            } else {
                canResend = true
                timer?.invalidate()
            }
        }
    }

    private func stepRow(number: String, icon: String, color: Color, title: String, subtitle: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color.opacity(0.12))
                    .frame(width: 36, height: 36)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(color.opacity(0.20), lineWidth: 1)
                    )

                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(color)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(SeillFont.headline(13))
                    .foregroundColor(.seilText)

                Text(subtitle)
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted2)
            }

            Spacer()

            Text(number)
                .font(.system(size: 11, weight: .heavy))
                .foregroundColor(.seilMuted)
                .frame(width: 18)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }
}
