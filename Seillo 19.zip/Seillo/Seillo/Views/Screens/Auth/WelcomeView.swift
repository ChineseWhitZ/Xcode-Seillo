import SwiftUI

// ─── Constantes de física ─────────────────────────────────────────────────────
private let swipeThreshold: CGFloat = 110  // px para disparar el dismiss
private let flyOutDistance: CGFloat = 620  // px de salida lateral

// Tarjetas decorativas para la animación de bienvenida.
// Son visuales, no datos reales — muestran la propuesta de valor a usuarios no logueados.
private let welcomeCards: [LoyaltyCard] = [
    LoyaltyCard(id: "w1", bizName: "Café Inti",        location: "café",       rewardText: "Café a elección gratis",   totalStamps: 10, filledStamps: 8, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w2", bizName: "Pizzería Fuego",   location: "pizzería",   rewardText: "Pizza personal gratis",    totalStamps: 10, filledStamps: 3, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w3", bizName: "Barbería Rey",     location: "barbería",   rewardText: "Corte + arreglo gratis",   totalStamps: 7,  filledStamps: 5, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w4", bizName: "Juguería Verde",   location: "juguería",   rewardText: "Jugo especial grande",     totalStamps: 5,  filledStamps: 4, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w5", bizName: "Brasa Real",       location: "pollería",   rewardText: "Pollo familiar gratis",    totalStamps: 8,  filledStamps: 2, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w6", bizName: "El Marino",        location: "cevichería", rewardText: "Ceviche mixto gratis",     totalStamps: 10, filledStamps: 7, negocioId: "", programaId: ""),
    LoyaltyCard(id: "w7", bizName: "La Lucha",         location: "sanguchería",rewardText: "Sánguchón especial gratis",totalStamps: 6,  filledStamps: 4, negocioId: "", programaId: ""),
]

struct WelcomeView: View {
    @EnvironmentObject var auth: AuthManager

    @State private var showRoleSheet     = false
    @State private var selectedRole: String? = nil
    @State private var navigateToRegister = false
    @State private var navigateToLogin    = false

    // ── Índice del card frontal ────────────────────────────────────────────
    @State private var topIndex = 0

    // ── Drag physics ──────────────────────────────────────────────────────
    @State private var dragX:  CGFloat = 0
    @State private var dragY:  CGFloat = 0

    // ── Floating bob (tres fases desfasadas) ──────────────────────────────
    @State private var bob0: CGFloat = 0
    @State private var bob1: CGFloat = 0
    @State private var bob2: CGFloat = 0
    @State private var bobRunning = false  // evita doble lanzamiento al regresar con NavigationStack

    // ── Entrada ───────────────────────────────────────────────────────────
    @State private var headerVisible = false
    @State private var cardsVisible  = false
    @State private var ctaVisible    = false
    @State private var pillsVisible  = false

    // ── Card alphas (para la animación de descarte) ───────────────────────
    @State private var alpha0: Double = 0
    @State private var alpha1: Double = 0
    @State private var alpha2: Double = 0
    @State private var alpha3: Double = 0

    private var cardCount: Int { welcomeCards.count }
    private var dragRotation: Double { Double(dragX / 18).clamped(to: -25...25) }
    private var dismissProgress: Double { min(abs(Double(dragX)) / Double(swipeThreshold), 1.0) }

    private func cardAlpha(_ idx: Int) -> Double {
        switch idx % 4 { case 0: return alpha0; case 1: return alpha1; case 2: return alpha2; default: return alpha3 }
    }
    private func bobFor(_ layer: Int) -> CGFloat {
        switch layer { case 0: return bob0; case 1: return bob1; default: return bob2 }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                // Glows de fondo
                glowBackground

                VStack(spacing: 0) {
                    // ── Header ─────────────────────────────────────────────
                    headerSection
                        .opacity(headerVisible ? 1 : 0)
                        .offset(y: headerVisible ? 0 : -20)
                        .animation(
                            SeillAnimation.panelCascade,
                            value: headerVisible
                        )

                    // ── Card stack (ocupa el peso disponible) ──────────────
                    cardStack
                        .opacity(cardsVisible ? 1 : 0)
                        .animation(.easeOut(duration: 0.5).delay(0.15), value: cardsVisible)

                    // ── Feature pills ──────────────────────────────────────
                    featurePills
                        .opacity(pillsVisible ? 1 : 0)
                        .offset(y: pillsVisible ? 0 : 16)
                        .animation(
                            SeillAnimation.panelCascade.delay(0.20),
                            value: pillsVisible
                        )

                    Spacer().frame(height: 28)

                    // ── CTA buttons ───────────────────────────────────────
                    ctaSection
                        .opacity(ctaVisible ? 1 : 0)
                        .offset(y: ctaVisible ? 0 : 60)
                        .animation(
                            SeillAnimation.panelCascade.delay(0.25),
                            value: ctaVisible
                        )
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateToLogin) { LoginView() }
            .navigationDestination(isPresented: $navigateToRegister) {
                if let selectedRole { RegisterView(role: selectedRole) }
            }
            .sheet(isPresented: $showRoleSheet) {
                RoleSelectorSheet { role in
                    selectedRole = role
                    showRoleSheet = false
                    Task {
                        try? await Task.sleep(for: .seconds(0.15))
                        navigateToRegister = true
                    }
                }
                .presentationDetents([.height(360)])
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilSurface)
            }
            .task { await runEntrance() }
            .task { await runBob() }
        }
    }

    // MARK: - Subviews

    private var glowBackground: some View {
        ZStack {
            // Top glow
            RadialGradient(
                colors: [Color.seilAccent.opacity(0.13), .clear],
                center: UnitPoint(x: 0.5, y: 0),
                startRadius: 0,
                endRadius: 280
            )
            .frame(height: 420)
            .frame(maxHeight: .infinity, alignment: .top)
            .offset(y: -60)

            // Bottom glow
            RadialGradient(
                colors: [Color.seilAccent.opacity(0.07), .clear],
                center: .center,
                startRadius: 0,
                endRadius: 200
            )
            .frame(height: 300)
            .frame(maxHeight: .infinity, alignment: .bottom)
            .offset(y: 80)
        }
        .ignoresSafeArea()
    }

    private var headerSection: some View {
        VStack(spacing: 14) {
            // Logo real — SeillLogoMark en Assets.xcassets
            // La imagen ya incluye el wordmark "Seillo", no agregar Text debajo
            Image("SeillLogoMark")
                .resizable()
                .interpolation(.high)
                .scaledToFit()
                .frame(width: 160, height: 160)
                .shadow(color: Color.seilAccent.opacity(0.35), radius: 24, y: 8)
                .padding(.top, 44)

            Text("Sellos digitales para tus negocios favoritos")
                .font(SeillFont.body(15))
                .foregroundColor(.seilMuted)
                .lineSpacing(4)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 32)
    }

    // ── Card stack arrastrable ─────────────────────────────────────────────
    private var cardStack: some View {
        GeometryReader { geo in
            let w = geo.size.width

            ZStack {
                // Carta fondo (backIdx)
                let backIdx   = (topIndex + 2) % cardCount
                let middleIdx = (topIndex + 1) % cardCount
                let frontIdx  = topIndex

                // Fondo — más pequeña, rotada izquierda
                StackCard(card: welcomeCards[backIdx])
                    .frame(width: w * 0.78)
                    .offset(x: -20, y: bobFor(0))
                    .rotationEffect(.degrees(-9))
                    .scaleEffect(0.93)
                    .opacity(cardAlpha(backIdx) * 0.72)
                    .zIndex(0)

                // Medio — pequeña, rotada derecha
                StackCard(card: welcomeCards[middleIdx])
                    .frame(width: w * 0.82)
                    .offset(x: 16, y: bobFor(1))
                    .rotationEffect(.degrees(6))
                    .scaleEffect(0.96)
                    .opacity(cardAlpha(middleIdx) * 0.86)
                    .zIndex(1)

                // Frente — arrastrable
                StackCard(card: welcomeCards[frontIdx])
                    .frame(width: w * 0.86)
                    .offset(x: dragX, y: bobFor(2) + dragY)
                    .rotationEffect(.degrees(dragRotation))
                    .opacity(cardAlpha(frontIdx) * (1 - dismissProgress * 0.3))
                    .zIndex(2)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                dragX = value.translation.width
                                dragY = value.translation.height * 0.35
                            }
                            .onEnded { value in
                                // Velocidad horizontal del gesto — un flick rápido
                                // descarta la tarjeta aunque no alcance swipeThreshold.
                                let velocity = value.velocity.width
                                if abs(dragX) > swipeThreshold || abs(velocity) > 800 {
                                    dismissCard(direction: (dragX > 0 || velocity > 0) ? 1 : -1)
                                } else {
                                    snapBack()
                                }
                            }
                    )
            }
            .frame(maxWidth: .infinity)
        }
        .frame(height: 220)
        .padding(.vertical, 20)
    }

    private var featurePills: some View {
        HStack(spacing: 24) {
            WelcomeFeaturePill(icon: "qrcode",    text: "QR rápido")
            WelcomeFeaturePill(icon: "gift.fill",  text: "Premios")
            WelcomeFeaturePill(icon: "leaf.fill",  text: "Sin papel")
        }
    }

    private var ctaSection: some View {
        VStack(spacing: 12) {
            SeillButton(title: "Comenzar", icon: "sparkles") {
                showRoleSheet = true
            }

            SeillButton(title: "Ya tengo una cuenta", style: .secondary) {
                navigateToLogin = true
            }

            Text("Al continuar aceptas nuestros Términos y Política de privacidad")
                .font(SeillFont.caption(10))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
    }

    // MARK: - Card dismiss physics

    private func dismissCard(direction: CGFloat) {
        Haptics.success()
        withAnimation(.easeIn(duration: 0.32)) {
            dragX = flyOutDistance * direction
            dragY += 60
        }
        // Task estructurado — cancelable si la vista desaparece antes del delay.
        Task {
            try? await Task.sleep(for: .seconds(0.30))
            topIndex = (topIndex + 1) % cardCount
            dragX = 0
            dragY = 0
        }
    }

    private func snapBack() {
        withAnimation(SeillAnimation.screenTransition) {
            dragX = 0
            dragY = 0
        }
    }

    // MARK: - Animations

    private func runEntrance() async {
        try? await Task.sleep(for: .seconds(0.08))

        // Cards alphas — stagger
        withAnimation(.easeOut(duration: 0.18)) { alpha0 = 1 }
        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(.easeOut(duration: 0.18)) { alpha1 = 1 }
        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(.easeOut(duration: 0.18)) { alpha2 = 1 }
        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(.easeOut(duration: 0.18)) { alpha3 = 1 }

        headerVisible = true
        try? await Task.sleep(for: .seconds(0.15))
        cardsVisible = true
        try? await Task.sleep(for: .seconds(0.10))
        pillsVisible = true
        try? await Task.sleep(for: .seconds(0.10))
        ctaVisible = true
    }

    // Bob flotante — tres fases desfasadas 120° para que no se muevan en sincronía.
    // guard bobRunning evita que .task relance un segundo loop al regresar con NavigationStack.
    private func runBob() async {
        guard !bobRunning else { return }
        bobRunning = true
        defer { bobRunning = false }

        while !Task.isCancelled {
            withAnimation(.easeInOut(duration: 2.8)) { bob0 = -6 }
            try? await Task.sleep(for: .seconds(0.40))
            withAnimation(.easeInOut(duration: 2.8)) { bob1 = -5 }
            try? await Task.sleep(for: .seconds(0.40))
            withAnimation(.easeInOut(duration: 2.8)) { bob2 = -4 }
            try? await Task.sleep(for: .seconds(1.60))
            withAnimation(.easeInOut(duration: 2.8)) { bob0 = 0 }
            try? await Task.sleep(for: .seconds(0.40))
            withAnimation(.easeInOut(duration: 2.8)) { bob1 = 0 }
            try? await Task.sleep(for: .seconds(0.40))
            withAnimation(.easeInOut(duration: 2.8)) { bob2 = 0 }
            try? await Task.sleep(for: .seconds(1.20))
        }
    }
}

// ─── StackCard — carta de la pila ─────────────────────────────────────────────
private struct StackCard: View {
    let card: LoyaltyCard

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(systemName: card.icon)
                    .foregroundColor(card.stampColor)
                    .font(.system(size: 14))
                Spacer().frame(width: 7)
                Text(card.bizName)
                    .font(SeillFont.headline(13))
                    .foregroundColor(.white)
                    .lineLimit(1)
                Spacer()
            }

            Spacer().frame(height: 2)
            Text(card.location)
                .font(SeillFont.caption(10))
                .foregroundColor(.white.opacity(0.50))

            Spacer().frame(height: 10)
            StampsRowView(card: card)
            Spacer().frame(height: 8)

            HStack(spacing: 2) {
                Text("\(card.filledStamps)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(card.stampColor)
                Text("/\(card.totalStamps)")
                    .font(.system(size: 11))
                    .foregroundColor(.white.opacity(0.45))
                Text(card.isComplete ? " · Premio listo"
                     : card.remainingStamps <= 2 ? " · ¡Casi listo!"
                     : " · \(card.rewardText)")
                    .font(.system(size: 11))
                    .foregroundColor(card.isComplete ? .seilGold : .white.opacity(0.45))
                    .lineLimit(1)
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: card.gradientColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.28), radius: 16, y: 8)
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

private struct WelcomeFeaturePill: View {
    let icon: String
    let text: String

    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(.seilAccent)
            Text(text)
                .font(SeillFont.caption(10))
                .foregroundColor(.seilMuted2)
        }
    }
}

// ─── RoleSelectorSheet / RoleCard — sin cambios ───────────────────────────────

struct RoleSelectorSheet: View {
    var onSelect: (String) -> Void

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .padding(.top, 12)

            Spacer().frame(height: 22)

            Text("¿Cómo quieres usar Seillo?")
                .font(SeillFont.title(18))
                .foregroundColor(.seilText)

            Spacer().frame(height: 5)

            Text("Elige tu perfil para personalizar tu experiencia")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)

            Spacer().frame(height: 24)

            RoleCard(
                icon:     "person.fill",
                title:    "Soy cliente",
                subtitle: "Acumula sellos y canjea premios\nen tus negocios favoritos",
                color:    .seilAccent
            ) { onSelect("cliente") }

            Spacer().frame(height: 12)

            RoleCard(
                icon:     "storefront.fill",
                title:    "Tengo un negocio",
                subtitle: "Fideliza a tus clientes con\ntarjetas de sellos digitales",
                color:    .seilGold
            ) { onSelect("negocio") }

            Spacer().frame(height: 8)
        }
        .padding(.horizontal, 24)
    }
}

struct RoleCard: View {
    let icon:     String
    let title:    String
    let subtitle: String
    let color:    Color
    let action:   () -> Void

    @State private var pressed = false

    var body: some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(color.opacity(0.12))
                        .frame(width: 52, height: 52)
                    Image(systemName: icon)
                        .font(.system(size: 24))
                        .foregroundColor(color)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(SeillFont.headline(15))
                        .foregroundColor(.seilText)
                    Text(subtitle)
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(3)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 13))
                    .foregroundColor(color)
            }
            .padding(18)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(color.opacity(0.25), lineWidth: 1)
            )
            .scaleEffect(pressed ? 0.97 : 1.0)
            .animation(SeillAnimation.chrome, value: pressed)
        }
        .buttonStyle(.plain)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in pressed = true }
                .onEnded   { _ in pressed = false }
        )
    }
}
