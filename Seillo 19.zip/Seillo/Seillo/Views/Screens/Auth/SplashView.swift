import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// SplashView.swift
//
// Splash minimalista basado en texto.
// La "S" aparece con un glow naranja y cuenta de sellos animada,
// luego "eillo." se escribe letra por letra desde la izquierda,
// el punto final pulsa en naranja, y la tagline sube.
//
// Fases:
//   1. Pausa 200ms
//   2. "S" aparece con bounce + glow ambiental (300ms)
//   3. Haptic de impacto
//   4. Ink rings burst desde la "S"
//   5. "eillo." slide desde izquierda (280ms)
//   6. "." puntea en naranja con micro-bounce
//   7. Tagline sube (380ms después)
//   8. Hold 1.4s → fade-out
// ─────────────────────────────────────────────────────────────────────────────

// Valores animados de la "S" — KeyframeAnimator requiere un tipo Animatable.
private struct SLetterAnimValues {
    var scale: CGFloat = 0.3
    var alpha: Double  = 0
}

struct SplashView: View {

    // ── Estados ───────────────────────────────────────────────────────────────
    // sScale / sAlpha eliminados — ahora los maneja KeyframeAnimator.
    @State private var triggerSBounce: Bool   = false  // dispara el KeyframeAnimator de la "S"
    @State private var glowAlpha   : Double  = 0
    @State private var ink1Scale   : CGFloat = 0.8    // ring burst exterior
    @State private var ink1Alpha   : Double  = 0
    @State private var ink2Scale   : CGFloat = 0.8    // ring burst interior
    @State private var ink2Alpha   : Double  = 0
    @State private var eilloOffset : CGFloat = -36    // "eillo" slide
    @State private var eilloAlpha  : Double  = 0
    @State private var dotScale    : CGFloat = 0.4    // "." micro-bounce
    @State private var dotAlpha    : Double  = 0
    @State private var tagOffset   : CGFloat = 12
    @State private var tagAlpha    : Double  = 0
    @State private var exitAlpha   : Double  = 1

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            // ── Glow ambiental ─────────────────────────────────────────────
            RadialGradient(
                colors: [Color.seilAccent.opacity(glowAlpha * 0.28), .clear],
                center: .center, startRadius: 0, endRadius: 280
            )
            .ignoresSafeArea()
            .animation(.easeOut(duration: 0.65), value: glowAlpha)

            VStack(spacing: 0) {
                Spacer()

                // ── Rings burst (detrás del wordmark) ─────────────────────
                ZStack {
                    Circle()
                        .stroke(Color.seilAccent.opacity(ink1Alpha), lineWidth: 2.0)
                        .frame(width: 110, height: 110)
                        .scaleEffect(ink1Scale)

                    Circle()
                        .stroke(Color.seilAccent.opacity(ink2Alpha * 0.5), lineWidth: 1.5)
                        .frame(width: 110, height: 110)
                        .scaleEffect(ink2Scale)

                    // ── Wordmark ───────────────────────────────────────────
                    HStack(spacing: 0) {

                        // "S" — KeyframeAnimator: bounce físico en un solo bloque declarativo.
                        // ProMotion-aware, cancela la necesidad de 4 withAnimation + 3 Task.sleep.
                        KeyframeAnimator(
                            initialValue: SLetterAnimValues(),
                            trigger: triggerSBounce
                        ) { vals in
                            Text("S")
                                .font(.system(size: 72, weight: .black, design: .rounded))
                                .foregroundStyle(
                                    LinearGradient(
                                        colors: [Color(hex: "#FF7D35"), Color.seilAccent],
                                        startPoint: .top, endPoint: .bottom
                                    )
                                )
                                .tracking(-3)
                                .scaleEffect(vals.scale)
                                .opacity(vals.alpha)
                                .shadow(color: Color.seilAccent.opacity(glowAlpha * vals.alpha * 0.55),
                                        radius: 18, y: 4)
                        } keyframes: { _ in
                            KeyframeTrack(\.scale) {
                                LinearKeyframe(0.3,  duration: 0.001)
                                SpringKeyframe(1.14, duration: 0.22, spring: .bouncy)
                                SpringKeyframe(0.94, duration: 0.10)
                                SpringKeyframe(1.03, duration: 0.08)
                                SpringKeyframe(1.00, duration: 0.14, spring: .smooth)
                            }
                            KeyframeTrack(\.alpha) {
                                LinearKeyframe(0.0, duration: 0.001)
                                LinearKeyframe(1.0, duration: 0.08)
                            }
                        }

                        // "eillo" — slide desde izquierda
                        Text("eillo")
                            .font(.system(size: 72, weight: .black, design: .rounded))
                            .foregroundColor(.seilText)
                            .tracking(-3)
                            .offset(x: eilloOffset)
                            .opacity(eilloAlpha)

                        // "." — micro-bounce en naranja
                        Text(".")
                            .font(.system(size: 72, weight: .black, design: .rounded))
                            .foregroundColor(.seilAccent)
                            .tracking(-3)
                            .scaleEffect(dotScale)
                            .opacity(dotAlpha)
                    }
                }

                Spacer().frame(height: 16)

                // ── Tagline ────────────────────────────────────────────────
                Text("Tus sellos, siempre contigo")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(.seilMuted2)
                    .tracking(0.5)
                    .offset(y: tagOffset)
                    .opacity(tagAlpha)

                Spacer()
            }
        }
        .opacity(exitAlpha)
        .task { await runSequence() }
    }

    // MARK: - Secuencia de animación

    private func runSequence() async {

        // 1. Pausa inicial
        try? await Task.sleep(for: .seconds(0.20))

        // 2. KeyframeAnimator de la "S" — trigger único reemplaza 4 withAnimation + 3 Task.sleep.
        //    Duración total de keyframes: 0.001 + 0.22 + 0.10 + 0.08 + 0.14 ≈ 0.54s
        Haptics.success()
        triggerSBounce = true
        try? await Task.sleep(for: .seconds(0.54))

        // 3. Glow ambiental
        withAnimation(.easeOut(duration: 0.6)) { glowAlpha = 1 }

        // 4. Ink rings burst — alpha con withAnimation para evitar flash abrupto
        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(.easeOut(duration: 0.08)) { ink1Alpha = 0.50; ink2Alpha = 0.32 }
        withAnimation(.easeOut(duration: 0.65)) { ink1Scale = 2.8; ink1Alpha = 0 }
        try? await Task.sleep(for: .seconds(0.07))
        withAnimation(.easeOut(duration: 0.52)) { ink2Scale = 2.2; ink2Alpha = 0 }

        // 5. "eillo" slide desde la izquierda
        try? await Task.sleep(for: .seconds(0.05))
        withAnimation(.interpolatingSpring(stiffness: 290, damping: 26)) {
            eilloOffset = 0
        }
        withAnimation(.easeOut(duration: 0.22)) { eilloAlpha = 1 }

        // 6. "." micro-bounce
        try? await Task.sleep(for: .seconds(0.18))
        withAnimation(.easeOut(duration: 0.08)) { dotAlpha = 1 }
        withAnimation(.interpolatingSpring(stiffness: 420, damping: 14)) {
            dotScale = 1.0
        }
        Haptics.tap()

        // 7. Tagline sube
        try? await Task.sleep(for: .seconds(0.36))
        withAnimation(.interpolatingSpring(stiffness: 240, damping: 26)) {
            tagOffset = 0
        }
        withAnimation(.easeOut(duration: 0.36)) { tagAlpha = 1 }

        // 8. Hold → fade-out de salida
        try? await Task.sleep(for: .seconds(1.4))
        Haptics.tap()
        withAnimation(.easeOut(duration: 0.40)) { exitAlpha = 0 }
    }
}
