import SwiftUI

struct BizCategory: Identifiable {
    let id = UUID()
    let label: String
    let icon: String
}

let bizCategories: [BizCategory] = [
    // ── Lo más peruano ─────────────────────────────────────────────────────
    .init(label: "Café / Cafetería",    icon: "cup.and.saucer.fill"),
    .init(label: "Pollería",            icon: "flame.fill"),
    .init(label: "Cevichería",          icon: "fish.fill"),
    .init(label: "Sanguchería",         icon: "bag.fill"),
    .init(label: "Juguería / Jugos",    icon: "drop.fill"),
    .init(label: "Chifa",               icon: "fork.knife.circle.fill"),
    .init(label: "Panadería",           icon: "leaf.fill"),
    .init(label: "Heladería",           icon: "snowflake"),
    // ── Otros ──────────────────────────────────────────────────────────────
    .init(label: "Restaurante",         icon: "fork.knife"),
    .init(label: "Barbería / Salón",    icon: "scissors"),
    .init(label: "Pastelería",          icon: "birthday.cake.fill"),
    .init(label: "Gimnasio / Fitness",  icon: "dumbbell.fill"),
    .init(label: "Tienda / Retail",     icon: "basket.fill"),
    .init(label: "Spa / Belleza",       icon: "sparkles"),
    .init(label: "Academia / Clases",   icon: "book.fill"),
    .init(label: "Veterinaria",         icon: "pawprint.fill"),
    .init(label: "Bar / Pub",           icon: "wineglass.fill"),
    .init(label: "Otro",                icon: "storefront.fill"),
]

struct RegisterView: View {
    let role: String
    var referralCode: String = ""

    @StateObject private var appleCoordinator = AppleSignInCoordinator()

    @EnvironmentObject var auth: AuthManager
    @Environment(\.dismiss) var dismiss

    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var password2 = ""
    @State private var showPass = false
    @State private var showPass2 = false

    @State private var bizName = ""
    @State private var bizAddress = ""
    @State private var bizCategory: BizCategory? = nil
    @State private var ruc = ""
    @State private var showCatSheet = false

    @State private var accepted = false
    @State private var loading = false
    @State private var errorMsg: String? = nil
    @State private var appear = false

    var isNegocio: Bool { role == "negocio" }
    var roleColor: Color { isNegocio ? .seilGold : .seilAccent }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [roleColor.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.16),
                startRadius: 0,
                endRadius: 340
            )
            .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    VStack(spacing: 16) {
                        HStack {
                            Button {
                                Haptics.tap()
                                dismiss()
                            } label: {
                                Image(systemName: "xmark")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.seilMuted)
                                    .frame(width: 38, height: 38)
                                    .background(Color.seilCard)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                            }
                            .buttonStyle(.plain)
                            Spacer()
                        }
                        .padding(.top, 18)
                        .padding(.horizontal, 24)

                        VStack(spacing: 10) {
                            HStack(spacing: 6) {
                                Image(systemName: isNegocio ? "storefront.fill" : "person.fill")
                                    .font(.system(size: 11, weight: .bold))
                                Text(isNegocio ? "Cuenta de negocio" : "Cuenta de cliente")
                                    .font(SeillFont.label(11))
                            }
                            .foregroundStyle(roleColor)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(roleColor.opacity(0.12))
                            .clipShape(Capsule())

                            // ── Banner referido (Lote 6) ────────────────
                            if !referralCode.isEmpty {
                                HStack(spacing: 10) {
                                    Image(systemName: "star.circle.fill")
                                        .font(.system(size: 18))
                                        .foregroundColor(.seilGold)

                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Invitado por un amigo")
                                            .font(SeillFont.headline(12))
                                            .foregroundColor(.seilText)
                                        Text("Código: \(referralCode) · Ambos ganan 2 sellos al registrarte")
                                            .font(SeillFont.caption(10))
                                            .foregroundColor(.seilMuted2)
                                    }
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 10)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.seilGold.opacity(0.08))
                                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .stroke(Color.seilGold.opacity(0.25), lineWidth: 1)
                                )
                            }

                            Text(isNegocio ? "Registra tu negocio" : "Crea tu cuenta")
                                .font(SeillFont.display(26))
                                .foregroundColor(.seilText)
                            Text(
                                isNegocio
                                ? "Empieza a fidelizar clientes hoy mismo."
                                : "Es gratis. Empieza a acumular sellos hoy."
                            )
                            .font(SeillFont.body(14))
                            .foregroundColor(.seilText)
                            .multilineTextAlignment(.center)
                        }
                        .padding(.horizontal, 24)
                    }

                    VStack(spacing: 18) {
                        SeillTextField(
                            label: "Tu nombre",
                            placeholder: "Carlos Mendoza",
                            icon: "person",
                            text: $name
                        )

                        SeillTextField(
                            label: "Correo electrónico",
                            placeholder: "tu@correo.com",
                            icon: "envelope",
                            text: $email,
                            keyboardType: .emailAddress
                        )

                        SeillTextField(
                            label: "Contraseña",
                            placeholder: "Mínimo 8 caracteres",
                            icon: "lock",
                            text: $password,
                            isSecure: !showPass,
                            trailingIcon: showPass ? "eye.slash" : "eye",
                            trailingAction: { showPass.toggle() }
                        )

                        SeillTextField(
                            label: "Confirmar contraseña",
                            placeholder: "Repite tu contraseña",
                            icon: "lock.fill",
                            text: $password2,
                            isSecure: !showPass2,
                            trailingIcon: showPass2 ? "eye.slash" : "eye",
                            trailingAction: { showPass2.toggle() }
                        )

                        if isNegocio {
                            VStack(spacing: 18) {
                                SectionDividerLabel(label: "DATOS DE TU NEGOCIO", color: .seilGold)

                                SeillTextField(
                                    label: "Nombre del negocio",
                                    placeholder: "Ej. Café Inti",
                                    icon: "storefront",
                                    text: $bizName
                                )

                                SeillTextField(
                                    label: "Dirección",
                                    placeholder: "Ej. Jr. Schell 392, Miraflores",
                                    icon: "location",
                                    text: $bizAddress
                                )

                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Categoría")
                                        .font(SeillFont.label(12))
                                        .foregroundColor(.seilMuted2)

                                    Button {
                                        Haptics.tap()
                                        showCatSheet = true
                                    } label: {
                                        HStack(spacing: 10) {
                                            Image(systemName: bizCategory?.icon ?? "square.grid.2x2")
                                                .foregroundColor(bizCategory != nil ? .seilGold : .seilMuted)

                                            Text(bizCategory?.label ?? "Selecciona una categoría")
                                                .font(SeillFont.body(14))
                                                .foregroundColor(bizCategory != nil ? .seilText : .seilMuted)

                                            Spacer()

                                            Image(systemName: "chevron.down")
                                                .font(.system(size: 13))
                                                .foregroundColor(.seilMuted)
                                        }
                                        .padding(.horizontal, 14)
                                        .padding(.vertical, 14)
                                        .background(Color.seilCard)
                                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                                .stroke(
                                                    bizCategory != nil ? Color.seilGold.opacity(0.40) : Color.seilBorder,
                                                    lineWidth: 1
                                                )
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }

                                SeillTextField(
                                    label: "RUC",
                                    placeholder: "Ej. 20123456789",
                                    icon: "creditcard",
                                    text: $ruc,
                                    keyboardType: .numberPad
                                )
                            }
                            .padding(.top, 6)
                        }

                        VStack(alignment: .leading, spacing: 12) {
                            Button {
                                Haptics.tap()
                                accepted.toggle()
                            } label: {
                                HStack(alignment: .top, spacing: 10) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                                            .stroke(accepted ? roleColor : Color.seilMuted, lineWidth: 1.5)
                                            .frame(width: 20, height: 20)

                                        if accepted {
                                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                                .fill(roleColor)
                                                .frame(width: 20, height: 20)

                                            Image(systemName: "checkmark")
                                                .font(.system(size: 11, weight: .bold))
                                                .foregroundStyle(.white)
                                        }
                                    }

                                    Text("Acepto los \(Text("Términos de uso").foregroundColor(roleColor).bold()) y la \(Text(SeillStrings.settings.privacyPolicy).foregroundColor(roleColor).bold())")
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted2)
                                    .multilineTextAlignment(.leading)

                                    Spacer(minLength: 0)
                                }
                            }
                            .buttonStyle(.plain)

                            if let msg = errorMsg {
                                HStack(spacing: 8) {
                                    Image(systemName: "exclamationmark.triangle.fill")
                                        .foregroundStyle(Color.red)
                                    Text(msg)
                                        .font(SeillFont.body(13))
                                        .foregroundStyle(Color.red)
                                }
                                .padding(12)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.red.opacity(0.08))
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            }
                        }

                        SeillButton(
                            title: isNegocio ? "Registrar mi negocio" : "Crear cuenta gratis",
                            icon: isNegocio ? "storefront.fill" : "person.badge.plus",
                            isLoading: loading,
                            disabled: !accepted
                        ) {
                            Task { await doRegister() }
                        }

                        AuthDivider()

                        VStack(spacing: 10) {
                            GoogleSignInButton(title: "Registrarse con Google") {
                                Task { await googleRegister() }
                            }

                            AppleSignInButton(title: "Registrarse con Apple") {
                                appleCoordinator.startSignIn()
                            }
                        }

                        HStack {
                            Spacer()
                            // Usar dismiss() en lugar de NavigationLink para evitar
                            // apilar Login → Register → Login → Register infinitamente.
                            HStack(spacing: 4) {
                                Text("¿Ya tienes cuenta? ")
                                    .font(SeillFont.body(13))
                                    .foregroundColor(.seilMuted2)
                                Button("Inicia sesión") {
                                    Haptics.tap()
                                    dismiss()
                                }
                                .font(SeillFont.label(13))
                                .foregroundColor(.seilAccent)
                                .buttonStyle(.plain)
                            }
                            Spacer()
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 28)
                    .padding(.bottom, 36)
                    .offset(y: appear ? 0 : 24)
                    .opacity(appear ? 1 : 0)
                    .animation(SeillAnimation.chrome.delay(0.08), value: appear)
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear { appear = true }
        .sheet(isPresented: $showCatSheet) {
            CategoryPickerSheet(selected: $bizCategory)
                .presentationDetents([.medium])
                .presentationBackground(Color.seilSurface)
        }
        // triggerID es Int (Equatable) — compatible con .onChange en iOS 26
        .onChange(of: appleCoordinator.triggerID) { _, _ in
            Task {
                loading = true
                errorMsg = nil
                if let credential = appleCoordinator.lastCredential {
                    do {
                        try await auth.loginWithApple(credential)
                        Haptics.success()
                    } catch {
                        errorMsg = error.localizedDescription
                        Haptics.error()
                    }
                } else if let error = appleCoordinator.lastError {
                    errorMsg = error.localizedDescription
                    Haptics.error()
                }
                loading = false
            }
        }
    }

    private func doRegister() async {
        guard validate() else {
            Haptics.error()
            return
        }

        loading = true
        errorMsg = nil

        do {
            try await auth.register(nombre: name, email: email, password: password, role: role)
            Haptics.success()
        } catch {
            errorMsg = error.localizedDescription
            Haptics.error()
        }

        loading = false
    }

    private func appleRegister() async {
        loading = true
        errorMsg = nil

        do {
            // TODO: reemplazar con ASAuthorizationAppleIDProvider real
            try await Task.sleep(nanoseconds: 900_000_000)
            try await auth.register(nombre: name, email: email, password: password, role: role)
            Haptics.success()
        } catch {
            errorMsg = error.localizedDescription
            Haptics.error()
        }

        loading = false
    }

    private func googleRegister() async {
        loading = true
        errorMsg = nil

        do {
            try await Task.sleep(nanoseconds: 900_000_000)
            try await auth.register(nombre: name, email: email, password: password, role: role)
            Haptics.success()
        } catch {
            errorMsg = error.localizedDescription
            Haptics.error()
        }

        loading = false
    }

    private func validate() -> Bool {
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            errorMsg = "Ingresa tu nombre"
            return false
        }

        if email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            errorMsg = "Ingresa tu correo"
            return false
        }

        if password.count < 8 {
            errorMsg = "Mínimo 8 caracteres"
            return false
        }

        if password != password2 {
            errorMsg = "Las contraseñas no coinciden"
            return false
        }

        if isNegocio {
            if bizName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                errorMsg = "Ingresa el nombre del negocio"
                return false
            }

            if bizCategory == nil {
                errorMsg = "Selecciona una categoría"
                return false
            }

            if ruc.count != 11 {
                errorMsg = "El RUC debe tener 11 dígitos"
                return false
            }
        }

        if !accepted {
            errorMsg = "Debes aceptar los términos"
            return false
        }

        return true
    }
}

struct CategoryPickerSheet: View {
    @Binding var selected: BizCategory?
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .frame(maxWidth: .infinity)
                .padding(.top, 12)

            Spacer().frame(height: 20)

            Text("Categoría del negocio")
                .font(SeillFont.title(18))
                .foregroundColor(.seilText)
                .padding(.horizontal, 24)

            Spacer().frame(height: 16)

            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach(bizCategories) { cat in
                        Button {
                            Haptics.tap()
                            selected = cat
                            dismiss()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: cat.icon)
                                    .font(.system(size: 14))
                                    .foregroundColor(selected?.id == cat.id ? .seilGold : .seilMuted2)

                                Text(cat.label)
                                    .font(SeillFont.body(12))
                                    .foregroundColor(selected?.id == cat.id ? .seilGold : .seilText)
                                    .lineLimit(2)
                                    .multilineTextAlignment(.leading)

                                Spacer()
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(selected?.id == cat.id ? Color.seilGold.opacity(0.12) : Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(
                                        selected?.id == cat.id ? Color.seilGold.opacity(0.40) : Color.seilBorder,
                                        lineWidth: 1
                                    )
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
    }
}
