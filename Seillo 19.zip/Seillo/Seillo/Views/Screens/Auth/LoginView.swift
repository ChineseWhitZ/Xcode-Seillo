import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthManager
    @Environment(\.dismiss) var dismiss

    @StateObject private var appleCoordinator = AppleSignInCoordinator()

    @State private var email = ""
    @State private var password = ""
    @State private var showPass = false
    @State private var loading = false
    @State private var oauthLoading: OAuthProvider? = nil   // HIGH: loading state en OAuth
    @State private var errorMsg: String? = nil
    @State private var appear = false
    @State private var showForgot = false

    // Distingue qué proveedor OAuth está en vuelo para deshabilitar ambos botones
    private enum OAuthProvider: Equatable { case google, apple }

    var body: some View {
        ZStack {
            Color.seilBg
                .ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilAccent.opacity(0.08), Color.clear],
                center: .init(x: 0.5, y: 0.18),
                startRadius: 0,
                endRadius: 320
            )
            .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    VStack(spacing: 16) {
                        HStack {
                            Button {
                                Haptics.tap()
                                dismiss()
                            } label: {
                                Image(systemName: "xmark")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(Color.seilMuted)
                                    .frame(width: 38, height: 38)
                                    .background(Color.seilCard)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle()
                                            .stroke(Color.seilBorder, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)

                            Spacer()
                        }
                        .padding(.top, 18)

                        VStack(spacing: 8) {
                            ZStack {
                                Circle()
                                    .fill(Color.seilAccent.opacity(0.12))
                                    .frame(width: 62, height: 62)

                                Image(systemName: "seal.fill")
                                    .font(.system(size: 27, weight: .black))
                                    .foregroundColor(Color.seilAccent)
                            }

                            Text(SeillStrings.auth.welcomeBack)
                                .font(SeillFont.display(26))
                                .foregroundColor(Color.seilText)

                            Text(SeillStrings.auth.signInSubtitle)
                                .font(SeillFont.body(14))
                                .foregroundColor(Color.seilMuted)
                        }
                    }
                    .padding(.horizontal, 24)

                    VStack(spacing: 18) {
                        TestCredentialsBanner()

                        SeillTextField(
                            label: "Correo electrónico",
                            placeholder: "tu@correo.com",
                            icon: "envelope",
                            text: $email,
                            keyboardType: .emailAddress
                        )

                        SeillTextField(
                            label: "Contraseña",
                            placeholder: "••••••••",
                            icon: "lock",
                            text: $password,
                            isSecure: !showPass,
                            trailingIcon: showPass ? "eye.slash" : "eye",
                            trailingAction: { showPass.toggle() }
                        )

                        HStack {
                            Spacer()
                            Button("¿Olvidaste tu contraseña?") {
                                Haptics.tap()
                                showForgot = true
                            }
                                .font(SeillFont.caption(12))
                                .foregroundColor(Color.seilAccent)
                        }

                        // HIGH: Error con animación de entrada (antes aparecía sin transición)
                        if let msg = errorMsg {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.red)

                                Text(msg)
                                    .font(SeillFont.body(13))
                                    .foregroundColor(.red)
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.red.opacity(0.08))
                            .clipShape(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                            )
                            .transition(
                                .asymmetric(
                                    insertion: .opacity.combined(with: .move(edge: .top)),
                                    removal:   .opacity
                                )
                            )
                        }

                        SeillButton(
                            title: "Iniciar sesión",
                            icon: "arrow.right",
                            isLoading: loading
                        ) {
                            Task {
                                await doLogin()
                            }
                        }
                        .disabled(oauthLoading != nil)

                        AuthDivider()

                        VStack(spacing: 10) {
                            // HIGH: GoogleSignInButton con isLoading propio
                            GoogleSignInButton(
                                isLoading: oauthLoading == .google
                            ) {
                                Task { await googleLogin() }
                            }
                            .disabled(loading || oauthLoading != nil)

                            // HIGH: AppleSignInButton con isLoading propio
                            AppleSignInButton(
                                isLoading: oauthLoading == .apple
                            ) {
                                oauthLoading = .apple
                                appleCoordinator.startSignIn()
                                // Apple devuelve el resultado vía callback asíncrono;
                                // el coordinator limpia el estado al terminar.
                            }
                            .disabled(loading || oauthLoading != nil)
                        }

                        HStack {
                            Spacer()

                            AuthBottomLink(
                                prefix: "¿No tienes cuenta? ",
                                action: "Regístrate gratis",
                                destination: AnyView(RegisterView(role: "cliente"))
                            )

                            Spacer()
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 30)
                    .padding(.bottom, 34)
                    .offset(y: appear ? 0 : 26)
                    .opacity(appear ? 1 : 0)
                    .animation(
                        SeillAnimation.chrome.delay(0.08),
                        value: appear
                    )
                }
            }
        }
        .sheet(isPresented: $showForgot) {
            ForgotPasswordView()
                .presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilSurface)
        }
        .navigationBarHidden(true)
        .onAppear {
            appear = true
        }
        // El coordinador publica triggerID: Int (Equatable) — no isFinished: Bool
        // Usamos la firma nueva onChange(of:) { old, new in } (iOS 17+)
        .onChange(of: appleCoordinator.triggerID) { _, _ in
            oauthLoading = nil
            if let error = appleCoordinator.lastError {
                withAnimation { errorMsg = error.localizedDescription }
                Haptics.error()
            }
            // Si lastCredential != nil el AuthManager ya manejó el login
            // vía el coordinator — no hace falta acción adicional aquí
        }
    }

    // MARK: - Email login

    private func doLogin() async {
        guard validate() else {
            Haptics.error()
            return
        }

        loading = true
        withAnimation { errorMsg = nil }

        do {
            try await auth.login(email: email, password: password)
            Haptics.success()
        } catch {
            withAnimation {
                errorMsg = error.localizedDescription
            }
            Haptics.error()
        }

        loading = false
    }

    // MARK: - Google Sign-In
    // CRÍTICO: antes llamaba auth.register() con un sleep falso.
    // Google Sign-In requiere GoogleSignIn SDK + configuración de OAuth.
    // Hasta que esté integrado, mostramos un error honesto en lugar de
    // registrar al usuario con datos vacíos/incorrectos.

    private func googleLogin() async {
        oauthLoading = .google
        withAnimation { errorMsg = nil }

        // TODO: integrar GoogleSignIn SDK cuando esté configurado el OAuth client ID.
        // Ejemplo de integración real:
        //   let result = try await GIDSignIn.sharedInstance.signIn(...)
        //   let idToken = result.user.idToken?.tokenString
        //   try await auth.loginWithGoogle(idToken: idToken)

        // Simulamos la latencia de red para que el loading state sea visible
        try? await Task.sleep(nanoseconds: 600_000_000)

        withAnimation {
            errorMsg = "Google Sign-In no está disponible aún. Usa correo y contraseña."
            oauthLoading = nil
        }
        Haptics.error()
    }

    // MARK: - Validación
    // MEDIO: antes solo chequeaba .isEmpty — ahora valida formato RFC básico

    private func validate() -> Bool {
        let trimmed = email.trimmingCharacters(in: .whitespacesAndNewlines)

        if trimmed.isEmpty {
            withAnimation { errorMsg = "Ingresa tu correo" }
            return false
        }

        // Regex básico RFC 5321: local@domain.tld
        let emailRegex = #"^[A-Z0-9a-z._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"#
        guard trimmed.range(of: emailRegex, options: .regularExpression) != nil else {
            withAnimation { errorMsg = "El correo no tiene un formato válido" }
            return false
        }

        if password.count < 8 {
            withAnimation { errorMsg = "Mínimo 8 caracteres" }
            return false
        }

        return true
    }
}
