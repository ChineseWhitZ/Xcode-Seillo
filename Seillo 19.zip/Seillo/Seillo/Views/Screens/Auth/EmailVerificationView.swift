import SwiftUI

// ─── EmailVerificationView ────────────────────────────────────────────────────
//
// Pantalla post-registro que pide al usuario verificar su email.
// Muestra countdown para reenvío y permite cambiar correo.
//
// Ruta: Seillo/Views/Screens/Auth/EmailVerificationView.swift
// ─────────────────────────────────────────────────────────────────────────────

struct EmailVerificationView: View {
    let email: String
    let isNegocio: Bool
    let onVerified: () -> Void
    let onChangeEmail: () -> Void

    @State private var countdown     = 60
    @State private var canResend     = false
    @State private var resending     = false
    @State private var timer: Timer? = nil
    @State private var appear        = false

    // Icono animado
    @State private var envelopeScale: CGFloat = 0.5
    @State private var envelopeOffset: CGFloat = 20

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                // ── Icono animado ─────────────────────────────────
                ZStack {
                    Circle()
                        .fill(Color.seilAccent.opacity(0.08))
                        .frame(width: 100, height: 100)
                    Circle()
                        .fill(Color.seilAccent.opacity(0.05))
                        .frame(width: 130, height: 130)
                    Image(systemName: "envelope.badge.fill")
                        .font(.system(size: 44, weight: .semibold))
                        .foregroundColor(.seilAccent)
                        .scaleEffect(envelopeScale)
                        .offset(y: envelopeOffset)
                }
                .padding(.bottom, 32)

                // ── Textos ────────────────────────────────────────
                Text("Verifica tu correo")
                    .font(SeillFont.display(24))
                    .foregroundColor(.seilText)
                    .padding(.bottom, 8)

                Text("Enviamos un enlace de verificación a")
                    .font(SeillFont.body(14))
                    .foregroundColor(.seilMuted2)

                Text(email)
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilAccent)
                    .padding(.top, 4)
                    .padding(.bottom, 24)

                Text("Revisa tu bandeja de entrada (y spam) y toca el enlace para activar tu cuenta.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 40)

                Spacer()

                // ── Botones ───────────────────────────────────────
                VStack(spacing: 12) {
                    // Ya verifiqué
                    Button {
                        Haptics.success()
                        onVerified()
                    } label: {
                        Text("Ya verifiqué mi correo")
                            .font(SeillFont.label(15))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color.seilAccent)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .shadow(color: Color.seilAccent.opacity(0.28), radius: 12, y: 6)
                    }
                    .buttonStyle(.plain)

                    // Reenviar
                    Button {
                        guard canResend else { return }
                        Haptics.tap()
                        resendEmail()
                    } label: {
                        HStack(spacing: 6) {
                            if resending {
                                ProgressView().tint(.seilAccent).scaleEffect(0.7)
                            }
                            Text(canResend ? "Reenviar correo" : "Reenviar en \(countdown)s")
                                .font(SeillFont.label(13))
                                .foregroundColor(canResend ? .seilAccent : .seilMuted)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(!canResend || resending)

                    // Cambiar correo
                    Button {
                        Haptics.tap()
                        onChangeEmail()
                    } label: {
                        Text("Cambiar correo")
                            .font(SeillFont.caption(12))
                            .foregroundColor(.seilMuted)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
            }
            .opacity(appear ? 1 : 0)
        }
        .onAppear {
            startCountdown()
            withAnimation(.easeOut(duration: 0.6)) {
                appear = true
                envelopeScale = 1
                envelopeOffset = 0
            }
        }
        .onDisappear { timer?.invalidate() }
    }

    // MARK: - Countdown

    private func startCountdown() {
        countdown = 60
        canResend = false
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if countdown > 1 {
                countdown -= 1
            } else {
                canResend = true
                timer?.invalidate()
            }
        }
    }

    private func resendEmail() {
        resending = true
        // TODO(backend): POST /api/auth/resend-verification
        Task {
            try? await Task.sleep(nanoseconds: 800_000_000)
            resending = false
            startCountdown()
        }
    }
}
