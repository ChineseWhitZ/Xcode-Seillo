import SwiftUI

// F-6 fix: ForgotPasswordView usa NavigationStack internamente.
// ResetPasswordView se empuja via navigationDestination en lugar de
// un segundo .sheet (sheet-dentro-sheet es inestable en iOS).
// LoginView presenta este sheet con .presentationDetents([.large]).

struct ForgotPasswordView: View {
    @Environment(\.dismiss) var dismiss

    @State private var email:          String  = ""
    @State private var loading:        Bool    = false
    @State private var errorMsg:       String? = nil
    @State private var appear:         Bool    = false
    @State private var navigateToReset = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                RadialGradient(
                    colors: [Color.seilAccent.opacity(0.07), Color.clear],
                    center: .init(x: 0.5, y: 0.15),
                    startRadius: 0,
                    endRadius: 300
                )
                .ignoresSafeArea()

                VStack(spacing: 0) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.seilBorder)
                        .frame(width: 36, height: 4)
                        .padding(.top, 12)
                        .padding(.bottom, 24)

                    formContent

                    Spacer()
                }
                .padding(.horizontal, 24)
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateToReset) {
                ResetPasswordView(email: email)
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome.delay(0.06)) {
                appear = true
            }
        }
    }

    // MARK: - Form

    private var formContent: some View {
        VStack(spacing: 0) {
            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.12))
                    .frame(width: 62, height: 62)

                Image(systemName: "lock.rotation")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundColor(.seilAccent)
            }
            .padding(.bottom, 16)

            Text("Recuperar contraseña")
                .font(SeillFont.display(22))
                .foregroundColor(.seilText)
                .padding(.bottom, 8)

            Text("Ingresa tu correo y te enviaremos instrucciones para restablecer tu contraseña.")
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
                .padding(.bottom, 28)

            SeillTextField(
                label: "Correo electrónico",
                placeholder: "tu@correo.com",
                icon: "envelope",
                text: $email,
                keyboardType: .emailAddress
            )
            .padding(.bottom, 12)

            if let msg = errorMsg {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.red)
                    Text(msg)
                        .font(SeillFont.body(13))
                        .foregroundColor(.red)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.red.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .padding(.bottom, 12)
            }

            SeillButton(
                title: "Enviar instrucciones",
                icon: "paperplane.fill",
                isLoading: loading
            ) {
                Task { await submit() }
            }
            .padding(.bottom, 16)

            Button("Cancelar") {
                Haptics.tap()
                dismiss()
            }
            .font(SeillFont.body(14))
            .foregroundColor(.seilMuted)
        }
        .offset(y: appear ? 0 : 22)
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Logic

    private func submit() async {
        let trimmed = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            errorMsg = "Ingresa tu correo"
            Haptics.error()
            return
        }
        guard trimmed.contains("@") else {
            errorMsg = "Correo no válido"
            Haptics.error()
            return
        }

        loading  = true
        errorMsg = nil

        try? await Task.sleep(nanoseconds: 1_100_000_000)

        loading = false
        Haptics.success()
        navigateToReset = true
    }
}
