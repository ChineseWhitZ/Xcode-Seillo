import SwiftUI

// ─── CreateProgramView ────────────────────────────────────────────────────────
// Wizard de 3 pasos para que el negocio cree un programa de fidelidad.
// Paso 1 — Configuración: nombre del programa, texto del premio, sellos
// Paso 2 — Diseño: gradiente de fondo, color del sello, ícono
// Paso 3 — Vista previa y publicar
// Acceso: BizTabDashboardView → botón "Nuevo programa"
// ─────────────────────────────────────────────────────────────────────────────

// ── Modelos de diseño ─────────────────────────────────────────────────────────

private struct GradientPreset: Identifiable {
    let id    = UUID()
    let label: String
    let colors: [Color]
}

private struct StampColorPreset: Identifiable {
    let id    = UUID()
    let color: Color
    let label: String
}

private struct IconPreset: Identifiable {
    let id     = UUID()
    let icon:  String
    let label: String
}

// Colores de gradiente de tarjeta — diseño específico, no tokenizable con tokens globales
private let gradientPresets: [GradientPreset] = [
    .init(label: "Café",    colors: [Color(hex: "#1A0800"), Color(hex: "#6B2E00")]),
    .init(label: "Océano",  colors: [Color(hex: "#04101A"), Color(hex: "#0A3D6B")]),
    .init(label: "Bosque",  colors: [Color(hex: "#041008"), Color(hex: "#0F4A1E")]),
    .init(label: "Noche",   colors: [Color(hex: "#0D0616"), Color(hex: "#2E1056")]),
    .init(label: "Carbón",  colors: [Color(hex: "#0A0A0A"), Color(hex: "#2A2A2A")]),
    .init(label: "Rojo",    colors: [Color(hex: "#1A0000"), Color(hex: "#6B0000")]),
    // ── Nuevos para categorías peruanas ────────────────────────────────────
    .init(label: "Brasa",   colors: [Color(hex: "#1A0400"), Color(hex: "#6B1C00")]),  // pollería
    .init(label: "Mar",     colors: [Color(hex: "#011525"), Color(hex: "#033F70")]),  // cevichería
    .init(label: "Trigo",   colors: [Color(hex: "#1A1000"), Color(hex: "#6B4800")]),  // panadería/sanguchería
]

/// Sugiere ícono y gradiente predeterminados según la categoría del negocio.
/// Reduce la fricción al crear un programa — el negocio ya ve seleccionado
/// lo más coherente con su tipo de local.
private func defaultDesignFor(categoriaId: String) -> (iconIndex: Int, gradientIndex: Int) {
    switch categoriaId {
    case "cafe":        return (0, 0)   // café + café
    case "barberia":    return (9, 3)   // scissors + noche
    case "jugueria":    return (4, 2)   // drop + bosque
    case "restaurante": return (8, 1)   // fork.knife + océano
    case "gym":         return (11, 4)  // dumbbell + carbón
    case "pasteleria":  return (10, 0)  // cake + café
    case "tienda":      return (12, 4)  // basket + carbón
    case "spa":         return (13, 3)  // sparkles + noche
    default:            return (18, 1)  // star + océano (genérico)
    }
}

private let stampColorPresets: [StampColorPreset] = [
    .init(color: .seilGold, label: "Dorado"),
    .init(color: .seilAccent, label: "Naranja"),
    .init(color: .seilBlue, label: "Azul"),
    .init(color: .seilGreen, label: "Verde"),
    .init(color: .seilPurple, label: "Violeta"),
]

private let iconPresets: [IconPreset] = [
    // ── Lo más peruano ────────────────────────────────────────────────────
    .init(icon: "cup.and.saucer.fill",    label: "Café"),
    .init(icon: "flame.fill",             label: "Pollería"),
    .init(icon: "fish.fill",              label: "Cevichería"),
    .init(icon: "bag.fill",               label: "Sanguchería"),
    .init(icon: "drop.fill",              label: "Jugos"),
    .init(icon: "fork.knife.circle.fill", label: "Chifa"),
    .init(icon: "leaf.fill",              label: "Panadería"),
    .init(icon: "snowflake",              label: "Heladería"),
    // ── Otros ─────────────────────────────────────────────────────────────
    .init(icon: "fork.knife",             label: "Restaurante"),
    .init(icon: "scissors",               label: "Barbería"),
    .init(icon: "birthday.cake.fill",     label: "Pastelería"),
    .init(icon: "dumbbell.fill",          label: "Gym"),
    .init(icon: "basket.fill",            label: "Tienda"),
    .init(icon: "sparkles",               label: "Spa"),
    .init(icon: "book.fill",              label: "Academia"),
    .init(icon: "pawprint.fill",          label: "Veterinaria"),
    .init(icon: "wineglass.fill",         label: "Bar"),
    .init(icon: "star.fill",              label: "General"),
    .init(icon: "gift.fill",              label: "Premio"),
]

// ── Vista principal ───────────────────────────────────────────────────────────

struct CreateProgramView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    private let service: NegocioServiceProtocol = APINegocioService()
    @State private var saving    = false
    @State private var saveError: String? = nil

    @State private var step = 0
    private let totalSteps = 3

    // Paso 1
    @State private var programaNombre = ""
    @State private var premioTexto    = ""
    @State private var sellosCount    = 10
    private let sellosOptions = [5, 7, 10, 12, 15]

    // Paso 2 — se inicializan en .onAppear con la categoría del negocio
    @State private var selectedGradient:   Int = 0
    @State private var selectedStampColor: Int = 0
    @State private var selectedIcon:       Int = 0
    @State private var defaultsApplied:    Bool = false

    // Animación
    @State private var appear = false

    private var step0Valid: Bool {
        !programaNombre.trimmingCharacters(in: .whitespaces).isEmpty &&
        !premioTexto.trimmingCharacters(in: .whitespaces).isEmpty
    }
    private var canProceed: Bool {
        step == 0 ? step0Valid : true
    }

    private var currentGradient: [Color] { gradientPresets[selectedGradient].colors }
    private var currentStampColor: Color { stampColorPresets[selectedStampColor].color }
    private var currentIcon: String      { iconPresets[selectedIcon].icon }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilAccent.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.12),
                startRadius: 0,
                endRadius: 340
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    Group {
                        switch step {
                        case 0: paso1
                        case 1: paso2
                        default: paso3
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                    .padding(.bottom, 140)
                    .transition(
                        .asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal:   .move(edge: .leading).combined(with: .opacity)
                        )
                    )
                    .animation(SeillAnimation.screenTransition, value: step)
                }

                Spacer()
            }

            // CTA flotante
            VStack {
                Spacer()
                ctaButton
                    .padding(.horizontal, 24)
                    .padding(.bottom, 36)
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
            // Aplicar sugerencia de diseño una sola vez al abrir
            if !defaultsApplied {
                let d = defaultDesignFor(categoriaId: bizStore.profile.categoriaId)
                selectedIcon     = d.iconIndex
                selectedGradient = d.gradientIndex
                defaultsApplied  = true
            }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 14) {
            HStack {
                Button {
                    Haptics.tap()
                    if step > 0 {
                        withAnimation(SeillAnimation.screenTransition) { step -= 1 }
                    } else {
                        dismiss()
                    }
                } label: {
                    Image(systemName: step > 0 ? "chevron.left" : "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()

                // Pills
                HStack(spacing: 6) {
                    ForEach(0..<totalSteps, id: \.self) { i in
                        Capsule()
                            .fill(i < step ? Color.seilAccent : i == step ? Color.seilAccent.opacity(0.85) : Color.white.opacity(0.12))
                            .frame(width: i == step ? 28 : 8, height: 8)
                            .animation(SeillAnimation.chrome, value: step)
                    }
                }

                Spacer()

                Text("\(step + 1)/\(totalSteps)")
                    .font(SeillFont.caption(12))
                    .foregroundColor(.seilMuted)
                    .frame(width: 36)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)

            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Paso 1: Configuración

    private var paso1: some View {
        VStack(alignment: .leading, spacing: 24) {
            stepHeader(
                icon: "star.fill",
                color: .seilAccent,
                title: "Configura tu\nprograma",
                subtitle: "Define el nombre, el premio y cuántos sellos necesita el cliente."
            )

            VStack(alignment: .leading, spacing: 10) {
                fieldLabel("NOMBRE DEL PROGRAMA")
                SeillTextField(
                    label: "", placeholder: "Ej. Tarjeta Café Inti",
                    icon: "textformat", text: $programaNombre
                )
            }

            VStack(alignment: .leading, spacing: 10) {
                fieldLabel("DESCRIPCIÓN DEL PREMIO")
                SeillTextField(
                    label: "", placeholder: "Ej. Café a elección gratis",
                    icon: "gift.fill", text: $premioTexto
                )
            }

            VStack(alignment: .leading, spacing: 12) {
                fieldLabel("SELLOS PARA EL PREMIO")

                HStack(spacing: 8) {
                    ForEach(sellosOptions, id: \.self) { n in
                        Button {
                            Haptics.tap()
                            sellosCount = n
                        } label: {
                            Text("\(n)")
                                .font(.system(size: 15, weight: .heavy))
                                .foregroundColor(sellosCount == n ? .white : .seilMuted2)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(
                                    sellosCount == n
                                    ? LinearGradient(colors: [Color.seilAccent, Color.seilAccent2], startPoint: .topLeading, endPoint: .bottomTrailing)
                                    : LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .topLeading, endPoint: .bottomTrailing)
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(sellosCount == n ? Color.clear : Color.seilBorder, lineWidth: 1)
                                )
                                .shadow(color: sellosCount == n ? Color.seilAccent.opacity(0.35) : .clear, radius: 8, y: 3)
                        }
                        .buttonStyle(.plain)
                        .animation(SeillAnimation.chrome, value: sellosCount)
                    }
                }
            }
        }
        .padding(.top, 24)
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    // MARK: - Paso 2: Diseño

    private var paso2: some View {
        VStack(alignment: .leading, spacing: 24) {
            stepHeader(
                icon: "paintbrush.fill",
                color: .seilPurple,
                title: "Diseña tu\ntarjeta",
                subtitle: "Elige el gradiente, el color del sello y el ícono."
            )

            // Mini preview en tiempo real
            miniCardPreview

            // Gradiente
            VStack(alignment: .leading, spacing: 12) {
                fieldLabel("FONDO")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(Array(gradientPresets.enumerated()), id: \.offset) { i, preset in
                            Button {
                                Haptics.tap()
                                selectedGradient = i
                            } label: {
                                VStack(spacing: 6) {
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(LinearGradient(colors: preset.colors, startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 44, height: 44)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(selectedGradient == i ? Color.white.opacity(0.80) : Color.clear, lineWidth: 2)
                                        )
                                        .shadow(color: selectedGradient == i ? .white.opacity(0.20) : .clear, radius: 6)

                                    Text(preset.label)
                                        .font(.system(size: 9, weight: selectedGradient == i ? .bold : .regular))
                                        .foregroundColor(selectedGradient == i ? .seilText : .seilMuted)
                                }
                            }
                            .buttonStyle(.plain)
                            .animation(SeillAnimation.chrome, value: selectedGradient)
                        }
                    }
                }
            }

            // Color de sello
            VStack(alignment: .leading, spacing: 12) {
                fieldLabel("COLOR DEL SELLO")
                HStack(spacing: 12) {
                    ForEach(Array(stampColorPresets.enumerated()), id: \.offset) { i, preset in
                        Button {
                            Haptics.tap()
                            selectedStampColor = i
                        } label: {
                            Circle()
                                .fill(preset.color)
                                .frame(width: 36, height: 36)
                                .overlay(
                                    Circle()
                                        .stroke(Color.white.opacity(selectedStampColor == i ? 0.90 : 0), lineWidth: 2.5)
                                )
                                .shadow(color: selectedStampColor == i ? preset.color.opacity(0.55) : .clear, radius: 8)
                        }
                        .buttonStyle(.plain)
                        .animation(SeillAnimation.chrome, value: selectedStampColor)
                    }
                }
            }

            // Ícono
            VStack(alignment: .leading, spacing: 12) {
                fieldLabel("ÍCONO")
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 10) {
                    ForEach(Array(iconPresets.enumerated()), id: \.offset) { i, preset in
                        Button {
                            Haptics.tap()
                            selectedIcon = i
                        } label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(selectedIcon == i ? currentStampColor.opacity(0.18) : Color.seilCard)
                                    .frame(width: 44, height: 44)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(selectedIcon == i ? currentStampColor.opacity(0.55) : Color.seilBorder, lineWidth: 1)
                                    )

                                Image(systemName: preset.icon)
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(selectedIcon == i ? currentStampColor : .seilMuted2)
                            }
                        }
                        .buttonStyle(.plain)
                        .animation(SeillAnimation.chrome, value: selectedIcon)
                    }
                }
            }
        }
        .padding(.top, 24)
    }

    // Mini preview de tarjeta
    private var miniCardPreview: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: currentIcon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(currentStampColor)

                Text(programaNombre.isEmpty ? "Nombre del programa" : programaNombre)
                    .font(SeillFont.headline(13))
                    .foregroundColor(.seilText)
                    .lineLimit(1)

                Spacer()
            }

            HStack(spacing: 5) {
                ForEach(0..<min(sellosCount, 10), id: \.self) { i in
                    Circle()
                        .fill(i < 3 ? currentStampColor.opacity(0.90) : currentStampColor.opacity(0.22))
                        .frame(width: 20, height: 20)
                        .overlay(Circle().stroke(currentStampColor.opacity(0.40), lineWidth: 1))
                }
                if sellosCount > 10 {
                    Text("+\(sellosCount - 10)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(currentStampColor)
                }
            }

            HStack(spacing: 5) {
                Image(systemName: "gift.fill")
                    .font(.system(size: 10))
                    .foregroundColor(currentStampColor)
                Text(premioTexto.isEmpty ? "Tu premio" : premioTexto)
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted2)
                    .lineLimit(1)
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: currentGradient,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.30), radius: 14, y: 6)
        .animation(.easeInOut(duration: 0.25), value: selectedGradient)
        .animation(.easeInOut(duration: 0.25), value: selectedStampColor)
        .animation(.easeInOut(duration: 0.25), value: selectedIcon)
    }

    // MARK: - Paso 3: Vista previa y publicar

    private var paso3: some View {
        VStack(spacing: 24) {
            stepHeader(
                icon: "checkmark.circle.fill",
                color: .seilGreen,
                title: "Vista previa y\npublicar",
                subtitle: "Así verán tus clientes la tarjeta. Cuando estés listo, publícala."
            )

            // Card preview grande
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(currentStampColor.opacity(0.20))
                            .frame(width: 36, height: 36)
                        Image(systemName: currentIcon)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(currentStampColor)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text(programaNombre.isEmpty ? "Mi programa" : programaNombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)
                        Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                            .font(SeillFont.body(11))
                            .foregroundColor(.seilMuted2)
                    }

                    Spacer()

                    Text("\(sellosCount) sellos")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.seilMuted2)
                }

                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: min(sellosCount, 10)), spacing: 8) {
                    ForEach(0..<min(sellosCount, 10), id: \.self) { i in
                        Circle()
                            .fill(i < 3 ? currentStampColor.opacity(0.90) : currentStampColor.opacity(0.18))
                            .frame(height: 28)
                            .overlay(Circle().stroke(currentStampColor.opacity(0.40), lineWidth: 1))
                    }
                }

                HStack(spacing: 6) {
                    Image(systemName: "gift.fill")
                        .font(.system(size: 12))
                        .foregroundColor(currentStampColor)
                    Text(premioTexto.isEmpty ? "Premio al completar" : premioTexto)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                }
            }
            .padding(18)
            .background(
                LinearGradient(
                    colors: currentGradient,
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.30), radius: 16, y: 8)

            // Resumen
            VStack(spacing: 0) {
                resumenRow(icon: "star.fill",        color: .seilAccent,             label: "Programa",  value: programaNombre.isEmpty ? "—" : programaNombre)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "gift.fill",        color: .seilBlue,   label: "Premio",    value: premioTexto.isEmpty ? "—" : premioTexto)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                resumenRow(icon: "seal.fill",        color: .seilGreen,              label: "Sellos",    value: "\(sellosCount)")
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
        }
        .padding(.top, 24)
    }

    // MARK: - CTA flotante

    private var ctaButton: some View {
        Group {
            if step < totalSteps - 1 {
                Button {
                    Haptics.tap()
                    withAnimation(SeillAnimation.screenTransition) { step += 1 }
                } label: {
                    HStack(spacing: 8) {
                        Text(step == 0 ? "Siguiente: Diseño" : "Siguiente: Vista previa")
                            .font(SeillFont.headline(15))
                        Image(systemName: "arrow.right")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .foregroundColor(canProceed ? .white : .seilMuted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        canProceed
                        ? LinearGradient(colors: [Color.seilAccent, Color.seilAccent2], startPoint: .leading, endPoint: .trailing)
                        : LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .leading, endPoint: .trailing)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: canProceed ? Color.seilAccent.opacity(0.38) : .clear, radius: 14, y: 4)
                    .animation(.easeInOut(duration: 0.22), value: canProceed)
                }
                .buttonStyle(.plain)
                .disabled(!canProceed)
            } else {
                Button {
                    Haptics.success()
                    guard !saving else { return }
                    saving = true
                    saveError = nil
                    Task {
                        let result = await service.crearPrograma(
                            nombre:     programaNombre.trimmingCharacters(in: .whitespaces),
                            sellosMeta: sellosCount,
                            premio:     premioTexto.trimmingCharacters(in: .whitespaces)
                        )
                        await MainActor.run {
                            saving = false
                            switch result {
                            case .success:
                                dismiss()
                            case .failure(let error):
                                withAnimation { saveError = "No se pudo publicar: \(error.localizedDescription)" }
                            }
                        }
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                        Text(saving ? "Publicando..." : "Publicar programa")
                            .font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(colors: [Color.seilGreen, Color.seilGreen.opacity(0.80)], startPoint: .leading, endPoint: .trailing)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: Color.seilGreen.opacity(0.40), radius: 14, y: 4)
                    .opacity(saving ? 0.7 : 1)
                }
                .buttonStyle(.plain)
                .disabled(saving)

                if let err = saveError {
                    Text(err)
                        .font(SeillFont.caption(12))
                        .foregroundColor(.seilRose)
                        .multilineTextAlignment(.center)
                        .transition(.opacity)
                }
            }
        }
    }

    // MARK: - Helpers

    private func stepHeader(icon: String, color: Color, title: String, subtitle: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(color.opacity(0.14))
                    .frame(width: 52, height: 52)
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(color.opacity(0.24), lineWidth: 1))
                Image(systemName: icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(color)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(SeillFont.display(22))
                    .foregroundColor(.seilText)
                    .lineSpacing(2)
                Text(subtitle)
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .lineSpacing(3)
            }
        }
    }

    private func fieldLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.seilMuted)
            .tracking(1.2)
    }

    private func resumenRow(icon: String, color: Color, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8).fill(color.opacity(0.12)).frame(width: 30, height: 30)
                Image(systemName: icon).font(.system(size: 13)).foregroundColor(color)
            }
            Text(label).font(SeillFont.body(13)).foregroundColor(.seilMuted2)
            Spacer()
            Text(value).font(SeillFont.label(13)).foregroundColor(.seilText).lineLimit(1)
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
    }
}
