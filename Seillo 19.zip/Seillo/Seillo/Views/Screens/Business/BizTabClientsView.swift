import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// BizTabClientsView.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - BizClient

struct BizClient: Identifiable {
    let id                    : String
    let nombre                : String
    let initial               : String
    let color                 : Color
    let filledStamps          : Int
    let totalStamps           : Int
    let lastVisit             : String
    let totalCanjes           : Int
    let diasDesdePrimeraVisita: Int?
    let diasDesdeUltimaVisita : Int?

    var isActiveToday : Bool { diasDesdeUltimaVisita == 0 }
    var isNearPrize   : Bool { (totalStamps - filledStamps) <= 2 && !isComplete }
    var isComplete    : Bool { filledStamps >= totalStamps }
    var progress      : Double { totalStamps > 0 ? Double(filledStamps) / Double(totalStamps) : 0 }
}

// MARK: - ClientFilter

private enum ClientFilter: CaseIterable {
    case all, activeToday, nearPrize
    case nuevo, enRiesgo, inactivo, dormido, premioPendiente

    var chipLabel: String {
        switch self {
        case .all:             return "Todos"
        case .activeToday:     return "Activos hoy"
        case .nearPrize:       return "Cerca del premio"
        case .nuevo:           return ClientSegment.nuevo.chipLabel
        case .enRiesgo:        return ClientSegment.enRiesgo.chipLabel
        case .inactivo:        return ClientSegment.inactivo.chipLabel
        case .dormido:         return ClientSegment.dormido.chipLabel
        case .premioPendiente: return ClientSegment.premioPendiente.chipLabel
        }
    }

    var accentColor: Color {
        switch self {
        case .nearPrize, .premioPendiente: return .seilGold
        case .nuevo:                       return .seilGreen
        case .enRiesgo:                    return .seilGold
        case .inactivo:                    return .seilRose
        case .dormido:                     return .seilDanger
        default:                           return .seilAccent
        }
    }

    func matches(_ client: BizClient) -> Bool {
        switch self {
        case .all:             return true
        case .activeToday:     return client.isActiveToday
        case .nearPrize:       return client.isNearPrize
        case .nuevo:           return client.segment == .nuevo
        case .enRiesgo:        return client.segment == .enRiesgo
        case .inactivo:        return client.segment == .inactivo
        case .dormido:         return client.segment == .dormido
        case .premioPendiente: return client.segment == .premioPendiente
        }
    }
}

// MARK: - Helpers de fecha

private func diasDesde(_ isoString: String?) -> Int? {
    guard let s = isoString else { return nil }
    let fmts = [
        "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss",
    ]
    for fmt in fmts {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = fmt
        if let date = f.date(from: s) {
            return Calendar.current.dateComponents([.day], from: date, to: Date()).day
        }
    }
    return nil
}

private func formatVisita(_ isoString: String?) -> String {
    guard let dias = diasDesde(isoString) else { return "Sin visitas" }
    switch dias {
    case 0:        return "Hoy"
    case 1:        return "Ayer"
    case 2...6:    return "Hace \(dias) días"
    case 7...13:   return "Hace 1 semana"
    case 14...29:  return "Hace \(dias / 7) semanas"
    default:       return "Hace \(dias / 30) mes\(dias / 30 == 1 ? "" : "es")"
    }
}

private let clientColors: [Color] = [
    .seilPurple, .seilBlue, .seilAccent, .seilGreen,
    .seilGold, .seilRose, .seilBlue, .seilPurple,
]

// MARK: - BizTabClientsView

struct BizTabClientsView: View {

    var subscription: BusinessSubscription? = nil
    var onUpgrade: (() -> Void)? = nil

    @State private var clients        : [BizClient] = []
    @State private var loading        = true
    @State private var errorMsg       : String?      = nil
    @State private var query          = ""
    @State private var activeFilter   : ClientFilter = .all
    @State private var showSegments   = false
    @State private var appear         = false

    private let negocioService: NegocioServiceProtocol = APINegocioService()

    // MARK: - Carga de datos

    private func cargarClientes() async {
        loading  = true
        errorMsg = nil
        let result = await negocioService.getClientes()
        loading = false

        switch result {
        case .success(let data):
            // Construimos BizClient desde ClienteUnico + TarjetaCliente
            clients = data.clientes.enumerated().map { idx, c in
                // Buscar la tarjeta con más progreso de este cliente
                let tarjetasCliente = data.tarjetas.filter { $0.usuarioId == c.id }
                let mejorTarjeta    = tarjetasCliente.max(by: { $0.sellosActuales < $1.sellosActuales })

                // Premio listo si está en la lista de premios
                let tienePremio = data.premios.contains { $0.usuarioId == c.id }

                let diasUltima    = diasDesde(c.ultimaVisita)
                let diasPrimera   = diasDesde(c.primeraVisita)
                let inicial       = String(c.nombre.prefix(1)).uppercased()
                let color         = clientColors[idx % clientColors.count]

                return BizClient(
                    id:                     c.id,
                    nombre:                 c.nombre,
                    initial:                inicial,
                    color:                  color,
                    filledStamps:           tienePremio ? (mejorTarjeta?.sellosMeta ?? 10) : (mejorTarjeta?.sellosActuales ?? 0),
                    totalStamps:            mejorTarjeta?.sellosMeta ?? 10,
                    lastVisit:              formatVisita(c.ultimaVisita),
                    totalCanjes:            c.totalCanjes,
                    diasDesdePrimeraVisita: diasPrimera,
                    diasDesdeUltimaVisita:  diasUltima
                )
            }

        case .failure(let error):
            errorMsg = error.localizedDescription
        }
    }

    // MARK: - Computed

    private var segmentCounts: [ClientSegment: Int] {
        clients.contarPorSegmento()
    }

    private func count(for filter: ClientFilter) -> Int {
        clients.filter { filter.matches($0) }.count
    }

    private var filtered: [BizClient] {
        clients.filter { client in
            let matchQuery = query.isEmpty || client.nombre.localizedCaseInsensitiveContains(query)
            return matchQuery && activeFilter.matches(client)
        }
    }

    // MARK: - Body

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                header
                    .padding(.horizontal, 22)
                    .padding(.top, 18)
                    .padding(.bottom, 14)

                if showSegments && !clients.isEmpty {
                    segmentBanner
                        .padding(.horizontal, 16)
                        .padding(.bottom, 12)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }

                searchBar
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)

                filterChips
                    .padding(.bottom, 12)

                if let sub = subscription, sub.cercaLimiteClientes {
                    clientLimitBanner(sub)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 10)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }

                // Error
                if let msg = errorMsg {
                    HStack(spacing: 10) {
                        Image(systemName: "wifi.slash")
                            .foregroundColor(.seilRose)
                        Text(msg)
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilRose)
                        Spacer()
                        Button {
                            Task { await cargarClientes() }
                        } label: {
                            Text("Reintentar")
                                .font(SeillFont.label(12))
                                .foregroundColor(.seilAccent)
                        }
                    }
                    .padding(12)
                    .background(Color.seilRose.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 16)
                    .padding(.bottom, 10)
                }

                // Contador
                if !loading {
                    HStack {
                        Text(filtered.isEmpty
                             ? "SIN RESULTADOS"
                             : "\(filtered.count) \(filtered.count == 1 ? "CLIENTE" : "CLIENTES")")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.seilMuted)
                            .tracking(1.3)
                        Spacer()
                    }
                    .padding(.horizontal, 22)
                    .padding(.bottom, 10)
                    .animation(.easeInOut(duration: 0.2), value: filtered.count)
                }

                // Lista / skeleton / empty
                if loading {
                    skeletonList
                } else if filtered.isEmpty {
                    emptyState
                } else {
                    ScrollView(showsIndicators: false) {
                        SeillContentBox {
                            LazyVStack(spacing: 8) {
                                ForEach(Array(filtered.enumerated()), id: \.element.id) { i, client in
                                    ClientCard(client: client)
                                        .opacity(appear ? 1 : 0)
                                        .offset(y: appear ? 0 : 16)
                                        .animation(.easeOut(duration: 0.30).delay(0.04 + Double(i) * 0.035), value: appear)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.bottom, SeillLayout.tabBarScrollReserve)
                        }
                    }
                }
            }
        }
        .animation(SeillAnimation.chrome, value: showSegments)
        .animation(SeillAnimation.chrome, value: errorMsg)
        .task { await cargarClientes() }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(alignment: .lastTextBaseline, spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Clientes")
                    .font(.system(size: 26, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                if loading {
                    Text("Cargando...")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                } else {
                    Text("\(clients.count) clientes registrados")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                }
            }

            Spacer()

            if !loading {
                Text("\(clients.count)")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundColor(.seilAccent)
                    .padding(.horizontal, 11).padding(.vertical, 6)
                    .background(Color.seilAccent.opacity(0.12))
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(Color.seilAccent.opacity(0.25), lineWidth: 1))
            }

            Button {
                Haptics.tap()
                withAnimation(SeillAnimation.chrome) { showSegments.toggle() }
            } label: {
                Image(systemName: showSegments ? "chart.bar.fill" : "chart.bar")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(showSegments ? .seilAccent : .seilMuted2)
                    .frame(width: 36, height: 36)
                    .background(showSegments ? Color.seilAccent.opacity(0.12) : Color.seilCard)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    // MARK: - Segment banner

    private var segmentBanner: some View {
        let visibles = ClientSegment.allCases.filter { (segmentCounts[$0] ?? 0) > 0 }

        return VStack(alignment: .leading, spacing: 10) {
            Text("DISTRIBUCIÓN DE CLIENTES")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.3)

            VStack(spacing: 6) {
                ForEach(visibles, id: \.self) { seg in
                    let count = segmentCounts[seg] ?? 0
                    let pct   = clients.isEmpty ? 0 : Int(Double(count) / Double(clients.count) * 100)
                    HStack(spacing: 8) {
                        Circle().fill(seg.color).frame(width: 8, height: 8)
                        Text(seg.label).font(SeillFont.body(12)).foregroundColor(.seilText)
                        Spacer()
                        Text("\(count)").font(SeillFont.label(12)).foregroundColor(.seilText)
                        Text("\(pct)%").font(SeillFont.body(11)).foregroundColor(.seilMuted2).frame(width: 34, alignment: .trailing)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
    }

    // MARK: - Search bar

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").font(.system(size: 15, weight: .medium)).foregroundColor(.seilMuted)

            TextField("Buscar cliente...", text: $query)
                .font(SeillFont.body(13))
                .foregroundColor(.seilText)
                .autocorrectionDisabled()

            if !query.isEmpty {
                Button {
                    Haptics.tap()
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill").font(.system(size: 15)).foregroundColor(.seilMuted)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 11)
        .glassEffect(in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
        .animation(.easeOut(duration: 0.35).delay(0.06), value: appear)
    }

    // MARK: - Filter chips

    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(ClientFilter.allCases, id: \.chipLabel) { filter in
                    let n        = count(for: filter)
                    let isActive = activeFilter == filter
                    let accent   = filter.accentColor

                    Button {
                        Haptics.tap()
                        withAnimation(SeillAnimation.chrome) { activeFilter = filter }
                    } label: {
                        HStack(spacing: 6) {
                            Text(filter.chipLabel).font(SeillFont.label(12)).foregroundColor(isActive ? accent : .seilMuted2)
                            Text("\(n)")
                                .font(.system(size: 10, weight: .heavy, design: .rounded))
                                .foregroundColor(isActive ? accent : .seilMuted)
                                .padding(.horizontal, 5).padding(.vertical, 1)
                                .background(isActive ? accent.opacity(0.20) : Color.white.opacity(0.06))
                                .clipShape(Capsule())
                        }
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .glassEffect(in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(isActive ? accent.opacity(0.45) : Color.clear, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .animation(.easeOut(duration: 0.2), value: isActive)
                }
            }
            .padding(.horizontal, 16)
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
        .animation(.easeOut(duration: 0.35).delay(0.09), value: appear)
    }

    // MARK: - Skeleton

    private var skeletonList: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 8) {
                ForEach(0..<6, id: \.self) { _ in
                    HStack(spacing: 12) {
                        SkeletonCircle(size: 44)
                        VStack(alignment: .leading, spacing: 6) {
                            SkeletonRect(width: 130, height: 13)
                            SkeletonRect(width: 90, height: 10)
                        }
                        Spacer()
                        SkeletonRect(width: 36, height: 18)
                    }
                    .padding(14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, SeillLayout.tabBarScrollReserve)
        }
    }

    // MARK: - Client limit banner

    private func clientLimitBanner(_ sub: BusinessSubscription) -> some View {
        let esLleno    = sub.clientesActuales >= sub.plan.maxClientes
        let accentColor: Color = esLleno ? .seilDanger : .seilGold
        let pct        = Int(sub.porcentajeClientes * 100)

        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: esLleno ? "person.crop.circle.badge.xmark" : "exclamationmark.triangle.fill")
                    .font(.system(size: 13)).foregroundColor(accentColor)
                Text(esLleno ? "Límite de clientes alcanzado" : "Cerca del límite (\(pct)%)")
                    .font(SeillFont.label(12)).foregroundColor(accentColor)
                Spacer()
                Button {
                    Haptics.tap()
                    onUpgrade?()
                } label: {
                    Text("Upgrade")
                        .font(SeillFont.label(11)).foregroundColor(accentColor)
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background(accentColor.opacity(0.13)).clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(accentColor.opacity(0.15)).frame(height: 5)
                    Capsule().fill(accentColor).frame(width: geo.size.width * sub.porcentajeClientes, height: 5)
                }
            }
            .frame(height: 5)

            Text("\(sub.clientesActuales) de \(sub.plan.maxClientes) clientes · Plan \(sub.plan.nombre)")
                .font(SeillFont.caption(11)).foregroundColor(.seilMuted2)
        }
        .padding(12)
        .background(accentColor.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(accentColor.opacity(0.22), lineWidth: 1))
    }

    // MARK: - Empty state

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            ZStack {
                Circle().fill(Color.seilCard).frame(width: 64, height: 64)
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "person.2.slash").font(.system(size: 26)).foregroundColor(.seilMuted)
            }
            Text(emptyTitle).font(SeillFont.headline(14)).foregroundColor(.seilText)
            Text("Intenta con otro filtro o búsqueda").font(SeillFont.body(12)).foregroundColor(.seilMuted)
            Spacer()
        }
    }

    private var emptyTitle: String {
        if !query.isEmpty { return "Sin resultados para \"\(query)\"" }
        return switch activeFilter {
        case .activeToday:     "Ningún cliente visitó hoy"
        case .nearPrize:       "Ningún cliente está cerca del premio"
        case .nuevo:           "No hay clientes nuevos"
        case .enRiesgo:        "No hay clientes en riesgo"
        case .inactivo:        "No hay clientes inactivos"
        case .dormido:         "No hay clientes dormidos"
        case .premioPendiente: "Ningún cliente tiene premio listo"
        case .all:             clients.isEmpty ? "Aún no tienes clientes" : "Sin resultados"
        }
    }
}

// MARK: - ClientCard

private struct ClientCard: View {
    let client: BizClient

    var body: some View {
        HStack(spacing: 12) {

            // Avatar
            ZStack(alignment: .topTrailing) {
                Circle()
                    .fill(client.color.opacity(0.15))
                    .frame(width: 44, height: 44)
                    .overlay(
                        Text(client.initial)
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .foregroundColor(client.color)
                    )

                if client.isComplete {
                    Circle().fill(Color.seilGold).frame(width: 14, height: 14)
                        .overlay(Image(systemName: "star.fill").font(.system(size: 7)).foregroundColor(.white))
                        .overlay(Circle().stroke(Color.seilCard, lineWidth: 1.5))
                        .offset(x: 2, y: -2)
                } else if client.segment == .nuevo {
                    Circle().fill(Color.seilGreen).frame(width: 12, height: 12)
                        .overlay(Circle().stroke(Color.seilCard, lineWidth: 1.5))
                        .offset(x: 2, y: -2)
                } else if client.segment == .dormido {
                    Circle().fill(Color.seilDanger).frame(width: 12, height: 12)
                        .overlay(Circle().stroke(Color.seilCard, lineWidth: 1.5))
                        .offset(x: 2, y: -2)
                }
            }

            // Info
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 6) {
                    Text(client.nombre)
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)
                        .lineLimit(1)

                    if client.segment.showsBadge {
                        Text(client.segment.badgeLabel)
                            .font(.system(size: 8, weight: .heavy))
                            .foregroundColor(client.segment.color)
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(client.segment.color.opacity(0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    }

                    Spacer()
                }

                HStack(spacing: 3) {
                    ForEach(0..<min(client.totalStamps, 12), id: \.self) { i in
                        Circle()
                            .fill(i < client.filledStamps ? client.color : Color.seilBorder)
                            .frame(width: 7, height: 7)
                    }
                    if client.totalStamps > 12 {
                        Text("+\(client.totalStamps - 12)")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundColor(.seilMuted)
                    }
                }

                Text(client.lastVisit)
                    .font(SeillFont.caption(11))
                    .foregroundColor(.seilMuted)
            }

            Spacer(minLength: 4)

            // Contador
            VStack(alignment: .trailing, spacing: 2) {
                Text("\(client.filledStamps)/\(client.totalStamps)")
                    .font(.system(size: 14, weight: .heavy, design: .rounded))
                    .foregroundColor(client.isComplete ? .seilGold : client.color)

                Text(client.isComplete   ? "completo"
                     : client.isNearPrize ? "¡casi!"
                     : "sellos")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(
                        client.isComplete    ? .seilGold
                        : client.isNearPrize ? .seilAccent
                        : .seilMuted
                    )
            }
        }
        .padding(14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(segmentBorderColor, lineWidth: 1)
        )
    }

    private var segmentBorderColor: Color {
        switch client.segment {
        case .premioPendiente: return Color.seilGold.opacity(0.30)
        case .dormido:         return Color.seilDanger.opacity(0.25)
        case .enRiesgo:        return Color.seilGold.opacity(0.28)
        default:               return Color.seilBorder
        }
    }
}
