import SwiftUI

// ─── BizMenuSheet ─────────────────────────────────────────────────────────────
// Sheet completo para que el negocio gestione su menú o lista de servicios.
//
// Ruta:   Seillo/Views/Screens/Business/BizMenuSheet.swift
// Acceso: BizTabProfileView → "Menú y servicios"
//
// Funciones:
//   • Ver todos los ítems agrupados por categoría
//   • Añadir ítem nuevo (nombre, descripción, precio, badge, categoría)
//   • Editar ítem existente
//   • Eliminar ítem con swipe o botón
//   • Sugerir categorías predefinidas según la categoría del negocio
// ─────────────────────────────────────────────────────────────────────────────

struct BizMenuSheet: View {
    @EnvironmentObject var bizStore: BizProfileStore
    @Environment(\.dismiss)  private var dismiss

    @State private var showAddItem     = false
    @State private var editingItem:    BizMenuItem? = nil
    @State private var appear          = false

    // Ítems agrupados por categoría
    private var grouped: [(String, [BizMenuItem])] {
        let cats = bizStore.profile.menu.map { $0.categoria }
        let unique = cats.reduce(into: [String]()) {
            if !$0.contains($1) { $0.append($1) }
        }
        return unique.map { cat in
            (cat, bizStore.profile.menu.filter { $0.categoria == cat })
        }
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                headerBar
                    .opacity(appear ? 1 : 0)

                if bizStore.profile.menu.isEmpty {
                    emptyState
                } else {
                    menuList
                }
            }
        }
        .sheet(isPresented: $showAddItem) {
            BizMenuItemForm(existingItem: nil) { newItem in
                bizStore.profile.menu.append(newItem)
            }
            .presentationDetents([.large])
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .sheet(item: $editingItem) { item in
            BizMenuItemForm(existingItem: item) { updated in
                if let idx = bizStore.profile.menu.firstIndex(where: { $0.id == updated.id }) {
                    bizStore.profile.menu[idx] = updated
                }
            }
            .presentationDetents([.large])
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome.delay(0.04)) {
                appear = true
            }
        }
    }

    // MARK: - Header

    private var headerBar: some View {
        HStack {
            Button {
                Haptics.tap()
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.seilMuted2)
                    .frame(width: 36, height: 36)
                    .background(Color.seilCard)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)

            Spacer()

            VStack(spacing: 2) {
                Text("Menú y servicios")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)

                Text("\(bizStore.profile.menu.count) ítem\(bizStore.profile.menu.count == 1 ? "" : "s")")
                    .font(.system(size: 11))
                    .foregroundColor(.seilMuted)
            }

            Spacer()

            Button {
                Haptics.tap()
                showAddItem = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(Color.seilAccent)
                    .clipShape(Circle())
                    .shadow(color: Color.seilAccent.opacity(0.35), radius: 8, y: 3)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 14)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
    }

    // MARK: - Menu list

    private var menuList: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 20) {
                ForEach(Array(grouped.enumerated()), id: \.element.0) { gi, group in
                    let (catName, items) = group

                    VStack(alignment: .leading, spacing: 10) {
                        // Header de categoría
                        HStack {
                            Text(catName.uppercased())
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilMuted)
                                .tracking(1.4)
                            Spacer()
                            Text("\(items.count) ítem\(items.count == 1 ? "" : "s")")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(.seilMuted)
                        }

                        // Ítems de la categoría
                        VStack(spacing: 0) {
                            ForEach(Array(items.enumerated()), id: \.element.id) { i, item in
                                menuItemRow(item, isLast: i == items.count - 1)
                            }
                        }
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .opacity(appear ? 1 : 0)
                    .offset(y: appear ? 0 : 14)
                    .animation(
                        SeillAnimation.chrome.delay(Double(gi) * 0.06),
                        value: appear
                    )
                }

                // Botón añadir ítem al final
                Button {
                    Haptics.tap()
                    showAddItem = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 16))
                            .foregroundColor(.seilAccent)
                        Text("Añadir ítem")
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilAccent)
                        Spacer()
                    }
                    .padding(16)
                    .background(Color.seilAccent.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.seilAccent.opacity(0.20), lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)

                Spacer().frame(height: 40)
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
        }
    }

    private func menuItemRow(_ item: BizMenuItem, isLast: Bool) -> some View {
        HStack(spacing: 12) {
            // Precio pill
            Text(item.precio)
                .font(.system(size: 12, weight: .heavy))
                .foregroundColor(.seilAccent)
                .padding(.horizontal, 8)
                .padding(.vertical, 5)
                .background(Color.seilAccent.opacity(0.10))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.seilAccent.opacity(0.22), lineWidth: 1))
                .frame(minWidth: 52, alignment: .center)

            // Nombre + descripción
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(item.nombre)
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)

                    if let badge = item.badge {
                        Text(badge)
                            .font(.system(size: 8, weight: .black))
                            .foregroundColor(.seilGold)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Color.seilGold.opacity(0.12))
                            .clipShape(Capsule())
                    }
                }

                if !item.descripcion.isEmpty {
                    Text(item.descripcion)
                        .font(SeillFont.body(11))
                        .foregroundColor(.seilMuted)
                        .lineLimit(1)
                }
            }

            Spacer()

            // Botones editar / eliminar
            HStack(spacing: 8) {
                Button {
                    Haptics.tap()
                    editingItem = item
                } label: {
                    Image(systemName: "pencil")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 30, height: 30)
                        .background(Color.seilCard2)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                .buttonStyle(.plain)

                Button {
                    Haptics.tap()
                    withAnimation {
                        bizStore.profile.menu.removeAll { $0.id == item.id }
                    }
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.seilRose)
                        .frame(width: 30, height: 30)
                        .background(Color.seilRose.opacity(0.10))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .overlay(alignment: .bottom) {
            if !isLast {
                Rectangle()
                    .fill(Color.seilBorder)
                    .frame(height: 1)
                    .padding(.leading, 14)
            }
        }
    }

    // MARK: - Empty state

    private var emptyState: some View {
        VStack(spacing: 20) {
            Spacer()

            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.08))
                    .frame(width: 80, height: 80)
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "menucard")
                    .font(.system(size: 32))
                    .foregroundColor(.seilMuted)
            }

            VStack(spacing: 8) {
                Text("Sin ítems aún")
                    .font(SeillFont.headline(16))
                    .foregroundColor(.seilText)
                Text("Añade tus productos o servicios\npara que tus clientes los vean.")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }

            // Sugerencias de categorías según tipo de negocio
            suggestedCategories

            Button {
                Haptics.tap()
                showAddItem = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "plus")
                        .font(.system(size: 15, weight: .bold))
                    Text("Añadir primer ítem")
                        .font(SeillFont.headline(14))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 13)
                .background(Color.seilAccent)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .shadow(color: Color.seilAccent.opacity(0.35), radius: 10, y: 4)
            }
            .buttonStyle(.plain)

            Spacer()
        }
        .padding(.horizontal, 32)
    }

    private var suggestedCategories: some View {
        let suggestions = categorySuggestions(for: bizStore.profile.categoriaId)
        guard !suggestions.isEmpty else { return AnyView(EmptyView()) }

        return AnyView(
            VStack(spacing: 6) {
                Text("Categorías sugeridas para tu negocio")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.seilMuted)

                HStack(spacing: 8) {
                    ForEach(suggestions, id: \.self) { cat in
                        Text(cat)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(.seilMuted2)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.seilCard)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
                    }
                }
            }
        )
    }

    private func categorySuggestions(for catId: String) -> [String] {
        switch catId {
        case "cafe":        return ["Bebidas", "Pastelería", "Desayunos"]
        case "restaurante": return ["Entradas", "Platos", "Postres"]
        case "barberia":    return ["Cortes", "Barba", "Tratamientos"]
        case "jugueria":    return ["Jugos", "Extractos", "Smoothies"]
        case "gym":         return ["Membresías", "Clases", "Servicios"]
        case "pasteleria":  return ["Tortas", "Pasteles", "Bebidas"]
        case "farmacia":    return ["Medicamentos", "Cuidado personal"]
        case "tienda":      return ["Productos", "Ofertas"]
        default:            return ["Productos", "Servicios"]
        }
    }
}

// ─── BizMenuItemForm ──────────────────────────────────────────────────────────
// Formulario para crear o editar un ítem del menú.

struct BizMenuItemForm: View {
    let existingItem:  BizMenuItem?
    let onSave:        (BizMenuItem) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var nombre:      String = ""
    @State private var descripcion: String = ""
    @State private var precio:      String = ""
    @State private var categoria:   String = ""
    @State private var badge:       String = ""
    @State private var showBadge:   Bool   = false

    private var isEditing: Bool { existingItem != nil }
    private var canSave: Bool {
        !nombre.trimmingCharacters(in: .whitespaces).isEmpty &&
        !precio.trimmingCharacters(in: .whitespaces).isEmpty &&
        !categoria.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private let badgeOptions = ["Popular", "Nuevo", "Favorito", "Oferta", "Limitado"]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                // Handle
                Capsule()
                    .fill(Color.seilBorder)
                    .frame(width: 36, height: 4)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 12)
                    .padding(.bottom, 20)

                Text(isEditing ? "Editar ítem" : "Nuevo ítem")
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .padding(.horizontal, 22)

                Text("Completa los datos del producto o servicio")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .padding(.horizontal, 22)
                    .padding(.top, 4)
                    .padding(.bottom, 24)

                // ── Nombre ─────────────────────────────────────────────────
                formLabel("NOMBRE *")
                    .padding(.horizontal, 22)
                    .padding(.bottom, 8)

                formTextField("Ej. Latte de especialidad", text: $nombre)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)

                // ── Categoría ──────────────────────────────────────────────
                formLabel("CATEGORÍA *")
                    .padding(.horizontal, 22)
                    .padding(.bottom, 8)

                formTextField("Ej. Bebidas calientes, Servicios...", text: $categoria)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)

                // ── Precio ─────────────────────────────────────────────────
                formLabel("PRECIO *")
                    .padding(.horizontal, 22)
                    .padding(.bottom, 8)

                formTextField("Ej. S/ 12", text: $precio)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)

                // ── Descripción ────────────────────────────────────────────
                formLabel("DESCRIPCIÓN (OPCIONAL)")
                    .padding(.horizontal, 22)
                    .padding(.bottom, 8)

                TextField("Breve descripción del ítem", text: $descripcion, axis: .vertical)
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilText)
                    .lineLimit(2...4)
                    .padding(14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)

                // ── Badge ──────────────────────────────────────────────────
                formLabel("BADGE (OPCIONAL)")
                    .padding(.horizontal, 22)
                    .padding(.bottom, 10)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        // Opción "Ninguno"
                        Button {
                            Haptics.tap()
                            withAnimation(.easeOut(duration: 0.18)) {
                                badge = ""
                                showBadge = false
                            }
                        } label: {
                            Text("Ninguno")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(badge.isEmpty ? .white : .seilMuted)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 9)
                                .background(badge.isEmpty ? Color.seilCard2 : Color.seilCard)
                                .clipShape(Capsule())
                                .overlay(
                                    Capsule().stroke(
                                        badge.isEmpty ? Color.seilBorder : Color.seilBorder,
                                        lineWidth: 1
                                    )
                                )
                        }
                        .buttonStyle(.plain)

                        ForEach(badgeOptions, id: \.self) { option in
                            let isSelected = badge == option
                            Button {
                                Haptics.tap()
                                withAnimation(.easeOut(duration: 0.18)) {
                                    badge     = option
                                    showBadge = true
                                }
                            } label: {
                                Text(option)
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundColor(isSelected ? .white : .seilGold)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 9)
                                    .background(isSelected ? Color.seilGold : Color.seilGold.opacity(0.10))
                                    .clipShape(Capsule())
                                    .overlay(
                                        Capsule().stroke(
                                            isSelected ? Color.clear : Color.seilGold.opacity(0.30),
                                            lineWidth: 1
                                        )
                                    )
                                    .shadow(
                                        color: isSelected ? Color.seilGold.opacity(0.35) : .clear,
                                        radius: 6, y: 2
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .padding(.bottom, 28)

                // ── Guardar ────────────────────────────────────────────────
                Button {
                    guard canSave else { return }
                    Haptics.success()

                    let item = BizMenuItem(
                        id:          existingItem?.id ?? UUID().uuidString,
                        categoria:   categoria.trimmingCharacters(in: .whitespaces),
                        nombre:      nombre.trimmingCharacters(in: .whitespaces),
                        descripcion: descripcion.trimmingCharacters(in: .whitespaces),
                        precio:      precio.trimmingCharacters(in: .whitespaces),
                        badge:       badge.isEmpty ? nil : badge
                    )

                    onSave(item)
                    dismiss()
                } label: {
                    Text(isEditing ? "Guardar cambios" : "Añadir ítem")
                        .font(SeillFont.headline(15))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            canSave ? Color.seilAccent : Color.seilAccent.opacity(0.35)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(
                            color: canSave ? Color.seilAccent.opacity(0.35) : .clear,
                            radius: 14, y: 6
                        )
                }
                .buttonStyle(.plain)
                .disabled(!canSave)
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
        }
        .onAppear {
            if let item = existingItem {
                nombre      = item.nombre
                descripcion = item.descripcion
                precio      = item.precio
                categoria   = item.categoria
                badge       = item.badge ?? ""
                showBadge   = item.badge != nil
            }
        }
    }

    private func formLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .heavy))
            .foregroundColor(.seilMuted)
            .tracking(1.2)
    }

    private func formTextField(_ placeholder: String, text: Binding<String>) -> some View {
        TextField(placeholder, text: text)
            .font(SeillFont.body(13))
            .foregroundColor(.seilText)
            .autocorrectionDisabled()
            .padding(14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
    }
}
