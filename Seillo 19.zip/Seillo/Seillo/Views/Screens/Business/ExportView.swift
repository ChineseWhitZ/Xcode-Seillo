import SwiftUI

// ─── ExportView ───────────────────────────────────────────────────────────────
// Feature premium: exportar datos del negocio a CSV o Excel.
// Acceso: BizTabProfileView → "Exportar datos" (lock si plan Free/Pro)
// ─────────────────────────────────────────────────────────────────────────────

private enum ExportFormat: String, CaseIterable {
    case csv   = "CSV"
    case excel = "Excel"

    var icon: String { self == .csv ? "doc.text.fill" : "tablecells.fill" }
    var color: Color { self == .csv ? Color.seilBlue : Color.seilGreen }
    var description: String {
        self == .csv
        ? "Compatible con cualquier app de hojas de cálculo"
        : "Archivo .xlsx con formato y colores"
    }
}

private enum DateRange: String, CaseIterable {
    case week    = "Última semana"
    case month   = "Último mes"
    case quarter = "Último trimestre"
    case year    = "Último año"
    case all     = "Todo el historial"

    var icon: String {
        switch self {
        case .week:    return "7.circle.fill"
        case .month:   return "30.circle.fill"
        case .quarter: return "3.circle.fill"
        case .year:    return "calendar.circle.fill"
        case .all:     return "infinity.circle.fill"
        }
    }
}

private struct ExportField: Identifiable {
    let id     = UUID()
    let label: String
    let icon:  String
    var enabled: Bool
}

struct ExportView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var format:    ExportFormat = .excel
    @State private var dateRange: DateRange    = .month
    @State private var fields: [ExportField] = [
        .init(label: "Nombre del cliente", icon: "person.fill",          enabled: true),
        .init(label: "Teléfono",           icon: "phone.fill",           enabled: false),
        .init(label: "Sellos acumulados",  icon: "seal.fill",            enabled: true),
        .init(label: "Fecha de registro",  icon: "calendar",             enabled: true),
        .init(label: "Última visita",      icon: "clock.fill",           enabled: true),
        .init(label: "Premio canjeado",    icon: "gift.fill",            enabled: false),
    ]

    @State private var appear      = false
    @State private var exporting   = false
    @State private var showSuccess = false

    private var estimatedRows: Int {
        switch dateRange {
        case .week:    return 38
        case .month:   return 142
        case .quarter: return 389
        case .year:    return 810
        case .all:     return 1240
        }
    }

    private var enabledFields: Int { fields.filter(\.enabled).count }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilGreen.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.10),
                startRadius: 0, endRadius: 320
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                if showSuccess {
                    successView
                } else {
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 24) {
                            Spacer().frame(height: 8)
                            formatSection
                            dateRangeSection
                            fieldsSection
                            summarySection
                            // SeillLayout.tabBarScrollReserve
                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                        }
                        .padding(.horizontal, 24)
                    }
                    .overlay(alignment: .bottom) { exportButton }
                }
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tap(); dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)
                Spacer()
                Text("Exportar datos").font(SeillFont.headline(15)).foregroundColor(Color.seilText)
                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 14)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Format

    private var formatSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionLabel("FORMATO")

            HStack(spacing: 10) {
                ForEach(ExportFormat.allCases, id: \.rawValue) { f in
                    Button {
                        Haptics.tap()
                        withAnimation(.easeOut(duration: 0.20)) { format = f }
                    } label: {
                        HStack(spacing: 10) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(format == f ? f.color.opacity(0.20) : Color.seilCard2)
                                    .frame(width: 36, height: 36)
                                Image(systemName: f.icon)
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(format == f ? f.color : .seilMuted2)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text(f.rawValue).font(SeillFont.label(13))
                                    .foregroundColor(format == f ? Color.seilText : .seilMuted2)
                                Text(f.description).font(SeillFont.body(10))
                                    .foregroundColor(Color.seilMuted).lineLimit(2)
                            }
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(format == f ? f.color.opacity(0.08) : Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(format == f ? f.color.opacity(0.40) : Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Date range

    private var dateRangeSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionLabel("PERÍODO")

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(DateRange.allCases, id: \.rawValue) { range in
                    Button {
                        Haptics.tap()
                        withAnimation(.easeOut(duration: 0.20)) { dateRange = range }
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: range.icon)
                                .font(.system(size: 14))
                                .foregroundColor(dateRange == range ? Color.seilGreen : .seilMuted2)
                            Text(range.rawValue)
                                .font(SeillFont.body(12))
                                .foregroundColor(dateRange == range ? Color.seilText : .seilMuted2)
                                .lineLimit(1)
                        }
                        .padding(.horizontal, 12).padding(.vertical, 11)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(dateRange == range ? Color.seilGreen.opacity(0.08) : Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(dateRange == range ? Color.seilGreen.opacity(0.40) : Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.08), value: appear)
    }

    // MARK: - Fields

    private var fieldsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                sectionLabel("COLUMNAS A EXPORTAR")
                Spacer()
                Text("\(enabledFields) seleccionadas")
                    .font(SeillFont.caption(11))
                    .foregroundColor(Color.seilGreen)
            }

            VStack(spacing: 0) {
                ForEach($fields) { $field in
                    HStack(spacing: 12) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(field.enabled ? Color.seilGreen.opacity(0.12) : Color.seilCard2)
                                .frame(width: 32, height: 32)
                            Image(systemName: field.icon)
                                .font(.system(size: 13))
                                .foregroundColor(field.enabled ? Color.seilGreen : Color.seilMuted)
                        }
                        Text(field.label)
                            .font(SeillFont.body(13))
                            .foregroundColor(field.enabled ? Color.seilText : .seilMuted2)
                        Spacer()
                        Toggle("", isOn: $field.enabled)
                            .tint(Color.seilGreen)
                            .labelsHidden()
                    }
                    .padding(.horizontal, 14).padding(.vertical, 12)

                    if field.id != fields.last?.id {
                        Divider().background(Color.seilBorder).padding(.leading, 58)
                    }
                }
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.12), value: appear)
    }

    // MARK: - Summary

    private var summarySection: some View {
        HStack(spacing: 10) {
            summaryChip(value: "\(estimatedRows)", label: "registros", icon: "person.2.fill", color: Color.seilBlue)
            summaryChip(value: "\(enabledFields)", label: "columnas", icon: "tablecells.fill", color: Color.seilGreen)
            summaryChip(value: format.rawValue, label: "formato", icon: format.icon, color: format.color)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.16), value: appear)
        .animation(.easeInOut(duration: 0.22), value: estimatedRows)
        .animation(.easeInOut(duration: 0.22), value: enabledFields)
    }

    private func summaryChip(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 14)).foregroundColor(color)
            Text(value).font(.system(size: 16, weight: .heavy)).foregroundColor(color)
            Text(label).font(.system(size: 9, weight: .bold)).foregroundColor(Color.seilMuted).tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
    }

    // MARK: - Export button

    private var exportButton: some View {
        Button {
            guard enabledFields > 0 else { return }
            Haptics.tap()
            exporting = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                exporting = false
                Haptics.success()
                withAnimation(SeillAnimation.screenTransition) { showSuccess = true }
            }
        } label: {
            Group {
                if exporting {
                    HStack(spacing: 10) {
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white)).scaleEffect(0.85)
                        Text("Preparando archivo...").font(SeillFont.headline(15))
                    }
                } else {
                    HStack(spacing: 8) {
                        Image(systemName: format.icon).font(.system(size: 14, weight: .semibold))
                        Text("Exportar \(estimatedRows) registros").font(SeillFont.headline(15))
                    }
                }
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                LinearGradient(
                    colors: [Color.seilGreen, Color.seilGreen],
                    startPoint: .leading, endPoint: .trailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: Color.seilGreen.opacity(0.40), radius: 14, y: 4)
        }
        .buttonStyle(.plain)
        .disabled(exporting || enabledFields == 0)
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
        .background(
            LinearGradient(colors: [Color.seilBg.opacity(0), Color.seilBg], startPoint: .top, endPoint: .bottom)
                .frame(height: 110).ignoresSafeArea(),
            alignment: .bottom
        )
    }

    // MARK: - Success

    private var successView: some View {
        VStack(spacing: 0) {
            Spacer()
            ZStack {
                Circle().fill(Color.seilGreen.opacity(0.08)).frame(width: 140, height: 140)
                Circle().fill(Color.seilGreen.opacity(0.14)).frame(width: 100, height: 100)
                    .overlay(Circle().stroke(Color.seilGreen.opacity(0.22), lineWidth: 1.5))
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 52)).foregroundColor(Color.seilGreen)
                    .shadow(color: Color.seilGreen.opacity(0.50), radius: 18, y: 6)
            }
            Spacer().frame(height: 24)
            Text("¡Archivo listo!")
                .font(SeillFont.display(24)).foregroundColor(Color.seilText)
            Spacer().frame(height: 10)
            Text("El archivo \(format.rawValue) con \(estimatedRows) registros\nse descargará en tu dispositivo.")
                .font(SeillFont.body(14)).foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center).lineSpacing(4).padding(.horizontal, 36)
            Spacer()
            Button { Haptics.tap(); dismiss() } label: {
                Text("Cerrar")
                    .font(SeillFont.headline(15)).foregroundColor(.white)
                    .frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(LinearGradient(colors: [Color.seilGreen, Color.seilGreen], startPoint: .leading, endPoint: .trailing))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: Color.seilGreen.opacity(0.40), radius: 14, y: 4)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 24).padding(.bottom, 44)
        }
        .transition(.opacity.combined(with: .scale(scale: 0.94)))
    }

    private func sectionLabel(_ text: String) -> some View {
        Text(text).font(.system(size: 10, weight: .bold)).foregroundColor(Color.seilMuted).tracking(1.2)
    }
}
