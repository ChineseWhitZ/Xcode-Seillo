import SwiftUI

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BizTabProfileView
// ═══════════════════════════════════════════════════════════════════════════════

struct BizTabProfileView: View {
    @EnvironmentObject var auth: AuthManager
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var showLogout = false
    @State private var showEditCard = false
    @State private var showHorario = false
    @State private var showResenas = false
    @State private var showFotos = false
    @State private var showPlanes = false
    @State private var showExport = false
    @State private var showAnalyticsProfile = false
    @State private var showEditProfile = false
    @State private var showCreateProgram = false
    @State private var showHelp = false
    @State private var showSendPush = false
    @State private var showInviteClients = false
    @State private var sellosParaPremio = 10
    @State private var premioTexto = "Café gratis"

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            ScrollView {
                LazyVStack(spacing: 0) {
                    VStack(spacing: 0) {
                        HStack(spacing: 16) {
                            ZStack {
                                Circle()
                                    .fill(Color.seilGold.opacity(0.15))
                                    .frame(width: 68, height: 68)
                                    .overlay(
                                        Circle().stroke(Color.seilGold.opacity(0.35), lineWidth: 1.5)
                                    )

                                Image(systemName: bizStore.profile.categoriaIcon)
                                    .font(.system(size: 30))
                                    .foregroundColor(.seilGold)
                            }

                            VStack(alignment: .leading, spacing: 4) {
                                Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                                    .font(.system(size: 19, weight: .heavy, design: .rounded))
                                    .foregroundColor(.seilText)

                                Text(bizStore.profile.categoriaLabel)
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted2)

                                HStack(spacing: 6) {
                                    Image(systemName: "location.fill")
                                        .font(.system(size: 10))
                                        .foregroundColor(.seilMuted)

                                    Text(bizStore.profile.direccion.isEmpty ? "Sin dirección" : bizStore.profile.direccion)
                                        .font(.system(size: 11))
                                        .foregroundColor(.seilMuted)
                                        .lineLimit(1)
                                }
                            }

                            Spacer()

                            Button {
                                Haptics.tap()
                                showEditProfile = true
                            } label: {
                                HStack(spacing: 5) {
                                    Image(systemName: "pencil").font(.system(size: 11))
                                    Text(SeillStrings.action.edit).font(SeillFont.label(11))
                                }
                                .foregroundColor(.seilGold)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.seilGold.opacity(0.10))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.seilGold.opacity(0.25), lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(20)
                        .background(
                            LinearGradient(
                                colors: [Color.seilGold.opacity(0.15), .clear],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .overlay(alignment: .bottom) {
                            Rectangle()
                                .fill(Color.seilBorder)
                                .frame(height: 1)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("TARJETA DE FIDELIZACIÓN")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilMuted)
                                .tracking(1.5)

                            Spacer()

                            Button {
                                showEditCard = true
                            } label: {
                                HStack(spacing: 5) {
                                    Image(systemName: "pencil")
                                        .font(.system(size: 11))

                                    Text(SeillStrings.action.edit)
                                        .font(SeillFont.label(11))
                                }
                                .foregroundColor(.seilAccent)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color.seilAccent.opacity(0.1))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            }
                            .buttonStyle(.plain)
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Image(systemName: "cup.and.saucer.fill")
                                    .foregroundColor(.seilGold)

                                Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                                    .font(SeillFont.headline(14))
                                    .foregroundColor(.seilText)

                                Spacer()

                                Text("\(sellosParaPremio) sellos")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(.seilMuted2)
                            }

                            HStack(spacing: 6) {
                                ForEach(0..<min(sellosParaPremio, 10), id: \.self) { i in
                                    Circle()
                                        .fill(i < 3 ? Color.seilGold.opacity(0.3) : Color.white.opacity(0.08))
                                        .frame(width: 24, height: 24)
                                        .overlay(
                                            Circle().stroke(
                                                i < 3 ? Color.seilGold : Color.white.opacity(0.12),
                                                lineWidth: 1.5
                                            )
                                        )
                                }
                            }

                            HStack(spacing: 6) {
                                Image(systemName: "gift.fill")
                                    .foregroundColor(.seilAccent)

                                Text(premioTexto)
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted2)
                            }
                        }
                        .padding(16)
                        .background(
                            LinearGradient(
                                colors: [Color.seilCard, Color.seilCard2],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 20)

                    Spacer().frame(height: 20)

                    VStack(spacing: 0) {
                        BizMenuRow(icon: "plus.circle.fill", label: "Nuevo programa") {
                            showCreateProgram = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "person.badge.plus", label: "Invitar clientes") {
                            showInviteClients = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "bell.badge.fill", label: "Enviar notificación") {
                            showSendPush = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "calendar.badge.clock", label: "Horarios del negocio") {
                            showHorario = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "photo.on.rectangle", label: "Fotos del local") {
                            showFotos = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "star.bubble", label: "Reseñas y calificaciones") {
                            showResenas = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "chart.line.uptrend.xyaxis", label: "Estadísticas avanzadas") {
                            showAnalyticsProfile = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "crown.fill", label: "Planes Seillo") {
                            showPlanes = true
                        }

                        Divider().background(Color.seilBorder).padding(.leading, 60)

                        BizMenuRow(icon: "square.and.arrow.up.fill", label: "Exportar clientes") {
                            showExport = true
                        }

                        BizMenuRow(icon: "questionmark.circle", label: "Centro de ayuda") {
                            showHelp = true
                        }
                    }
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
                    .padding(.horizontal, 16)

                    Spacer().frame(height: 16)

                    Button {
                        showLogout = true
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 14))

                            Text(SeillStrings.action.signOut)
                                .font(SeillFont.headline(14))
                        }
                        .foregroundColor(.seilRose)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.seilRose.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.seilRose.opacity(0.3), lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 16)

                    Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                }
            }
        }
        .sheet(isPresented: $showLogout) {
            LogoutConfirmSheet {
                auth.logout()
            }
            .presentationDetents(adaptiveDetents(height: 320))
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showEditCard) {
            BizEditCardSheet(sellos: $sellosParaPremio, premio: $premioTexto)
                .presentationDetents(adaptiveDetents(height: 440))
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showHorario) {
            BizHorarioSheet()
                .presentationDetents(largeDetent)
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showResenas) {
            BizResenasSheet()
                .presentationDetents(largeDetent)
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showFotos) {
            BizComingSoonSheet(
                icon: "photo.on.rectangle",
                title: "Fotos del local",
                descriptionText: "Próximamente podrás subir fotos de tu local para que los clientes puedan verlas en tu perfil."
            )
            .presentationDetents(adaptiveDetents(height: 360))
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .sheet(isPresented: $showEditProfile) {
            EditBizProfileView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showCreateProgram) {
            CreateProgramView()
                .presentationBackground(Color.seilBg)
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showSendPush) {
            SendPushView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showInviteClients) {
            InviteClientsView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showPlanes) {
            PlanesView()
        }
        .sheet(isPresented: $showExport) {
            ExportView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showAnalyticsProfile) {
            BizAnalyticsView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showHelp) {
            BizHelpSheet()
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
        }
    }
}

private struct BizMenuRow: View {
    let icon: String
    let label: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.seilCard2)
                        .frame(width: 34, height: 34)

                    Image(systemName: icon)
                        .font(.system(size: 15))
                        .foregroundColor(.seilMuted2)
                }

                Text(label)
                    .font(SeillFont.label(13))
                    .foregroundColor(.seilText)

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 13))
                    .foregroundColor(.seilMuted)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 13)
        }
        .buttonStyle(.plain)
    }
}

struct BizEditCardSheet: View {
    @Binding var sellos: Int
    @Binding var premio: String
    @Environment(\.dismiss) private var dismiss
    @State private var localSellos: Int = 10
    @State private var localPremio: String = ""
    private let options = [5, 7, 10, 12, 15]

    var body: some View {
        SeillSheetBox {
            VStack(spacing: 0) {
                Capsule()
                    .fill(Color.seilBorder)
                    .frame(width: 36, height: 4)
                    .padding(.top, 12)

                Spacer().frame(height: 18)

                Text("Configurar tarjeta")
                    .font(.system(size: 18, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)

                Text("Los cambios son visibles para tus clientes")
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted)
                    .padding(.top, 4)

                Spacer().frame(height: 22)

                VStack(alignment: .leading, spacing: 14) {
                    Text("SELLOS PARA EL PREMIO")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.2)

                    HStack(spacing: 8) {
                        ForEach(options, id: \.self) { n in
                            Button {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                localSellos = n
                            } label: {
                                Text("\(n)")
                                    .font(.system(size: 14, weight: .heavy))
                                    .foregroundColor(localSellos == n ? .white : .seilMuted2)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(localSellos == n ? Color.seilAccent : Color.seilCard)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(localSellos == n ? Color.clear : Color.seilBorder, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    Spacer().frame(height: 4)

                    Text("DESCRIPCIÓN DEL PREMIO")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilMuted)
                        .tracking(1.2)

                    TextField("Ej. Café a elección gratis", text: $localPremio)
                        .font(SeillFont.body(13))
                        .foregroundColor(.seilText)
                        .padding(14)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.seilBorder, lineWidth: 1)
                        )
                }
                .padding(.horizontal, 20)

                Spacer().frame(height: 24)

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    sellos = localSellos
                    if !localPremio.trimmingCharacters(in: .whitespaces).isEmpty {
                        premio = localPremio
                    }
                    dismiss()
                } label: {
                    Text(SeillStrings.action.saveChanges)
                        .font(SeillFont.headline(15))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color.seilAccent)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .shadow(color: Color.seilAccent.opacity(0.35), radius: 12, y: 4)
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 20)

                Spacer().frame(height: 20)
            }
        }
        .onAppear {
            localSellos = sellos
            localPremio = premio
        }
    }
}

private struct BizHorarioDia: Codable {
    var activo: Bool
    var abreMinutos: Int
    var cierraMinutos: Int
}

private func defaultHorario() -> [BizHorarioDia] {
    (0..<7).map { i in
        BizHorarioDia(activo: i < 6, abreMinutos: 8 * 60, cierraMinutos: 20 * 60)
    }
}

private func minutesToDate(_ m: Int) -> Date {
    Calendar.current.date(from: DateComponents(hour: m / 60, minute: m % 60)) ?? Date()
}

private func dateToMinutes(_ d: Date) -> Int {
    let c = Calendar.current.dateComponents([.hour, .minute], from: d)
    return (c.hour ?? 8) * 60 + (c.minute ?? 0)
}

struct BizHorarioSheet: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("biz_horario_json") private var horarioJSON: String = ""

    private let api = APIClient.shared

    private let dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

    @State private var horario: [BizHorarioDia] = defaultHorario()
    @State private var abreDates: [Date] = Array(repeating: minutesToDate(480), count: 7)
    @State private var cierraDates: [Date] = Array(repeating: minutesToDate(1200), count: 7)

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                List {
                    ForEach(dias.indices, id: \.self) { i in
                        VStack(spacing: 10) {
                            HStack {
                                Text(dias[i])
                                    .font(SeillFont.headline(14))
                                    .foregroundColor(horario[i].activo ? .seilText : .seilMuted)

                                Spacer()

                                Toggle("", isOn: Binding(
                                    get: { horario[i].activo },
                                    set: { horario[i].activo = $0 }
                                ))
                                .tint(.seilAccent)
                                .labelsHidden()
                            }

                            if horario[i].activo {
                                HStack(spacing: 12) {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Abre")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(.seilMuted)

                                        DatePicker("", selection: $abreDates[i], displayedComponents: .hourAndMinute)
                                            .datePickerStyle(.compact)
                                            .labelsHidden()
                                            .onChange(of: abreDates[i]) { _, d in
                                                horario[i].abreMinutos = dateToMinutes(d)
                                            }
                                    }

                                    Image(systemName: "arrow.right")
                                        .font(.system(size: 12))
                                        .foregroundColor(.seilMuted)

                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Cierra")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(.seilMuted)

                                        DatePicker("", selection: $cierraDates[i], displayedComponents: .hourAndMinute)
                                            .datePickerStyle(.compact)
                                            .labelsHidden()
                                            .onChange(of: cierraDates[i]) { _, d in
                                                horario[i].cierraMinutos = dateToMinutes(d)
                                            }
                                    }

                                    Spacer()
                                }
                            }
                        }
                        .padding(.vertical, 4)
                        .listRowBackground(Color.seilCard)
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Horario de atención")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Guardar") {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        saveHorario()
                        dismiss()
                    }
                    .font(SeillFont.label(14))
                    .foregroundColor(.seilAccent)
                }

                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancelar") { dismiss() }
                        .font(SeillFont.label(13))
                        .foregroundColor(.seilMuted)
                }
            }
            .onAppear { loadHorario() }
        }
    }

    private func loadHorario() {
        guard !horarioJSON.isEmpty,
              let data = horarioJSON.data(using: .utf8),
              let saved = try? JSONDecoder().decode([BizHorarioDia].self, from: data),
              saved.count == 7
        else {
            horario = defaultHorario()
            syncDates()
            return
        }

        horario = saved
        syncDates()
    }

    private func syncDates() {
        for i in 0..<7 {
            abreDates[i] = minutesToDate(horario[i].abreMinutos)
            cierraDates[i] = minutesToDate(horario[i].cierraMinutos)
        }
    }

    private func saveHorario() {
        // 1. Persistir localmente (fuente de verdad offline)
        if let data = try? JSONEncoder().encode(horario),
           let json = String(data: data, encoding: .utf8) {
            horarioJSON = json
        }
        // 2. Sincronizar con el backend — espera { horarios: [{ dia, abierto, hora_inicio, hora_cierre }] }
        Task {
            struct HorarioItem: Encodable {
                let dia: Int; let abierto: Int
                let hora_inicio: String; let hora_cierre: String
            }
            struct HorariosBody: Encodable { let horarios: [HorarioItem] }
            let items = horario.enumerated().map { i, h in
                HorarioItem(
                    dia:         i,
                    abierto:     h.activo ? 1 : 0,
                    hora_inicio: minutesToHHMM(h.abreMinutos),
                    hora_cierre: minutesToHHMM(h.cierraMinutos)
                )
            }
            try? await api.put("api/negocio/horario", body: HorariosBody(horarios: items))
        }
    }

    private func minutesToHHMM(_ minutes: Int) -> String {
        let h = minutes / 60
        let m = minutes % 60
        return String(format: "%02d:%02d:00", h, m)
    }
}

private struct BizReview: Identifiable {
    let id      : String
    let name    : String
    let initial : String
    let color   : Color
    let stars   : Int
    let text    : String
    let date    : String
}

private let reviewColors: [Color] = [.seilPurple, .seilBlue, .seilGreen, .seilGold, .seilRose, .seilAccent]

private func reviewFromDTO(_ dto: ResenaDTO, index: Int) -> BizReview {
    BizReview(
        id      : dto.id,
        name    : dto.nombre,
        initial : String(dto.nombre.prefix(1)).uppercased(),
        color   : reviewColors[index % reviewColors.count],
        stars   : dto.estrellas,
        text    : dto.texto,
        date    : formatRelativeReview(dto.createdAt)
    )
}

private func formatRelativeReview(_ iso: String) -> String {
    let fmts = ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ss"]
    for fmt in fmts {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = fmt
        if let date = f.date(from: iso) {
            let days = Calendar.current.dateComponents([.day], from: date, to: Date()).day ?? 0
            switch days {
            case 0:       return "Hoy"
            case 1:       return "Ayer"
            case 2...6:   return "Hace \(days) días"
            case 7...13:  return "Hace 1 semana"
            default:      return "Hace \(days / 7) semanas"
            }
        }
    }
    return ""
}

struct BizResenasSheet: View {
    @State private var reviews   : [BizReview] = []
    @State private var loading   = true
    @State private var negocioId : String      = ""

    private let api = APIClient.shared

    private var promedioEstrellas: Double {
        guard !reviews.isEmpty else { return 0 }
        return Double(reviews.map(\.stars).reduce(0, +)) / Double(reviews.count)
    }

    private func pct(for stars: Int) -> Double {
        guard !reviews.isEmpty else { return 0 }
        let count = reviews.filter { $0.stars == stars }.count
        return Double(count) / Double(reviews.count)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                if loading {
                    ProgressView().tint(.seilAccent)
                } else {
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 0) {

                            // ── Resumen general ───────────────────────────
                            HStack(spacing: 16) {
                                VStack(spacing: 4) {
                                    let avg = promedioEstrellas
                                    Text(avg > 0 ? String(format: "%.1f", avg) : "—")
                                        .font(.system(size: 40, weight: .heavy, design: .rounded))
                                        .foregroundColor(.seilText)

                                    HStack(spacing: 3) {
                                        ForEach(1...5, id: \.self) { i in
                                            Image(systemName: avg >= Double(i) ? "star.fill"
                                                  : avg >= Double(i) - 0.5 ? "star.leadinghalf.filled"
                                                  : "star")
                                                .font(.system(size: 12))
                                                .foregroundColor(.seilGold)
                                        }
                                    }

                                    Text("\(reviews.count) reseña\(reviews.count == 1 ? "" : "s")")
                                        .font(SeillFont.body(11))
                                        .foregroundColor(.seilMuted)
                                }

                                Spacer()

                                VStack(spacing: 4) {
                                    ForEach([5, 4, 3, 2, 1], id: \.self) { s in
                                        HStack(spacing: 6) {
                                            Text("\(s)")
                                                .font(.system(size: 11))
                                                .foregroundColor(.seilMuted)
                                                .frame(width: 10)

                                            GeometryReader { geo in
                                                ZStack(alignment: .leading) {
                                                    Capsule().fill(Color.seilBorder).frame(height: 5)
                                                    Capsule().fill(Color.seilGold)
                                                        .frame(width: geo.size.width * pct(for: s), height: 5)
                                                }
                                            }
                                            .frame(height: 5)
                                        }
                                    }
                                }
                                .frame(maxWidth: 160)
                            }
                            .padding(20)
                            .background(Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
                            .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 12)

                            HStack(spacing: 6) {
                                Image(systemName: "checkmark.seal.fill").font(.system(size: 12)).foregroundColor(.seilGreen)
                                Text("Solo clientes con sellos pueden reseñar").font(SeillFont.caption(11)).foregroundColor(.seilMuted2)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(Color.seilGreen.opacity(0.06)).clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.seilGreen.opacity(0.2), lineWidth: 1))
                            .padding(.bottom, 16)

                            if reviews.isEmpty {
                                VStack(spacing: 12) {
                                    Image(systemName: "star.slash").font(.system(size: 32)).foregroundColor(.seilMuted)
                                    Text("Aún no hay reseñas").font(SeillFont.headline(13)).foregroundColor(.seilText)
                                    Text("Los clientes que visiten tu negocio podrán dejarte una reseña.")
                                        .font(SeillFont.body(12)).foregroundColor(.seilMuted2).multilineTextAlignment(.center)
                                }
                                .padding(32)
                            } else {
                                ForEach(reviews) { r in
                                    VStack(alignment: .leading, spacing: 10) {
                                        HStack(spacing: 10) {
                                            ZStack {
                                                Circle().fill(r.color.opacity(0.15)).frame(width: 38, height: 38)
                                                Text(r.initial).font(.system(size: 14, weight: .heavy)).foregroundColor(r.color)
                                            }
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(r.name).font(SeillFont.headline(13)).foregroundColor(.seilText)
                                                Text(r.date).font(SeillFont.caption(10)).foregroundColor(.seilMuted)
                                            }
                                            Spacer()
                                            HStack(spacing: 2) {
                                                ForEach(1...5, id: \.self) { i in
                                                    Image(systemName: i <= r.stars ? "star.fill" : "star")
                                                        .font(.system(size: 10))
                                                        .foregroundColor(i <= r.stars ? .seilGold : Color.seilBorder)
                                                }
                                            }
                                        }
                                        Text(r.text).font(SeillFont.body(12)).foregroundColor(.seilMuted2).lineSpacing(3)
                                    }
                                    .padding(16)
                                    .background(Color.seilCard)
                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
                                    .padding(.horizontal, 16).padding(.bottom, 10)
                                }
                            }

                            Spacer().frame(height: 32)
                        }
                    }
                }
            }
            .navigationTitle("Reseñas y calificaciones")
            .navigationBarTitleDisplayMode(.large)
            .task {
                loading = true
                // Obtener negocioId desde el perfil del negocio
                if let perfil = try? await api.get("api/negocio/perfil") as NegocioPerfilDTO,
                   let progId = perfil.programaId {
                    // Las reseñas usan el negocio_id — lo obtenemos buscando el negocio por programa
                    // El endpoint público GET /api/negocios no filtra, usamos el programaId como proxy
                    // hasta que el perfil exponga negocio_id directamente
                    negocioId = progId
                }
                if !negocioId.isEmpty,
                   let dtos = try? await api.getPublic("api/negocios/\(negocioId)/resenas") as [ResenaDTO] {
                    reviews = dtos.enumerated().map { reviewFromDTO($0.element, index: $0.offset) }
                }
                loading = false
            }
        }
    }
}

struct BizComingSoonSheet: View {
    let icon: String
    let title: String
    let descriptionText: String

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .padding(.top, 12)

            Spacer()

            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.10))
                    .frame(width: 72, height: 72)
                    .overlay(
                        Circle().stroke(Color.seilAccent.opacity(0.2), lineWidth: 1.5)
                    )

                Image(systemName: icon)
                    .font(.system(size: 28))
                    .foregroundColor(.seilAccent)
            }

            Spacer().frame(height: 18)

            Text(title)
                .font(.system(size: 18, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)
                .multilineTextAlignment(.center)

            Spacer().frame(height: 10)

            Text(descriptionText)
                .font(SeillFont.body(13))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .lineSpacing(4)
                .padding(.horizontal, 32)

            Spacer().frame(height: 8)

            Text("Próximamente")
                .font(.system(size: 11, weight: .heavy))
                .foregroundColor(.seilAccent)
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .background(Color.seilAccent.opacity(0.1))
                .clipShape(Capsule())
                .overlay(
                    Capsule().stroke(Color.seilAccent.opacity(0.25), lineWidth: 1)
                )

            Spacer()

            Button {
                dismiss()
            } label: {
                Text("Entendido")
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilText)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.seilBorder, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 20)
            .padding(.bottom, 28)
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BizHelpSheet (NUEVO — Lote 7)
// ═══════════════════════════════════════════════════════════════════════════════
/// Centro de ayuda con FAQs expandibles — equivalente a HelpSheet en Android.

private let bizFaqs: [(question: String, answer: String)] = [
    ("¿Cómo escaneo el QR de un cliente?",
     "Ve a la pestaña \"Escanear\", apunta la cámara al código QR del cliente y el sello se registrará automáticamente."),
    ("¿Puedo cambiar mi premio en cualquier momento?",
     "Sí. En \"Tarjetas de fidelización\" selecciona la tarjeta y presiona editar."),
    ("¿Mis clientes pierden sus sellos si cambio el premio?",
     "No. Los sellos ya acumulados se conservan."),
    ("¿Cómo renuevo mi plan?",
     "En la sección \"Mi Plan\" puedes ver la fecha de vencimiento y renovar."),
    ("¿Cómo contacto a soporte?",
     "Escríbenos a soporte@seillo.site y te responderemos a la brevedad."),
]

struct BizHelpSheet: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            HStack(spacing: 8) {
                Image(systemName: "questionmark.circle")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.seilMuted2)
                Text("Centro de ayuda")
                    .font(SeillFont.headline(16))
                    .foregroundColor(.seilText)
                Spacer()
                Button { dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 30, height: 30)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            .padding(.bottom, 14)

            Rectangle().fill(Color.seilBorder).frame(height: 1)

            // FAQ list
            ScrollView(showsIndicators: false) {
                VStack(spacing: 8) {
                    ForEach(Array(bizFaqs.enumerated()), id: \.offset) { _, faq in
                        BizFaqRow(question: faq.question, answer: faq.answer)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 40)
            }
        }
    }
}

private struct BizFaqRow: View {
    let question: String
    let answer: String

    @State private var expanded = false

    var body: some View {
        Button {
            Haptics.tap()
            withAnimation(.easeOut(duration: 0.25)) { expanded.toggle() }
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    Text(question)
                        .font(SeillFont.headline(13))
                        .foregroundColor(expanded ? .seilAccent : .seilText)
                        .multilineTextAlignment(.leading)

                    Spacer()

                    Image(systemName: expanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(expanded ? .seilAccent : .seilMuted2)
                }

                if expanded {
                    Text(answer)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(3)
                        .padding(.top, 10)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .padding(14)
            .background(expanded ? Color.seilAccent.opacity(0.06) : Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(expanded ? Color.seilAccent.opacity(0.30) : Color.seilBorder, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}
