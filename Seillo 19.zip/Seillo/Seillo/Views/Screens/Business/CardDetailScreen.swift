import SwiftUI

struct CardDetailScreen: View {
    let card: LoyaltyCard

    @Environment(\.dismiss) private var dismiss
    @State private var showQRSheet     = false
    @State private var showRedeemSheet = false
    @State private var animProgress: Double = 0
    @State private var scrollOffset: CGFloat = 0

    // ── Cascade panel entry — cada panel tiene su propio Animatable ──────
    @State private var heroAlpha:    Double  = 0
    @State private var heroOffset:   CGFloat = 20
    @State private var p1Alpha:      Double  = 0
    @State private var p1Offset:     CGFloat = 20
    @State private var p2Alpha:      Double  = 0
    @State private var p2Offset:     CGFloat = 20
    @State private var p3Alpha:      Double  = 0
    @State private var p3Offset:     CGFloat = 20
    @State private var p4Alpha:      Double  = 0
    @State private var p4Offset:     CGFloat = 20
    @State private var p5Alpha:      Double  = 0
    @State private var p5Offset:     CGFloat = 20

    // Datos reales del negocio cargados desde backend
    @State private var bizDireccion:   String = ""
    @State private var bizDistrito:    String = ""
    @State private var bizDescripcion: String = ""
    @State private var bizRating:      Double = 0
    @State private var bizReviews:     Int    = 0
    @State private var bizHoursLabel:  String = ""
    @State private var bizHorario:     [HorarioDiaDTO] = []

    private let api = APIClient.shared

    private var progress: Double {
        guard card.totalStamps > 0 else { return 0 }
        return Double(card.filledStamps) / Double(card.totalStamps)
    }

    private var stampsLeft: Int {
        max(card.totalStamps - card.filledStamps, 0)
    }

    private var business: Business {
        Business(
            name:         card.bizName,
            district:     bizDistrito,
            address:      bizDireccion,
            hoursNow:     bizHoursLabel,
            desc:         bizDescripcion.isEmpty
                            ? "Disfruta tus sellos, premios y beneficios en este local."
                            : bizDescripcion,
            bannerColors: card.gradientColors,
            rating:       bizRating,
            reviewCount:  bizReviews,
            tags:         [card.location],
            menu:         [],
            reviews:      [],
            lat: -12.0464, lon: -77.0428
        )
    }

    var body: some View {
        ZStack {
            Color.seilBg
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    heroSection

                    VStack(spacing: 18) {
                        loyaltyCardPanel
                            .opacity(p1Alpha)
                            .offset(y: p1Offset)
                        businessInfoPanel
                            .opacity(p2Alpha)
                            .offset(y: p2Offset)
                        businessLinkPanel
                            .opacity(p3Alpha)
                            .offset(y: p3Offset)
                        aboutPanel
                            .opacity(p4Alpha)
                            .offset(y: p4Offset)
                        // historial de visitas — pendiente endpoint GET /api/cliente/historial?tarjetaId=:id
                            .opacity(p5Alpha)
                            .offset(y: p5Offset)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 18)

                    // Espacio para el bottomCTA overlay (no relacionado con tab bar)
                    Spacer().frame(height: 120)
                }
                // Scroll offset tracker para parallax
                .background(
                    GeometryReader { geo in
                        Color.clear.preference(
                            key: ScrollOffsetKey.self,
                            value: -geo.frame(in: .named("scroll")).minY
                        )
                    }
                )
            }
            .coordinateSpace(name: "scroll")
            .onPreferenceChange(ScrollOffsetKey.self) { scrollOffset = $0 }
            .ignoresSafeArea(edges: .top)

            bottomCTA
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .enableSwipeBack()
        .sheet(isPresented: $showQRSheet) {
            QRSheetView()
                .presentationDetents([.height(520)])
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .sheet(isPresented: $showRedeemSheet) {
            RedeemSheetView(card: card)
                .presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color(hex: "#0F0C0A"))
        }
        .task {
            async let cascade: () = runCascade()
            async let data: ()    = loadNegocioData()
            await cascade
            await data
        }
    }
}

// ─── Scroll offset preference ────────────────────────────────────────────────
private struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

private extension CardDetailScreen {

    func loadNegocioData() async {
        let negocioId = card.negocioId
        guard !negocioId.isEmpty else { return }

        // Datos del negocio (dirección, descripción, rating) desde listado público
        if let dtos = try? await api.getPublic("api/negocios") as [NegocioDTO],
           let dto = dtos.first(where: { $0.id == negocioId }) {
            bizDireccion   = dto.direccion   ?? ""
            bizDistrito    = dto.distrito    ?? ""
            bizDescripcion = dto.descripcion ?? ""
            if let r  = dto.rating      { bizRating  = r  }
            if let rc = dto.reviewCount { bizReviews = rc }
        }

        // Horario del negocio
        if let h = try? await api.getPublic("api/negocios/\(negocioId)/horario") as [HorarioDiaDTO] {
            bizHorario = h
            updateHoursFromHorario(h)
        }
    }

    func updateHoursFromHorario(_ horario: [HorarioDiaDTO]) {
        let cal     = Calendar.current
        let weekday = cal.component(.weekday, from: Date())
        let diaIdx  = (weekday + 5) % 7
        guard let hoy = horario.first(where: { $0.dia == diaIdx }) else { return }
        if hoy.abierto == 1 {
            let cierre = String(hoy.horaCierre.prefix(5))
            bizHoursLabel = "Abierto · cierra a las \(cierre)"
        } else {
            bizHoursLabel = "Cerrado hoy"
        }
    }

    func runCascade() async {
        // Hero
        withAnimation(SeillAnimation.panelCascade) {
            heroAlpha = 1; heroOffset = 0
        }
        withAnimation(.easeOut(duration: 0.72).delay(0.22)) {
            animProgress = progress
        }

        try? await Task.sleep(for: .seconds(0.08))
        withAnimation(SeillAnimation.panelCascade) { p1Alpha = 1; p1Offset = 0 }

        try? await Task.sleep(for: .seconds(0.08))
        withAnimation(SeillAnimation.panelCascade) { p2Alpha = 1; p2Offset = 0 }

        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(SeillAnimation.panelCascade) { p3Alpha = 1; p3Offset = 0 }

        try? await Task.sleep(for: .seconds(0.06))
        withAnimation(SeillAnimation.panelCascade) { p4Alpha = 1; p4Offset = 0 }

        try? await Task.sleep(for: .seconds(0.05))
        withAnimation(SeillAnimation.panelCascade) { p5Alpha = 1; p5Offset = 0 }
    }
}

private extension CardDetailScreen {
    var heroSection: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(
                colors: business.bannerColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .frame(height: 258)
            // Parallax — el banner sube al 40% de la velocidad del scroll
            .offset(y: min(scrollOffset * 0.40, 60))
            .overlay(
                LinearGradient(
                    colors: [
                        .black.opacity(0.10),
                        .black.opacity(0.18),
                        Color.seilBg.opacity(0.88)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )

            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    backButton
                    Spacer()
                }
                .padding(.top, 56)
                .padding(.horizontal, 16)

                Spacer()

                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 10) {
                        ZStack {
                            Circle()
                                .fill(Color.seilSurface.opacity(0.76))
                                .frame(width: 58, height: 58)
                                .overlay(
                                    // seilBorderGlass
                                Circle()
                                        .stroke(Color.seilBorderGlass, lineWidth: 1)
                                )

                            Image(systemName: card.icon)
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundColor(card.stampColor)
                        }

                        VStack(alignment: .leading, spacing: 4) {
                            Text(card.bizName)
                                .font(.system(size: 24, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)

                            Text(card.location)
                                .font(SeillFont.body(12))
                                .foregroundColor(.white.opacity(0.72))
                        }

                        Spacer()
                    }

                    HStack(spacing: 8) {
                        chip(system: "gift.fill", text: card.rewardText)

                        if card.isComplete {
                            chip(system: "sparkles", text: "Premio listo", tint: .seilGreen)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
        }
        .frame(height: 258)
    }

    var loyaltyCardPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("TU TARJETA")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)

                Spacer()

                Text("\(card.filledStamps)/\(card.totalStamps)")
                    .font(.system(size: 13, weight: .heavy))
                    .foregroundColor(card.stampColor)
            }

            VStack(alignment: .leading, spacing: 12) {
                ElegantStampProgressView(card: card)
                progressBar
            }

            rewardStateBlock
        }
        .padding(18)
        .background(.ultraThinMaterial.opacity(0.22))
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.white.opacity(0.035))
        )
        // seilBorderGlass — antes: Color.white.opacity(0.08)
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .stroke(Color.seilBorderGlass, lineWidth: 1)
        )
        .shadow(color: card.stampColor.opacity(0.12), radius: 18, y: 8)
        
    }

    var progressBar: some View {
        GeometryReader { geo in
            VStack(alignment: .leading, spacing: 8) {
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(Color.white.opacity(0.07))
                        .frame(height: 10)

                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [card.stampColor.opacity(0.65), card.stampColor],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(
                            width: max(geo.size.width * animProgress, animProgress == 0 ? 0 : 18),
                            height: 10
                        )
                        .shadow(color: card.stampColor.opacity(0.28), radius: 8, y: 0)
                }

                HStack {
                    Text(card.isComplete ? "Completada" : "Te faltan \(stampsLeft) sello\(stampsLeft == 1 ? "" : "s")")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(card.isComplete ? .seilGreen : .seilMuted2)

                    Spacer()

                    Text("\(Int(progress * 100))%")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.seilMuted)
                }
            }
        }
        .frame(height: 32)
    }

    var rewardStateBlock: some View {
        Group {
            if card.isComplete {
                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(Color.seilGreen.opacity(0.16))
                            .frame(width: 38, height: 38)

                        Image(systemName: "sparkles")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.seilGreen)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text("¡Premio listo para canjear!")
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .foregroundColor(.seilText)

                        Text("Muéstrale tu QR al negocio para registrar el canje.")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                    }

                    Spacer()
                }
                .padding(14)
                .background(Color.seilGreen.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.seilGreen.opacity(0.18), lineWidth: 1)
                )
            } else {
                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(card.stampColor.opacity(0.14))
                            .frame(width: 38, height: 38)

                        Image(systemName: "gift.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(card.stampColor)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text(card.rewardText)
                            .font(.system(size: 14, weight: .heavy, design: .rounded))
                            .foregroundColor(.seilText)

                        Text(
                            stampsLeft <= 2
                            ? "Ya casi. Esta tarjeta está a punto de completarse."
                            : "Sigue juntando sellos para desbloquear tu premio."
                        )
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                    }

                    Spacer()
                }
                .padding(14)
                .background(Color.white.opacity(0.03))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.white.opacity(0.06), lineWidth: 1)
                )
            }
        }
    }

    var businessInfoPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("NEGOCIO")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)

            VStack(spacing: 12) {
                if bizRating > 0 {
                    SeillDetailRow(
                        icon: "star.fill",
                        title: "Calificación",
                        value: "\(String(format: "%.1f", bizRating)) · \(bizReviews) reseña\(bizReviews == 1 ? "" : "s")"
                    )
                }
                if !bizDireccion.isEmpty {
                    SeillDetailRow(icon: "location.fill", title: "Dirección", value: bizDireccion)
                }
                if !bizDistrito.isEmpty {
                    SeillDetailRow(icon: "map.fill",      title: "Distrito",  value: bizDistrito)
                }
                if !bizHoursLabel.isEmpty {
                    SeillDetailRow(
                        icon: "clock.fill",
                        title: "Horario",
                        value: bizHoursLabel
                    )
                }
                SeillDetailRow(icon: "storefront.fill", title: "Categoría",  value: card.location)
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        
    }

    var businessLinkPanel: some View {
        NavigationLink {
            BizProfileScreen(card: card, showCard: false)
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.seilAccent.opacity(0.14))
                        .frame(width: 38, height: 38)

                    Image(systemName: "storefront.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilAccent)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Ver negocio")
                        .font(SeillFont.headline(14))
                        .foregroundColor(.seilText)

                    Text("Horarios, ubicación, reseñas y más")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white.opacity(0.35))
            }
            .padding(16)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        
    }

    var aboutPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ACERCA DEL LOCAL")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)

            Text(
                business.desc.isEmpty
                ? "Disfruta tus sellos, premios y beneficios en este local."
                : business.desc
            )
            .font(SeillFont.body(13))
            .foregroundColor(.seilMuted2)
            .lineSpacing(4)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        
    }




    var bottomCTA: some View {
        VStack {
            Spacer()

            VStack(spacing: 0) {
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [Color.clear, Color.seilBg.opacity(0.85), Color.seilBg],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(height: 32)

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    if card.isComplete {
                        showRedeemSheet = true
                    } else {
                        showQRSheet = true
                    }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: card.isComplete ? "gift.fill" : "qrcode.viewfinder")
                            .font(.system(size: 18, weight: .semibold))

                        Text(card.isComplete ? "Canjear mi premio" : "Mostrar mi QR")
                            .font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(
                            colors: card.isComplete
                                ? [Color.seilGreen.opacity(0.95), Color.seilGreen]
                                : [Color.seilAccent, Color.seilAccent2],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .shadow(
                        color: (card.isComplete ? Color.seilGreen : Color.seilAccent).opacity(0.34),
                        radius: 16,
                        y: 8
                    )
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 20)
                .padding(.bottom, 26)
                .background(Color.seilBg)
            }
        }
    }

    var backButton: some View {
        Button {
            dismiss()
        } label: {
            Image(systemName: "chevron.left")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white)
                .frame(width: 38, height: 38)
                .glassEffect(in: Circle())
        }
        .buttonStyle(.plain)
    }

    func chip(system: String, text: String, tint: Color = .white) -> some View {
        HStack(spacing: 6) {
            Image(systemName: system)
                .font(.system(size: 10, weight: .bold))

            Text(text)
                .font(.system(size: 11, weight: .semibold))
                .lineLimit(1)
        }
        .foregroundColor(tint)
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Color.white.opacity(0.10))
        .clipShape(Capsule())
        .overlay(
            Capsule().stroke(Color.seilBorderGlass, lineWidth: 1)  // seilBorderGlass
        )
    }

}
