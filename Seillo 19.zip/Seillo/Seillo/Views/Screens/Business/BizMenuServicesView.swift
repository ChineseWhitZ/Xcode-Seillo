import SwiftUI

// ─── BizMenuServicesView ──────────────────────────────────────────────────────
//
// Gestión completa de items del negocio (menú, servicios, promos temporales).
// CRUD: crear, editar, eliminar, toggle disponibilidad.
//
// Ruta: Seillo/Views/Screens/Business/BizMenuServicesView.swift
// Acceso: BizMenuSheet o BizTabProfileView → "Carta y servicios"
// ─────────────────────────────────────────────────────────────────────────────

struct BizMenuServicesView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var items:      [NegocioItem] = []
    @State private var loading     = true
    @State private var showCreate  = false
    @State private var editingItem : NegocioItem? = nil
    @State private var appear:     Double = 0

    private let service: NegocioServiceProtocol = APINegocioService()

    private var grouped: [(String, [NegocioItem])] {
        let dict = Dictionary(grouping: items) { $0.grupo }
        return dict.sorted { $0.key < $1.key }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                if loading {
                    VStack(spacing: 16) {
                        ProgressView().tint(.seilAccent)
                        Text("Cargando items...")
                            .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                    }
                } else if items.isEmpty {
                    SeillEmptyState(
                        icon: "menucard",
                        title: "Sin items",
                        message: "Agrega productos o servicios para que tus clientes los vean.",
                        buttonTitle: "Crear item",
                        buttonAction: { showCreate = true }
                    )
                } else {
                    List {
                        ForEach(grouped, id: \.0) { group, groupItems in
                            Section {
                                ForEach(groupItems) { item in
                                    itemRow(item)
                                        .listRowBackground(Color.seilCard)
                                }
                                .onDelete { offsets in
                                    deleteItems(group: group, offsets: offsets, groupItems: groupItems)
                                }
                            } header: {
                                Text(group.uppercased())
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.seilMuted)
                                    .tracking(1.2)
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationTitle("Carta y servicios")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Haptics.tap()
                        showCreate = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.seilAccent)
                    }
                }
            }
            .sheet(isPresented: $showCreate) {
                ItemFormSheet(existingItem: nil) { request in
                    createItem(request)
                }
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
            }
            .sheet(item: $editingItem) { item in
                ItemFormSheet(existingItem: item) { request in
                    updateItem(id: item.id, request)
                }
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilSurface)
            }
        }
        .task { await loadItems() }
    }

    // MARK: - Item Row

    private func itemRow(_ item: NegocioItem) -> some View {
        Button {
            Haptics.tap()
            editingItem = item
        } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Text(item.nombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)

                        if !item.disponible {
                            SeillStatusBadge(text: "No disponible", color: .seilDanger, size: .small)
                        }
                    }

                    if let desc = item.descripcion, !desc.isEmpty {
                        Text(desc)
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                            .lineLimit(1)
                    }
                }

                Spacer()

                if let precio = item.precio {
                    Text("S/ \(String(format: "%.0f", precio))")
                        .font(SeillFont.label(14))
                        .foregroundColor(.seilAccent)
                }

                Image(systemName: "chevron.right")
                    .font(.system(size: 11))
                    .foregroundColor(.seilMuted)
            }
        }
        .buttonStyle(.plain)
    }

    // MARK: - Actions

    private func loadItems() async {
        let result = await service.getItems()
        if case .success(let data) = result { items = data }
        loading = false
    }

    private func createItem(_ request: NegocioItemRequest) {
        Task {
            let result = await service.crearItem(request)
            if case .success(let id) = result {
                let newItem = NegocioItem(
                    id: id, negocioId: "", grupo: request.grupo,
                    nombre: request.nombre, descripcion: request.descripcion,
                    precio: request.precio, duracionMin: request.duracionMin,
                    disponible: true, createdAt: "Ahora",
                    fechaInicio: request.fechaInicio, fechaFin: request.fechaFin
                )
                items.append(newItem)
            }
        }
    }

    private func updateItem(id: String, _ request: NegocioItemRequest) {
        Task {
            _ = await service.actualizarItem(id: id, request)
            if let idx = items.firstIndex(where: { $0.id == id }) {
                items[idx] = NegocioItem(
                    id: id, negocioId: items[idx].negocioId, grupo: request.grupo,
                    nombre: request.nombre, descripcion: request.descripcion,
                    precio: request.precio, duracionMin: request.duracionMin,
                    disponible: items[idx].disponible, createdAt: items[idx].createdAt,
                    fechaInicio: request.fechaInicio, fechaFin: request.fechaFin
                )
            }
        }
    }

    private func deleteItems(group: String, offsets: IndexSet, groupItems: [NegocioItem]) {
        for offset in offsets {
            let item = groupItems[offset]
            Task { _ = await service.eliminarItem(id: item.id) }
            items.removeAll { $0.id == item.id }
        }
    }
}

// MARK: - Item Form Sheet

private struct ItemFormSheet: View {
    let existingItem: NegocioItem?
    let onSave: (NegocioItemRequest) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var grupo       = "Bebidas"
    @State private var nombre      = ""
    @State private var descripcion = ""
    @State private var precioText  = ""
    @State private var duracionText = ""

    private let grupoOptions = ["Bebidas", "Comida", "Pastelería", "Servicios", "Promociones"]

    private var canSave: Bool {
        !nombre.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        // Grupo
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Categoría")
                                .font(SeillFont.label(12)).foregroundColor(.seilMuted2)
                            Picker("", selection: $grupo) {
                                ForEach(grupoOptions, id: \.self) { Text($0).tag($0) }
                            }
                            .pickerStyle(.segmented)
                        }

                        // Nombre
                        field("Nombre del item", text: $nombre, placeholder: "Ej: Americano")

                        // Descripción
                        field("Descripcion (opcional)", text: $descripcion, placeholder: "Ej: Shot doble, agua caliente")

                        // Precio
                        field("Precio en soles (opcional)", text: $precioText, placeholder: "Ej: 12", keyboard: .decimalPad)

                        // Duración
                        field("Duracion en min (opcional)", text: $duracionText, placeholder: "Ej: 30", keyboard: .numberPad)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    .padding(.bottom, 40)
                }
            }
            .navigationTitle(existingItem == nil ? "Nuevo item" : "Editar item")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancelar") { dismiss() }
                        .foregroundColor(.seilMuted2)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Haptics.success()
                        onSave(NegocioItemRequest(
                            grupo: grupo,
                            nombre: nombre.trimmingCharacters(in: .whitespaces),
                            descripcion: descripcion.isEmpty ? nil : descripcion,
                            precio: Double(precioText),
                            duracionMin: Int(duracionText),
                            fechaInicio: nil,
                            fechaFin: nil
                        ))
                        dismiss()
                    } label: {
                        Text("Guardar")
                            .font(SeillFont.label(14))
                            .foregroundColor(canSave ? .seilAccent : .seilMuted)
                    }
                    .disabled(!canSave)
                }
            }
        }
        .onAppear {
            if let item = existingItem {
                grupo       = item.grupo
                nombre      = item.nombre
                descripcion = item.descripcion ?? ""
                precioText  = item.precio.map { String(format: "%.0f", $0) } ?? ""
                duracionText = item.duracionMin.map { String($0) } ?? ""
            }
        }
    }

    private func field(_ label: String, text: Binding<String>, placeholder: String, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(SeillFont.label(12)).foregroundColor(.seilMuted2)
            TextField(placeholder, text: text)
                .font(SeillFont.body(14)).foregroundColor(.seilText)
                .keyboardType(keyboard)
                .padding(14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
        }
    }
}
