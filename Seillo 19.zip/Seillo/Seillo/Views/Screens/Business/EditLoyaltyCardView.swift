import SwiftUI

// ─── EditLoyaltyCardView ──────────────────────────────────────────────────────
//
// Edición de un programa de fidelización existente.
// Permite cambiar nombre, meta de sellos, y texto del premio.
// Preview en vivo de la tarjeta con los cambios.
//
// Ruta: Seillo/Views/Screens/Business/EditLoyaltyCardView.swift
// Acceso: BizTabProfileView → botón editar en cada programa
// ─────────────────────────────────────────────────────────────────────────────

struct EditLoyaltyCardView: View {
    let programaId: String
    let onSaved: () -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var nombre     = ""
    @State private var sellosMeta = 10
    @State private var premio     = ""
    @State private var loading    = true
    @State private var saving     = false
    @State private var saveSuccess = false

    private let service: NegocioServiceProtocol = APINegocioService()

    private var canSave: Bool {
        !nombre.trimmingCharacters(in: .whitespaces).isEmpty &&
        !premio.trimmingCharacters(in: .whitespaces).isEmpty &&
        sellosMeta >= 3 && sellosMeta <= 30
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.seilBg.ignoresSafeArea()

                if loading {
                    VStack(spacing: 16) {
                        ProgressView().tint(.seilAccent)
                        Text("Cargando programa...")
                            .font(SeillFont.body(13)).foregroundColor(.seilMuted)
                    }
                } else {
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 24) {
                            // ── Preview ──────────────────────────────
                            previewCard
                                .padding(.top, 8)

                            // ── Campos ───────────────────────────────
                            formFields

                            // ── Guardar ──────────────────────────────
                            saveSection
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 40)
                    }
                }
            }
            .navigationTitle("Editar programa")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        Haptics.tap()
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                    }
                }
            }
        }
        .task {
            let result = await service.getProgramas()
            if case .success(let programas) = result,
               let prog = programas.first(where: { $0.id == programaId }) {
                nombre     = prog.nombre
                sellosMeta = prog.sellosMeta
                premio     = prog.premio
            }
            loading = false
        }
    }

    // MARK: - Preview Card

    private var previewCard: some View {
        VStack(spacing: 12) {
            Text("PREVIEW")
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.5)

            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(Color.seilAccent.opacity(0.15))
                            .frame(width: 36, height: 36)
                        Image(systemName: "cup.and.saucer.fill")
                            .font(.system(size: 15))
                            .foregroundColor(.seilAccent)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(nombre.isEmpty ? "Nombre del programa" : nombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(nombre.isEmpty ? .seilMuted : .seilText)
                        Text(premio.isEmpty ? "Premio por completar" : premio)
                            .font(SeillFont.body(11))
                            .foregroundColor(premio.isEmpty ? .seilMuted : .seilMuted2)
                    }
                    Spacer()
                    Text("0/\(sellosMeta)")
                        .font(SeillFont.label(12))
                        .foregroundColor(.seilAccent)
                }

                // Mock stamps row
                HStack(spacing: 4) {
                    ForEach(0..<min(sellosMeta, 15), id: \.self) { i in
                        Circle()
                            .fill(i < 3 ? Color.seilAccent : Color.seilCard2)
                            .frame(width: sellosMeta > 10 ? 18 : 24,
                                   height: sellosMeta > 10 ? 18 : 24)
                            .overlay(
                                Circle().stroke(Color.seilAccent.opacity(i < 3 ? 0.5 : 0.15), lineWidth: 1)
                            )
                    }
                    if sellosMeta > 15 {
                        Text("+\(sellosMeta - 15)")
                            .font(SeillFont.caption(10))
                            .foregroundColor(.seilMuted)
                    }
                    Spacer()
                }
            }
            .padding(16)
            .background(
                LinearGradient(
                    colors: [Color(hex: "#1A0800"), Color(hex: "#3D1A00"), Color(hex: "#6B2E00")],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
        }
    }

    // MARK: - Form

    private var formFields: some View {
        VStack(alignment: .leading, spacing: 18) {
            // Nombre
            VStack(alignment: .leading, spacing: 6) {
                Text("Nombre del programa")
                    .font(SeillFont.label(12)).foregroundColor(.seilMuted2)
                TextField("Ej: Cafe a eleccion", text: $nombre)
                    .font(SeillFont.body(14)).foregroundColor(.seilText)
                    .padding(14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            }

            // Meta de sellos
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Meta de sellos")
                        .font(SeillFont.label(12)).foregroundColor(.seilMuted2)
                    Spacer()
                    Text("\(sellosMeta) sellos")
                        .font(SeillFont.headline(14)).foregroundColor(.seilAccent)
                }

                HStack(spacing: 16) {
                    Button {
                        Haptics.tap()
                        if sellosMeta > 3 { sellosMeta -= 1 }
                    } label: {
                        Image(systemName: "minus.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(sellosMeta > 3 ? .seilAccent : .seilMuted)
                    }
                    .buttonStyle(.plain)
                    .disabled(sellosMeta <= 3)

                    Slider(value: Binding(
                        get: { Double(sellosMeta) },
                        set: { sellosMeta = Int($0) }
                    ), in: 3...30, step: 1)
                    .tint(.seilAccent)

                    Button {
                        Haptics.tap()
                        if sellosMeta < 30 { sellosMeta += 1 }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(sellosMeta < 30 ? .seilAccent : .seilMuted)
                    }
                    .buttonStyle(.plain)
                    .disabled(sellosMeta >= 30)
                }
            }

            // Premio
            VStack(alignment: .leading, spacing: 6) {
                Text("Premio al completar")
                    .font(SeillFont.label(12)).foregroundColor(.seilMuted2)
                TextField("Ej: Cafe gratis", text: $premio)
                    .font(SeillFont.body(14)).foregroundColor(.seilText)
                    .padding(14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            }
        }
    }

    // MARK: - Save

    private var saveSection: some View {
        VStack(spacing: 8) {
            if saveSuccess {
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                    Text("Programa actualizado")
                        .font(SeillFont.headline(14))
                }
                .foregroundColor(.seilGreen)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(Color.seilGreen.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .transition(.opacity)
            } else {
                Button {
                    guard canSave else { return }
                    Haptics.success()
                    saving = true
                    Task {
                        _ = await service.updatePrograma(
                            id: programaId,
                            nombre: nombre,
                            sellosMeta: sellosMeta,
                            premio: premio
                        )
                        saving = false
                        withAnimation { saveSuccess = true }
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                        onSaved()
                        dismiss()
                    }
                } label: {
                    HStack(spacing: 8) {
                        if saving {
                            ProgressView().tint(.white).scaleEffect(0.8)
                        } else {
                            Text("Guardar cambios")
                                .font(SeillFont.label(15))
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .foregroundColor(.white)
                    .background(canSave ? Color.seilAccent : Color.seilAccent.opacity(0.35))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: canSave ? Color.seilAccent.opacity(0.28) : .clear, radius: 12, y: 6)
                }
                .buttonStyle(.plain)
                .disabled(!canSave || saving)
            }
        }
    }
}
