import SwiftUI

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BizTabDashboardView
// ═══════════════════════════════════════════════════════════════════════════════


// ─── Helpers del Dashboard ────────────────────────────────────────────────────

private func formatActivityTime(_ iso: String) -> String {
    let fmts = ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ss"]
    for fmt in fmts {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = fmt
        if let date = f.date(from: iso) {
            let mins = Int(-date.timeIntervalSinceNow / 60)
            switch mins {
            case 0..<60:  return "Hace \(mins)m"
            case 60..<120: return "Hace 1h"
            default:      return "Hace \(mins/60)h"
            }
        }
    }
    return ""
}

struct ActivityItem: Identifiable {
    let id = UUID()
    let name: String
    let initial: String
    let stamps: Int
    let total: Int
    let filled: Int
    let color: Color
    let time: String
    var redeemed: Bool = false
}

struct BizTabDashboardView: View {
    @EnvironmentObject var bizStore: BizProfileStore
    @State private var listAnim: Double = 0
    @State private var showCampaigns = false
    @State private var showCreateProgram = false
    @State private var showPlanesDash = false
    @State private var showAnalytics = false
    @State private var showSendPushDash = false
    @State private var showAutomation   = false

    @State private var subscription: BusinessSubscription = .mockFree

    @State private var activity    : [ActivityItem]     = []
    @State private var dashStats   : DashboardDTO?       = nil
    @State private var semanaData  : [(String, Int, Bool)] = []
    @State private var distribucion: DistribucionDTO?    = nil

    private var weekTotal: Int {
        semanaData.reduce(0) { $0 + $1.1 }
    }

    private func aAlpha(_ i: Int) -> Double {
        let s = min(Double(i) * 0.09, 0.55)
        let e = min(s + 0.45, 1.0)
        let raw = (listAnim - s) / (e - s)
        return Swift.max(0, Swift.min(1, raw))
    }

    private func aOffset(_ i: Int) -> CGFloat {
        CGFloat(16 * (1 - aAlpha(i)))
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                SeillContentBox {
                    LazyVStack(spacing: 0) {
                        dashboardHeader
                            .padding(.horizontal, 22)
                            .padding(.top, 18)
                            .padding(.bottom, 18)

                        // ── Checklist de primeros pasos ──────────────────
                        OnboardingChecklist(
                            subscription: subscription,
                            onNavigate: { destino in
                                switch destino {
                                case .crearTarjeta, .configurarRecompensa:
                                    showCreateProgram = true
                                case .crearLocal:
                                    showPlanesDash = true
                                case .activarQr:
                                    break   // el QR está en la tab Escanear
                                case .invitarStaff:
                                    break   // TODO: pantalla de staff
                                }
                            }
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                        .opacity(aAlpha(0))
                        .offset(y: aOffset(0))

                        // ── Uso del plan ──────────────────────────────────
                        PlanUsageCard(
                            subscription: subscription,
                            onUpgrade: { showPlanesDash = true }
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 18)
                        .opacity(aAlpha(0))
                        .offset(y: aOffset(0))

                        quickSummaryCard
                            .padding(.horizontal, 16)
                            .padding(.bottom, 18)

                        actionInsightCard
                            .padding(.horizontal, 16)
                            .padding(.bottom, 18)
                            .opacity(aAlpha(1))
                            .offset(y: aOffset(1))
                            .animation(SeillAnimation.listEntrance, value: listAnim)

                        AdaptiveStatGrid(stats: dashStats)

                        chartSection
                            .padding(.horizontal, 16)
                            .padding(.bottom, 18)

                        retentionPanel
                            .padding(.horizontal, 16)
                            .padding(.bottom, 18)

                        AdaptiveQuickActions(
                            showCreateProgram: $showCreateProgram,
                            showCampaigns: $showCampaigns,
                            showPlanesDash: $showPlanesDash,
                            showAnalytics: $showAnalytics,
                            showSendPushDash: $showSendPushDash,
                            showAutomation: $showAutomation
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 18)
                        .opacity(aAlpha(4))
                        .offset(y: aOffset(4))
                        .animation(.easeOut(duration: 0.4).delay(0.10), value: listAnim)

                        HStack {
                            Text(SeillStrings.biz.recentActivity)
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.seilMuted)
                                .tracking(1.5)

                            Spacer()

                            Text("\(activity.count) movimientos")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundColor(.seilAccent)
                        }
                        .padding(.horizontal, 22)
                        .padding(.bottom, 10)
                        .opacity(aAlpha(8))

                        ForEach(Array(activity.enumerated()), id: \.element.id) { i, item in
                            ActivityRow(item: item)
                                .opacity(aAlpha(9))
                                .offset(y: aOffset(9))
                                .animation(
                                    .easeOut(duration: 0.4).delay(0.22 + Double(i) * 0.05),
                                    value: listAnim
                                )
                        }

                        Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                    }
                }
            }
        }
        .sheet(isPresented: $showCampaigns) {
            BizCampaignsView()
                .presentationBackground(Color.seilBg)
        }
        .sheet(isPresented: $showCreateProgram) {
            CreateProgramView()
                .presentationBackground(Color.seilBg)
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showPlanesDash) {
            PlanesView()
        }
        .sheet(isPresented: $showAnalytics) {
            BizAnalyticsView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showSendPushDash) {
            SendPushView()
                .environmentObject(bizStore)
        }
        .sheet(isPresented: $showAutomation) {
            BizAutomationView(subscription: subscription)
        }
        .task {
            withAnimation(SeillAnimation.chrome) { listAnim = 1.0 }

            // Cargar todo en paralelo
            async let planResult  = APIClient.shared.get("api/negocio/plan-info") as PlanInfoDTO
            async let dashResult  = APIClient.shared.get("api/negocio/dashboard") as DashboardDTO
            async let semResult   = APIClient.shared.get("api/negocio/semana") as [SemanaDTO]
            async let distResult  = APIClient.shared.get("api/negocio/distribucion") as DistribucionDTO

            if let dto = try? await planResult {
                subscription = BusinessSubscription(
                    plan             : PlanCatalog.fromString(dto.plan),
                    clientesActuales : dto.uso?.clientesUnicos ?? 0
                )
            }

            if let dto = try? await dashResult {
                dashStats = dto
                let actColors: [Color] = [.seilBlue, .seilPurple, .seilGold, .seilGreen, .seilRose, .seilAccent]
                activity = dto.actividadReciente.enumerated().map { idx, a in
                    let inicial  = String(a.clienteNombre.prefix(1)).uppercased()
                    let esCanjeado = a.tipo == "canje"
                    return ActivityItem(
                        name     : a.clienteNombre,
                        initial  : inicial,
                        stamps   : esCanjeado ? 0 : 1,
                        total    : 10,
                        filled   : 5,
                        color    : actColors[idx % actColors.count],
                        time     : formatActivityTime(a.createdAt),
                        redeemed : esCanjeado
                    )
                }
            }

            if let dtos = try? await semResult {
                semanaData = dtos.map { ($0.label, $0.total, $0.esHoy) }
            }

            if let dto = try? await distResult {
                distribucion = dto
            }

            // Top clientes — solo si hay analytics disponibles
            if let tops = try? await APIClient.shared.get("api/negocio/analytics/top-clientes") as [AnalyticsTopClienteDTO] {
                let topColors: [Color] = [.seilPurple, .seilBlue, .seilAccent, .seilGold, .seilGreen]
                topClients = tops.prefix(3).enumerated().map { idx, t in
                    TopClient(
                        name    : t.nombre,
                        initial : String(t.nombre.prefix(1)).uppercased(),
                        color   : topColors[idx % topColors.count],
                        stamps  : t.visitas
                    )
                }
            }
        }
    }

    private func quickActionButton(icon: String, label: String, color: Color, action: @escaping () -> Void) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        } label: {
            VStack(spacing: 8) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(color.opacity(0.12))
                        .frame(width: 48, height: 48)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(color.opacity(0.22), lineWidth: 1))

                    Image(systemName: icon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(color)
                }

                Text(label)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted2)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var dashboardHeader: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(SeillStrings.biz.dashboard)
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted2)

                HStack(spacing: 8) {
                    Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundColor(.seilText)

                    Text(SeillStrings.biz.openStatus)
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.seilGreen)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(Color.seilGreen.opacity(0.15))
                        .clipShape(RoundedRectangle(cornerRadius: 7))
                }

                Text("Hoy estás viendo el resumen de actividad, sellos y canjes")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
            }

            Spacer()

            ZStack {
                Circle()
                    .fill(Color.seilGold.opacity(0.15))
                    .frame(width: 46, height: 46)
                    .overlay(
                        Circle().stroke(Color.seilGold.opacity(0.3), lineWidth: 1)
                    )

                Image(systemName: bizStore.profile.categoriaIcon)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundColor(.seilGold)
            }
        }
        .opacity(aAlpha(0))
        .offset(y: aOffset(0))
    }

    private var quickSummaryCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.seilAccent.opacity(0.14))
                    .frame(width: 54, height: 54)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.seilAccent.opacity(0.22), lineWidth: 1)
                    )

                Image(systemName: "bolt.fill")
                    .font(.system(size: 22))
                    .foregroundColor(.seilAccent)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Resumen rápido")
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(.seilText)

                Text("Tu local registró \(weekTotal) movimientos esta semana y hoy mantiene una actividad positiva.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .lineSpacing(3)
            }

            Spacer()
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [Color.white.opacity(0.035), Color.white.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .background(.ultraThinMaterial.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .shadow(color: Color.seilAccent.opacity(0.08), radius: 12, y: 4)
        .opacity(aAlpha(1))
        .offset(y: aOffset(1))
    }

    private var chartSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Sellos esta semana")
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)

                    Text("Tendencia semanal de actividad")
                        .font(.system(size: 11))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                Text("Total: \(weekTotal)")
                    .font(SeillFont.label(11))
                    .foregroundColor(.seilAccent)
            }

            WeekBarChart(data: semanaData)
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(aAlpha(1))
        .offset(y: aOffset(1))
    }

    private var retentionPanel: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Retención de clientes")
                        .font(SeillFont.headline(13))
                        .foregroundColor(.seilText)

                    Text("Últimos 30 días")
                        .font(.system(size: 11))
                        .foregroundColor(.seilMuted)
                }

                Spacer()

                HStack(spacing: 5) {
                    Image(systemName: "arrow.trianglehead.2.counterclockwise.rotate.90")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilGreen)

                    Text(distribucion.map { "\($0.regularesPct + $0.ocasionalesPct)%" } ?? "—")
                        .font(.system(size: 13, weight: .heavy))
                        .foregroundColor(.seilGreen)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Color.seilGreen.opacity(0.10))
                .clipShape(Capsule())
                .overlay(
                    Capsule().stroke(Color.seilGreen.opacity(0.25), lineWidth: 1)
                )
            }

            HStack(spacing: 20) {
                ZStack {
                    Circle()
                        .stroke(Color.seilBorder, lineWidth: 10)
                        .frame(width: 90, height: 90)

                    Circle()
                        .trim(from: 0, to: listAnim > 0.3 ? distribucion.map { Double($0.regularesPct + $0.ocasionalesPct) / 100.0 } ?? 0.75 : 0)
                        .stroke(
                            Color.seilGreen,
                            style: StrokeStyle(lineWidth: 10, lineCap: .round)
                        )
                        .frame(width: 90, height: 90)
                        .rotationEffect(.degrees(-90))
                        .animation(
                            .easeOut(duration: 1.1).delay(0.2),
                            value: listAnim
                        )

                    VStack(spacing: 1) {
                        Text(distribucion.map { "\($0.regularesPct + $0.ocasionalesPct)%" } ?? "—")
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                            .foregroundColor(.seilText)

                        Text("vuelven")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundColor(.seilMuted)
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    RetentionBar(
                        label: "Regulares",
                        pct: distribucion.map { Double($0.regularesPct) / 100.0 } ?? 0.60,
                        count: distribucion.map { "\($0.regulares)" } ?? "—",
                        color: .seilAccent,
                        appear: listAnim > 0.3
                    )

                    RetentionBar(
                        label: "Ocasionales",
                        pct: distribucion.map { Double($0.ocasionalesPct) / 100.0 } ?? 0.24,
                        count: distribucion.map { "\($0.ocasionales)" } ?? "—",
                        color: .seilBlue,
                        appear: listAnim > 0.3
                    )

                    RetentionBar(
                        label: "Nuevos",
                        pct: distribucion.map { Double($0.nuevosPct) / 100.0 } ?? 0.16,
                        count: distribucion.map { "\($0.nuevos)" } ?? "—",
                        color: .seilGreen,
                        appear: listAnim > 0.3
                    )
                }
                .frame(maxWidth: .infinity)
            }

            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)

            VStack(alignment: .leading, spacing: 12) {
                Text("TOP CLIENTES DEL MES")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)

                ForEach(Array(topClients.enumerated()), id: \.offset) { i, client in
                    HStack(spacing: 12) {
                        Text("\(i + 1)")
                            .font(.system(size: 12, weight: .heavy, design: .rounded))
                            .foregroundColor(i == 0 ? .seilGold : .seilMuted)
                            .frame(width: 16)

                        ZStack {
                            Circle()
                                .fill(client.color.opacity(0.15))
                                .frame(width: 34, height: 34)

                            Text(client.initial)
                                .font(.system(size: 13, weight: .heavy))
                                .foregroundColor(client.color)
                        }

                        Text(client.name)
                            .font(SeillFont.headline(13))
                            .foregroundColor(.seilText)

                        Spacer()

                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .font(.system(size: 10))
                                .foregroundColor(.seilGold)

                            Text("\(client.stamps)")
                                .font(.system(size: 12, weight: .heavy))
                                .foregroundColor(.seilText)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.seilGold.opacity(0.08))
                        .clipShape(Capsule())
                        .overlay(
                            Capsule().stroke(Color.seilGold.opacity(0.2), lineWidth: 1)
                        )
                    }
                    .opacity(aAlpha(3))
                    .offset(y: aOffset(3))
                    .animation(
                        .easeOut(duration: 0.35).delay(0.3 + Double(i) * 0.06),
                        value: listAnim
                    )
                }
            }
        }
        .padding(18)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .opacity(aAlpha(2))
        .offset(y: aOffset(2))
    }

    private struct TopClient {
        let name: String
        let initial: String
        let color: Color
        let stamps: Int
    }

    @State private var topClients: [TopClient] = []

    // ── Insight accionable ──────────────────────────────────────────────────
    // Clientes que están a 3 sellos o menos de completar su tarjeta (sin canje).
    // Si no hay ninguno, el panel no aparece.
    private var clientsNearReward: [ActivityItem] {
        activity.filter { !$0.redeemed && ($0.total - $0.filled) <= 3 }
    }

    @ViewBuilder
    private var actionInsightCard: some View {
        if !clientsNearReward.isEmpty {
            let count   = clientsNearReward.count
            let first   = clientsNearReward[0]
            let stampsLeft = first.total - first.filled

            VStack(spacing: 0) {
                // ── Cabecera ────────────────────────────────────────────
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 13)
                            .fill(Color.seilGold.opacity(0.14))
                            .frame(width: 44, height: 44)
                            .overlay(
                                RoundedRectangle(cornerRadius: 13)
                                    .stroke(Color.seilGold.opacity(0.26), lineWidth: 1)
                            )

                        Image(systemName: "gift.circle.fill")
                            .font(.system(size: 21, weight: .semibold))
                            .foregroundColor(.seilGold)
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 5) {
                            Text("OPORTUNIDAD HOY")
                                .font(.system(size: 9, weight: .black))
                                .foregroundColor(.seilGold)
                                .tracking(1.2)

                            Circle()
                                .fill(Color.seilGold)
                                .frame(width: 4, height: 4)
                        }

                        if count == 1 {
                            Text("\(first.name) está a \(stampsLeft) sello\(stampsLeft == 1 ? "" : "s") de canjear su premio.")
                                .font(SeillFont.body(12))
                                .foregroundColor(.seilText)
                                .lineSpacing(2)
                        } else {
                            Text("\(first.name) y \(count - 1) cliente\(count - 1 == 1 ? "" : "s") más están cerca de canjear.")
                                .font(SeillFont.body(12))
                                .foregroundColor(.seilText)
                                .lineSpacing(2)
                        }
                    }

                    Spacer()
                }

                // ── Chips de clientes + CTA ──────────────────────────────
                HStack(spacing: 8) {
                    // Avatars de los clientes cercanos (máx 3)
                    HStack(spacing: 4) {
                        ForEach(Array(clientsNearReward.prefix(3).enumerated()), id: \.offset) { _, item in
                            HStack(spacing: 5) {
                                ZStack {
                                    Circle()
                                        .fill(item.color.opacity(0.20))
                                        .frame(width: 20, height: 20)
                                    Text(item.initial)
                                        .font(.system(size: 9, weight: .heavy))
                                        .foregroundColor(item.color)
                                }
                                Text(item.name)
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundColor(.seilMuted2)
                                    .lineLimit(1)
                                Text("· faltan \(item.total - item.filled)")
                                    .font(.system(size: 9, weight: .medium))
                                    .foregroundColor(.seilMuted)
                            }
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.seilCard2)
                            .clipShape(Capsule())
                            .overlay(
                                Capsule().stroke(Color.seilBorder, lineWidth: 0.5)
                            )
                        }
                    }

                    Spacer()

                    // Botón CTA
                    Button {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        showSendPushDash = true
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 11, weight: .semibold))
                            Text("Enviar push")
                                .font(.system(size: 11, weight: .bold))
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            LinearGradient(
                                colors: [Color.seilGold, Color.seilGold.opacity(0.85)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .shadow(color: Color.seilGold.opacity(0.35), radius: 8, y: 3)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 12)
            }
            .padding(16)
            .background(
                LinearGradient(
                    colors: [Color.seilGold.opacity(0.07), Color.seilGold.opacity(0.02)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.seilGold.opacity(0.22), lineWidth: 1)
            )
            .shadow(color: Color.seilGold.opacity(0.08), radius: 12, y: 4)
        }
    }
}

private struct RetentionBar: View {
    let label: String
    let pct: Double
    let count: String
    let color: Color
    let appear: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                HStack(spacing: 5) {
                    Circle()
                        .fill(color)
                        .frame(width: 7, height: 7)

                    Text(label)
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                }

                Spacer()

                Text(count)
                    .font(.system(size: 11, weight: .heavy))
                    .foregroundColor(.seilText)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(Color.seilBorder)
                        .frame(height: 5)

                    Capsule()
                        .fill(color)
                        .frame(
                            width: appear ? geo.size.width * pct : 0,
                            height: 5
                        )
                        .animation(
                            .easeOut(duration: 0.9).delay(0.3),
                            value: appear
                        )
                }
            }
            .frame(height: 5)
        }
    }
}

private struct AdaptiveStatGrid: View {
    let stats: DashboardDTO?
    @Environment(\.horizontalSizeClass) private var hSizeClass

    var body: some View {
        let cols = hSizeClass == .regular
            ? Array(repeating: GridItem(.flexible()), count: 4)
            : [GridItem(.flexible()), GridItem(.flexible())]

        LazyVGrid(columns: cols, spacing: 10) {
            BizStatCard(
                label: "Sellos hoy",
                value: stats.map { "\($0.sellosHoy)" } ?? "—",
                icon: "star.fill", color: .seilAccent,
                delta: nil, positive: nil
            )
            BizStatCard(
                label: "Clientes hoy",
                value: stats.map { "\($0.clientesHoy)" } ?? "—",
                icon: "person.2.fill", color: .seilBlue,
                delta: nil, positive: nil
            )
            BizStatCard(
                label: "Canjes hoy",
                value: stats.map { "\($0.canjesHoy)" } ?? "—",
                icon: "trophy.fill", color: .seilGold,
                delta: nil, positive: nil
            )
            BizStatCard(
                label: "Esta semana",
                value: stats == nil ? "—" : "Ver",
                icon: "chart.bar.fill", color: .seilGreen,
                delta: nil, positive: nil
            )
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 18)
    }
}

private struct AdaptiveQuickActions: View {
    @Binding var showCreateProgram: Bool
    @Binding var showCampaigns: Bool
    @Binding var showPlanesDash: Bool
    @Binding var showAnalytics: Bool
    @Binding var showSendPushDash: Bool
    @Binding var showAutomation: Bool

    @Environment(\.horizontalSizeClass) private var hSizeClass

    private struct ActionItem: Identifiable {
        let id = UUID()
        let icon: String
        let label: String
        let color: Color
        let action: () -> Void
    }

    var body: some View {
        let items: [ActionItem] = [
            .init(icon: "plus.circle.fill", label: "Nuevo programa", color: .seilAccent) { showCreateProgram = true },
            .init(icon: "megaphone.fill", label: "Campañas", color: .seilBlue) { showCampaigns = true },
            .init(icon: "crown.fill", label: "Planes", color: .seilGold) { showPlanesDash = true },
            .init(icon: "chart.line.uptrend.xyaxis", label: "Analytics", color: .seilPurple) { showAnalytics = true },
            .init(icon: "bell.badge.fill", label: "Notif. push", color: .seilBlue) { showSendPushDash = true },
            .init(icon: "bolt.badge.clock.fill", label: "Automatizar", color: .seilAccent) { showAutomation = true },
        ]

        if hSizeClass == .regular {
            HStack(spacing: 10) {
                ForEach(items) { item in
                    quickButton(item)
                }
            }
        } else {
            VStack(spacing: 10) {
                HStack(spacing: 10) {
                    ForEach(items.prefix(3)) { item in
                        quickButton(item)
                    }
                }
                HStack(spacing: 10) {
                    ForEach(items.suffix(3)) { item in
                        quickButton(item)
                    }
                }
            }
        }
    }

    private func quickButton(_ item: ActionItem) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            item.action()
        } label: {
            VStack(spacing: 8) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(item.color.opacity(0.12))
                        .frame(width: 48, height: 48)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(item.color.opacity(0.22), lineWidth: 1)
                        )

                    Image(systemName: item.icon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(item.color)
                }

                Text(item.label)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted2)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.seilBorder, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct BizStatCard: View {
    let label: String
    let value: String
    let icon: String
    let color: Color
    let delta: String?
    let positive: Bool?

    var deltaColor: Color {
        guard let p = positive else { return .seilMuted }
        return p ? .seilGreen : .seilRose
    }
    var hasDelta: Bool { delta != nil }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color.opacity(0.12))
                    .frame(width: 34, height: 34)

                Image(systemName: icon)
                    .font(.system(size: 14))
                    .foregroundColor(color)
            }

            Spacer().frame(height: 12)

            Text(value)
                .font(.system(size: 24, weight: .heavy))
                .foregroundColor(.seilText)
                .lineLimit(1)

            Spacer().frame(height: 2)

            Text(label)
                .font(.system(size: 9 + SeillLayout.tinyFontBoost, weight: .semibold))
                .foregroundColor(.seilMuted2)
                .lineLimit(1)

            Spacer().frame(height: 6)

            if let d = delta {
                Text(d)
                    .font(.system(size: 8 + SeillLayout.tinyFontBoost, weight: .semibold))
                    .foregroundColor(deltaColor)
                    .lineLimit(1)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
    }
}

struct WeekBarChart: View {
    let data: [(String, Int, Bool)]

    // MEDIO: antes maxVal = 28 hardcodeado — si un día supera 28 sellos
    // la barra se recorta o desborda. Ahora se computa del dato real
    // con un mínimo de 1 para evitar división por cero.
    private var maxVal: Int {
        max(1, data.map(\.1).max() ?? 1)
    }

    @Environment(\.horizontalSizeClass) private var hSizeClass
    @State private var barScales: [Double] = []

    private var chartHeight: CGFloat {
        hSizeClass == .regular ? SeillLayout.chartHeightIPad : 100
    }

    private var barMaxHeight: CGFloat {
        chartHeight - 36
    }

    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            ForEach(Array(data.enumerated()), id: \.offset) { i, item in
                let (day, value, isToday) = item
                let pct = Double(value) / Double(maxVal)
                let scale = i < barScales.count ? barScales[i] : 0.0

                VStack(spacing: 6) {
                    Text("\(value)")
                        .font(.system(size: 9 + SeillLayout.tinyFontBoost, weight: .bold))
                        .foregroundColor(isToday ? .seilAccent : .seilMuted)
                        .opacity(scale)

                    RoundedRectangle(cornerRadius: 7)
                        .fill(
                            isToday
                            ? LinearGradient(
                                colors: [Color.seilAccent, Color.seilAccent2],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                            : LinearGradient(
                                colors: [Color.seilAccent.opacity(0.28), Color.seilAccent.opacity(0.14)],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(height: max(2, barMaxHeight * pct * scale))

                    Text(day)
                        .font(.system(size: 8 + SeillLayout.tinyFontBoost, weight: isToday ? .bold : .regular))
                        .foregroundColor(isToday ? .seilAccent : .seilMuted)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: chartHeight)
        .task {
            barScales = Array(repeating: 0.0, count: data.count)
            try? await Task.sleep(nanoseconds: 200_000_000)
            for i in data.indices {
                withAnimation(.easeOut(duration: 0.55)) {
                    barScales[i] = 1.0
                }
                try? await Task.sleep(nanoseconds: 45_000_000)
            }
        }
    }
}

struct ActivityRow: View {
    let item: ActivityItem

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(item.color.opacity(0.15))
                    .frame(width: 40, height: 40)

                Text(item.initial)
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(item.color)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(item.name)
                    .font(SeillFont.headline(13 + SeillLayout.tinyFontBoost))
                    .foregroundColor(.seilText)

                HStack(spacing: 3) {
                    ForEach(0..<item.total, id: \.self) { i in
                        Circle()
                            .fill(i < item.filled ? item.color : Color.seilBorder)
                            .frame(width: SeillLayout.activityDotSize, height: SeillLayout.activityDotSize)
                    }
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 5) {
                if item.redeemed {
                    HStack(spacing: 5) {
                        Image(systemName: "gift.fill")
                            .font(.system(size: 11 + SeillLayout.tinyFontBoost))
                            .foregroundColor(.seilGold)

                        Text("Canje")
                            .font(.system(size: 9 + SeillLayout.tinyFontBoost, weight: .bold))
                            .foregroundColor(.seilGold)
                    }
                    .padding(.horizontal, 7)
                    .padding(.vertical, 3)
                    .background(Color.seilGold.opacity(0.15))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                } else {
                    Text("+\(item.stamps) sello\(item.stamps > 1 ? "s" : "")")
                        .font(.system(size: 9 + SeillLayout.tinyFontBoost, weight: .bold))
                        .foregroundColor(.seilAccent)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.seilAccent.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                }

                Text(item.time)
                    .font(.system(size: 9 + SeillLayout.tinyFontBoost))
                    .foregroundColor(.seilMuted)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(
            LinearGradient(
                colors: [Color.seilCard, Color.seilCard.opacity(0.96)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.seilBorder, lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
    }
}
