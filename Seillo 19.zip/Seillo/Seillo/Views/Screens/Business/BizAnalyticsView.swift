import SwiftUI

// ─── BizAnalyticsView ─────────────────────────────────────────────────────────
// Secciones:
//   1. KPI strip — retención %, visitas/cliente, ticket estimado, activos hoy
//   2. Toggle de período: Semana / Mes / Trimestre
//   3. Gráfico de línea — visitas en el período
//   4. Retención con gauge animado
//   5. Hora pico del día
//   6. Top clientes por visitas
//   7. Completaciones de tarjeta
// Acceso: BizTabDashboardView → botón "Analytics"
// ─────────────────────────────────────────────────────────────────────────────

// ── Modelos ───────────────────────────────────────────────────────────────────

private enum AnalyticsPeriod: String, CaseIterable {
    case week    = "Semana"
    case month   = "Mes"
    case quarter = "Trimestre"
}

private struct LinePoint: Identifiable {
    let id    = UUID()
    let label: String
    let value: Double
}

private struct HourBar: Identifiable {
    let id     = UUID()
    let hour:  String
    let pct:   Double
    let isPeak: Bool
}

// ── Vista principal ───────────────────────────────────────────────────────────

struct BizAnalyticsView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var period: AnalyticsPeriod = .week
    @State private var appear = false
    @State private var showExport = false

    // ── Datos reales del backend ──────────────────────────────────────────
    private let service: NegocioServiceProtocol = APINegocioService()
    @State private var kpisData: AnalyticsKPIs? = nil
    @State private var visitasByPeriod: [String: [LinePoint]] = [:]
    @State private var horasData: [HourBar] = []
    @State private var topClientesData: [AnalyticsTopCliente] = []
    @State private var completacionesByPeriod: [String: [(String, Double)]] = [:]
    @State private var completacionesTotal: Int = 0
    @State private var analyticsLoading = true

    private var currentPoints: [LinePoint] {
        visitasByPeriod[period.rawValue] ?? []
    }
    private var currentCompletaciones: [(String, Double)] {
        completacionesByPeriod[period.rawValue] ?? []
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 14) {
                        Spacer().frame(height: 4)
                        kpiStrip
                        periodToggle
                        lineChartCard
                        retentionCard
                        hourPeakCard
                        topClientsCard
                        completionsCard
                        Spacer().frame(height: 40)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                }
            }
        }
        .sheet(isPresented: $showExport) {
            ExportView().environmentObject(bizStore)
        }
        .task {
            await loadAnalytics(periodo: period.rawValue)
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
        .onChange(of: period) { _, newPeriod in
            Task { await loadAnalytics(periodo: newPeriod.rawValue) }
        }
    }

    // MARK: - Load analytics

    private func loadAnalytics(periodo: String) async {
        analyticsLoading = true

        // KPIs — solo se cargan una vez (no dependen de período)
        if kpisData == nil {
            if case .success(let k) = await service.getAnalyticsKPIs() {
                kpisData = k
            }
        }

        // Las cuatro llamadas que dependen del período en paralelo
        async let visitasResult   = service.getAnalyticsVisitas(periodo: periodo)
        async let horasResult     = service.getAnalyticsHoras(periodo: periodo)
        async let topResult       = service.getAnalyticsTopClientes(periodo: periodo)
        async let compResult      = service.getAnalyticsCompletaciones(periodo: periodo)

        if case .success(let v) = await visitasResult {
            visitasByPeriod[periodo] = v.map { LinePoint(label: $0.label, value: Double($0.value)) }
        }
        if case .success(let h) = await horasResult {
            horasData = h.map { HourBar(hour: $0.label, pct: $0.pct, isPeak: $0.isPeak) }
        }
        if case .success(let t) = await topResult {
            topClientesData = t
        }
        if case .success(let c) = await compResult {
            completacionesByPeriod[periodo] = c.puntos
            completacionesTotal = c.totalMes
        }

        analyticsLoading = false
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tap(); dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()
                VStack(spacing: 2) {
                    Text("Analytics").font(SeillFont.headline(15)).foregroundColor(Color.seilText)
                    if !bizStore.profile.nombre.isEmpty {
                        Text(bizStore.profile.nombre)
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(.seilMuted)
                    }
                }
                Spacer()

                // Exportar (Premium)
                Button {
                    Haptics.tap()
                    showExport = true
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "lock.fill")
                            .font(.system(size: 10, weight: .bold))
                        Text("Exportar")
                            .font(SeillFont.label(12))
                    }
                    .foregroundColor(Color.seilGold)
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(Color.seilGold.opacity(0.10))
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.seilGold.opacity(0.25), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 14)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - 1. KPI Strip

    private var kpisForCategory: [(String, String, String, Bool, Color, String)] {
        switch bizStore.profile.categoriaId {
        case "cafe":
            return [
                ("72%",  "Retención",       "+8%",   true,  Color.seilGreen,   "arrow.trianglehead.2.counterclockwise.rotate.90"),
                ("4.2",  "Visitas/cliente", "↑ 0.8", true,  Color.seilBlue,    "person.fill"),
                ("S/18", "Ticket est.",     "+S/2",  true,  Color.seilPurple,  "creditcard.fill"),
                ("38",   "Activos hoy",     "+5",    true,  Color.seilAccent,  "person.2.fill"),
            ]
        case "barberia":
            return [
                ("84%",  "Retención",       "+15%",  true,  Color.seilGreen,   "arrow.trianglehead.2.counterclockwise.rotate.90"),
                ("2.1",  "Visitas/cliente", "↑ 0.3", true,  Color.seilBlue,    "person.fill"),
                ("S/32", "Ticket est.",     "+S/4",  true,  Color.seilPurple,  "creditcard.fill"),
                ("22",   "Activos hoy",     "+2",    true,  Color.seilAccent,  "person.2.fill"),
            ]
        case "restaurante":
            return [
                ("61%",  "Retención",       "+6%",   true,  Color.seilGreen,   "arrow.trianglehead.2.counterclockwise.rotate.90"),
                ("2.8",  "Visitas/cliente", "↑ 0.4", true,  Color.seilBlue,    "person.fill"),
                ("S/42", "Ticket est.",     "+S/5",  true,  Color.seilPurple,  "creditcard.fill"),
                ("54",   "Activos hoy",     "−2",    false, Color.seilAccent,  "person.2.fill"),
            ]
        default:
            return [
                ("68%",  "Retención",       "+12%",  true,  Color.seilGreen,   "arrow.trianglehead.2.counterclockwise.rotate.90"),
                ("3.4",  "Visitas/cliente", "↑ 0.6", true,  Color.seilBlue,    "person.fill"),
                ("S/24", "Ticket est.",     "+S/3",  true,  Color.seilPurple,  "creditcard.fill"),
                ("47",   "Activos hoy",     "−3",    false, Color.seilAccent,  "person.2.fill"),
            ]
        }
    }

    private var kpiStrip: some View {
        // Usa datos reales del backend si están disponibles; fallback a kpisForCategory mientras carga.
        let kpis: [(String, String, String, Bool, Color, String)] = {
            guard let k = kpisData else { return kpisForCategory }
            return [
                ("\(k.retencionPct)%", "Retención",     "—", true,  Color.seilGreen,  "arrow.trianglehead.2.counterclockwise.rotate.90"),
                ("\(k.totalClientes)", "Clientes",       "—", true,  Color.seilBlue,   "person.fill"),
                ("\(k.totalSellos)",   "Sellos totales", "—", true,  Color.seilPurple, "seal.fill"),
                ("\(k.totalCanjes)",   "Canjes totales", "—", true,  Color.seilAccent, "gift.fill"),
            ]
        }()

        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            ForEach(Array(kpis.enumerated()), id: \.offset) { i, kpi in
                let (value, label, delta, positive, color, icon) = kpi
                VStack(alignment: .leading, spacing: 0) {
                    Image(systemName: icon)
                        .font(.system(size: 13))
                        .foregroundColor(color)

                    Spacer().frame(height: 8)

                    Text(value)
                        .font(.system(size: 22, weight: .heavy))
                        .foregroundColor(Color.seilText)

                    Spacer().frame(height: 2)

                    Text(label)
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.seilMuted2)

                    Spacer().frame(height: 5)

                    Text(delta)
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(positive ? Color.seilGreen : Color.seilRose)
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(color.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(color.opacity(0.18), lineWidth: 1))
                .opacity(appear ? 1 : 0)
                .offset(y: appear ? 0 : 12)
                .animation(SeillAnimation.chrome.delay(Double(i) * 0.07), value: appear)
            }
        }
    }

    // MARK: - 2. Period Toggle

    private var periodToggle: some View {
        HStack(spacing: 8) {
            ForEach(AnalyticsPeriod.allCases, id: \.rawValue) { p in
                let active = period == p
                Button {
                    Haptics.tap()
                    withAnimation(.easeOut(duration: 0.22)) { period = p }
                } label: {
                    Text(p.rawValue)
                        .font(.system(size: 13, weight: active ? .heavy : .medium))
                        .foregroundColor(active ? .white : .seilMuted2)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(active ? Color.seilAccent : Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(active ? Color.clear : Color.seilBorder, lineWidth: 1)
                        )
                        .shadow(color: active ? Color.seilAccent.opacity(0.35) : .clear, radius: 8, y: 3)
                        .animation(SeillAnimation.chrome, value: period)
                }
                .buttonStyle(.plain)
            }
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - 3. Line Chart

    private var lineChartCard: some View {
        analyticsCard(title: "VISITAS EN EL PERÍODO") {
            SeilloLineChart(points: currentPoints, color: Color.seilAccent)
                .frame(height: 130)
                .animation(.easeInOut(duration: 0.35), value: period)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.10), value: appear)
    }

    // MARK: - 4. Retention

    private var retentionCard: some View {
        analyticsCard(title: "RETENCIÓN DE CLIENTES") {
            HStack(spacing: 20) {
                RetentionGauge(pct: kpisData.map { Double($0.retencionPct) / 100.0 } ?? 0.68)
                    .frame(width: 100, height: 100)

                VStack(alignment: .leading, spacing: 10) {
                    retentionBar(label: "Volvieron",     pct: kpisData.map { Double($0.retencionPct) / 100.0 } ?? 0.68, color: Color.seilGreen)
                    retentionBar(label: "No volvieron",  pct: kpisData.map { 1 - Double($0.retencionPct) / 100.0 } ?? 0.32, color: Color.seilRose)

                    Text("+12% vs mes anterior")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(Color.seilGreen)
                        .padding(.horizontal, 10).padding(.vertical, 4)
                        .background(Color.seilGreen.opacity(0.10))
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(Color.seilGreen.opacity(0.25), lineWidth: 1))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.14), value: appear)
    }

    private func retentionBar(label: String, pct: Double, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label).font(.system(size: 11)).foregroundColor(.seilMuted2)
                Spacer()
                Text("\(Int(pct * 100))%").font(.system(size: 11, weight: .heavy)).foregroundColor(color)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.06)).frame(height: 5)
                    Capsule().fill(color).frame(width: geo.size.width * pct, height: 5)
                }
            }
            .frame(height: 5)
        }
    }

    // MARK: - 5. Hour peak

    private var peakHourLabel: String {
        if let peak = horasData.first(where: { $0.isPeak }) { return peak.hour }
        switch bizStore.profile.categoriaId {
        case "cafe":     return "9am"
        case "barberia": return "5pm"
        default:         return "1pm"
        }
    }

    private var hourPeakCard: some View {
        analyticsCard(title: "HORA PICO DEL DÍA") {
            VStack(spacing: 8) {
                HourPeakChart(bars: horasData)
                    .frame(height: 80)

                HStack(spacing: 8) {
                    Image(systemName: "clock.fill")
                        .font(.system(size: 12))
                        .foregroundColor(Color.seilBlue)
                    Text("Hora pico: \(peakHourLabel) · Prepara más personal en este horario")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                }
                .padding(12)
                .background(Color.seilBlue.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.seilBlue.opacity(0.18), lineWidth: 1))
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.18), value: appear)
    }

    // MARK: - 6. Top clients

    private var topClientsCard: some View {
        analyticsCard(title: "TOP CLIENTES DEL PERÍODO") {
            VStack(spacing: 0) {
                let palette: [Color] = [.seilAccent, .seilBlue, .seilPurple, .seilGreen, .seilGold]
                // Usa datos reales si disponibles, si no muestra los mocks mientras carga
                let items: [(nombre: String, visitas: Int, sellos: Int)] = topClientesData.map { (nombre: $0.nombre, visitas: $0.visitas, sellos: $0.sellos) }

                ForEach(Array(items.enumerated()), id: \.offset) { i, client in
                    let color = palette[i % palette.count]
                    HStack(spacing: 10) {
                        Text("#\(i + 1)")
                            .font(.system(size: 12, weight: .heavy))
                            .foregroundColor(i == 0 ? Color.seilGold : Color.seilMuted)
                            .frame(width: 24)

                        ZStack {
                            Circle().fill(color.opacity(0.15)).frame(width: 34, height: 34)
                                .overlay(Circle().stroke(color.opacity(0.30), lineWidth: 1))
                            Text(String(client.nombre.prefix(1)))
                                .font(.system(size: 13, weight: .heavy))
                                .foregroundColor(color)
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            Text(client.nombre).font(SeillFont.headline(13)).foregroundColor(Color.seilText)
                            Text("\(client.sellos) sellos acumulados").font(SeillFont.body(11)).foregroundColor(.seilMuted2)
                        }

                        Spacer()

                        Text("\(client.visitas) visitas")
                            .font(.system(size: 11, weight: .heavy))
                            .foregroundColor(color)
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(color.opacity(0.10))
                            .clipShape(Capsule())
                    }
                    .padding(.vertical, 8)

                    if i < items.count - 1 {
                        Divider().background(Color.seilBorder)
                    }
                }
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.22), value: appear)
    }

    // MARK: - 7. Completions

    private var completionsCard: some View {
        let data: [(String, Double)] = currentCompletaciones.isEmpty
            ? [("Sem 1", 4), ("Sem 2", 7), ("Sem 3", 6), ("Sem 4", 11)]
            : currentCompletaciones
        let maxVal = data.map(\.1).max() ?? 1
        let badge = completacionesTotal > 0 ? "\(completacionesTotal) este período" : "este período"

        return analyticsCard(title: "COMPLETACIONES DE TARJETA", badge: badge, badgeColor: Color.seilPurple) {
            VStack(spacing: 8) {
                HStack(alignment: .bottom, spacing: 10) {
                    ForEach(data, id: \.0) { label, val in
                        VStack(spacing: 4) {
                            Text("\(Int(val))")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(Color.seilPurple)

                            RoundedRectangle(cornerRadius: 6)
                                .fill(
                                    LinearGradient(
                                        colors: [Color.seilPurple, Color.seilPurple.opacity(0.35)],
                                        startPoint: .top, endPoint: .bottom
                                    )
                                )
                                .frame(height: appear ? max(16, 64 * val / maxVal) : 2)
                                .animation(.easeOut(duration: 0.7).delay(0.25), value: appear)

                            Text(label)
                                .font(.system(size: 10))
                                .foregroundColor(Color.seilMuted)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 90)

                HStack(spacing: 8) {
                    Image(systemName: "lightbulb.fill")
                        .font(.system(size: 12))
                        .foregroundColor(Color.seilPurple)
                    Text("La semana 4 tiene 2.7× más canjes. Considera lanzar una campaña en semana 1.")
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                        .lineSpacing(3)
                }
                .padding(12)
                .background(Color.seilPurple.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.seilPurple.opacity(0.18), lineWidth: 1))
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.26), value: appear)
    }

    // MARK: - Card wrapper

    private func analyticsCard<Content: View>(
        title: String,
        badge: String? = nil,
        badgeColor: Color = Color.seilAccent,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(title)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(Color.seilMuted)
                    .tracking(1.2)

                Spacer()

                if let badge {
                    Text(badge)
                        .font(.system(size: 9, weight: .heavy))
                        .foregroundColor(badgeColor)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(badgeColor.opacity(0.12))
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(badgeColor.opacity(0.25), lineWidth: 1))
                }
            }
            content()
        }
        .padding(16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
    }
}

// ─── SeilloLineChart ──────────────────────────────────────────────────────────

private struct SeilloLineChart: View {
    let points: [LinePoint]
    let color:  Color

    @State private var progress: Double = 0

    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { geo in
                let w = geo.size.width
                let h = geo.size.height
                let maxV = points.map(\.value).max() ?? 1
                let minV = points.map(\.value).min() ?? 0
                let range = maxV - minV == 0 ? 1 : maxV - minV
                let step = points.count > 1 ? w / Double(points.count - 1) : w

                let pts: [CGPoint] = points.enumerated().map { i, p in
                    CGPoint(x: Double(i) * step, y: h - ((p.value - minV) / range) * h)
                }

                ZStack {
                    // Fill gradient
                    if pts.count >= 2 {
                        Path { path in
                            path.move(to: CGPoint(x: pts[0].x, y: h))
                            pts.forEach { path.addLine(to: $0) }
                            path.addLine(to: CGPoint(x: pts.last!.x, y: h))
                            path.closeSubpath()
                        }
                        .fill(
                            LinearGradient(
                                colors: [color.opacity(0.22), Color.clear],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                    }

                    // Grid lines
                    ForEach(0..<4, id: \.self) { i in
                        let y = h / 3.0 * Double(i)
                        Path { p in p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: w, y: y)) }
                            .stroke(Color.white.opacity(0.04), lineWidth: 1)
                    }

                    // Line — drawn to progress
                    if pts.count >= 2 {
                        let visibleCount = Int(progress * Double(pts.count - 1))
                        let partial      = progress * Double(pts.count - 1) - Double(visibleCount)
                        let visiblePts   = Array(pts.prefix(visibleCount + 1))
                        let lastPt: CGPoint? = visibleCount < pts.count - 1
                            ? CGPoint(
                                x: pts[visibleCount].x + (pts[visibleCount + 1].x - pts[visibleCount].x) * partial,
                                y: pts[visibleCount].y + (pts[visibleCount + 1].y - pts[visibleCount].y) * partial
                              )
                            : nil

                        Path { path in
                            guard let first = visiblePts.first else { return }
                            path.move(to: first)
                            visiblePts.dropFirst().forEach { path.addLine(to: $0) }
                            if let lp = lastPt { path.addLine(to: lp) }
                        }
                        .stroke(color, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))

                        // Dot
                        if let dot = lastPt ?? pts.last {
                            Circle().fill(color).frame(width: 8, height: 8)
                                .position(dot)
                            Circle().fill(Color.white).frame(width: 4, height: 4)
                                .position(dot)
                        }
                    }
                }
            }

            // X labels
            HStack(spacing: 0) {
                ForEach(points) { pt in
                    Text(pt.label)
                        .font(.system(size: 9))
                        .foregroundColor(Color.seilMuted)
                        .frame(maxWidth: .infinity)
                }
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.8).delay(0.1)) { progress = 1.0 }
        }
        .onChange(of: points.count) { _, _ in
            progress = 0
            withAnimation(.easeOut(duration: 0.6)) { progress = 1.0 }
        }
    }
}

// ─── RetentionGauge ───────────────────────────────────────────────────────────

private struct RetentionGauge: View {
    let pct: Double
    @State private var arcProgress: Double = 0

    var body: some View {
        ZStack {
            // Track
            Circle()
                .trim(from: 0, to: 0.75)
                .stroke(Color.white.opacity(0.06), style: StrokeStyle(lineWidth: 12, lineCap: .round))
                .rotationEffect(.degrees(135))

            // Fill
            Circle()
                .trim(from: 0, to: 0.75 * arcProgress)
                .stroke(
                    LinearGradient(
                        colors: [Color.seilGreen, Color.seilBlue],
                        startPoint: .leading, endPoint: .trailing
                    ),
                    style: StrokeStyle(lineWidth: 12, lineCap: .round)
                )
                .rotationEffect(.degrees(135))
                .animation(.easeOut(duration: 1.0).delay(0.2), value: arcProgress)

            VStack(spacing: 1) {
                Text("\(Int(pct * 100))%")
                    .font(.system(size: 18, weight: .heavy, design: .rounded))
                    .foregroundColor(Color.seilText)
                Text("retención")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(Color.seilMuted)
            }
        }
        .onAppear { arcProgress = pct }
    }
}

// ─── HourPeakChart ────────────────────────────────────────────────────────────

private struct HourPeakChart: View {
    /// Barras reales del backend (si están disponibles) o fallback a mock por categoría.
    var bars: [HourBar]
    @State private var barProgress: Double = 0

    var body: some View {
        HStack(alignment: .bottom, spacing: 3) {
            ForEach(Array(bars.enumerated()), id: \.element.id) { i, bar in
                VStack(spacing: 4) {
                    Spacer()

                    RoundedRectangle(cornerRadius: 4)
                        .fill(bar.isPeak ? Color.seilGold : Color.seilAccent.opacity(0.25))
                        .frame(height: max(4, 56 * bar.pct * barProgress))
                        .animation(.easeOut(duration: 0.6).delay(Double(i) * 0.03), value: barProgress)

                    Text(i % 2 == 0 ? bar.hour : "")
                        .font(.system(size: 7, weight: bar.isPeak ? .bold : .regular))
                        .foregroundColor(bar.isPeak ? Color.seilGold : Color.seilMuted)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .onAppear { withAnimation(.easeOut(duration: 0.7)) { barProgress = 1.0 } }
        .onChange(of: bars.count) { _, _ in
            barProgress = 0
            withAnimation(.easeOut(duration: 0.7)) { barProgress = 1.0 }
        }
    }
}
