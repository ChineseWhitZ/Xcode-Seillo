import SwiftUI
import AVFoundation

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BizTabScanView
// ═══════════════════════════════════════════════════════════════════════════════

struct BizTabScanView: View {
    @State private var showSuccess        = false
    @State private var appear             = false
    @State private var isScannerActive    = true
    @State private var scannedResult:    ScannedClient?   = nil

    // ── Multi-programa ───────────────────────────────────────────────────
    @State private var programas:          [ProgramaItem]  = []
    @State private var loadingProgramas    = true
    @State private var scannedQR:          String?          = nil
    @State private var showProgramaPicker: Bool             = false

    // ── Estado de red ────────────────────────────────────────────────────
    @State private var isProcessing        = false
    @State private var errorMsg:           String?          = nil

    private let negocioService: NegocioServiceProtocol = APINegocioService()

    struct ScannedClient {
        let rawCode         : String
        var nombre          : String  = "Cliente"
        var sellos          : Int     = 0
        var total           : Int     = 10
        var premioListo     : Bool    = false
        var campaniaActiva  : String? = nil
    }

    // ── Carga de programas ───────────────────────────────────────────────

    private func cargarProgramas() async {
        loadingProgramas = true
        let result = await negocioService.getProgramas()
        loadingProgramas = false
        switch result {
        case .success(let lista):
            programas = lista
                .filter { $0.activo }
                .map { ProgramaItem(id: $0.id, nombre: $0.nombre, sellosMeta: $0.sellosMeta, premio: $0.premio) }
        case .failure:
            programas = []
        }
    }

    // ── Flujo QR detectado ───────────────────────────────────────────────

    private func onQRDetected(_ code: String) {
        guard !showSuccess && !showProgramaPicker && !isProcessing else { return }
        isScannerActive = false
        switch programas.count {
        case 0:
            isScannerActive = true
        case 1:
            Task { await sellarDirecto(qr: code, programaId: programas[0].id) }
        default:
            scannedQR = code
            withAnimation(SeillAnimation.chrome) { showProgramaPicker = true }
        }
    }

    private func onProgramaSelected(_ programaId: String) {
        let qr = scannedQR ?? ""
        withAnimation(SeillAnimation.chrome) { showProgramaPicker = false }
        scannedQR = nil
        Task { await sellarDirecto(qr: qr, programaId: programaId) }
    }

    private func onDismissPicker() {
        withAnimation(SeillAnimation.chrome) { showProgramaPicker = false }
        scannedQR = nil
        isScannerActive = true
    }

    // ── Llamada real al backend ──────────────────────────────────────────

    private func sellarDirecto(qr: String, programaId: String) async {
        isProcessing = true
        errorMsg = nil

        // El APINegocioService.escanearQR toma el primer programa activo,
        // pero aquí ya sabemos el programaId elegido — llamamos directamente.
        do {
            let body = EscanearRequest(qrCode: qr, programaId: programaId)
            let dto: EscanearDTO = try await APIClient.shared.post("api/negocio/escanear", body: body)
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            scannedResult = ScannedClient(
                rawCode:        qr,
                nombre:         dto.clienteNombre,
                sellos:         dto.sellosActuales,
                total:          dto.sellosTotal,
                premioListo:    dto.premioListo,
                campaniaActiva: dto.campaniaActiva
            )
            showSuccess = true
        } catch let error as APIError {
            UINotificationFeedbackGenerator().notificationOccurred(.error)
            errorMsg = error.localizedDescription
            isScannerActive = true
        } catch {
            UINotificationFeedbackGenerator().notificationOccurred(.error)
            errorMsg = "QR inválido o expirado"
            isScannerActive = true
        }

        isProcessing = false
    }

    // ── Body ─────────────────────────────────────────────────────────────

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                SeillContentBox {
                    VStack(spacing: 0) {
                        headerSection
                            .padding(.horizontal, 22)
                            .padding(.top, 18)
                            .padding(.bottom, 18)

                        quickGuideCard
                            .padding(.horizontal, 16)
                            .padding(.bottom, 18)

                        // ── Banner de error ────────────────────────────────
                        if let msg = errorMsg {
                            HStack(spacing: 10) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.seilRose)
                                Text(msg)
                                    .font(SeillFont.body(13))
                                    .foregroundColor(.seilRose)
                                Spacer()
                                Button { errorMsg = nil } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 12, weight: .bold))
                                        .foregroundColor(.seilMuted)
                                }
                            }
                            .padding(14)
                            .background(Color.seilRose.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilRose.opacity(0.25), lineWidth: 1))
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                            .transition(.move(edge: .top).combined(with: .opacity))
                        }

                        // ── Estado de carga de programas ───────────────────
                        if loadingProgramas {
                            HStack(spacing: 10) {
                                ProgressView()
                                    .scaleEffect(0.8)
                                Text("Cargando programas...")
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted)
                            }
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                        } else if programas.isEmpty {
                            HStack(spacing: 10) {
                                Image(systemName: "creditcard.trianglebadge.exclamationmark")
                                    .foregroundColor(.seilGold)
                                Text("No tienes programas activos. Crea uno para empezar a sellar.")
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted)
                            }
                            .padding(14)
                            .background(Color.seilGold.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilGold.opacity(0.22), lineWidth: 1))
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                        }

                        // ── Selector de programa activo (1 programa) ───────
                        if programas.count == 1 {
                            HStack(spacing: 10) {
                                Image(systemName: "checkmark.seal.fill")
                                    .foregroundColor(.seilAccent)
                                    .font(.system(size: 14))
                                Text(programas[0].nombre)
                                    .font(SeillFont.label(13))
                                    .foregroundColor(.seilText)
                                Spacer()
                                Text("\(programas[0].sellosMeta) sellos")
                                    .font(SeillFont.caption(11))
                                    .foregroundColor(.seilMuted2)
                            }
                            .padding(12)
                            .background(Color.seilAccent.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilAccent.opacity(0.20), lineWidth: 1))
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                        }

                        scannerCard
                            .padding(.horizontal, 16)
                            .frame(maxWidth: isIPad ? 480 : .infinity)
                            .frame(maxWidth: .infinity)
                            .padding(.bottom, 12)

                        // ── Overlay de procesamiento ───────────────────────
                        if isProcessing {
                            HStack(spacing: 10) {
                                ProgressView()
                                    .scaleEffect(0.85)
                                Text("Registrando sello...")
                                    .font(SeillFont.body(13))
                                    .foregroundColor(.seilMuted)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                        }

                        instructionFlow
                            .padding(.horizontal, 20)
                            .padding(.bottom, 28)

                        actionHintCard
                            .padding(.horizontal, 16)

                        Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                    }
                }
            }
        }
        // ── Picker de programa ─────────────────────────────────────────────
        .overlay(alignment: .bottom) {
            if showProgramaPicker {
                Color.black.opacity(0.55)
                    .ignoresSafeArea()
                    .onTapGesture { onDismissPicker() }
                    .overlay(alignment: .bottom) {
                        ProgramaPickerSheet(
                            programas:  programas,
                            onSelected: { id in onProgramaSelected(id) },
                            onCancel:   { onDismissPicker() }
                        )
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
            }
        }
        .animation(SeillAnimation.chrome, value: showProgramaPicker)
        .animation(SeillAnimation.chrome, value: errorMsg)
        .sheet(isPresented: $showSuccess, onDismiss: {
            isScannerActive = true
        }) {
            ScanSuccessSheet(
                clienteName:    scannedResult?.nombre      ?? "Cliente",
                sellos:         scannedResult?.sellos      ?? 0,
                total:          scannedResult?.total       ?? 10,
                premioListo:    scannedResult?.premioListo ?? false,
                campaniaActiva: scannedResult?.campaniaActiva
            )
            .presentationDetents(adaptiveDetents(height: 420))
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .task { await cargarProgramas() }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
            isScannerActive = true
        }
        .onDisappear {
            isScannerActive = false
        }
    }

    // MARK: - Subviews

    private var headerSection: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(SeillStrings.scan.title)
                    .font(SeillFont.body(11))
                    .foregroundColor(.seilMuted2)

                Text(SeillStrings.scan.giveStamp)
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)

                Text("Escanea el QR del cliente para registrar un sello o validar un canje")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
            }

            Spacer()

            ZStack {
                Circle()
                    .fill(Color.seilAccent.opacity(0.14))
                    .frame(width: 46, height: 46)
                    .overlay(Circle().stroke(Color.seilAccent.opacity(0.24), lineWidth: 1))

                Image(systemName: "qrcode.viewfinder")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(.seilAccent)
            }
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    private var quickGuideCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.seilGold.opacity(0.14))
                    .frame(width: 54, height: 54)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilGold.opacity(0.24), lineWidth: 1))

                Image(systemName: "bolt.fill")
                    .font(.system(size: 22))
                    .foregroundColor(.seilGold)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Escaneo rápido")
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(.seilText)

                Text("Apunta al QR, valida al cliente y registra el sello en segundos.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .lineSpacing(3)
            }

            Spacer()
        }
        .padding(16)
        .background(LinearGradient(colors: [Color.white.opacity(0.035), Color.white.opacity(0.02)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .background(.ultraThinMaterial.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08), lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 16)
    }

    private var scannerCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("CÁMARA DE ESCANEO")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.seilMuted)
                    .tracking(1.4)

                Spacer()

                let status = AVCaptureDevice.authorizationStatus(for: .video)
                if status == .authorized {
                    HStack(spacing: 5) {
                        Circle().fill(Color.seilGreen).frame(width: 6, height: 6)
                        Text(SeillStrings.scan.live)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.seilGreen)
                    }
                } else if status == .denied {
                    Text("Sin permiso")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.seilRose)
                }
            }

            QRScannerContainerView(isActive: $isScannerActive) { code in
                onQRDetected(code)
            }
            .aspectRatio(1, contentMode: .fit)
        }
        .padding(16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 16)
    }

    private var instructionFlow: some View {
        VStack(spacing: 16) {
            Text("Así funciona")
                .font(SeillFont.headline(13))
                .foregroundColor(.seilText)

            HStack(spacing: 8) {
                instruccion(icon: "iphone", label: "Cliente abre\nSeillo")
                Image(systemName: "arrow.right").font(.system(size: 14)).foregroundColor(.seilMuted)
                instruccion(icon: "qrcode.viewfinder", label: "Tú\nescaneas")
                Image(systemName: "arrow.right").font(.system(size: 14)).foregroundColor(.seilMuted)
                instruccion(icon: "star.fill", label: "Sello\nregistrado")
            }
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 18)
    }

    private var actionHintCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12).fill(Color.seilAccent.opacity(0.12)).frame(width: 42, height: 42)
                Image(systemName: "info.circle.fill").font(.system(size: 18)).foregroundColor(.seilAccent)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text("Consejo")
                    .font(.system(size: 13, weight: .heavy))
                    .foregroundColor(.seilText)

                Text("Mantén el QR centrado dentro del marco para un reconocimiento más rápido.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted)
                    .lineSpacing(3)
            }

            Spacer()
        }
        .padding(16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 18)
    }

    private func instruccion(icon: String, label: String) -> some View {
        VStack(spacing: 5) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(Color.seilAccent.opacity(0.12)).frame(width: 38, height: 38)
                Image(systemName: icon).font(.system(size: 14, weight: .semibold)).foregroundColor(.seilAccent)
            }
            Text(label).font(.system(size: 9)).foregroundColor(.seilMuted).multilineTextAlignment(.center).lineSpacing(2)
        }
    }
}

// ─── ProgramaItem ─────────────────────────────────────────────────────────────

struct ProgramaItem: Identifiable {
    let id:         String
    let nombre:     String
    let sellosMeta: Int
    let premio:     String
}

// ─── ProgramaPickerSheet ──────────────────────────────────────────────────────

private struct ProgramaPickerSheet: View {
    let programas:  [ProgramaItem]
    let onSelected: (String) -> Void
    let onCancel:   () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 32, height: 4)
                .padding(.top, 12)
                .padding(.bottom, 16)

            Image(systemName: "rectangle.stack.fill")
                .font(.system(size: 26, weight: .semibold))
                .foregroundColor(.seilAccent)
                .padding(.bottom, 10)

            Text("¿A qué tarjeta va el sello?")
                .font(.system(size: 17, weight: .heavy, design: .rounded))
                .foregroundColor(.seilText)

            Text("Este cliente tiene tarjetas en varios programas")
                .font(SeillFont.body(12))
                .foregroundColor(.seilMuted2)
                .padding(.top, 4)
                .padding(.bottom, 20)

            VStack(spacing: 10) {
                ForEach(programas) { programa in
                    Button {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        onSelected(programa.id)
                    } label: {
                        HStack(spacing: 14) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.seilAccent.opacity(0.12))
                                    .frame(width: 42, height: 42)
                                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilAccent.opacity(0.22), lineWidth: 1))
                                Image(systemName: "creditcard.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.seilAccent)
                            }

                            VStack(alignment: .leading, spacing: 3) {
                                Text(programa.nombre)
                                    .font(SeillFont.headline(14))
                                    .foregroundColor(.seilText)
                                    .lineLimit(1)
                                Text("\(programa.sellosMeta) sellos · \(programa.premio)")
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted2)
                                    .lineLimit(1)
                            }

                            Spacer()

                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.seilMuted)
                        }
                        .padding(14)
                        .background(Color.seilCard)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder.opacity(0.5), lineWidth: 1))
                    }
                    .buttonStyle(CardPressStyle())
                }
            }
            .padding(.horizontal, 24)

            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                onCancel()
            } label: {
                Text("Cancelar")
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilMuted2)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            .padding(.top, 6)
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
        }
        .frame(maxWidth: .infinity)
        .background(Color.seilSurface)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: .black.opacity(0.3), radius: 24, y: -8)
    }
}

// ─── ScannerCorners ───────────────────────────────────────────────────────────

struct ScannerCorners: View {
    var body: some View {
        ZStack {
            corner(top: true, left: true)
            corner(top: true, left: false)
            corner(top: false, left: true)
            corner(top: false, left: false)
        }
    }

    private func corner(top: Bool, left: Bool) -> some View {
        VStack {
            if !top { Spacer() }
            HStack {
                if !left { Spacer() }
                CornerShape(top: top, left: left)
                    .stroke(Color.seilAccent, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .frame(width: 30, height: 30)
                    .padding(14)
                if left { Spacer() }
            }
            if top { Spacer() }
        }
    }
}

struct CornerShape: Shape {
    let top: Bool
    let left: Bool

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height

        if top && left {
            p.move(to: CGPoint(x: w, y: 0))
            p.addLine(to: CGPoint(x: 0, y: 0))
            p.addLine(to: CGPoint(x: 0, y: h))
        } else if top && !left {
            p.move(to: CGPoint(x: 0, y: 0))
            p.addLine(to: CGPoint(x: w, y: 0))
            p.addLine(to: CGPoint(x: w, y: h))
        } else if !top && left {
            p.move(to: CGPoint(x: 0, y: 0))
            p.addLine(to: CGPoint(x: 0, y: h))
            p.addLine(to: CGPoint(x: w, y: h))
        } else {
            p.move(to: CGPoint(x: w, y: 0))
            p.addLine(to: CGPoint(x: w, y: h))
            p.addLine(to: CGPoint(x: 0, y: h))
        }

        return p
    }
}

// ─── ScanSuccessSheet ─────────────────────────────────────────────────────────

struct ScanSuccessSheet: View {
    let clienteName    : String
    let sellos         : Int
    let total          : Int
    let premioListo    : Bool
    var campaniaActiva : String? = nil

    @Environment(\.dismiss) var dismiss

    var body: some View {
        SeillSheetBox {
            VStack(spacing: 0) {
                Capsule()
                    .fill(Color.seilBorder)
                    .frame(width: 36, height: 4)
                    .padding(.top, 12)

                Spacer().frame(height: 24)

                ZStack {
                    Circle()
                        .fill(Color.seilGreen.opacity(0.15))
                        .frame(width: 72, height: 72)
                    Image(systemName: "checkmark")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.seilGreen)
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Sello registrado exitosamente")

                Spacer().frame(height: 16)

                Text(SeillStrings.scan.stampRegistered)
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)

                Spacer().frame(height: 6)

                Text("\(clienteName) · \(sellos)/\(total) sellos")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)

                // Banner de campaña activa
                if let campania = campaniaActiva {
                    Spacer().frame(height: 10)
                    HStack(spacing: 6) {
                        Image(systemName: campania == "happy_hour" ? "clock.fill" : "star.fill")
                            .foregroundColor(.seilAccent)
                            .font(.system(size: 11))
                        Text(campania == "double_stamps" ? "Doble sellos activos" : "Happy Hour activo")
                            .font(SeillFont.label(12))
                            .foregroundColor(.seilAccent)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(Color.seilAccent.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }

                if premioListo {
                    Spacer().frame(height: 12)
                    HStack(spacing: 6) {
                        Image(systemName: "trophy.fill").foregroundColor(.seilGold)
                        Text(SeillStrings.detail.rewardReady)
                            .font(SeillFont.headline(13))
                            .foregroundColor(.seilGold)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.seilGold.opacity(0.15))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Premio listo para canjear")
                } else {
                    Spacer().frame(height: 8)
                    Text("Faltan \(total - sellos) sellos para el premio")
                        .font(.system(size: 12))
                        .foregroundColor(.seilMuted)
                }

                Spacer().frame(height: 26)

                HStack(spacing: 8) {
                    ForEach(0..<total, id: \.self) { i in
                        Circle()
                            .fill(i < sellos ? Color.seilGreen : Color.white.opacity(0.08))
                            .frame(width: 12, height: 12)
                    }
                }

                Spacer().frame(height: 28)

                Button {
                    dismiss()
                } label: {
                    Text(SeillStrings.scan.keepScanning)
                        .font(SeillFont.headline(14))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color.seilAccent)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 24)

                Spacer().frame(height: 20)
            }
        }
    }
}
