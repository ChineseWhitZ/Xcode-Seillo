import SwiftUI

// ─── InviteClientsView ────────────────────────────────────────────────────────
// El negocio genera su QR personal + link de invitación para compartir
// con clientes por WhatsApp, Instagram, impreso, etc.
// Acceso: BizTabProfileView → "Invitar clientes"
// ─────────────────────────────────────────────────────────────────────────────

private struct ShareChannel: Identifiable {
    let id    = UUID()
    let icon:  String
    let label: String
    let color: Color
    let action: () -> Void
}

struct InviteClientsView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var appear       = false
    @State private var codeCopied   = false
    @State private var showQRLarge  = false

    private var inviteCode: String {
        let name = bizStore.profile.nombre
        let slug = name.lowercased()
            .replacingOccurrences(of: " ", with: "-")
            .filter { $0.isLetter || $0 == "-" }
        return slug.isEmpty ? "mi-negocio" : slug
    }

    private var inviteLink: String { "seillo.pe/unirse/\(inviteCode)" }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilAccent.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.10),
                startRadius: 0, endRadius: 300
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        Spacer().frame(height: 8)

                        // ── QR central ─────────────────────────────────────
                        qrSection

                        // ── Link copiable ──────────────────────────────────
                        linkSection

                        // ── Canales de share ───────────────────────────────
                        shareSection

                        // ── Stats motivacionales ───────────────────────────
                        statsSection

                        Spacer().frame(height: 40)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .sheet(isPresented: $showQRLarge) {
            QRFullscreenSheet(bizName: bizStore.profile.nombre, inviteLink: inviteLink)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
                .presentationBackground(Color.seilBg)
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button {
                    Haptics.tap()
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()

                Text("Invitar clientes")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)

                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 14)

            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - QR Section

    private var qrSection: some View {
        VStack(spacing: 16) {
            Text("TU CÓDIGO QR DE NEGOCIO")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)
                .frame(maxWidth: .infinity, alignment: .leading)

            // QR card
            VStack(spacing: 16) {
                // Header de la tarjeta
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.seilAccent.opacity(0.14))
                            .frame(width: 36, height: 36)
                        Image(systemName: bizStore.profile.categoriaIcon)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.seilAccent)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)
                        Text("Únete a mi programa de sellos")
                            .font(SeillFont.body(11))
                            .foregroundColor(.seilMuted2)
                    }

                    Spacer()
                }

                // QR visual
                Button {
                    Haptics.tap()
                    showQRLarge = true
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.white)
                            .frame(width: 190, height: 190)
                            .shadow(color: .black.opacity(0.18), radius: 16, y: 4)

                        InviteQRView(link: "https://\(inviteLink)")
                            .frame(width: 160, height: 160)

                        // Overlay con hint
                        VStack {
                            Spacer()
                            Text("Toca para ampliar")
                                .font(.system(size: 9, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color.black.opacity(0.50))
                                .clipShape(Capsule())
                                .padding(.bottom, 10)
                        }
                        .frame(width: 190, height: 190)
                    }
                }
                .buttonStyle(.plain)

                // Código debajo del QR
                HStack(spacing: 6) {
                    Image(systemName: "link")
                        .font(.system(size: 11))
                        .foregroundColor(.seilMuted)
                    Text(inviteLink)
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundColor(.seilMuted2)
                        .lineLimit(1)
                }
            }
            .padding(20)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.seilAccent.opacity(0.22), lineWidth: 1)
            )
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    // MARK: - Link Section

    private var linkSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("LINK DE INVITACIÓN")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)

            HStack(spacing: 12) {
                Image(systemName: "link")
                    .font(.system(size: 15))
                    .foregroundColor(.seilAccent)

                Text(inviteLink)
                    .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    .foregroundColor(.seilText)
                    .lineLimit(1)

                Spacer()

                Button {
                    UIPasteboard.general.string = "https://\(inviteLink)"
                    Haptics.success()
                    withAnimation { codeCopied = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                        withAnimation { codeCopied = false }
                    }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: codeCopied ? "checkmark" : "doc.on.doc")
                            .font(.system(size: 12, weight: .semibold))
                        Text(codeCopied ? "¡Copiado!" : "Copiar")
                            .font(SeillFont.label(12))
                    }
                    .foregroundColor(codeCopied ? .seilGreen : .seilAccent)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(codeCopied ? Color.seilGreen.opacity(0.10) : Color.seilAccent.opacity(0.10))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .animation(.easeInOut(duration: 0.22), value: codeCopied)
                }
                .buttonStyle(.plain)
            }
            .padding(14)
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(codeCopied ? Color.seilGreen.opacity(0.35) : Color.seilBorder, lineWidth: 1)
            )
            .animation(.easeInOut(duration: 0.22), value: codeCopied)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.10), value: appear)
    }

    // MARK: - Share Section

    private var shareSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("COMPARTIR POR")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.4)

            // ShareLink nativo de SwiftUI
            ShareLink(
                item: URL(string: "https://\(inviteLink)")!,
                subject: Text("Únete a mi programa de sellos"),
                message: Text("¡Acumula sellos y gana premios en \(bizStore.profile.nombre.isEmpty ? "mi negocio" : bizStore.profile.nombre)! Regístrate aquí: https://\(inviteLink)")
            ) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.seilAccent.opacity(0.12))
                            .frame(width: 44, height: 44)
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.seilAccent)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Compartir link")
                            .font(SeillFont.headline(14))
                            .foregroundColor(.seilText)
                        Text("WhatsApp, Instagram, impreso y más")
                            .font(SeillFont.body(12))
                            .foregroundColor(.seilMuted2)
                    }

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.seilMuted)
                }
                .padding(14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.seilAccent.opacity(0.22), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.15), value: appear)
    }

    // MARK: - Stats Section

    private var statsSection: some View {
        HStack(spacing: 10) {
            statCard(value: "142", label: "Clientes activos", icon: "person.2.fill", color: Color.seilBlue)
            statCard(value: "28",  label: "Nuevos este mes",  icon: "sparkles",        color: .seilGreen)
            statCard(value: "4.8", label: "Valoración",       icon: "star.fill",       color: .seilGold)
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.20), value: appear)
    }

    private func statCard(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 20, weight: .heavy))
                .foregroundColor(color)

            Text(label)
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(.seilMuted)
                .multilineTextAlignment(.center)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
    }
}

// ─── QR fullscreen sheet ───────────────────────────────────────────────────────
private struct QRFullscreenSheet: View {
    let bizName:    String
    let inviteLink: String
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 24) {
            Capsule()
                .fill(Color.seilBorder)
                .frame(width: 36, height: 4)
                .padding(.top, 12)

            Spacer()

            Text(bizName.isEmpty ? "Mi negocio" : bizName)
                .font(SeillFont.display(22))
                .foregroundColor(.seilText)

            Text("Escanea este QR para unirte a mi programa de sellos")
                .font(SeillFont.body(14))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)

            ZStack {
                RoundedRectangle(cornerRadius: 24)
                    .fill(.white)
                    .frame(width: 280, height: 280)
                    .shadow(color: .black.opacity(0.20), radius: 24, y: 8)

                InviteQRView(link: "https://\(inviteLink)")
                    .frame(width: 240, height: 240)
            }

            Text(inviteLink)
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundColor(.seilMuted2)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(Color.seilCard)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))

            Spacer()

            Button { dismiss() } label: {
                Text("Cerrar")
                    .font(SeillFont.headline(14))
                    .foregroundColor(.seilMuted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 24)
            .padding(.bottom, 36)
        }
    }
}

// ─── InviteQRView — QR escaneable real ───────────────────────────────────────
// Usa QRCodeView (CoreImage) definido en UserSheets.swift.
// Fondo blanco para que el QR sea escaneable sobre cualquier fondo.
struct InviteQRView: View {
    let link: String

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.white)
            QRCodeView(content: link)
                .padding(8)
        }
    }
}
