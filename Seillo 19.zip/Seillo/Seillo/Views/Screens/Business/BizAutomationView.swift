import SwiftUI
import Combine

// MARK: - AutomationViewModel

@MainActor
final class AutomationViewModel: ObservableObject {

    @Published private(set) var rules        : [AutomationRule] = []
    @Published private(set) var isLoading                       = true
    @Published private(set) var errorMessage : String?          = nil
    @Published              var toastMessage : String?          = nil

    private let api = APIClient.shared

    // ── Carga real desde el backend ───────────────────────────────────────────
    func cargar() async {
        isLoading    = true
        errorMessage = nil
        do {
            let dtos: [AutomationRuleDTO] = try await api.get("api/negocio/automatizaciones")
            rules = dtos.compactMap { dto in
                guard let tipo = AutomationTipo(rawValue: dto.tipo) else { return nil }
                return AutomationRule(
                    id            : dto.id,
                    tipo          : tipo,
                    isActive      : (dto.isActive ?? 0) == 1,
                    totalDisparos : dto.totalDisparos ?? 0,
                    ultimoDisparo : dto.ultimoDisparo
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    // ── Toggle con optimistic update + persistencia real ──────────────────────
    func toggle(ruleId: String, newValue: Bool) async {
        guard let idx = rules.firstIndex(where: { $0.id == ruleId }) else { return }
        let original = rules[idx]

        // 1. Actualizar localmente de inmediato (optimistic)
        rules[idx] = AutomationRule(
            id            : original.id,
            tipo          : original.tipo,
            isActive      : newValue,
            totalDisparos : original.totalDisparos,
            ultimoDisparo : original.ultimoDisparo
        )

        // 2. Persistir en backend
        do {
            try await api.patch(
                "api/negocio/automatizaciones/\(ruleId)",
                body: ToggleAutomationRequest(isActive: newValue)
            )
            let label = rules[idx].nombre
            toastMessage = newValue ? "\(label) activada" : "\(label) desactivada"
        } catch {
            // Rollback si falla
            rules[idx]   = original
            toastMessage = "No se pudo guardar el cambio"
        }
    }

    func clearToast() { toastMessage = nil }
}

// MARK: - BizAutomationView

struct BizAutomationView: View {

    let subscription: BusinessSubscription

    @StateObject private var vm = AutomationViewModel()
    @Environment(\.dismiss) private var dismiss

    @State private var showInfoBanner   = true
    @State private var showUpgradeModal = false
    @State private var selectedRule: AutomationRule? = nil
    @State private var showPlanes       = false
    @State private var appear           = false

    private var gate             : FeatureGate  { FeatureGate(subscription) }
    private var automationGate   : GateResult   { gate.canUseAutomations() }
    private var planLocked       : Bool         { !automationGate.allowed }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar
                Rectangle().fill(Color.seilBorder).frame(height: 1)

                if vm.isLoading {
                    loadingState
                } else if let err = vm.errorMessage {
                    errorState(message: err)
                } else {
                    content
                }
            }

            if showUpgradeModal {
                UpgradeModal(
                    result    : automationGate,
                    onUpgrade : { showUpgradeModal = false; showPlanes = true },
                    onDismiss : { showUpgradeModal = false }
                )
                .zIndex(10)
                .transition(.opacity)
            }

            if let msg = vm.toastMessage {
                VStack {
                    Spacer()
                    Text(msg)
                        .font(SeillFont.label(13))
                        .foregroundColor(.seilText)
                        .padding(.horizontal, 18).padding(.vertical, 12)
                        .background(Color.seilCard)
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
                        .shadow(color: .black.opacity(0.25), radius: 10, y: 3)
                        .padding(.bottom, SeillLayout.tabBarScrollReserve + 8)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                .zIndex(9)
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                        withAnimation { vm.clearToast() }
                    }
                }
            }
        }
        .sheet(isPresented: $showPlanes) { PlanesView() }
        .sheet(item: $selectedRule) { rule in
            AutomationDetailSheet(
                rule     : binding(for: rule),
                locked   : planLocked,
                onToggle : { newVal in
                    if planLocked {
                        selectedRule     = nil
                        showUpgradeModal = true
                    } else {
                        Task { await vm.toggle(ruleId: rule.id, newValue: newVal) }
                        Haptics.tap()
                    }
                },
                onDismiss: { selectedRule = nil }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .task { await vm.cargar() }
        .onAppear { withAnimation(SeillAnimation.chrome.delay(0.05)) { appear = true } }
    }

    // MARK: - Top bar

    private var topBar: some View {
        HStack(spacing: 12) {
            Button { Haptics.tap(); dismiss() } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.seilText)
                    .frame(width: 36, height: 36)
                    .background(Color.seilCard)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 2) {
                Text("Automatizaciones")
                    .font(SeillFont.headline(16))
                    .foregroundColor(.seilText)

                let activeCount = planLocked ? 0 : vm.rules.filter(\.isActive).count
                Text(
                    planLocked
                        ? "Plan Pro requerido"
                        : "\(activeCount) activa\(activeCount == 1 ? "" : "s")"
                )
                .font(SeillFont.caption(11))
                .foregroundColor(
                    planLocked      ? planColor(for: automationGate.requiredTier ?? .pro)
                    : activeCount > 0 ? .seilGreen : .seilMuted
                )
                .animation(.easeInOut(duration: 0.2), value: activeCount)
            }

            Spacer()

            Button {
                Haptics.tap()
                withAnimation(SeillAnimation.chrome) { showInfoBanner.toggle() }
            } label: {
                Image(systemName: showInfoBanner ? "info.circle.fill" : "info.circle")
                    .font(.system(size: 18))
                    .foregroundColor(.seilAccent)
                    .frame(width: 36, height: 36)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Content

    private var content: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 14) {

                if planLocked {
                    UpgradeBanner(
                        mensaje     : "Recupera clientes inactivos sin levantar un dedo.",
                        planLabel   : "Plan Pro",
                        accentColor : planColor(for: automationGate.requiredTier ?? .pro),
                        onUpgrade   : { showPlanes = true }
                    )
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }

                if showInfoBanner {
                    infoBanner
                        .padding(.horizontal, 20)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }

                VStack(spacing: 10) {
                    ForEach(Array(vm.rules.enumerated()), id: \.element.id) { i, rule in
                        AutomationCard(
                            rule    : rule,
                            locked  : planLocked,
                            onToggle: { newVal in
                                if planLocked {
                                    Haptics.tap()
                                    withAnimation { showUpgradeModal = true }
                                } else {
                                    Haptics.tap()
                                    Task { await vm.toggle(ruleId: rule.id, newValue: newVal) }
                                }
                            },
                            onTap   : {
                                Haptics.tap()
                                if planLocked { withAnimation { showUpgradeModal = true } }
                                else          { selectedRule = rule }
                            }
                        )
                        .opacity(appear ? 1 : 0)
                        .offset(y: appear ? 0 : 16)
                        .animation(.easeOut(duration: 0.28).delay(Double(i) * 0.045), value: appear)
                    }
                }
                .padding(.horizontal, 20)

                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
            .padding(.top, 12)
        }
    }

    // MARK: - Info banner

    private var infoBanner: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "sparkles")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.seilAccent)
                .padding(.top, 2)

            VStack(alignment: .leading, spacing: 4) {
                Text("Las automatizaciones se ejecutan en el servidor.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilText)
                Text("Actívalas o desactívalas cuando quieras — los cambios se aplican en tiempo real.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer()

            Button {
                Haptics.tap()
                withAnimation(SeillAnimation.chrome) { showInfoBanner = false }
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.seilMuted)
                    .frame(width: 22, height: 22)
            }
            .buttonStyle(.plain)
        }
        .padding(14)
        .background(Color.seilAccent.opacity(0.07))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.seilAccent.opacity(0.18), lineWidth: 1))
    }

    // MARK: - Loading / Error

    private var loadingState: some View {
        VStack(spacing: 16) {
            Spacer()
            ProgressView().progressViewStyle(.circular).tint(.seilAccent).scaleEffect(1.2)
            Text("Cargando automatizaciones…").font(SeillFont.body(13)).foregroundColor(.seilMuted)
            Spacer()
        }
    }

    private func errorState(message: String) -> some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "wifi.slash").font(.system(size: 44)).foregroundColor(.seilMuted)
            Text(message).font(SeillFont.body(13)).foregroundColor(.seilMuted2).multilineTextAlignment(.center)
            Button { Task { await vm.cargar() } } label: {
                Text("Reintentar")
                    .font(SeillFont.label(14)).foregroundColor(.seilAccent)
                    .padding(.horizontal, 24).padding(.vertical, 10)
                    .background(Color.seilAccent.opacity(0.12)).clipShape(Capsule())
            }
            .buttonStyle(.plain)
            Spacer()
        }
        .padding(.horizontal, 40)
    }

    private func binding(for rule: AutomationRule) -> Binding<AutomationRule> {
        Binding(
            get: { vm.rules.first(where: { $0.id == rule.id }) ?? rule },
            set: { _ in }
        )
    }
}

// MARK: - AutomationCard

private struct AutomationCard: View {
    let rule    : AutomationRule
    let locked  : Bool
    let onToggle: (Bool) -> Void
    let onTap   : () -> Void

    private var proColor : Color { planColor(for: .pro) }
    private var iconColor: Color {
        if locked        { return proColor.opacity(0.50) }
        if rule.isActive { return .seilAccent }
        return .seilMuted2
    }

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(iconColor.opacity(0.14)).frame(width: 42, height: 42)
                    Image(systemName: locked ? "lock.fill" : rule.icono)
                        .font(.system(size: locked ? 15 : 18, weight: .semibold))
                        .foregroundColor(locked ? proColor.opacity(0.70) : iconColor)
                }

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(rule.nombre)
                            .font(SeillFont.label(13))
                            .foregroundColor(locked ? .seilMuted2 : .seilText)
                            .lineLimit(1)
                        if locked {
                            Text("Pro")
                                .font(.system(size: 9, weight: .heavy))
                                .foregroundColor(proColor)
                                .padding(.horizontal, 6).padding(.vertical, 2)
                                .background(proColor.opacity(0.13)).clipShape(Capsule())
                        }
                    }
                    Text(rule.descripcion)
                        .font(SeillFont.body(12))
                        .foregroundColor(locked ? .seilMuted.opacity(0.6) : .seilMuted2)
                        .lineLimit(2)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Toggle("", isOn: Binding(
                    get: { rule.isActive && !locked },
                    set: { onToggle($0) }
                ))
                .labelsHidden()
                .tint(.seilAccent)
                .disabled(locked)
                .allowsHitTesting(true)
            }
            .padding(.horizontal, 16).padding(.vertical, 14)
            .background(rule.isActive && !locked ? Color.seilAccent.opacity(0.07) : Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(rule.isActive && !locked ? Color.seilAccent.opacity(0.25) : Color.seilBorder, lineWidth: 1)
            )
            .animation(.easeInOut(duration: 0.2), value: rule.isActive)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - AutomationDetailSheet

private struct AutomationDetailSheet: View {
    @Binding var rule    : AutomationRule
    let locked  : Bool
    let onToggle: (Bool) -> Void
    let onDismiss: () -> Void

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle().fill(Color.seilAccent.opacity(0.14)).frame(width: 50, height: 50)
                            Image(systemName: rule.icono).font(.system(size: 22, weight: .semibold)).foregroundColor(.seilAccent)
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text(rule.nombre).font(SeillFont.display(18)).foregroundColor(.seilText)
                            Text(rule.descripcion).font(SeillFont.body(13)).foregroundColor(.seilMuted2)
                        }
                    }
                    .padding(.top, 8)

                    Divider().background(Color.seilBorder)

                    VStack(spacing: 12) {
                        infoRow(label: "Cuándo",  value: rule.triggerLabel)
                        infoRow(label: "Qué hace", value: rule.accionLabel)
                        if rule.totalDisparos > 0 {
                            infoRow(label: "Disparos totales", value: "\(rule.totalDisparos)")
                        }
                        if let ultima = rule.ultimoDisparo {
                            infoRow(label: "Último disparo", value: ultima)
                        }
                    }

                    Divider().background(Color.seilBorder)

                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(rule.isActive && !locked ? "Activa" : "Inactiva")
                                .font(SeillFont.label(14)).foregroundColor(.seilText)
                            Text(rule.isActive && !locked
                                    ? "Se ejecutará automáticamente"
                                    : locked ? "Requiere plan Pro" : "No se ejecutará")
                                .font(SeillFont.body(12)).foregroundColor(.seilMuted2)
                        }
                        Spacer()
                        Toggle("", isOn: Binding(
                            get: { rule.isActive && !locked },
                            set: { onToggle($0) }
                        ))
                        .labelsHidden().tint(.seilAccent).disabled(locked)
                    }

                    Spacer().frame(height: 20)
                }
                .padding(.horizontal, 24)
            }
        }
        .presentationBackground(Color.seilBg)
    }

    private func infoRow(label: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(label).font(SeillFont.body(12)).foregroundColor(.seilMuted2).frame(width: 110, alignment: .leading)
            Text(value).font(SeillFont.body(12)).foregroundColor(.seilText).fixedSize(horizontal: false, vertical: true)
            Spacer()
        }
    }
}
