import SwiftUI

// ─── SendPushView ─────────────────────────────────────────────────────────────
// El negocio redacta un mensaje push y lo envía a un segmento de sus clientes.
// Acceso: BizTabProfileView → "Enviar notificación"
//         BizTabDashboardView → quickActionButton "Mensaje"
// ─────────────────────────────────────────────────────────────────────────────

private enum AudienceFilter: String, CaseIterable {
    case all        = "Todos los clientes"
    case nearPrize  = "Cerca del premio"
    case inactive   = "Sin visitar (7+ días)"
    case newClients = "Nuevos esta semana"

    var icon: String {
        switch self {
        case .all:        return "person.2.fill"
        case .nearPrize:  return "trophy.fill"
        case .inactive:   return "hourglass"
        case .newClients: return "sparkles"
        }
    }

    var color: Color {
        switch self {
        case .all:        return Color.seilBlue
        case .nearPrize:  return Color.seilGold
        case .inactive:   return Color.seilRose
        case .newClients: return Color.seilGreen
        }
    }

    var estimatedCount: Int {
        switch self {
        case .all:        return 142
        case .nearPrize:  return 38
        case .inactive:   return 24
        case .newClients: return 11
        }
    }
}

/// Sugerencias organizadas por categoría del negocio.
/// Clave = categoriaId de BizProfile. "default" aplica a cualquier tipo.
private let messageSuggestionsByCategory: [String: [String]] = [
    "cafe": [
        "¡Esta semana doble sellos en todos tus cafés! Ven a tu hora favorita.",
        "Tu café gratis te espera. Muéstrale tu QR al barista hoy.",
        "¿Probaste ya nuestro nuevo blend de temporada? Ven y acumula tu sello.",
        "¡Te extrañamos! Vuelve esta semana y te regalamos un sello extra.",
    ],
    "restaurante": [
        "Doble sellos este fin de semana. ¡Ven con quien quieras!",
        "Tu próximo plato gratis está a un sello. ¡Visítanos hoy!",
        "Menú especial de temporada disponible. Ven y sella tu visita.",
        "¡Te extrañamos! Esta semana tienes un sello de bienvenida.",
    ],
    "barberia": [
        "¿Ya es hora del corte? Doble sellos esta semana.",
        "Tu corte gratis está listo. Muéstrale tu QR al llegar.",
        "Nuevo servicio disponible: arreglo de barba + aromaterapia. Reserva ya.",
        "¡Han pasado unos días! Vuelve y te regalamos un sello.",
    ],
    "jugueria": [
        "Doble sellos en todos los jugos naturales esta semana. ¡Salud!",
        "Tu jugo especial gratis te espera. Muéstranos tu tarjeta.",
        "Nuevo jugo detox de temporada. Ven, pruébalo y sella tu visita.",
        "¡Te echamos de menos! Esta semana un sello de cortesía.",
    ],
    "default": [
        "¡Esta semana tienes doble sellos en todas tus visitas!",
        "Tu premio te está esperando. Visítanos hoy y canjéalo.",
        "Tenemos algo especial para ti. ¡Ven a descubrirlo!",
        "¡Te extrañamos! Vuelve esta semana y recibe un sello extra.",
    ],
]

struct SendPushView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var audience: AudienceFilter = .all
    @State private var messageText = ""
    @State private var step: SendStep = .compose
    @State private var appear   = false
    @State private var sending   = false
    @State private var sendError: String? = nil

    private let api      = APIClient.shared
    private let maxChars = 160

    private enum SendStep { case compose, confirm, sent }

    // Mapeo al valor que espera el backend en POST /api/negocio/push/enviar
    private var backendAudiencia: String {
        switch audience {
        case .all:        return "todos"
        case .nearPrize:  return "cerca_premio"
        case .inactive:   return "inactivos"
        case .newClients: return "nuevos"
        }
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [Color.seilBlue.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.10),
                startRadius: 0, endRadius: 320
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                switch step {
                case .compose: composeView
                case .confirm: confirmView
                case .sent:    sentView
                }
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button {
                    Haptics.tap()
                    if step == .confirm {
                        withAnimation { step = .compose }
                    } else {
                        dismiss()
                    }
                } label: {
                    Image(systemName: step == .confirm ? "chevron.left" : "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()

                Text(step == .sent ? "¡Enviado!" : "Enviar mensaje")
                    .font(SeillFont.headline(15))
                    .foregroundColor(Color.seilText)

                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 14)

            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Paso 1: Compose

    private var composeView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {

                // Audiencia
                VStack(alignment: .leading, spacing: 12) {
                    sectionLabel("AUDIENCIA")

                    VStack(spacing: 8) {
                        ForEach(AudienceFilter.allCases, id: \.self) { filter in
                            Button {
                                Haptics.tap()
                                withAnimation(.easeOut(duration: 0.2)) { audience = filter }
                            } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(filter.color.opacity(audience == filter ? 0.20 : 0.10))
                                            .frame(width: 36, height: 36)
                                        Image(systemName: filter.icon)
                                            .font(.system(size: 15, weight: .semibold))
                                            .foregroundColor(filter.color)
                                    }

                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(filter.rawValue)
                                            .font(SeillFont.label(13))
                                            .foregroundColor(Color.seilText)
                                        Text("\(filter.estimatedCount) clientes")
                                            .font(SeillFont.body(11))
                                            .foregroundColor(.seilMuted2)
                                    }

                                    Spacer()

                                    if audience == filter {
                                        Image(systemName: "checkmark.circle.fill")
                                            .font(.system(size: 18))
                                            .foregroundColor(filter.color)
                                    } else {
                                        Circle()
                                            .stroke(Color.seilBorder, lineWidth: 1.5)
                                            .frame(width: 18, height: 18)
                                    }
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 12)
                                .background(audience == filter ? filter.color.opacity(0.08) : Color.seilCard)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14)
                                        .stroke(audience == filter ? filter.color.opacity(0.35) : Color.seilBorder, lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // Mensaje
                VStack(alignment: .leading, spacing: 12) {
                    sectionLabel("MENSAJE")

                    ZStack(alignment: .topLeading) {
                        if messageText.isEmpty {
                            Text("Escribe tu mensaje aquí...")
                                .font(SeillFont.body(14))
                                .foregroundColor(Color.seilMuted)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 14)
                        }

                        TextEditor(text: $messageText)
                            .font(SeillFont.body(14))
                            .foregroundColor(Color.seilText)
                            .scrollContentBackground(.hidden)
                            .frame(minHeight: 110, maxHeight: 150)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 10)
                            .onChange(of: messageText) { _, v in
                                if v.count > maxChars { messageText = String(v.prefix(maxChars)) }
                            }
                    }
                    .background(Color.seilCard)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(messageText.isEmpty ? Color.seilBorder : Color.seilBlue.opacity(0.40), lineWidth: 1)
                    )

                    HStack {
                        Spacer()
                        Text("\(messageText.count)/\(maxChars)")
                            .font(SeillFont.caption(11))
                            .foregroundColor(messageText.count > 140 ? Color.seilRose : Color.seilMuted)
                    }
                }

                // Sugerencias
                VStack(alignment: .leading, spacing: 10) {
                    sectionLabel("SUGERENCIAS PARA TU NEGOCIO")

                    let catKey = bizStore.profile.categoriaId
                    let suggestions = messageSuggestionsByCategory[catKey]
                        ?? messageSuggestionsByCategory["default"]!

                    ForEach(suggestions, id: \.self) { suggestion in
                        Button {
                            Haptics.tap()
                            messageText = suggestion
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "text.bubble.fill")
                                    .font(.system(size: 13))
                                    .foregroundColor(Color.seilBlue)
                                    .frame(width: 24)

                                Text(suggestion)
                                    .font(SeillFont.body(12))
                                    .foregroundColor(.seilMuted2)
                                    .lineSpacing(3)
                                    .multilineTextAlignment(.leading)

                                Spacer()
                            }
                            .padding(12)
                            .background(Color.seilCard)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.seilBorder, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }

                // SeillLayout.tabBarScrollReserve
                Spacer().frame(height: SeillLayout.tabBarScrollReserve)
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
        }
        .overlay(alignment: .bottom) {
            // CTA flotante
            Button {
                guard !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                Haptics.tap()
                withAnimation(.easeInOut(duration: 0.28)) { step = .confirm }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 14, weight: .semibold))
                    Text("Revisar y enviar")
                        .font(SeillFont.headline(15))
                }
                .foregroundColor(messageText.isEmpty ? Color.seilMuted : .white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    messageText.isEmpty
                    ? LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .leading, endPoint: .trailing)
                    : LinearGradient(colors: [Color.seilBlue, Color.seilBlue], startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: messageText.isEmpty ? .clear : Color.seilBlue.opacity(0.38), radius: 14, y: 4)
                .animation(.easeInOut(duration: 0.22), value: messageText.isEmpty)
            }
            .buttonStyle(.plain)
            .disabled(messageText.isEmpty)
            .padding(.horizontal, 24)
            .padding(.bottom, 36)
            .background(
                LinearGradient(
                    colors: [Color.seilBg.opacity(0), Color.seilBg],
                    startPoint: .top, endPoint: .bottom
                )
                .frame(height: 120)
                .ignoresSafeArea(),
                alignment: .bottom
            )
        }
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 14)
    }

    // MARK: - Paso 2: Confirm

    private var confirmView: some View {
        VStack(spacing: 24) {
            Spacer().frame(height: 16)

            // Preview de notificación
            VStack(alignment: .leading, spacing: 16) {
                sectionLabel("VISTA PREVIA")

                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.seilAccent.opacity(0.16))
                            .frame(width: 40, height: 40)
                        Image(systemName: "seal.fill")
                            .font(.system(size: 18))
                            .foregroundColor(Color.seilAccent)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("Seillo")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(Color.seilText)
                            Spacer()
                            Text("ahora")
                                .font(.system(size: 11))
                                .foregroundColor(Color.seilMuted)
                        }
                        Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.seilMuted2)
                        Text(messageText)
                            .font(.system(size: 13))
                            .foregroundColor(Color.seilText)
                            .lineSpacing(3)
                            .lineLimit(3)
                    }
                }
                .padding(14)
                .background(Color.seilCard)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.seilBorder, lineWidth: 1)
                )
            }
            .padding(.horizontal, 24)

            // Resumen
            VStack(spacing: 0) {
                confirmRow(icon: "person.2.fill", color: audience.color, label: "Audiencia", value: audience.rawValue)
                Divider().background(Color.seilBorder).padding(.leading, 50)
                confirmRow(icon: "person.badge.clock", color: Color.seilBlue, label: "Destinatarios", value: "\(audience.estimatedCount) clientes")
                Divider().background(Color.seilBorder).padding(.leading, 50)
                confirmRow(icon: "character.bubble", color: Color.seilGreen, label: "Caracteres", value: "\(messageText.count)/\(maxChars)")
            }
            .background(Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
            .padding(.horizontal, 24)

            // Aviso
            HStack(spacing: 10) {
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 14))
                    .foregroundColor(Color.seilBlue)
                Text("Los clientes recibirán esta notificación en sus dispositivos. Esta acción no se puede deshacer.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                    .lineSpacing(3)
            }
            .padding(14)
            .background(Color.seilBlue.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilBlue.opacity(0.18), lineWidth: 1))
            .padding(.horizontal, 24)

            Spacer()

            // Error de envío
            if let err = sendError {
                Text(err)
                    .font(SeillFont.caption(12))
                    .foregroundColor(.seilRose)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .transition(.opacity)
            }

            // Confirmar
            Button {
                guard !sending else { return }
                Haptics.success()
                sending = true
                sendError = nil
                Task {
                    do {
                        struct PushRequest: Encodable { let mensaje: String; let audiencia: String }
                        struct PushResponse: Decodable { let ok: Bool?; let enviados: Int? }
                        let _: PushResponse = try await api.post(
                            "api/negocio/push/enviar",
                            body: PushRequest(mensaje: messageText, audiencia: backendAudiencia)
                        )
                        await MainActor.run {
                            sending = false
                            withAnimation(SeillAnimation.screenTransition) { step = .sent }
                        }
                    } catch {
                        await MainActor.run {
                            sending = false
                            withAnimation { sendError = "No se pudo enviar. Intenta de nuevo." }
                        }
                    }
                }
            } label: {
                HStack(spacing: 8) {
                    if sending {
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white)).scaleEffect(0.85)
                    } else {
                        Image(systemName: "paperplane.fill").font(.system(size: 14, weight: .semibold))
                        Text("Confirmar envío").font(SeillFont.headline(15))
                    }
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(LinearGradient(colors: [Color.seilBlue, Color.seilBlue], startPoint: .leading, endPoint: .trailing))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.seilBlue.opacity(0.38), radius: 14, y: 4)
                .opacity(sending ? 0.7 : 1)
            }
            .buttonStyle(.plain)
            .disabled(sending)
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .transition(.asymmetric(
            insertion: .move(edge: .trailing).combined(with: .opacity),
            removal: .move(edge: .leading).combined(with: .opacity)
        ))
    }

    // MARK: - Paso 3: Sent

    private var sentView: some View {
        VStack(spacing: 0) {
            Spacer()

            ZStack {
                Circle().fill(Color.seilBlue.opacity(0.08)).frame(width: 140, height: 140)
                Circle().fill(Color.seilBlue.opacity(0.14)).frame(width: 100, height: 100)
                    .overlay(Circle().stroke(Color.seilBlue.opacity(0.22), lineWidth: 1.5))
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 44, weight: .semibold))
                    .foregroundColor(Color.seilBlue)
                    .shadow(color: Color.seilBlue.opacity(0.50), radius: 18, y: 6)
            }

            Spacer().frame(height: 28)

            Text("¡Mensaje enviado!")
                .font(SeillFont.display(26))
                .foregroundColor(Color.seilText)
                .multilineTextAlignment(.center)

            Spacer().frame(height: 10)

            Text("\(audience.estimatedCount) clientes de \"\(audience.rawValue)\" recibirán tu notificación en los próximos segundos.")
                .font(SeillFont.body(14))
                .foregroundColor(.seilMuted2)
                .multilineTextAlignment(.center)
                .lineSpacing(4)
                .padding(.horizontal, 36)

            Spacer()

            Button {
                Haptics.tap()
                dismiss()
            } label: {
                Text("Cerrar")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(LinearGradient(colors: [Color.seilBlue, Color.seilBlue], startPoint: .leading, endPoint: .trailing))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: Color.seilBlue.opacity(0.38), radius: 14, y: 4)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 24)
            .padding(.bottom, 44)
        }
        .transition(.opacity.combined(with: .scale(scale: 0.94)))
    }

    // MARK: - Helpers

    private func sectionLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(Color.seilMuted)
            .tracking(1.2)
    }

    private func confirmRow(icon: String, color: Color, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8).fill(color.opacity(0.12)).frame(width: 30, height: 30)
                Image(systemName: icon).font(.system(size: 13)).foregroundColor(color)
            }
            Text(label).font(SeillFont.body(13)).foregroundColor(.seilMuted2)
            Spacer()
            Text(value).font(SeillFont.label(13)).foregroundColor(Color.seilText).lineLimit(1)
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
    }
}
