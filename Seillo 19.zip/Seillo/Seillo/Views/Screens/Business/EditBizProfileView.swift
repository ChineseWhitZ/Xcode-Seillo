import SwiftUI

// ─── EditBizProfileView ───────────────────────────────────────────────────────
// Pantalla para editar el perfil del negocio: nombre, dirección y categoría.
// Acceso: BizTabProfileView → header o botón "Editar perfil"
// ─────────────────────────────────────────────────────────────────────────────

private struct BizEditCategory: Identifiable {
    let id:    String
    let label: String
    let icon:  String
    let color: Color
}

private let bizEditCategories: [BizEditCategory] = [
    .init(id: "cafe",        label: "Café / Cafetería",   icon: "cup.and.saucer.fill", color: .seilGold),
    .init(id: "restaurante", label: "Restaurante",        icon: "fork.knife",          color: .seilAccent),
    .init(id: "bar",         label: "Bar / Pub",          icon: "wineglass.fill",      color: .seilBlue),
    .init(id: "barberia",    label: "Barbería / Salón",   icon: "scissors",            color: .seilRose),
    .init(id: "jugueria",    label: "Juguería / Jugos",   icon: "drop.fill",           color: .seilGreen),
    .init(id: "pasteleria",  label: "Pastelería",         icon: "birthday.cake.fill",  color: .seilPurple),
    .init(id: "gym",         label: "Gimnasio / Fitness", icon: "dumbbell.fill",       color: .seilAccent),
    .init(id: "tienda",      label: "Tienda / Retail",    icon: "basket.fill",         color: .seilBlue),
    .init(id: "spa",         label: "Spa / Belleza",      icon: "sparkles",            color: .seilPurple),
    .init(id: "academia",    label: "Academia / Clases",  icon: "book.fill",           color: .seilGreen),
]

struct EditBizProfileView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var bizStore: BizProfileStore

    @State private var nombre       = ""
    @State private var direccion    = ""
    @State private var categoriaId  = "cafe"

    @State private var nombreError:    String? = nil
    @State private var direccionError: String? = nil
    @State private var loading        = false
    @State private var showDiscard    = false
    @State private var showMenu       = false
    @State private var appear         = false

    private var selectedCat: BizEditCategory {
        bizEditCategories.first { $0.id == categoriaId } ?? bizEditCategories[0]
    }

    private var hasChanges: Bool {
        nombre    != bizStore.profile.nombre ||
        direccion != bizStore.profile.direccion ||
        categoriaId != bizStore.profile.categoriaId
    }

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [selectedCat.color.opacity(0.08), .clear],
                center: .init(x: 0.5, y: 0.10),
                startRadius: 0,
                endRadius: 300
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.45), value: categoriaId)

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        // ── Logo preview ───────────────────────────────────
                        logoPreview

                        // ── Nombre ─────────────────────────────────────────
                        VStack(alignment: .leading, spacing: 8) {
                            fieldLabel("NOMBRE DEL NEGOCIO")
                            SeillTextField(
                                label: "",
                                placeholder: "Ej. Café Inti",
                                icon: "storefront",
                                text: $nombre
                            )
                            .onChange(of: nombre) { _, _ in nombreError = nil }

                            if let err = nombreError {
                                errorLabel(err)
                            }
                        }

                        // ── Dirección ──────────────────────────────────────
                        VStack(alignment: .leading, spacing: 8) {
                            fieldLabel("DIRECCIÓN")
                            SeillTextField(
                                label: "",
                                placeholder: "Ej. Jr. Schell 392, Miraflores",
                                icon: "location",
                                text: $direccion
                            )
                            .onChange(of: direccion) { _, _ in direccionError = nil }

                            if let err = direccionError {
                                errorLabel(err)
                            }
                        }

                        // ── Menú y servicios ───────────────────────────────
                        VStack(alignment: .leading, spacing: 8) {
                            fieldLabel("MENÚ Y SERVICIOS")

                            Button {
                                Haptics.tap()
                                showMenu = true
                            } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.seilGreen.opacity(0.12))
                                            .frame(width: 34, height: 34)
                                        Image(systemName: "menucard.fill")
                                            .font(.system(size: 14, weight: .semibold))
                                            .foregroundColor(.seilGreen)
                                    }
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Gestionar menú")
                                            .font(SeillFont.headline(13))
                                            .foregroundColor(.seilText)
                                        let count = bizStore.profile.menu.count
                                        Text(count == 0 ? "Sin ítems aún" : "\(count) ítem\(count == 1 ? "" : "s") cargados")
                                            .font(.system(size: 11))
                                            .foregroundColor(.seilMuted)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.system(size: 12, weight: .semibold))
                                        .foregroundColor(.seilAccent)
                                }
                                .padding(14)
                                .background(Color.seilCard)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14)
                                        .stroke(Color.seilBorder, lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }

                        // ── Categoría ──────────────────────────────────────
                        VStack(alignment: .leading, spacing: 12) {
                            fieldLabel("CATEGORÍA")

                            LazyVGrid(
                                columns: [GridItem(.flexible()), GridItem(.flexible())],
                                spacing: 10
                            ) {
                                ForEach(bizEditCategories) { cat in
                                    Button {
                                        Haptics.tap()
                                        withAnimation(SeillAnimation.chrome) {
                                            categoriaId = cat.id
                                        }
                                    } label: {
                                        HStack(spacing: 10) {
                                            ZStack {
                                                RoundedRectangle(cornerRadius: 8)
                                                    .fill(cat.color.opacity(categoriaId == cat.id ? 0.22 : 0.10))
                                                    .frame(width: 32, height: 32)
                                                Image(systemName: cat.icon)
                                                    .font(.system(size: 14, weight: .semibold))
                                                    .foregroundColor(cat.color)
                                            }

                                            Text(cat.label)
                                                .font(SeillFont.body(12))
                                                .foregroundColor(categoriaId == cat.id ? .seilText : .seilMuted2)
                                                .lineLimit(1)

                                            Spacer(minLength: 0)

                                            if categoriaId == cat.id {
                                                Image(systemName: "checkmark.circle.fill")
                                                    .font(.system(size: 14))
                                                    .foregroundColor(cat.color)
                                            }
                                        }
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 10)
                                        .background(
                                            categoriaId == cat.id
                                            ? cat.color.opacity(0.10)
                                            : Color.seilCard
                                        )
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(
                                                    categoriaId == cat.id ? cat.color.opacity(0.45) : Color.seilBorder,
                                                    lineWidth: 1
                                                )
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        // SeillLayout.tabBarScrollReserve (aprox)
                        Spacer().frame(height: SeillLayout.tabBarScrollReserve)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                }

                Spacer()
            }

            // ── Botón guardar flotante ─────────────────────────────────────
            VStack {
                Spacer()
                saveButton
                    .padding(.horizontal, 24)
                    .padding(.bottom, 36)
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            nombre      = bizStore.profile.nombre
            direccion   = bizStore.profile.direccion
            categoriaId = bizStore.profile.categoriaId
            withAnimation(SeillAnimation.chrome) {
                appear = true
            }
        }
        .sheet(isPresented: $showMenu) {
            BizMenuSheet()
                .environmentObject(bizStore)
                .presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationBackground(Color.seilBg)
        }
        .alert("¿Descartar cambios?", isPresented: $showDiscard) {
            Button("Descartar", role: .destructive) { dismiss() }
            Button("Seguir editando", role: .cancel) { }
        } message: {
            Text("Los cambios que hiciste no se guardarán.")
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button {
                    Haptics.tap()
                    if hasChanges {
                        showDiscard = true
                    } else {
                        dismiss()
                    }
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)

                Spacer()

                Text("Editar negocio")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)

                Spacer()

                // Placeholder para centrar el título
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 14)

            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // ── Logo preview ───────────────────────────────────────────────────────────
    private var logoPreview: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(selectedCat.color.opacity(0.15))
                    .frame(width: 72, height: 72)
                    .overlay(Circle().stroke(selectedCat.color.opacity(0.30), lineWidth: 1.5))

                Image(systemName: selectedCat.icon)
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundColor(selectedCat.color)
            }
            .animation(SeillAnimation.chrome, value: categoriaId)

            VStack(alignment: .leading, spacing: 4) {
                Text(nombre.isEmpty ? "Nombre del negocio" : nombre)
                    .font(.system(size: 17, weight: .heavy, design: .rounded))
                    .foregroundColor(nombre.isEmpty ? .seilMuted : .seilText)
                    .lineLimit(1)
                    .animation(.easeOut(duration: 0.2), value: nombre)

                Text(selectedCat.label)
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
                    .animation(.easeOut(duration: 0.2), value: categoriaId)

                if !direccion.isEmpty {
                    HStack(spacing: 4) {
                        Image(systemName: "location.fill")
                            .font(.system(size: 9))
                            .foregroundColor(.seilMuted)
                        Text(direccion)
                            .font(.system(size: 11))
                            .foregroundColor(.seilMuted)
                            .lineLimit(1)
                    }
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                }
            }

            Spacer()
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [selectedCat.color.opacity(0.12), .clear],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(selectedCat.color.opacity(0.20), lineWidth: 1)
        )
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 12)
    }

    // ── Botón guardar ──────────────────────────────────────────────────────────
    private var saveButton: some View {
        Button {
            guard validate() else { return }
            Haptics.success()
            loading = true

            // Actualiza el store (cuando haya backend: PATCH /api/negocio/perfil)
            var updated = bizStore.profile
            updated.nombre      = nombre.trimmingCharacters(in: .whitespaces)
            updated.direccion   = direccion.trimmingCharacters(in: .whitespaces)
            updated.categoriaId = categoriaId
            bizStore.update(updated)

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                loading = false
                dismiss()
            }
        } label: {
            Group {
                if loading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                } else {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                        Text("Guardar cambios")
                            .font(SeillFont.headline(15))
                    }
                }
            }
            .foregroundColor(hasChanges ? .white : .seilMuted)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                hasChanges
                ? LinearGradient(colors: [Color.seilAccent, Color.seilAccent2], startPoint: .leading, endPoint: .trailing)
                : LinearGradient(colors: [Color.seilCard, Color.seilCard], startPoint: .leading, endPoint: .trailing)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: hasChanges ? Color.seilAccent.opacity(0.38) : .clear, radius: 14, y: 4)
            .animation(.easeInOut(duration: 0.22), value: hasChanges)
        }
        .buttonStyle(.plain)
        .disabled(!hasChanges || loading)
    }

    // MARK: - Helpers

    private func validate() -> Bool {
        let n = nombre.trimmingCharacters(in: .whitespaces)
        let d = direccion.trimmingCharacters(in: .whitespaces)

        if n.isEmpty {
            nombreError = "Ingresa el nombre del negocio"
            Haptics.error()
            return false
        }
        if d.isEmpty {
            direccionError = "Ingresa la dirección"
            Haptics.error()
            return false
        }
        return true
    }

    private func fieldLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .bold))
            .foregroundColor(.seilMuted)
            .tracking(1.2)
    }

    private func errorLabel(_ text: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 11))
                .foregroundColor(.seilRose)
            Text(text)
                .font(SeillFont.body(12))
                .foregroundColor(.seilRose)
        }
    }
}
