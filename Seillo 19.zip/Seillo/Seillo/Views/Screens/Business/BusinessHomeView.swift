import SwiftUI

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BusinessHomeView
// ═══════════════════════════════════════════════════════════════════════════════

struct BusinessHomeView: View {
    @State private var selectedTab = 0

    var body: some View {
        GeometryReader { geo in
            if isIPad && isLandscape(geo) {
                // ── iPad landscape: sidebar + contenido ──────────────────
                BizLandscapeLayout(selectedTab: $selectedTab)
            } else {
                // ── iPhone + iPad portrait: pill flotante ────────────────
                BizPortraitLayout(selectedTab: $selectedTab)
            }
        }
        .ignoresSafeArea()
    }
}

// ─── BizPortraitLayout ───────────────────────────────────────────────────────
/// Layout original con pill flotante. iPhone siempre + iPad portrait.

private struct BizPortraitLayout: View {
    @Binding var selectedTab: Int

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.seilBg.ignoresSafeArea()

            // MEDIO: antes usaba .page — swipe horizontal entre tabs,
            // sin animación de transición propia de iOS y sin accesibilidad
            // de tab bar nativo. Ahora cada tab se muestra directamente
            // con .opacity transition controlada por selectedTab.
            ZStack {
                Group {
                    switch selectedTab {
                    case 0: BizTabDashboardView()
                    case 1: BizTabScanView()
                    case 2: BizTabClientsView()
                    default: BizTabProfileView()
                    }
                }
                .transition(.opacity)
                .id(selectedTab)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .safeAreaInset(edge: .bottom) {
                Color.clear.frame(height: SeillLayout.tabBarScrollReserve)
            }
            .animation(SeillAnimation.chrome, value: selectedTab)

            bizTabBar
        }
    }

    private var bizTabBar: some View {
        HStack(spacing: 6) {
            bizTabItem(index: 0, icon: "chart.bar.fill", label: "Panel")
            bizTabItem(index: 1, icon: "qrcode.viewfinder", label: "Escanear", isCenter: true)
            bizTabItem(index: 2, icon: "person.2.fill", label: "Clientes")
            bizTabItem(index: 3, icon: "building.2.fill", label: "Negocio")
        }
        .padding(.horizontal, SeillLayout.tabBarInternalPadding)
        .padding(.vertical, SeillLayout.tabBarInternalPadding)
        .glassEffect(in: RoundedRectangle(cornerRadius: SeillLayout.tabBarCornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: SeillLayout.tabBarCornerRadius, style: .continuous)
                .stroke(Color.seilBorderGlass, lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.20), radius: 20, y: 6)
        .frame(maxWidth: isIPad ? SeillLayout.tabBarMaxWidthIPad : .infinity)
        .padding(.horizontal, SeillLayout.tabBarHorizontalPadding)
        .padding(.bottom, isIPad ? SeillLayout.tabBarBottomPaddingIPad : SeillLayout.tabBarBottomPadding)
    }

    @ViewBuilder
    private func bizTabItem(index: Int, icon: String, label: String, isCenter: Bool = false) -> some View {
        let isSelected = selectedTab == index
        let activeColor: Color = isCenter ? .seilGold : .seilAccent

        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            withAnimation(SeillAnimation.chrome) { selectedTab = index }
        } label: {
            VStack(spacing: 5) {
                ZStack {
                    if isSelected {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(activeColor.opacity(isCenter ? 0.20 : 0.15))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(activeColor.opacity(0.25), lineWidth: 1)
                            )
                            .frame(width: isCenter ? 58 : 50, height: isCenter ? 42 : 38)
                    }

                    Image(systemName: icon)
                        .font(.system(size: isCenter ? 20 : 17, weight: .semibold))
                        .foregroundColor(isSelected ? activeColor : Color.primary.opacity(0.40))
                        .shadow(color: isSelected ? activeColor.opacity(0.22) : .clear, radius: 8, y: 2)
                }

                Text(label)
                    .font(.system(size: 9, weight: isSelected ? .bold : .semibold))
                    .foregroundColor(isSelected ? activeColor : Color.primary.opacity(0.40))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, isCenter ? 2 : 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// ─── BizLandscapeLayout ──────────────────────────────────────────────────────
/// iPad landscape: sidebar fija a la izquierda + área de contenido.

private struct BizLandscapeLayout: View {
    @Binding var selectedTab: Int

    var body: some View {
        HStack(spacing: 0) {
            BizSidebarView(selectedTab: $selectedTab)
                .frame(width: SeillLayout.bizSidebarWidth)
                .zIndex(1)

            Rectangle()
                .fill(Color.seilBorder)
                .frame(width: 1)
                .ignoresSafeArea()

            ZStack {
                Color.seilBg.ignoresSafeArea()

                // MEDIO: antes el switch de tab en sidebar era instantáneo —
                // sin transición entre vistas. Ahora usa .opacity + .id para
                // la misma transición suave que BizPortraitLayout.
                Group {
                    switch selectedTab {
                    case 0: BizTabDashboardView()
                    case 1: BizTabScanView()
                    case 2: BizTabClientsView()
                    default: BizTabProfileView()
                    }
                }
                .transition(.opacity)
                .id(selectedTab)
                .animation(SeillAnimation.chrome, value: selectedTab)
            }
            .frame(maxWidth: .infinity)
        }
        .background(Color.seilBg.ignoresSafeArea())
    }
}

// ─── SidebarItem ─────────────────────────────────────────────────────────────
// FIX: movido fuera de BizSidebarView para que BizSidebarRow pueda accederlo.

private struct SidebarItem {
    let index: Int
    let icon: String
    let label: String
    let isCenter: Bool
}

// ─── BizSidebarView ──────────────────────────────────────────────────────────
/// Sidebar de negocio para iPad landscape.

private struct BizSidebarView: View {
    @Binding var selectedTab: Int
    @EnvironmentObject var bizStore: BizProfileStore

    private let items: [SidebarItem] = [
        .init(index: 0, icon: "chart.bar.fill", label: "Panel", isCenter: false),
        .init(index: 1, icon: "qrcode.viewfinder", label: "Escanear", isCenter: true),
        .init(index: 2, icon: "person.2.fill", label: "Clientes", isCenter: false),
        .init(index: 3, icon: "building.2.fill", label: "Negocio", isCenter: false),
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                ZStack {
                    Circle()
                        .fill(Color.seilGold.opacity(0.15))
                        .frame(width: 48, height: 48)
                        .overlay(Circle().stroke(Color.seilGold.opacity(0.3), lineWidth: 1))

                    Image(systemName: bizStore.profile.categoriaIcon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.seilGold)
                }

                Text(bizStore.profile.nombre.isEmpty ? "Mi negocio" : bizStore.profile.nombre)
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                    .lineLimit(2)

                Text(bizStore.profile.categoriaLabel)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundColor(.seilMuted)

                HStack(spacing: 5) {
                    Circle().fill(Color.seilGreen).frame(width: 6, height: 6)
                    Text("Abierto")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.seilGreen)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.seilGreen.opacity(0.12))
                .clipShape(Capsule())
            }
            .padding(.horizontal, 20)
            .padding(.top, 28)
            .padding(.bottom, 24)

            Rectangle()
                .fill(Color.seilBorder)
                .frame(height: 1)
                .padding(.horizontal, 16)

            Spacer().frame(height: 12)

            ForEach(items, id: \.index) { item in
                BizSidebarRow(
                    item: item,
                    isSelected: selectedTab == item.index
                ) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(SeillAnimation.chrome) {
                        selectedTab = item.index
                    }
                }
            }

            Spacer()

            Text("Seillo · Panel de negocio")
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(.seilMuted)
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
        }
        .frame(maxHeight: .infinity)
        .background(Color.seilSurface)
    }
}

private struct BizSidebarRow: View {
    let item: SidebarItem
    let isSelected: Bool
    let action: () -> Void

    private var activeColor: Color { item.isCenter ? .seilGold : .seilAccent }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(
                            isSelected
                            ? activeColor.opacity(item.isCenter ? 0.20 : 0.15)
                            : Color.clear
                        )
                        .frame(width: 38, height: 38)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(
                                    isSelected ? activeColor.opacity(0.25) : Color.clear,
                                    lineWidth: 1
                                )
                        )

                    Image(systemName: item.icon)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(isSelected ? activeColor : .seilMuted)
                        .shadow(
                            color: isSelected ? activeColor.opacity(0.22) : .clear,
                            radius: 6,
                            y: 2
                        )
                }

                Text(item.label)
                    .font(.system(size: 13, weight: isSelected ? .bold : .semibold, design: .rounded))
                    .foregroundColor(isSelected ? .seilText : .seilMuted2)

                Spacer()

                if isSelected {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(activeColor)
                        .frame(width: 3, height: 20)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(
                isSelected
                ? activeColor.opacity(0.06)
                : Color.clear
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
