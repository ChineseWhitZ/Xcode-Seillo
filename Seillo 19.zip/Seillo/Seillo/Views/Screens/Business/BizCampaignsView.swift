import SwiftUI
import Combine

// Tipos Campaign, CampaignType, CampaignStatus definidos en Models/Campaign.swift

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - BizCampaignsView
// ═══════════════════════════════════════════════════════════════════════════════

struct BizCampaignsView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var campaigns  : [Campaign] = []
    @State private var loading    = true
    @State private var errorMsg   : String?    = nil
    @State private var showCreate = false
    @State private var deleteTarget: Campaign? = nil
    @State private var appear     = false

    private let api = APIClient.shared

    private var active:  [Campaign] { campaigns.filter { $0.status != .expired } }
    private var expired: [Campaign] { campaigns.filter { $0.status == .expired } }

    // MARK: - Carga

    private func cargar() async {
        loading  = true
        errorMsg = nil
        do {
            let dtos: [CampaniaDTO] = try await api.get("api/negocio/campanias")
            campaigns = dtos.map { campaignFromDTO($0) }
        } catch {
            errorMsg = error.localizedDescription
        }
        loading = false
    }

    private func campaignFromDTO(_ dto: CampaniaDTO) -> Campaign {
        let type: CampaignType = switch dto.tipo {
            case "double_stamps": .doubleStamps
            case "happy_hour":    .happyHour
            default:              .specialOffer
        }
        let status: CampaignStatus = switch dto.estado {
            case "active":     .active
            case "paused":     .paused
            case "scheduled":  .scheduled
            default:           .expired
        }
        let isoFmt = ISO8601DateFormatter()
        let start  = dto.fechaInicio.flatMap { isoFmt.date(from: $0) } ?? Date()
        let end    = dto.fechaFin.flatMap    { isoFmt.date(from: $0) } ?? Date()

        return Campaign(
            id: dto.id, type: type,
            title: dto.titulo, description: dto.descripcion ?? "",
            startDate: start, endDate: end, status: status,
            programaId: dto.programaId, programaNombre: dto.programaNombre
        )
    }

    // MARK: - Acciones

    private func toggleStatus(_ c: Campaign) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let nuevoEstado = c.isActive ? "paused" : "active"
        withAnimation { c.status = c.isActive ? .paused : .active }
        Task {
            do {
                try await api.patch(
                    "api/negocio/campanias/\(c.id)/estado",
                    body: CambiarEstadoCampaniaRequest(estado: nuevoEstado)
                )
            } catch {
                // Revertir si falla
                withAnimation { c.status = c.status == .paused ? .active : .paused }
            }
        }
    }

    private func eliminar(_ c: Campaign) {
        Task {
            do {
                try await api.delete("api/negocio/campanias/\(c.id)")
                withAnimation { campaigns.removeAll { $0.id == c.id } }
            } catch {
                // Silently ignore — la campaña sigue en lista
            }
        }
    }

    // MARK: - Body

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            VStack(spacing: 0) {
                header
                    .padding(.horizontal, 22).padding(.top, 18).padding(.bottom, 16)

                newCampaignButton
                    .padding(.horizontal, 16).padding(.bottom, 20)

                if loading {
                    Spacer()
                    ProgressView().tint(.seilAccent)
                    Spacer()
                } else if let msg = errorMsg {
                    Spacer()
                    VStack(spacing: 14) {
                        Image(systemName: "wifi.slash").font(.system(size: 36)).foregroundColor(.seilMuted)
                        Text(msg).font(SeillFont.body(13)).foregroundColor(.seilMuted2).multilineTextAlignment(.center)
                        Button { Task { await cargar() } } label: {
                            Text("Reintentar")
                                .font(SeillFont.label(13)).foregroundColor(.seilAccent)
                                .padding(.horizontal, 20).padding(.vertical, 10)
                                .background(Color.seilAccent.opacity(0.12)).clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 32)
                    Spacer()
                } else if campaigns.isEmpty {
                    emptyState
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 0) {
                            if !active.isEmpty {
                                sectionLabel("\(active.count) campaña\(active.count > 1 ? "s" : "") en curso")
                                    .padding(.bottom, 10)

                                ForEach(Array(active.enumerated()), id: \.element.id) { i, c in
                                    CampaignCard(
                                        campaign: c,
                                        onToggle: { toggleStatus(c) },
                                        onDelete: { deleteTarget = c }
                                    )
                                    .padding(.bottom, 10)
                                    .opacity(appear ? 1 : 0)
                                    .offset(y: appear ? 0 : 16)
                                    .animation(.easeOut(duration: 0.35).delay(0.08 + Double(i) * 0.05), value: appear)
                                }
                            }

                            if !expired.isEmpty {
                                sectionLabel("Historial")
                                    .padding(.top, active.isEmpty ? 0 : 16).padding(.bottom, 10)

                                ForEach(expired) { c in
                                    CampaignCard(campaign: c, onToggle: nil, onDelete: { deleteTarget = c })
                                        .padding(.bottom, 10)
                                }
                            }

                            Spacer().frame(height: 40)
                        }
                        .padding(.horizontal, 16)
                    }
                }
            }
        }
        .sheet(isPresented: $showCreate) {
            CreateCampaignSheet { newCampaign in
                withAnimation { campaigns.insert(newCampaign, at: 0) }
                // Recargar para tener el ID real del backend
                Task { await cargar() }
            }
            .presentationDetents([.large])
            .presentationDragIndicator(.hidden)
            .presentationBackground(Color.seilSurface)
        }
        .sheet(item: $deleteTarget) { target in
            DeleteConfirmSheet(title: target.title) { eliminar(target) }
                .presentationDetents([.height(340)])
                .presentationDragIndicator(.hidden)
                .presentationBackground(.ultraThinMaterial)
        }
        .task { await cargar() }
        .onAppear { withAnimation(SeillAnimation.chrome) { appear = true } }
    }

    // MARK: - Subviews

    private var header: some View {
        HStack {
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.seilText)
                    .frame(width: 36, height: 36)
                    .glassEffect(in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)

            Spacer().frame(width: 12)

            VStack(alignment: .leading, spacing: 2) {
                Text("Campañas")
                    .font(.system(size: 22, weight: .heavy, design: .rounded))
                    .foregroundColor(.seilText)
                Text("Gestiona tus promociones activas")
                    .font(SeillFont.body(12)).foregroundColor(.seilMuted)
            }

            Spacer()
        }
        .opacity(appear ? 1 : 0).offset(y: appear ? 0 : 14)
    }

    private var newCampaignButton: some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            showCreate = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "plus").font(.system(size: 16, weight: .bold))
                Text("Nueva campaña").font(SeillFont.headline(14))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 15)
            .background(LinearGradient(colors: [.seilAccent, .seilAccent2], startPoint: .leading, endPoint: .trailing))
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .shadow(color: Color.seilAccent.opacity(0.35), radius: 14, y: 6)
        }
        .buttonStyle(.plain)
        .opacity(appear ? 1 : 0).offset(y: appear ? 0 : 14)
        .animation(.easeOut(duration: 0.35).delay(0.06), value: appear)
    }

    private func sectionLabel(_ text: String) -> some View {
        Text(text).font(.system(size: 11, weight: .bold)).foregroundColor(.seilMuted).frame(maxWidth: .infinity, alignment: .leading)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            ZStack {
                Circle().fill(Color.seilCard).frame(width: 64, height: 64).overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                Image(systemName: "megaphone").font(.system(size: 26)).foregroundColor(.seilMuted)
            }
            Text("Sin campañas activas").font(SeillFont.headline(14)).foregroundColor(.seilText)
            Text("Crea tu primera campaña\npara premiar a tus clientes")
                .font(SeillFont.body(12)).foregroundColor(.seilMuted).multilineTextAlignment(.center)
            Spacer()
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - CampaignCard
// ═══════════════════════════════════════════════════════════════════════════════

private struct CampaignCard: View {
    @ObservedObject var campaign: Campaign
    let onToggle: (() -> Void)?
    let onDelete: () -> Void

    private static let dateFmt: DateFormatter = {
        let f = DateFormatter(); f.dateFormat = "d/M/yyyy"; return f
    }()

    private var isExpired: Bool { campaign.status == .expired }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(isExpired ? Color.seilBorder : campaign.type.color.opacity(0.12))
                        .frame(width: 42, height: 42)
                    Image(systemName: campaign.type.icon)
                        .font(.system(size: 18))
                        .foregroundColor(isExpired ? .seilMuted : campaign.type.color)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(campaign.type.label.uppercased())
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundColor(isExpired ? .seilMuted : campaign.type.color)
                            .tracking(0.6)
                        Spacer()
                        Text(campaign.status.label)
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundColor(campaign.status.color)
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .glassEffect(in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).stroke(campaign.status.color.opacity(0.35), lineWidth: 1))
                    }
                    Text(campaign.title)
                        .font(SeillFont.headline(14))
                        .foregroundColor(isExpired ? .seilMuted2 : .seilText)
                        .lineLimit(2)
                }
            }
            .padding(16)

            Text(campaign.description)
                .font(SeillFont.body(12)).foregroundColor(.seilMuted2).lineSpacing(3)
                .padding(.horizontal, 16).padding(.bottom, 12)

            HStack {
                Image(systemName: "calendar").font(.system(size: 12)).foregroundColor(.seilMuted)
                Text("\(Self.dateFmt.string(from: campaign.startDate)) — \(Self.dateFmt.string(from: campaign.endDate))")
                    .font(SeillFont.caption(11)).foregroundColor(.seilMuted)
                Spacer()
                if !isExpired {
                    let days = campaign.daysLeft
                    Text(days == 0 ? "Vence hoy" : "Faltan \(days) días")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(days <= 2 ? Color.seilRose : .seilMuted2)
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 12)

            Rectangle().fill(Color.seilBorder).frame(height: 1)

            HStack(spacing: 0) {
                if let toggle = onToggle {
                    Button { toggle() } label: {
                        HStack(spacing: 5) {
                            Image(systemName: campaign.isActive ? "pause.fill" : "play.fill").font(.system(size: 12))
                            Text(campaign.isActive ? "Pausar" : "Reanudar").font(SeillFont.label(12))
                        }
                        .foregroundColor(.seilMuted2).frame(maxWidth: .infinity).padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    Rectangle().fill(Color.seilBorder).frame(width: 1, height: 28)
                }

                Button { onDelete() } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "trash").font(.system(size: 12))
                        Text("Eliminar").font(SeillFont.label(12))
                    }
                    .foregroundColor(Color.seilRose).frame(maxWidth: .infinity).padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
        }
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(isExpired ? Color.seilBorder : campaign.type.color.opacity(0.18), lineWidth: 1)
        )
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARK: - CampaignTemplate + CreateCampaignSheet + helpers (sin cambios)
// ═══════════════════════════════════════════════════════════════════════════════

private struct CampaignTemplate: Identifiable {
    let id    = UUID()
    let icon  : String
    let label : String
    let title : String
    let desc  : String
    let type  : CampaignType
    let days  : Int
    let color : Color
}

private let campaignTemplates: [CampaignTemplate] = [
    CampaignTemplate(icon: "star.circle.fill", label: "Doble lunes",  title: "Doble sellos cada lunes",       desc: "Visítanos los lunes y acumula el doble de sellos.", type: .doubleStamps, days: 30, color: .seilAccent),
    CampaignTemplate(icon: "clock.fill",        label: "Happy hour",  title: "Happy hour: 3pm a 6pm",          desc: "Sellos dobles de lunes a viernes en horario de tarde.", type: .happyHour, days: 14, color: .seilGold),
    CampaignTemplate(icon: "person.2.fill",     label: "Trae un amigo", title: "Trae a un amigo y gana",      desc: "Si vienes con un amigo nuevo, ambos reciben un sello extra.", type: .specialOffer, days: 21, color: .seilBlue),
    CampaignTemplate(icon: "sun.max.fill",      label: "Fin de semana", title: "Fin de semana especial",      desc: "Sábados y domingos con doble sellos.", type: .doubleStamps, days: 7, color: .seilPurple),
    CampaignTemplate(icon: "gift.fill",         label: "Premio #100",  title: "Premio para nuestro cliente 100", desc: "Celebramos nuestra primera centena de clientes.", type: .specialOffer, days: 10, color: .seilGreen),
]

struct CreateCampaignSheet: View {
    let onCreate: (Campaign) -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var selectedType   : CampaignType = .doubleStamps
    @State private var title          : String = ""
    @State private var desc           : String = ""
    @State private var startDate      : Date   = .now
    @State private var endDate        : Date   = .now + 7*86400
    @State private var saving         = false
    @State private var appliedTemplate: UUID?  = nil

    private let api = APIClient.shared
    private var canSave: Bool { !title.trimmingCharacters(in: .whitespaces).isEmpty && endDate > startDate }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Capsule().fill(Color.seilBorder).frame(width: 36, height: 4).frame(maxWidth: .infinity)
                    .padding(.top, 12).padding(.bottom, 20)

                Text("Nueva campaña").font(.system(size: 20, weight: .heavy, design: .rounded)).foregroundColor(.seilText).padding(.horizontal, 22)
                Text("Define el tipo y duración de tu promoción").font(SeillFont.body(12)).foregroundColor(.seilMuted)
                    .padding(.horizontal, 22).padding(.top, 4).padding(.bottom, 24)

                fieldLabel("INICIO RÁPIDO").padding(.horizontal, 22).padding(.bottom, 10)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(campaignTemplates) { tpl in
                            let isApplied = appliedTemplate == tpl.id
                            Button {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                withAnimation(SeillAnimation.chrome) {
                                    appliedTemplate = isApplied ? nil : tpl.id
                                    if !isApplied { selectedType = tpl.type; title = tpl.title; desc = tpl.desc; endDate = .now + Double(tpl.days)*86400 }
                                }
                            } label: {
                                HStack(spacing: 7) {
                                    Image(systemName: tpl.icon).font(.system(size: 12, weight: .semibold))
                                    Text(tpl.label).font(.system(size: 12, weight: .bold))
                                    if isApplied { Image(systemName: "checkmark").font(.system(size: 10, weight: .heavy)) }
                                }
                                .foregroundColor(isApplied ? .white : tpl.color)
                                .padding(.horizontal, 14).padding(.vertical, 10)
                                .background(isApplied ? tpl.color : tpl.color.opacity(0.10))
                                .clipShape(Capsule())
                                .overlay(Capsule().stroke(isApplied ? Color.clear : tpl.color.opacity(0.30), lineWidth: 1))
                                .shadow(color: isApplied ? tpl.color.opacity(0.40) : .clear, radius: 8, y: 3)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16).padding(.bottom, 4)
                }
                .padding(.bottom, 20)

                if appliedTemplate != nil {
                    HStack(spacing: 6) {
                        Image(systemName: "wand.and.stars").font(.system(size: 11, weight: .semibold)).foregroundColor(.seilAccent)
                        Text("Plantilla aplicada · puedes editar cualquier campo").font(.system(size: 11)).foregroundColor(.seilMuted2)
                        Spacer()
                        Button {
                            withAnimation(SeillAnimation.chrome) { appliedTemplate = nil; title = ""; desc = ""; selectedType = .doubleStamps; endDate = .now + 7*86400 }
                        } label: { Text("Limpiar").font(.system(size: 10, weight: .bold)).foregroundColor(.seilAccent) }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 16).padding(.bottom, 16)
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }

                fieldLabel("TIPO DE CAMPAÑA").padding(.horizontal, 22).padding(.bottom, 10)
                VStack(spacing: 8) {
                    ForEach(CampaignType.allCases) { type in
                        TypeOptionRow(type: type, isSelected: selectedType == type) {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(SeillAnimation.chrome) { selectedType = type }
                        }
                    }
                }
                .padding(.horizontal, 16).padding(.bottom, 22)

                fieldLabel("NOMBRE").padding(.horizontal, 22).padding(.bottom, 8)
                TextField("Ej. Doble sellos de lunes a miércoles", text: $title)
                    .font(SeillFont.body(13)).foregroundColor(.seilText).padding(14)
                    .background(Color.seilCard).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilBorder, lineWidth: 1))
                    .padding(.horizontal, 16).padding(.bottom, 16)

                fieldLabel("DESCRIPCIÓN (OPCIONAL)").padding(.horizontal, 22).padding(.bottom, 8)
                TextField("Explícale a tus clientes de qué trata", text: $desc, axis: .vertical)
                    .font(SeillFont.body(13)).foregroundColor(.seilText).lineLimit(3...5).padding(14)
                    .background(Color.seilCard).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilBorder, lineWidth: 1))
                    .padding(.horizontal, 16).padding(.bottom, 22)

                fieldLabel("DURACIÓN").padding(.horizontal, 22).padding(.bottom, 10)
                HStack(spacing: 10) {
                    DatePickerField(label: "Inicio", date: $startDate)
                    DatePickerField(label: "Fin",    date: $endDate)
                }
                .padding(.horizontal, 16).padding(.bottom, 28)

                Button {
                    guard canSave else { return }
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    saving = true

                    let tipoStr: String = switch selectedType {
                        case .doubleStamps: "double_stamps"
                        case .happyHour:    "happy_hour"
                        case .specialOffer: "special_offer"
                    }
                    let fmt = DateFormatter()
                    fmt.dateFormat = "yyyy-MM-dd"

                    Task {
                        do {
                            let body = CrearCampaniaRequest(
                                tipo        : tipoStr,
                                titulo      : title.trimmingCharacters(in: .whitespaces),
                                descripcion : desc.isEmpty ? nil : desc,
                                enviarPush  : false,
                                fechaInicio : fmt.string(from: startDate),
                                fechaFin    : fmt.string(from: endDate),
                                programaId  : nil,
                                horaInicio  : nil,
                                horaFin     : nil
                            )
                            let _: CampaniaDTO = try await api.post("api/negocio/campanias", body: body)
                        } catch { }

                        // Construir objeto local para UI inmediata
                        let status: CampaignStatus = startDate > .now ? .scheduled : .active
                        let campaign = Campaign(
                            id: UUID().uuidString, type: selectedType,
                            title: title.trimmingCharacters(in: .whitespaces),
                            description: desc.isEmpty ? selectedType.subtitle : desc,
                            startDate: startDate, endDate: endDate, status: status
                        )
                        await MainActor.run {
                            onCreate(campaign)
                            dismiss()
                        }
                    }
                } label: {
                    Group {
                        if saving { ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white)).scaleEffect(0.9) }
                        else { Text("Crear campaña").font(SeillFont.headline(15)) }
                    }
                    .foregroundColor(.white).frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(canSave ? Color.seilAccent : Color.seilAccent.opacity(0.3))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: canSave ? Color.seilAccent.opacity(0.35) : .clear, radius: 14, y: 6)
                }
                .buttonStyle(.plain).disabled(!canSave || saving)
                .padding(.horizontal, 16).padding(.bottom, 32)
            }
        }
    }

    private func fieldLabel(_ text: String) -> some View {
        Text(text).font(.system(size: 10, weight: .heavy)).foregroundColor(.seilMuted).tracking(1.2)
    }
}

private struct TypeOptionRow: View {
    let type      : CampaignType
    let isSelected: Bool
    let onTap     : () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(isSelected ? type.color.opacity(0.15) : Color.seilBorder).frame(width: 38, height: 38)
                    Image(systemName: type.icon).font(.system(size: 16)).foregroundColor(isSelected ? type.color : .seilMuted)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(type.label).font(SeillFont.headline(13)).foregroundColor(isSelected ? .seilText : .seilMuted2)
                    Text(type.subtitle).font(SeillFont.caption(11)).foregroundColor(.seilMuted)
                }
                Spacer()
                if isSelected {
                    ZStack {
                        Circle().fill(type.color).frame(width: 20, height: 20)
                        Image(systemName: "checkmark").font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                    }
                }
            }
            .padding(14)
            .background(isSelected ? type.color.opacity(0.07) : Color.seilCard)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(isSelected ? type.color.opacity(0.4) : Color.seilBorder, lineWidth: isSelected ? 1.5 : 1))
        }
        .buttonStyle(.plain).animation(.easeOut(duration: 0.18), value: isSelected)
    }
}

private struct DatePickerField: View {
    let label: String
    @Binding var date: Date

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.system(size: 10, weight: .bold)).foregroundColor(.seilMuted)
            DatePicker("", selection: $date, displayedComponents: .date).datePickerStyle(.compact).labelsHidden().frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(12).background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.seilBorder, lineWidth: 1))
        .frame(maxWidth: .infinity)
    }
}

private struct DeleteConfirmSheet: View {
    let title    : String
    let onConfirm: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            Capsule().fill(Color.seilBorder).frame(width: 36, height: 4).padding(.top, 12).padding(.bottom, 20)
            ZStack {
                Circle().fill(Color.seilRose.opacity(0.12)).frame(width: 56, height: 56)
                Image(systemName: "trash.fill").font(.system(size: 22)).foregroundColor(Color.seilRose)
            }
            Spacer().frame(height: 14)
            Text("¿Eliminar campaña?").font(.system(size: 17, weight: .heavy, design: .rounded)).foregroundColor(.seilText)
            Spacer().frame(height: 6)
            Text("Esta acción no se puede deshacer.").font(SeillFont.body(13)).foregroundColor(.seilMuted2)
            Spacer().frame(height: 24)
            HStack(spacing: 10) {
                Button { dismiss() } label: {
                    Text("Cancelar").font(SeillFont.headline(14)).foregroundColor(.seilMuted).frame(maxWidth: .infinity).padding(.vertical, 14)
                        .background(Color.seilCard).clipShape(RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)
                Button { onConfirm(); dismiss() } label: {
                    Text("Eliminar").font(SeillFont.headline(14)).foregroundColor(.white).frame(maxWidth: .infinity).padding(.vertical, 14)
                        .background(Color.seilRose).clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            Spacer().frame(height: 20)
        }
    }
}
