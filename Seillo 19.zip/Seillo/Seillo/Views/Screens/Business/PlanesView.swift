import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// PlanesView.swift
//
// Ruta: Seillo/Seillo/Views/Screens/Business/PlanesView.swift
//
// Tabla comparativa de planes SaaS de Seillo.
// Usa el sistema global de SubscriptionPlan / PlanCatalog / PlanTier
// definido en Models/SubscriptionPlan.swift.
//
// Acceso: BizTabProfileView → "Ver planes"
//         BizTabDashboard   → "Mejorar plan"
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Helpers de presentación (solo para esta vista)

private extension SubscriptionPlan {
    var icon: String {
        switch tier {
        case .free:       return "leaf.fill"
        case .starter:    return "flame.fill"
        case .growth:     return "chart.line.uptrend.xyaxis"
        case .pro:        return "bolt.fill"
        case .enterprise: return "crown.fill"
        }
    }

    var isPopular: Bool { tier == .pro }
}

// MARK: - Modelo de fila de comparación

private struct PlanFeatureRow {
    let texto: String
    /// Clausura que recibe un SubscriptionPlan y devuelve si el feature está incluido.
    let incluido: (SubscriptionPlan) -> Bool
    var isNew: Bool = false
}

private let featureRows: [PlanFeatureRow] = [
    .init(texto: "Programa de fidelidad",           incluido: { _ in true }),
    .init(texto: "Escaneo QR básico",               incluido: { _ in true }),
    .init(texto: "Dashboard semanal",               incluido: { _ in true }),
    .init(texto: "Límite de clientes",              incluido: { _ in true }),    // label especial abajo
    .init(texto: "Locales activos",                 incluido: { _ in true }),    // label especial abajo
    .init(texto: "Tarjetas activas",                incluido: { _ in true }),    // label especial abajo
    .init(texto: "Campañas y promociones",          incluido: { $0.tienePromociones }),
    .init(texto: "Notificaciones push",             incluido: { $0.tienePushNotifications }),
    .init(texto: "Gestión de staff",                incluido: { $0.tieneStaff }),
    .init(texto: "Analítica avanzada",              incluido: { $0.tieneAnaliticaAvanzada }),
    .init(texto: "Automatizaciones",                incluido: { $0.tieneAutomatizaciones }, isNew: true),
    .init(texto: "Branding propio",                 incluido: { $0.tieneBrandingPropio }),
    .init(texto: "Soporte prioritario",             incluido: { $0.tieneSoportePrioritario }),
    .init(texto: "Integraciones API",               incluido: { $0.tieneIntegracionesApi }),
    .init(texto: "Onboarding dedicado",             incluido: { $0.tieneOnboardingDedicado }),
]

// MARK: - PlanesView

struct PlanesView: View {
    @Environment(\.dismiss) var dismiss

    @State private var selectedPlan: SubscriptionPlan = PlanCatalog.pro
    @State private var appear = false

    /// Planes que se muestran en el picker (excluye Enterprise — contacto directo)
    private let planes: [SubscriptionPlan] = [
        PlanCatalog.free,
        PlanCatalog.starter,
        PlanCatalog.growth,
        PlanCatalog.pro,
    ]

    var body: some View {
        ZStack {
            Color.seilBg.ignoresSafeArea()

            RadialGradient(
                colors: [selectedPlan.color.opacity(0.10), .clear],
                center: .init(x: 0.5, y: 0.12),
                startRadius: 0, endRadius: 360
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.45), value: selectedPlan.tier)

            VStack(spacing: 0) {
                topBar

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        Spacer().frame(height: 8)
                        planPickerSection
                        selectedPlanCard
                        featureTable
                        enterpriseBanner
                        ctaSection
                        Spacer().frame(height: 40)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .onAppear {
            withAnimation(SeillAnimation.chrome) { appear = true }
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tap(); dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.seilMuted2)
                        .frame(width: 36, height: 36)
                        .background(Color.seilCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.seilBorder, lineWidth: 1))
                }
                .buttonStyle(.plain)
                Spacer()
                Text("Planes Seillo")
                    .font(SeillFont.headline(15))
                    .foregroundColor(.seilText)
                Spacer()
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 14)
            Rectangle().fill(Color.seilBorder).frame(height: 1)
        }
        .opacity(appear ? 1 : 0)
    }

    // MARK: - Plan picker

    private var planPickerSection: some View {
        HStack(spacing: 8) {
            ForEach(planes, id: \.tier.rawValue) { plan in
                Button {
                    Haptics.tap()
                    withAnimation(SeillAnimation.chrome) { selectedPlan = plan }
                } label: {
                    let isSelected = selectedPlan.tier == plan.tier
                    VStack(spacing: 6) {
                        ZStack(alignment: .topTrailing) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(isSelected ? plan.color.opacity(0.20) : Color.seilCard)
                                    .frame(width: 48, height: 48)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(isSelected ? plan.color.opacity(0.50) : Color.seilBorder, lineWidth: 1.5)
                                    )
                                Image(systemName: plan.icon)
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundColor(isSelected ? plan.color : .seilMuted2)
                            }
                            if plan.isPopular {
                                Text("Popular")
                                    .font(.system(size: 7, weight: .heavy))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 5).padding(.vertical, 2)
                                    .background(Color.seilAccent)
                                    .clipShape(Capsule())
                                    .offset(x: 6, y: -6)
                            }
                        }
                        Text(plan.nombre)
                            .font(.system(size: 11, weight: isSelected ? .heavy : .semibold))
                            .foregroundColor(isSelected ? plan.color : .seilMuted2)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(isSelected ? plan.color.opacity(0.06) : Color.clear)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .animation(SeillAnimation.chrome, value: selectedPlan.tier)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(8)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 12)
    }

    // MARK: - Selected plan card

    private var selectedPlanCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(selectedPlan.color.opacity(0.18))
                        .frame(width: 52, height: 52)
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(selectedPlan.color.opacity(0.30), lineWidth: 1))
                    Image(systemName: selectedPlan.icon)
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundColor(selectedPlan.color)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text("Plan \(selectedPlan.nombre)")
                            .font(SeillFont.display(20))
                            .foregroundColor(.seilText)
                        if selectedPlan.isPopular {
                            Text("Más popular")
                                .font(.system(size: 9, weight: .heavy))
                                .foregroundColor(.white)
                                .padding(.horizontal, 8).padding(.vertical, 3)
                                .background(Color.seilAccent)
                                .clipShape(Capsule())
                        }
                    }
                    HStack(spacing: 4) {
                        Text(selectedPlan.tier == .free ? "Gratis" : "Consultar precio")
                            .font(SeillFont.headline(16))
                            .foregroundColor(selectedPlan.color)
                    }
                    Text(selectedPlan.tagline)
                        .font(SeillFont.body(12))
                        .foregroundColor(.seilMuted2)
                }

                Spacer()
            }

            // Límites rápidos del plan
            HStack(spacing: 12) {
                limitChip(icon: "person.2.fill",  label: selectedPlan.labelLimiteClientes(), color: selectedPlan.color)
                limitChip(icon: "mappin.circle.fill", label: selectedPlan.labelLimiteLocales(), color: selectedPlan.color)
                limitChip(icon: "creditcard.fill", label: selectedPlan.labelLimiteTarjetas(), color: selectedPlan.color)
            }
        }
        .padding(18)
        .background(
            LinearGradient(
                colors: [selectedPlan.color.opacity(0.10), selectedPlan.color.opacity(0.04)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(selectedPlan.color.opacity(0.28), lineWidth: 1))
        .opacity(appear ? 1 : 0)
        .animation(.easeInOut(duration: 0.35), value: selectedPlan.tier)
    }

    private func limitChip(icon: String, label: String, color: Color) -> some View {
        HStack(spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(color)
            Text(label)
                .font(SeillFont.caption(10))
                .foregroundColor(.seilMuted2)
        }
        .padding(.horizontal, 10).padding(.vertical, 6)
        .background(Color.seilCard)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.seilBorder, lineWidth: 1))
    }

    // MARK: - Feature table

    private var featureTable: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("COMPARACIÓN COMPLETA")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.seilMuted)
                .tracking(1.3)

            // Header columnas
            HStack {
                Spacer()
                ForEach(planes, id: \.tier.rawValue) { plan in
                    Text(plan.nombre)
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundColor(plan.tier == selectedPlan.tier ? plan.color : .seilMuted)
                        .frame(width: 48, alignment: .center)
                }
            }
            .padding(.horizontal, 14)

            VStack(spacing: 0) {
                ForEach(Array(featureRows.enumerated()), id: \.offset) { i, row in
                    HStack(spacing: 0) {
                        HStack(spacing: 6) {
                            Text(row.texto)
                                .font(SeillFont.body(12))
                                .foregroundColor(.seilText)
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                            if row.isNew {
                                Text("Nuevo")
                                    .font(.system(size: 8, weight: .heavy))
                                    .foregroundColor(.seilAccent)
                                    .padding(.horizontal, 5).padding(.vertical, 2)
                                    .background(Color.seilAccent.opacity(0.12))
                                    .clipShape(Capsule())
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)

                        ForEach(planes, id: \.tier.rawValue) { plan in
                            featureCell(included: row.incluido(plan), plan: plan)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(i % 2 == 0 ? Color.seilCard : Color.seilCard2)

                    if i < featureRows.count - 1 {
                        Divider().background(Color.seilBorder)
                    }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.12), value: appear)
    }

    private func featureCell(included: Bool, plan: SubscriptionPlan) -> some View {
        let isSelected = plan.tier == selectedPlan.tier
        return Image(systemName: included ? "checkmark.circle.fill" : "xmark.circle")
            .font(.system(size: 18))
            .foregroundColor(
                included
                    ? (isSelected ? plan.color : plan.color.opacity(0.45))
                    : Color.white.opacity(0.12)
            )
            .frame(width: 48, alignment: .center)
            .animation(.easeInOut(duration: 0.22), value: selectedPlan.tier)
    }

    // MARK: - Enterprise banner

    private var enterpriseBanner: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.seilPurple.opacity(0.15))
                    .frame(width: 42, height: 42)
                Image(systemName: "crown.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.seilPurple)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("¿Necesitas más?")
                    .font(SeillFont.headline(13))
                    .foregroundColor(.seilText)
                Text("Habla con nosotros para un plan Enterprise a medida.")
                    .font(SeillFont.body(12))
                    .foregroundColor(.seilMuted2)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.seilMuted)
        }
        .padding(16)
        .background(Color.seilCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.seilBorder, lineWidth: 1))
        .opacity(appear ? 1 : 0)
    }

    // MARK: - CTA

    private var ctaSection: some View {
        VStack(spacing: 12) {
            if selectedPlan.tier == .free {
                Text("Estás usando el plan gratuito")
                    .font(SeillFont.body(13))
                    .foregroundColor(.seilMuted2)
                    .frame(maxWidth: .infinity, alignment: .center)
            } else {
                // CTA → abre mailto a ventas
                Button {
                    Haptics.success()
                    let subject = "Quiero el plan \(selectedPlan.nombre) — Seillo"
                    let subjectEnc = subject.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    if let url = URL(string: "mailto:ventas@seillo.site?subject=\(subjectEnc)") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "envelope.fill")
                            .font(.system(size: 14, weight: .semibold))
                        Text("Solicitar Plan \(selectedPlan.nombre)")
                            .font(SeillFont.headline(15))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(
                            colors: [selectedPlan.color, selectedPlan.color.opacity(0.80)],
                            startPoint: .leading, endPoint: .trailing
                        )
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: selectedPlan.color.opacity(0.40), radius: 14, y: 4)
                }
                .buttonStyle(.plain)
                .animation(.easeInOut(duration: 0.25), value: selectedPlan.tier)

                // Link alternativo a la web
                Button {
                    if let url = URL(string: "https://seillo.site/planes") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Text("Ver detalles en seillo.site →")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(selectedPlan.color)
                }
                .buttonStyle(.plain)
            }
        }
        .opacity(appear ? 1 : 0)
        .animation(.easeOut(duration: 0.4).delay(0.16), value: appear)
    }
}
