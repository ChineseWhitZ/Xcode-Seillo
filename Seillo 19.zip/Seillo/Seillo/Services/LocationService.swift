import Foundation
import CoreLocation
import Combine

// ─── LocationService ──────────────────────────────────────────────────────────
//
// Wrapper ligero de CLLocationManager para uso en SwiftUI.
// Solicita permiso "cuando se usa", obtiene una lectura de ubicación
// y publica la coordenada. No mantiene actualización continua
// (ahorra batería — solo se necesita la posición al abrir TabCercaView).
//
// IMPORTANTE: añadir en Info.plist:
//   NSLocationWhenInUseUsageDescription  →  "Seillo usa tu ubicación para
//   mostrarte negocios cercanos con programas de lealtad activos."
//
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class LocationService: NSObject, ObservableObject {

    @Published var coordinate: CLLocationCoordinate2D? = nil
    @Published var status: CLAuthorizationStatus = .notDetermined

    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<CLLocationCoordinate2D?, Never>?

    override init() {
        super.init()
        manager.delegate     = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        status = manager.authorizationStatus
    }

    // Solicita permiso si es necesario y devuelve la coordenada actual.
    func requestAndFetch() async {
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            coordinate = await fetchOnce()
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
            // Esperar a que el usuario responda — el delegate actualiza status
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if manager.authorizationStatus == .authorizedWhenInUse ||
               manager.authorizationStatus == .authorizedAlways {
                coordinate = await fetchOnce()
            }
        default:
            break   // denegado — no insistir
        }
    }

    // Obtiene una sola lectura de posición.
    private func fetchOnce() async -> CLLocationCoordinate2D? {
        return await withCheckedContinuation { cont in
            self.continuation = cont
            manager.requestLocation()
        }
    }
}

// ── CLLocationManagerDelegate ─────────────────────────────────────────────────

extension LocationService: CLLocationManagerDelegate {

    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        let coord = locations.first?.coordinate
        Task { @MainActor in
            self.continuation?.resume(returning: coord)
            self.continuation = nil
        }
    }

    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        Task { @MainActor in
            self.continuation?.resume(returning: nil)
            self.continuation = nil
        }
    }

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor in
            self.status = manager.authorizationStatus
        }
    }
}
