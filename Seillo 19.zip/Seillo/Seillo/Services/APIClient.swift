import Foundation
import Security

// ─── API Client ──────────────────────────────────────────────────────────────
//
// Capa base de networking para Seillo iOS.
// Equivalente a RetrofitClient.kt + TokenManager.kt de Android.
//
// Responsabilidades:
//   1. URLSession configurada con timeouts
//   2. Persistencia de JWT en Keychain (seguro)
//   3. Persistencia de datos de sesión en UserDefaults
//   4. Métodos HTTP genéricos con inyección automática de Bearer token
//
// Uso:
//   let client = APIClient.shared
//   let tarjetas: [TarjetaDTO] = try await client.get("api/cliente/tarjetas")
//
// Ruta: Seillo/Services/APIClient.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - APIError

enum APIError: LocalizedError {
    case noToken
    case badURL
    case badStatus(Int, String?)
    case decodingFailed(Error)
    case networkError(Error)

    var errorDescription: String? {
        switch self {
        case .noToken:                   return "Sesión expirada. Inicia sesión de nuevo."
        case .badURL:                    return "URL inválida."
        case .badStatus(let code, let msg):
            return msg ?? "Error del servidor (\(code))"
        case .decodingFailed(let err):   return "Error al leer datos: \(err.localizedDescription)"
        case .networkError(let err):     return "Sin conexión: \(err.localizedDescription)"
        }
    }
}

// MARK: - APIClient

final class APIClient: @unchecked Sendable {

    static let shared = APIClient()

    // ── Configuración ───────────────────────────────────────────────────────

    /// URL base del backend en Railway (misma que Android)
    private let baseURL = "https://seillo-backend-production.up.railway.app/"

    private let session: URLSession
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    private init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 30
        session = URLSession(configuration: config)

        decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase

        encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
    }

    // ── Requests genéricos ──────────────────────────────────────────────────

    /// GET autenticado — decodifica JSON a T.
    func get<T: Decodable>(_ path: String, query: [String: String]? = nil) async throws -> T {
        let request = try buildRequest(path: path, method: "GET", query: query)
        return try await execute(request)
    }

    /// POST autenticado con body Encodable — decodifica respuesta a T.
    func post<B: Encodable, T: Decodable>(_ path: String, body: B) async throws -> T {
        var request = try buildRequest(path: path, method: "POST")
        request.httpBody = try encoder.encode(body)
        return try await execute(request)
    }

    /// POST autenticado con body — respuesta ignorada (Void).
    func post<B: Encodable>(_ path: String, body: B) async throws {
        var request = try buildRequest(path: path, method: "POST")
        request.httpBody = try encoder.encode(body)
        try await executeVoid(request)
    }

    /// POST autenticado sin body — decodifica respuesta a T.
    func post<T: Decodable>(_ path: String) async throws -> T {
        let request = try buildRequest(path: path, method: "POST")
        return try await execute(request)
    }

    /// PATCH autenticado con body — decodifica respuesta a T.
    func patch<B: Encodable, T: Decodable>(_ path: String, body: B) async throws -> T {
        var request = try buildRequest(path: path, method: "PATCH")
        request.httpBody = try encoder.encode(body)
        return try await execute(request)
    }

    /// PATCH autenticado con body — respuesta ignorada.
    func patch<B: Encodable>(_ path: String, body: B) async throws {
        var request = try buildRequest(path: path, method: "PATCH")
        request.httpBody = try encoder.encode(body)
        try await executeVoid(request)
    }

    /// PUT autenticado con body — respuesta ignorada.
    func put<B: Encodable>(_ path: String, body: B) async throws {
        var request = try buildRequest(path: path, method: "PUT")
        request.httpBody = try encoder.encode(body)
        try await executeVoid(request)
    }

    /// PUT autenticado sin body — respuesta ignorada.
    func putVoid(_ path: String) async throws {
        let request = try buildRequest(path: path, method: "PUT")
        try await executeVoid(request)
    }

    /// DELETE autenticado — respuesta ignorada.
    func delete(_ path: String) async throws {
        let request = try buildRequest(path: path, method: "DELETE")
        try await executeVoid(request)
    }

    /// GET público (sin token) — decodifica JSON a T.
    func getPublic<T: Decodable>(_ path: String, query: [String: String]? = nil) async throws -> T {
        let request = try buildRequest(path: path, method: "GET", query: query, auth: false)
        return try await execute(request)
    }

    /// POST público (sin token, para login/register) — decodifica a T.
    func postPublic<B: Encodable, T: Decodable>(_ path: String, body: B) async throws -> T {
        var request = try buildRequest(path: path, method: "POST", auth: false)
        request.httpBody = try encoder.encode(body)
        return try await execute(request)
    }

    // ── Build & Execute ─────────────────────────────────────────────────────

    private func buildRequest(
        path: String,
        method: String,
        query: [String: String]? = nil,
        auth: Bool = true
    ) throws -> URLRequest {
        guard var components = URLComponents(string: baseURL + path) else {
            throw APIError.badURL
        }

        if let query {
            components.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }

        guard let url = components.url else { throw APIError.badURL }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if auth {
            guard let token = TokenStore.getToken() else { throw APIError.noToken }
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        return request
    }

    private func execute<T: Decodable>(_ request: URLRequest) async throws -> T {
        let (data, response) = try await performRequest(request)

        guard let http = response as? HTTPURLResponse else {
            throw APIError.badStatus(0, nil)
        }

        guard (200...299).contains(http.statusCode) else {
            let body = try? decoder.decode(ErrorBody.self, from: data)
            throw APIError.badStatus(http.statusCode, body?.error)
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decodingFailed(error)
        }
    }

    private func executeVoid(_ request: URLRequest) async throws {
        let (data, response) = try await performRequest(request)

        guard let http = response as? HTTPURLResponse else {
            throw APIError.badStatus(0, nil)
        }

        guard (200...299).contains(http.statusCode) else {
            let body = try? decoder.decode(ErrorBody.self, from: data)
            throw APIError.badStatus(http.statusCode, body?.error)
        }
    }

    private func performRequest(_ request: URLRequest) async throws -> (Data, URLResponse) {
        do {
            return try await session.data(for: request)
        } catch {
            throw APIError.networkError(error)
        }
    }
}

// MARK: - Error body

private struct ErrorBody: Decodable {
    let error: String?
    let diasRestantes: Int?
}

// MARK: - TokenStore (Keychain)

/// Almacena JWT en Keychain y datos de sesión en UserDefaults.
/// Equivalente a TokenManager.kt de Android (DataStore).
enum TokenStore {

    private static let service = "com.seillo.auth"
    private static let tokenKey = "jwt_token"

    // ── JWT en Keychain ─────────────────────────────────────────────────

    static func saveToken(_ token: String) {
        let data = Data(token.utf8)
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  tokenKey,
        ]

        // Eliminar existente
        SecItemDelete(query as CFDictionary)

        // Guardar nuevo
        var addQuery = query
        addQuery[kSecValueData as String] = data
        SecItemAdd(addQuery as CFDictionary, nil)
    }

    static func getToken() -> String? {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  tokenKey,
            kSecReturnData as String:   true,
            kSecMatchLimit as String:   kSecMatchLimitOne,
        ]

        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func deleteToken() {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  tokenKey,
        ]
        SecItemDelete(query as CFDictionary)
    }

    // ── Datos de sesión en UserDefaults ──────────────────────────────────

    private static let defaults = UserDefaults.standard

    static func saveSession(
        id: String,
        nombre: String,
        email: String,
        tipo: String,
        avatarId: Int = 0,
        codigoAmigo: String? = nil
    ) {
        defaults.set(id,       forKey: "session_user_id")
        defaults.set(nombre,   forKey: "session_user_nombre")
        defaults.set(email,    forKey: "session_user_email")
        defaults.set(tipo,     forKey: "session_user_tipo")
        defaults.set(avatarId, forKey: "session_avatar_id")
        if let codigo = codigoAmigo {
            defaults.set(codigo, forKey: "session_codigo_amigo")
        }
    }

    static var userId: String?       { defaults.string(forKey: "session_user_id") }
    static var userName: String?     { defaults.string(forKey: "session_user_nombre") }
    static var userEmail: String?    { defaults.string(forKey: "session_user_email") }
    static var userTipo: String?     { defaults.string(forKey: "session_user_tipo") }
    static var avatarId: Int         { defaults.integer(forKey: "session_avatar_id") }
    static var codigoAmigo: String?  { defaults.string(forKey: "session_codigo_amigo") }

    static func updateNombre(_ nombre: String)   { defaults.set(nombre, forKey: "session_user_nombre") }
    static func updateAvatarId(_ id: Int)        { defaults.set(id, forKey: "session_avatar_id") }
    static func updateCodigoAmigo(_ c: String)   { defaults.set(c, forKey: "session_codigo_amigo") }

    static var isLoggedIn: Bool { getToken() != nil }

    static func clearAll() {
        deleteToken()
        let keys = [
            "session_user_id", "session_user_nombre", "session_user_email",
            "session_user_tipo", "session_avatar_id", "session_codigo_amigo"
        ]
        keys.forEach { defaults.removeObject(forKey: $0) }
    }
}
