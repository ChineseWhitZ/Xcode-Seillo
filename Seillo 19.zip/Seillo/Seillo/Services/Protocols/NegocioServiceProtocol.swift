import SwiftUI

// ─── Negocio Service Protocol ─────────────────────────────────────────────────
//
// Protocolo para operaciones del lado negocio.
//
// Ruta: Seillo/Services/Protocols/NegocioServiceProtocol.swift
// ─────────────────────────────────────────────────────────────────────────────

protocol NegocioServiceProtocol {

    // ── Perfil ───────────────────────────────────────────────────────────
    func getPerfil() async -> Result<BizProfile, Error>
    func updatePerfil(_ profile: BizProfile) async -> Result<Void, Error>

    // ── Dashboard ────────────────────────────────────────────────────────
    func getDashboard() async -> Result<DashboardData, Error>
    func getSemana() async -> Result<[SemanaEntry], Error>
    func getDistribucion() async -> Result<DistribucionData, Error>

    // ── Clientes ─────────────────────────────────────────────────────────
    func getClientes() async -> Result<ClientesData, Error>

    // ── Programas ────────────────────────────────────────────────────────
    func getProgramas() async -> Result<[ProgramaData], Error>
    func crearPrograma(nombre: String, sellosMeta: Int, premio: String) async -> Result<String, Error>
    func updatePrograma(id: String, nombre: String?, sellosMeta: Int?, premio: String?) async -> Result<Void, Error>

    // ── Escaneo QR ───────────────────────────────────────────────────────
    func escanearQR(code: String) async -> Result<EscaneoResult, Error>

    // ── Horario ──────────────────────────────────────────────────────────
    func getHorario() async -> Result<[HorarioDia], Error>
    func saveHorario(_ horarios: [HorarioDia]) async -> Result<Void, Error>

    // ── Items (menú/servicios) ───────────────────────────────────────────
    func getItems() async -> Result<[NegocioItem], Error>
    func crearItem(_ item: NegocioItemRequest) async -> Result<String, Error>
    func actualizarItem(id: String, _ item: NegocioItemRequest) async -> Result<Void, Error>
    func eliminarItem(id: String) async -> Result<Void, Error>

    // ── Analytics ────────────────────────────────────────────────────────
    func getAnalyticsKPIs() async -> Result<AnalyticsKPIs, Error>
    func getAnalyticsVisitas(periodo: String) async -> Result<[AnalyticsVisita], Error>
    func getAnalyticsHoras(periodo: String) async -> Result<[AnalyticsHora], Error>
    func getAnalyticsTopClientes(periodo: String) async -> Result<[AnalyticsTopCliente], Error>
    func getAnalyticsCompletaciones(periodo: String) async -> Result<AnalyticsCompletaciones, Error>

    // ── Reseñas ──────────────────────────────────────────────────────────
    func getResenas() async -> Result<[ReviewItem], Error>
}

// MARK: - Supporting Data Types

struct DashboardData {
    let sellosHoy   : Int
    let clientesHoy : Int
    let canjesHoy   : Int
    let actividadReciente: [ActividadReciente]
}

struct ActividadReciente: Identifiable {
    let id            : String = UUID().uuidString
    let tipo          : String        // "sello", "canje"
    let clienteNombre : String
    let createdAt     : String
}

struct SemanaEntry: Identifiable {
    let id    : String = UUID().uuidString
    let label : String                // "Lun", "Mar", etc.
    let total : Int
    let esHoy : Bool
}

struct DistribucionData {
    let total          : Int
    let nuevos         : Int
    let ocasionales    : Int
    let regulares      : Int
    let nuevosPct      : Int
    let ocasionalesPct : Int
    let regularesPct   : Int
}

struct ClientesData {
    let clientes : [ClienteUnico]
    let premios  : [PremioListo]
    let tarjetas : [TarjetaCliente]
}

struct ClienteUnico: Identifiable {
    let id            : String
    let nombre        : String
    let primeraVisita : String?
    let ultimaVisita  : String?
    let totalCanjes   : Int
}

struct PremioListo: Identifiable {
    let id              : String = UUID().uuidString
    let usuarioId       : String
    let nombre          : String
    let sellosActuales  : Int
    let sellosMeta      : Int
    let programaNombre  : String
    let tarjetaId       : String
}

struct TarjetaCliente: Identifiable {
    let id                    : String = UUID().uuidString
    let usuarioId             : String
    let tarjetaId             : String
    let programaNombre        : String
    let sellosActuales        : Int
    let sellosMeta            : Int
    let totalCanjes           : Int
    let ultimaVisitaTarjeta   : String?
}

struct ProgramaData: Identifiable {
    let id           : String
    let nombre       : String
    let sellosMeta   : Int
    let premio       : String
    let gradientIdx  : Int
    let stampColorIdx: Int
    let activo       : Bool
}

struct EscaneoResult {
    let ok              : Bool
    let clienteNombre   : String
    let sellosActuales  : Int
    let sellosTotal     : Int
    let premioListo     : Bool
    let premio          : String
    let campaniaActiva  : String?
}

struct NegocioItem: Identifiable {
    let id          : String
    let negocioId   : String
    let grupo       : String           // "Bebidas", "Comida", "Servicios"
    let nombre      : String
    let descripcion : String?
    let precio      : Double?
    let duracionMin : Int?
    let disponible  : Bool
    let createdAt   : String
    let fechaInicio : String?          // para items temporales
    let fechaFin    : String?
}

struct NegocioItemRequest {
    let grupo       : String
    let nombre      : String
    let descripcion : String?
    let precio      : Double?
    let duracionMin : Int?
    let fechaInicio : String?
    let fechaFin    : String?
}

struct AnalyticsKPIs {
    let retencionPct  : Int
    let totalSellos   : Int
    let totalCanjes   : Int
    let totalClientes : Int
}

// MARK: - Analytics extended data models

struct AnalyticsVisita {
    let label: String
    let value: Int
}

struct AnalyticsHora {
    let label:  String
    let pct:    Double
    let isPeak: Bool
}

struct AnalyticsTopCliente: Identifiable {
    let id:      String
    let nombre:  String
    let visitas: Int
    let sellos:  Int
}

struct AnalyticsCompletaciones {
    let puntos:    [(label: String, value: Double)]
    let totalMes:  Int
}
