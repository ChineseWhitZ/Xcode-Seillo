import SwiftUI

// ─── Client Service Protocol ──────────────────────────────────────────────────
//
// Protocolo que abstrae el acceso a datos del cliente.
// MockClientService lo conforma con data local.
// Cuando llegue el API, crear APIClientService que conforme el mismo protocolo.
//
// Ruta: Seillo/Services/Protocols/ClientServiceProtocol.swift
// ─────────────────────────────────────────────────────────────────────────────

protocol ClientServiceProtocol {

    // ── Tarjetas ─────────────────────────────────────────────────────────
    func getTarjetas() async -> Result<[LoyaltyCard], Error>
    func getHistorial() async -> Result<[HistoryEntry], Error>
    func getHistorialCompletadas() async -> Result<[CompletedCard], Error>

    // ── QR y Canje ───────────────────────────────────────────────────────
    func getQR() async -> Result<String, Error>
    func getCanjeToken(tarjetaId: String) async -> Result<String, Error>

    // ── Notificaciones ───────────────────────────────────────────────────
    func getNotificaciones() async -> Result<[NotificationItem], Error>
    func marcarNotificacionesLeidas() async -> Result<Void, Error>

    // ── Perfil ───────────────────────────────────────────────────────────
    func updatePerfil(nombre: String, avatarId: Int) async -> Result<Void, Error>

    // ── Favoritos ────────────────────────────────────────────────────────
    func getFavoritos() async -> Result<Set<String>, Error>
    func toggleFavorito(negocioId: String) async -> Result<Bool, Error>

    // ── Identidad ────────────────────────────────────────────────────────
    func getIdentidad() async -> Result<UserIdentity, Error>
    func updateIdentidad(_ request: UpdateIdentityRequest) async -> Result<Void, Error>

    // ── Perfil publico ───────────────────────────────────────────────────
    func getPerfilPublico(userId: String) async -> Result<PublicProfile, Error>

    // ── Wizard ───────────────────────────────────────────────────────────
    func updateWizard(genero: String?, fechaNacimiento: String?, preferencias: [String]) async -> Result<Void, Error>
}

// MARK: - Supporting types

/// Cartilla completada (historial de premios canjeados)
struct CompletedCard: Identifiable {
    let id              : String
    let negocioNombre   : String
    let categoria       : String
    let premio          : String
    let fechaCompletada : String
    let sellosMeta      : Int
}
