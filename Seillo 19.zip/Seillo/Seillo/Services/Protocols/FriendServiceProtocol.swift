import SwiftUI

// ─── Friend Service Protocol ──────────────────────────────────────────────────
//
// Protocolo para el sistema de amigos.
//
// Ruta: Seillo/Services/Protocols/FriendServiceProtocol.swift
// ─────────────────────────────────────────────────────────────────────────────

protocol FriendServiceProtocol {

    /// Lista de amigos actuales
    func getAmigos() async -> Result<[Friend], Error>

    /// Solicitudes de amistad pendientes (entrantes)
    func getSolicitudes() async -> Result<[Friend], Error>

    /// Buscar usuarios por nombre o código
    func buscarAmigos(query: String) async -> Result<[FriendSearchResult], Error>

    /// Buscar usuario por código de amigo (SEILLO-XXXX)
    func buscarPorCodigo(codigo: String) async -> Result<FriendSearchResult, Error>

    /// Enviar solicitud de amistad
    func enviarSolicitud(destinatarioId: String) async -> Result<Void, Error>

    /// Responder solicitud (aceptar o rechazar)
    func responderSolicitud(solicitudId: String, accion: SolicitudAccion) async -> Result<Void, Error>

    /// Feed de actividad reciente de amigos
    func getActividadAmigos() async -> Result<[FriendActivity], Error>

    /// Eliminar amigo
    func eliminarAmigo(amigoId: String) async -> Result<Void, Error>
}

// MARK: - Supporting types

enum SolicitudAccion: String {
    case aceptar  = "aceptar"
    case rechazar = "rechazar"
}
