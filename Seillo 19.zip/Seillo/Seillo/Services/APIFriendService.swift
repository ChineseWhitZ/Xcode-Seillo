import SwiftUI

// ─── API Friend Service ──────────────────────────────────────────────────────
//
// Implementación REAL de FriendServiceProtocol.
// Reemplaza a MockFriendService — misma interfaz, datos del backend.
//
// Equivalente a FriendRepository.kt de Android.
//
// Ruta: Seillo/Services/APIFriendService.swift
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
class APIFriendService: FriendServiceProtocol {

    private let api = APIClient.shared

    // MARK: - Amigos

    func getAmigos() async -> Result<[Friend], Error> {
        do {
            let dtos: [AmigoDTO] = try await api.get("api/amigos")
            let friends = dtos.map { dto in
                let totalSellos = dto.totalSellos ?? 0
                let level = UserLevel.level(for: totalSellos)
                let avatarIdx = dto.avatarId ?? 0
                let avatar = UserProfile.avatarOptions[avatarIdx % UserProfile.avatarOptions.count]

                return Friend(
                    id: dto.id,
                    name: dto.nombre,
                    initial: String(dto.nombre.prefix(1)),
                    color: avatar.color,
                    level: level.name,
                    levelIcon: level.icon,
                    levelColor: level.color,
                    totalStamps: totalSellos,
                    topBiz: "",
                    status: .friend,
                    mutualCount: 0
                )
            }
            return .success(friends)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Solicitudes

    func getSolicitudes() async -> Result<[Friend], Error> {
        do {
            let dtos: [SolicitudDTO] = try await api.get("api/amigos/solicitudes")
            let friends = dtos.map { dto in
                let totalSellos = dto.totalSellos ?? 0
                let level = UserLevel.level(for: totalSellos)
                let avatarIdx = dto.avatarId ?? 0
                let avatar = UserProfile.avatarOptions[avatarIdx % UserProfile.avatarOptions.count]

                return Friend(
                    id: dto.id,
                    name: dto.nombre,
                    initial: String(dto.nombre.prefix(1)),
                    color: avatar.color,
                    level: level.name,
                    levelIcon: level.icon,
                    levelColor: level.color,
                    totalStamps: totalSellos,
                    topBiz: "",
                    status: .incoming,
                    mutualCount: 0,
                    solicitudId: dto.solicitudId
                )
            }
            return .success(friends)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Buscar

    func buscarAmigos(query: String) async -> Result<[FriendSearchResult], Error> {
        do {
            let dtos: [BuscarAmigoDTO] = try await api.get("api/amigos/buscar", query: ["q": query])
            let results = dtos.map { dto in
                FriendSearchResult(
                    id: dto.id,
                    nombre: dto.nombre,
                    avatarId: dto.avatarId ?? 0,
                    totalSellos: dto.totalSellos ?? 0,
                    yaAmigo: (dto.yaAmigo ?? 0) == 1,
                    solicitudEnviada: (dto.solicitudEnviada ?? 0) == 1
                )
            }
            return .success(results)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Buscar por código

    func buscarPorCodigo(codigo: String) async -> Result<FriendSearchResult, Error> {
        do {
            let dto: BuscarAmigoDTO = try await api.get("api/amigos/por-codigo", query: ["codigo": codigo])
            let result = FriendSearchResult(
                id: dto.id,
                nombre: dto.nombre,
                avatarId: dto.avatarId ?? 0,
                totalSellos: dto.totalSellos ?? 0,
                yaAmigo: (dto.yaAmigo ?? 0) == 1,
                solicitudEnviada: (dto.solicitudEnviada ?? 0) == 1
            )
            return .success(result)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Enviar solicitud

    func enviarSolicitud(destinatarioId: String) async -> Result<Void, Error> {
        do {
            let body = EnviarSolicitudRequest(destinatarioId: destinatarioId)
            try await api.post("api/amigos/solicitud", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Responder solicitud

    func responderSolicitud(solicitudId: String, accion: SolicitudAccion) async -> Result<Void, Error> {
        do {
            let body = ResponderSolicitudRequest(accion: accion.rawValue)
            try await api.patch("api/amigos/solicitud/\(solicitudId)", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Actividad de amigos

    func getActividadAmigos() async -> Result<[FriendActivity], Error> {
        do {
            let dtos: [FriendActividadDTO] = try await api.get("api/amigos/actividad")
            let activities = dtos.map { dto in
                let actType: FriendActivityType = dto.tipo == "canje" ? .reward : .stamp
                let catColor = colorForCategory(dto.negocioCategoria ?? "")
                let catIcon = iconForCategory(dto.negocioCategoria ?? "")

                return FriendActivity(
                    id: dto.id,
                    friendName: dto.amigoNombre,
                    friendInitial: String(dto.amigoNombre.prefix(1)),
                    friendColor: .seilAccent,
                    type: actType,
                    bizName: dto.negocioNombre,
                    bizIcon: catIcon,
                    bizColor: catColor,
                    detail: actType == .reward
                        ? "Canjeó premio en \(dto.negocioNombre)"
                        : "\(dto.sellosActuales)/\(dto.sellosMeta) sellos en \(dto.negocioNombre)",
                    timeAgo: formatRelativeDate(dto.createdAt)
                )
            }
            return .success(activities)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Eliminar amigo

    func eliminarAmigo(amigoId: String) async -> Result<Void, Error> {
        do {
            try await api.delete("api/amigos/\(amigoId)")
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Helpers

    // MEDIO: antes duplicaba la lógica de formatRelativeDate de APIClientService
    // con una variante ligeramente distinta (retornaba "sem" en vez de "d" para semanas).
    // Ahora delega a APIClientService.parseDate — fuente única de verdad para
    // parsear timestamps. El formato relativo se mantiene local (distinto del cliente).
    private func formatRelativeDate(_ iso: String) -> String {
        guard let date = APIClientService.parseDate(iso) else { return iso }
        let diff = Date().timeIntervalSince(date)
        if diff < 60     { return "Ahora" }
        if diff < 3600   { return "Hace \(Int(diff / 60))min" }
        if diff < 86400  { return "Hace \(Int(diff / 3600))h" }
        if diff < 604800 { return "Hace \(Int(diff / 86400))d" }
        return "Hace \(Int(diff / 604800))sem"
    }
}
