import Foundation

// MARK: - GateResult

/// Resultado de una evaluación de acceso a un feature.
struct GateResult {
    let allowed        : Bool
    let upgradeMessage : String    // solo relevante si !allowed
    let requiredTier   : PlanTier? // plan mínimo necesario

    // Resultado de acceso permitido — atajo para no repetir el init.
    static let ok = GateResult(allowed: true, upgradeMessage: "", requiredTier: nil)
}

// MARK: - FeatureGate

struct FeatureGate {

    private let sub: BusinessSubscription

    init(_ subscription: BusinessSubscription) {
        self.sub = subscription
    }

    // MARK: - Features booleanos

    func canUseAutomations() -> GateResult {
        gate(
            condition      : sub.plan.tieneAutomatizaciones,
            requiredTier   : .pro,
            upgradeMessage : "Las automatizaciones están disponibles en el plan Pro. " +
                             "Actívalas para recuperar clientes inactivos sin esfuerzo."
        )
    }

    func canUsePromotions() -> GateResult {
        gate(
            condition      : sub.plan.tienePromociones,
            requiredTier   : .growth,
            upgradeMessage : "Las promociones están disponibles desde el plan Growth. " +
                             "Crea campañas para impulsar tus visitas."
        )
    }

    func canUseStaff() -> GateResult {
        gate(
            condition      : sub.plan.tieneStaff,
            requiredTier   : .growth,
            upgradeMessage : "La gestión de staff está disponible desde el plan Growth. " +
                             "Agrega a tu equipo para operar en varios turnos."
        )
    }

    func canUseBranding() -> GateResult {
        gate(
            condition      : sub.plan.tieneBrandingPropio,
            requiredTier   : .pro,
            upgradeMessage : "El branding propio está disponible en el plan Pro. " +
                             "Elimina el logo de Seillo y personaliza con el tuyo."
        )
    }

    func canUsePushNotifications() -> GateResult {
        gate(
            condition      : sub.plan.tienePushNotifications,
            requiredTier   : .growth,
            upgradeMessage : "Las notificaciones push están disponibles desde el plan Growth."
        )
    }

    func canUseAdvancedAnalytics() -> GateResult {
        gate(
            condition      : sub.plan.tieneAnaliticaAvanzada,
            requiredTier   : .growth,
            upgradeMessage : "La analítica avanzada está disponible desde el plan Growth."
        )
    }

    func canUseApiIntegrations() -> GateResult {
        gate(
            condition      : sub.plan.tieneIntegracionesApi,
            requiredTier   : .enterprise,
            upgradeMessage : "Las integraciones API están disponibles en el plan Enterprise."
        )
    }

    // MARK: - Límites numéricos

    func canAddClient() -> GateResult {
        let limit = sub.plan.maxClientes
        guard limit > 0 else { return .ok }
        if sub.clientesActuales < limit { return .ok }
        return GateResult(
            allowed        : false,
            upgradeMessage : "Alcanzaste el límite de \(limit) clientes en el plan \(sub.plan.nombre). " +
                             "Actualiza tu plan para seguir creciendo.",
            requiredTier   : nextTier()
        )
    }

    func canAddLocation() -> GateResult {
        let limit = sub.plan.maxLocales
        guard limit > 0 else { return .ok }
        if sub.localesActuales < limit { return .ok }
        return GateResult(
            allowed        : false,
            upgradeMessage : "Alcanzaste el límite de \(limit) local\(limit == 1 ? "" : "es") " +
                             "en el plan \(sub.plan.nombre). Actualiza tu plan para agregar más locales.",
            requiredTier   : nextTier()
        )
    }

    func canAddLoyaltyCard() -> GateResult {
        let limit = sub.plan.maxTarjetasActivas
        guard limit > 0 else { return .ok }
        if sub.tarjetasActivasActuales < limit { return .ok }
        return GateResult(
            allowed        : false,
            upgradeMessage : "Alcanzaste el límite de \(limit) tarjeta\(limit == 1 ? "" : "s") activa\(limit == 1 ? "" : "s") " +
                             "en el plan \(sub.plan.nombre). Actualiza tu plan para crear más programas.",
            requiredTier   : nextTier()
        )
    }

    // MARK: - Privado

    private func gate(
        condition      : Bool,
        requiredTier   : PlanTier,
        upgradeMessage : String
    ) -> GateResult {
        condition
            ? .ok
            : GateResult(allowed: false, upgradeMessage: upgradeMessage, requiredTier: requiredTier)
    }

    /// Devuelve el tier inmediatamente superior al plan actual.
    private func nextTier() -> PlanTier {
        let all = PlanTier.allCases
        let current = all.firstIndex(of: sub.plan.tier) ?? 0
        let next = min(current + 1, all.count - 1)
        return all[next]
    }
}
