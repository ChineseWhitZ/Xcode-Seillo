import SwiftUI

// ─── API Negocio Service ─────────────────────────────────────────────────────
//
// Implementación REAL de NegocioServiceProtocol.
// Reemplaza a MockNegocioService — misma interfaz, datos del backend.
//
// Equivalente a NegocioRepository.kt de Android.
//
// Ruta: Seillo/Services/APINegocioService.swift
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
class APINegocioService: NegocioServiceProtocol {

    private let api = APIClient.shared

    // MARK: - Perfil

    func getPerfil() async -> Result<BizProfile, Error> {
        do {
            let dto: NegocioPerfilDTO = try await api.get("api/negocio/perfil")
            let profile = BizProfile(
                nombre: dto.nombre,
                direccion: dto.direccion,
                categoriaId: dto.categoriaId,
                sellosParaPremio: dto.sellosParaPremio,
                premioTexto: dto.premioTexto,
                menu: []
            )
            return .success(profile)
        } catch {
            return .failure(error)
        }
    }

    func updatePerfil(_ profile: BizProfile) async -> Result<Void, Error> {
        do {
            let body = UpdateNegocioRequest(
                nombre: profile.nombre,
                direccion: profile.direccion,
                categoriaId: profile.categoriaId,
                horario: nil,
                telefono: nil,
                descripcion: nil
            )
            try await api.put("api/negocio/perfil", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Dashboard

    func getDashboard() async -> Result<DashboardData, Error> {
        do {
            let dto: DashboardDTO = try await api.get("api/negocio/dashboard")
            let data = DashboardData(
                sellosHoy: dto.sellosHoy,
                clientesHoy: dto.clientesHoy,
                canjesHoy: dto.canjesHoy,
                actividadReciente: dto.actividadReciente.map {
                    ActividadReciente(
                        tipo: $0.tipo,
                        clienteNombre: $0.clienteNombre,
                        createdAt: $0.createdAt
                    )
                }
            )
            return .success(data)
        } catch {
            return .failure(error)
        }
    }

    func getSemana() async -> Result<[SemanaEntry], Error> {
        do {
            let dtos: [SemanaDTO] = try await api.get("api/negocio/semana")
            let entries = dtos.map {
                SemanaEntry(label: $0.label, total: $0.total, esHoy: $0.esHoy)
            }
            return .success(entries)
        } catch {
            return .failure(error)
        }
    }

    func getDistribucion() async -> Result<DistribucionData, Error> {
        do {
            let dto: DistribucionDTO = try await api.get("api/negocio/distribucion")
            let data = DistribucionData(
                total: dto.total,
                nuevos: dto.nuevos,
                ocasionales: dto.ocasionales,
                regulares: dto.regulares,
                nuevosPct: dto.nuevosPct,
                ocasionalesPct: dto.ocasionalesPct,
                regularesPct: dto.regularesPct
            )
            return .success(data)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Clientes

    func getClientes() async -> Result<ClientesData, Error> {
        do {
            let dto: ClientesNegocioDTO = try await api.get("api/negocio/clientes")
            let data = ClientesData(
                clientes: dto.clientes.map {
                    ClienteUnico(
                        id: $0.id,
                        nombre: $0.nombre,
                        primeraVisita: $0.primeraVisita,
                        ultimaVisita: $0.ultimaVisita,
                        totalCanjes: $0.totalCanjes ?? 0
                    )
                },
                premios: dto.premios.map {
                    PremioListo(
                        usuarioId: $0.usuarioId,
                        nombre: $0.nombre,
                        sellosActuales: $0.sellosActuales,
                        sellosMeta: $0.sellosMeta,
                        programaNombre: $0.programaNombre,
                        tarjetaId: $0.tarjetaId
                    )
                },
                tarjetas: dto.tarjetas.map {
                    TarjetaCliente(
                        usuarioId: $0.usuarioId,
                        tarjetaId: $0.tarjetaId,
                        programaNombre: $0.programaNombre,
                        sellosActuales: $0.sellosActuales,
                        sellosMeta: $0.sellosMeta,
                        totalCanjes: $0.totalCanjes,
                        ultimaVisitaTarjeta: $0.ultimaVisitaTarjeta
                    )
                }
            )
            return .success(data)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Programas

    func getProgramas() async -> Result<[ProgramaData], Error> {
        do {
            let dtos: [ProgramaDTO] = try await api.get("api/negocio/programas")
            let programas = dtos.map {
                ProgramaData(
                    id: $0.id,
                    nombre: $0.nombre,
                    sellosMeta: $0.sellosMeta,
                    premio: $0.premio,
                    gradientIdx: $0.gradientIdx ?? 0,
                    stampColorIdx: $0.stampColorIdx ?? 0,
                    activo: ($0.activo ?? 1) == 1
                )
            }
            return .success(programas)
        } catch {
            return .failure(error)
        }
    }

    func crearPrograma(nombre: String, sellosMeta: Int, premio: String) async -> Result<String, Error> {
        do {
            let body = CrearProgramaRequest(
                nombre: nombre,
                premio: premio,
                sellosMeta: sellosMeta,
                descripcion: nil,
                gradientIdx: 0,
                stampColorIdx: 0,
                mantenerPremios: true
            )
            let dto: CrearProgramaResponseDTO = try await api.post("api/negocio/programa/crear", body: body)
            return .success(dto.programaId)
        } catch {
            return .failure(error)
        }
    }

    func updatePrograma(id: String, nombre: String?, sellosMeta: Int?, premio: String?) async -> Result<Void, Error> {
        do {
            let body = UpdateProgramaRequest(
                sellosMeta: sellosMeta ?? 10,
                premio: premio ?? "",
                programaId: id,
                nombre: nombre
            )
            try await api.patch("api/negocio/programa", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Escaneo QR

    func escanearQR(code: String) async -> Result<EscaneoResult, Error> {
        do {
            // El negocio necesita mandar programa_id — obtenemos el primero activo
            let programas: [ProgramaDTO] = try await api.get("api/negocio/programas")
            guard let primerPrograma = programas.first(where: { ($0.activo ?? 1) == 1 }) else {
                return .failure(APIError.badStatus(400, "No tienes programas activos"))
            }

            let body = EscanearRequest(qrCode: code, programaId: primerPrograma.id)
            let dto: EscanearDTO = try await api.post("api/negocio/escanear", body: body)
            let result = EscaneoResult(
                ok: dto.ok,
                clienteNombre: dto.clienteNombre,
                sellosActuales: dto.sellosActuales,
                sellosTotal: dto.sellosTotal,
                premioListo: dto.premioListo,
                premio: dto.premio,
                campaniaActiva: dto.campaniaActiva
            )
            return .success(result)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Horario

    func getHorario() async -> Result<[HorarioDia], Error> {
        do {
            let dtos: [HorarioDiaDTO] = try await api.get("api/negocio/horario")
            let horarios = dtos.map { $0.toUI() }
            return .success(horarios)
        } catch {
            return .failure(error)
        }
    }

    func saveHorario(_ horarios: [HorarioDia]) async -> Result<Void, Error> {
        do {
            let body = SaveHorarioRequest(horarios: horarios.map { $0.toDTO() })
            try await api.put("api/negocio/horario", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Items (menú/servicios)

    func getItems() async -> Result<[NegocioItem], Error> {
        do {
            let dtos: [NegocioItemDTO] = try await api.get("api/negocio/items")
            let items = dtos.map {
                NegocioItem(
                    id: $0.id,
                    negocioId: $0.negocioId,
                    grupo: $0.grupo,
                    nombre: $0.nombre,
                    descripcion: $0.descripcion,
                    precio: $0.precio,
                    duracionMin: $0.duracionMin,
                    disponible: ($0.disponible ?? 1) == 1,
                    createdAt: $0.createdAt,
                    fechaInicio: $0.fechaInicio,
                    fechaFin: $0.fechaFin
                )
            }
            return .success(items)
        } catch {
            return .failure(error)
        }
    }

    func crearItem(_ item: NegocioItemRequest) async -> Result<String, Error> {
        do {
            let body = CrearItemRequest(
                grupo: item.grupo,
                nombre: item.nombre,
                descripcion: item.descripcion,
                precio: item.precio,
                duracionMin: item.duracionMin,
                fechaInicio: item.fechaInicio,
                fechaFin: item.fechaFin
            )
            let dto: NegocioItemDTO = try await api.post("api/negocio/items", body: body)
            return .success(dto.id)
        } catch {
            return .failure(error)
        }
    }

    func actualizarItem(id: String, _ item: NegocioItemRequest) async -> Result<Void, Error> {
        // El backend no tiene un PATCH individual de items — usar DELETE + POST
        do {
            try await api.delete("api/negocio/items/\(id)")
            let body = CrearItemRequest(
                grupo: item.grupo,
                nombre: item.nombre,
                descripcion: item.descripcion,
                precio: item.precio,
                duracionMin: item.duracionMin,
                fechaInicio: item.fechaInicio,
                fechaFin: item.fechaFin
            )
            let _: NegocioItemDTO = try await api.post("api/negocio/items", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    func eliminarItem(id: String) async -> Result<Void, Error> {
        do {
            try await api.delete("api/negocio/items/\(id)")
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Analytics

    func getAnalyticsKPIs() async -> Result<AnalyticsKPIs, Error> {
        do {
            let dto: AnalyticsKpisDTO = try await api.get("api/negocio/analytics/kpis")
            let kpis = AnalyticsKPIs(
                retencionPct: dto.retencionPct,
                totalSellos: dto.totalSellos,
                totalCanjes: dto.totalCanjes,
                totalClientes: dto.totalClientes
            )
            return .success(kpis)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Reseñas


    // MARK: - Analytics: visitas

    func getAnalyticsVisitas(periodo: String) async -> Result<[AnalyticsVisita], Error> {
        do {
            let dtos: [AnalyticsLinePointDTO] = try await api.get(
                "api/negocio/analytics/visitas",
                query: ["periodo": periodo]
            )
            return .success(dtos.map { AnalyticsVisita(label: $0.label, value: $0.value) })
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Analytics: horas pico

    func getAnalyticsHoras(periodo: String) async -> Result<[AnalyticsHora], Error> {
        do {
            let dtos: [AnalyticsHoraDTO] = try await api.get(
                "api/negocio/analytics/horas",
                query: ["periodo": periodo]
            )
            return .success(dtos.map { AnalyticsHora(label: $0.label, pct: Double($0.pct), isPeak: $0.isPeak) })
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Analytics: top clientes

    func getAnalyticsTopClientes(periodo: String) async -> Result<[AnalyticsTopCliente], Error> {
        do {
            let dtos: [AnalyticsTopClienteDTO] = try await api.get(
                "api/negocio/analytics/top-clientes",
                query: ["periodo": periodo]
            )
            return .success(dtos.map {
                AnalyticsTopCliente(id: $0.id, nombre: $0.nombre, visitas: $0.visitas, sellos: $0.sellos)
            })
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Analytics: completaciones

    func getAnalyticsCompletaciones(periodo: String) async -> Result<AnalyticsCompletaciones, Error> {
        do {
            let dto: AnalyticsCompletacionesDTO = try await api.get(
                "api/negocio/analytics/completaciones",
                query: ["periodo": periodo]
            )
            let puntos = dto.data.map { (label: $0.label, value: Double($0.value)) }
            return .success(AnalyticsCompletaciones(puntos: puntos, totalMes: dto.totalMes))
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Reseñas

    func getResenas() async -> Result<[ReviewItem], Error> {
        do {
            let perfil: NegocioPerfilDTO = try await api.get("api/negocio/perfil")
            // negocioId requiere que David añada el campo a la respuesta de /api/negocio/perfil
            guard let negocioId = perfil.negocioId else { return .success([]) }
            let dtos: [ResenaDTO] = try await api.getPublic("api/negocios/\(negocioId)/resenas")
            let palette: [Color] = [.seilAccent, .seilBlue, .seilPurple, .seilGreen, .seilGold]
            let items = dtos.enumerated().map { i, dto in
                ReviewItem(
                    name:        dto.nombre,
                    date:        dto.createdAt,
                    text:        dto.texto,
                    stars:       dto.estrellas,
                    avatarColor: palette[i % palette.count]
                )
            }
            return .success(items)
        } catch {
            return .failure(error)
        }
    }
}
