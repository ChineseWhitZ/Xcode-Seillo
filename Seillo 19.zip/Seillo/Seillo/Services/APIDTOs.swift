import Foundation

// ─── API DTOs ────────────────────────────────────────────────────────────────
//
// Structs Codable que mapean 1:1 al JSON del backend.
// Equivalente a los data class en ApiService.kt de Android.
//
// Convención:
//   - Suffix "DTO" para responses del backend
//   - Suffix "Request" para bodies de POST/PATCH
//   - snake_case se maneja con keyDecodingStrategy del APIClient
//
// Ruta: Seillo/Services/APIDTOs.swift
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Auth

struct LoginRequest: Encodable {
    let email: String
    let password: String
}

struct RegisterRequest: Encodable {
    let nombre: String
    let email: String
    let password: String
    let role: String
    let firebaseUid: String?
    let bizNombre: String?
    let bizDireccion: String?
    let bizRuc: String?
    let bizCategoria: String?
    let bizCategoriaId: Int?
    let bizDistrito: String?

    init(
        nombre: String,
        email: String,
        password: String,
        role: String = "cliente",
        firebaseUid: String? = nil,
        bizNombre: String? = nil,
        bizDireccion: String? = nil,
        bizRuc: String? = nil,
        bizCategoria: String? = nil,
        bizCategoriaId: Int? = nil,
        bizDistrito: String? = nil
    ) {
        self.nombre = nombre
        self.email = email
        self.password = password
        self.role = role
        self.firebaseUid = firebaseUid
        self.bizNombre = bizNombre
        self.bizDireccion = bizDireccion
        self.bizRuc = bizRuc
        self.bizCategoria = bizCategoria
        self.bizCategoriaId = bizCategoriaId
        self.bizDistrito = bizDistrito
    }
}

struct GoogleAuthRequest: Encodable {
    let nombre: String
    let email: String
    let idToken: String
    let action: String
    let role: String
}

struct ForgotPasswordRequest: Encodable {
    let email: String
}

struct ResetPasswordRequest: Encodable {
    let token: String
    let password: String
}

struct LoginResponseDTO: Decodable {
    let token: String
    let usuario: UsuarioDTO
    let negocio: NegocioLoginDTO?
}

struct UsuarioDTO: Decodable {
    let id: String
    let nombre: String
    let email: String
    let tipo: String
    let codigoAmigo: String?
    let avatarId: Int?
}

struct NegocioLoginDTO: Decodable {
    let nombre: String
    let direccion: String
    let categoria: String
}

// MARK: - Cliente: Tarjetas

struct TarjetaDTO: Decodable {
    let id: String
    let sellosActuales: Int
    let totalCanjes: Int
    let programaId: String
    let programaNombre: String
    let sellosMeta: Int
    let premio: String
    let negocioId: String
    let negocioNombre: String
    let emoji: String
    let categoria: String?
    let gradientIdx: Int?
    let stampColorIdx: Int?
}

// MARK: - Cliente: Historial

struct HistorialDTO: Decodable {
    let id: String
    let tipo: String
    let createdAt: String
    let negocio: String
    let emoji: String
    let negocioId: String?
}

// MARK: - Cliente: Notificaciones

struct NotificacionDTO: Decodable {
    let id: String
    let tipo: String
    let titulo: String
    let mensaje: String
    let negocioNombre: String?
    let leido: Int
    let createdAt: String
}

// MARK: - Cliente: QR

struct QRDTO: Decodable {
    let qrCode: String
    let expiresAt: String
}

// MARK: - Cliente: Canje Token

struct CanjeTokenDTO: Decodable {
    let token: String
    let premio: String?
    let creadoAt: String?
}

// MARK: - Cliente: Completadas

struct CartillaCompletadaDTO: Decodable {
    let negocioNombre: String
    let negocioCategoria: String?
    let premio: String
    let sellosMeta: Int
    let canjeadoAt: String
}

// MARK: - Cliente: Perfil

struct UpdatePerfilRequest: Encodable {
    let nombre: String
    let avatarId: Int
    let fechaNacimiento: String?

    init(nombre: String, avatarId: Int, fechaNacimiento: String? = nil) {
        self.nombre = nombre
        self.avatarId = avatarId
        self.fechaNacimiento = fechaNacimiento
    }
}

struct FcmTokenRequest: Encodable {
    let fcmToken: String
    let plataforma: String = "ios"
}

// MARK: - Cliente: Identidad

struct IdentidadDTO: Decodable {
    let badgesGanados: [BadgeItemDTO]?
    let badgesVisibles: [String]?
    let framesGanados: [FrameItemDTO]?
    let frameActivo: String?
    let titulosGanados: [TituloItemDTO]?
    let tituloActivo: String?
}

struct BadgeItemDTO: Decodable {
    let id: String
    let nombre: String
    let tipo: String
}

struct FrameItemDTO: Decodable {
    let id: String
    let nombre: String
    let tipo: String
}

struct TituloItemDTO: Decodable {
    let id: String
    let texto: String
    let tipo: String
}

struct UpdateIdentidadRequest: Encodable {
    let frameActivo: String?
    let tituloActivo: String?
    let badgesVisibles: [String]?
}

// MARK: - Cliente: Perfil Público

struct PerfilPublicoDTO: Decodable {
    let id: String
    let nombre: String
    let avatarId: Int?
    let nivel: String?
    let totalSellos: Int?
    let totalTarjetas: Int?
    let totalPremios: Int?
    let tarjetasActivas: [PublicTarjetaDTO]?
    let identidad: PublicIdentidadDTO?
    let esAmigo: Bool?

    // CodingKeys explícito para que funcione con convertFromSnakeCase + custom init
    enum CodingKeys: String, CodingKey {
        case id, nombre, avatarId, nivel
        case totalSellos, totalTarjetas, totalPremios
        case tarjetasActivas, identidad, esAmigo
    }

    // Custom init: totalSellos y totalPremios llegan como String desde MySQL SUM()
    init(from decoder: Decoder) throws {
        let c           = try decoder.container(keyedBy: CodingKeys.self)
        id              = try  c.decode(String.self,            forKey: .id)
        nombre          = try  c.decode(String.self,            forKey: .nombre)
        avatarId        = try? c.decode(Int.self,               forKey: .avatarId)
        nivel           = try? c.decode(String.self,            forKey: .nivel)
        totalSellos     = c.decodeFlexInt(forKey: .totalSellos)
        totalTarjetas   = c.decodeFlexInt(forKey: .totalTarjetas)
        totalPremios    = c.decodeFlexInt(forKey: .totalPremios)
        tarjetasActivas = try? c.decode([PublicTarjetaDTO].self,  forKey: .tarjetasActivas)
        identidad       = try? c.decode(PublicIdentidadDTO.self,  forKey: .identidad)
        esAmigo         = try? c.decode(Bool.self,               forKey: .esAmigo)
    }
}

struct PublicTarjetaDTO: Decodable {
    let negocioNombre: String
    let sellosActuales: Int
    let sellosMeta: Int
    let categoria: String?
}

struct PublicIdentidadDTO: Decodable {
    let frameActivo: String?
    let tituloTexto: String?
    let badgesVisibles: [BadgeItemDTO]?
}

// MARK: - Cliente: Wizard

struct UpdateWizardRequest: Encodable {
    let genero: String?
    let fechaNacimiento: String?
    let preferencias: [String]
}

// MARK: - Cliente: Favoritos

struct ToggleFavoritoDTO: Decodable {
    let favorito: Bool?
}

// MARK: - Cliente: Password

struct CambiarPasswordRequest: Encodable {
    let passwordActual: String
    let passwordNueva: String
}

// MARK: - Negocios (público)

struct NegocioDTO: Decodable {
    let id: String
    let nombre: String
    let categoria: String?
    let emoji: String?
    let direccion: String?
    let distrito: String?
    let latitud: Double?
    let longitud: Double?
    let descripcion: String?
    let rating: Double?
    let reviewCount: Int?

    enum CodingKeys: String, CodingKey {
        case id, nombre, categoria, emoji, direccion, distrito
        case latitud, longitud, descripcion, rating
        case reviewCount = "review_count"
    }

    // Custom init: rating llega como String ("3.5000") desde MySQL AVG()
    init(from decoder: Decoder) throws {
        let c   = try decoder.container(keyedBy: CodingKeys.self)
        id          = try  c.decode(String.self, forKey: .id)
        nombre      = try  c.decode(String.self, forKey: .nombre)
        categoria   = try? c.decode(String.self, forKey: .categoria)
        emoji       = try? c.decode(String.self, forKey: .emoji)
        direccion   = try? c.decode(String.self, forKey: .direccion)
        distrito    = try? c.decode(String.self, forKey: .distrito)
        latitud     = try? c.decode(Double.self, forKey: .latitud)
        longitud    = try? c.decode(Double.self, forKey: .longitud)
        descripcion = try? c.decode(String.self, forKey: .descripcion)
        rating      = c.decodeFlexDouble(forKey: .rating)
        reviewCount = c.decodeFlexInt(forKey: .reviewCount)
    }
}

struct CategoriaDTO: Decodable {
    let id: Int
    let nombre: String
    let grupo: String
    let icono: String?
    let orden: Int?
}

struct TendenciaDTO: Decodable {
    let nombre: String
    let categoria: String
    let total: Int?
}

// MARK: - Negocio: Dashboard

struct DashboardDTO: Decodable, Sendable {
    let sellosHoy: Int
    let clientesHoy: Int
    let canjesHoy: Int
    let actividadReciente: [ActividadDTO]
}

struct ActividadDTO: Decodable, Sendable {
    let tipo: String
    let createdAt: String
    let clienteNombre: String
}

// MARK: - Negocio: Perfil

struct NegocioPerfilDTO: Decodable {
    let negocioId: String?      // PENDIENTE BACKEND: David debe añadir este campo a /api/negocio/perfil
    let nombre: String
    let direccion: String
    let categoriaId: String
    let sellosParaPremio: Int
    let premioTexto: String
    let programaId: String?
    let totalClientes: Int
    let totalSellos: Int
    let totalCanjes: Int
    let plan: String?
    let totalProgramas: Int?
    let telefono: String?
    let descripcion: String?
}

struct UpdateNegocioRequest: Encodable {
    let nombre: String
    let direccion: String
    let categoriaId: String
    let horario: String?
    let telefono: String?
    let descripcion: String?
}

// MARK: - Negocio: Programas

struct ProgramaDTO: Decodable {
    let id: String
    let nombre: String
    let sellosMeta: Int
    let premio: String
    let gradientIdx: Int?
    let stampColorIdx: Int?
    let activo: Int?
}

struct CrearProgramaRequest: Encodable {
    let nombre: String
    let premio: String
    let sellosMeta: Int
    let descripcion: String?
    let gradientIdx: Int?
    let stampColorIdx: Int?
    let mantenerPremios: Bool?
}

struct CrearProgramaResponseDTO: Decodable {
    let ok: Bool
    let programaId: String
}

struct UpdateProgramaRequest: Encodable {
    let sellosMeta: Int
    let premio: String
    let programaId: String
    let nombre: String?
}

// MARK: - Negocio: Escaneo

struct EscanearRequest: Encodable {
    let qrCode: String
    let programaId: String
}

struct EscanearDTO: Decodable {
    let ok: Bool
    let clienteNombre: String
    let sellosActuales: Int
    let sellosTotal: Int
    let premioListo: Bool
    let premio: String
    let campaniaActiva: String?
}

// MARK: - Negocio: Clientes

struct ClientesNegocioDTO: Decodable {
    let clientes: [ClienteUnicoDTO]
    let premios: [PremioListoDTO]
    let tarjetas: [TarjetaClienteDTO]
}

struct ClienteUnicoDTO: Decodable {
    let id: String
    let nombre: String
    let primeraVisita: String?
    let ultimaVisita: String?
    let totalCanjes: Int?
}

struct PremioListoDTO: Decodable {
    let usuarioId: String
    let nombre: String
    let sellosActuales: Int
    let sellosMeta: Int
    let programaNombre: String
    let tarjetaId: String
}

struct TarjetaClienteDTO: Decodable {
    let usuarioId: String
    let tarjetaId: String
    let programaNombre: String
    let sellosActuales: Int
    let sellosMeta: Int
    let totalCanjes: Int
    let ultimaVisitaTarjeta: String?
}

// MARK: - Negocio: Semana

struct SemanaDTO: Decodable, Sendable {
    let label: String
    let total: Int
    let esHoy: Bool
}

// MARK: - Negocio: Distribución

struct DistribucionDTO: Decodable, Sendable {
    let total: Int
    let nuevos: Int
    let ocasionales: Int
    let regulares: Int
    let nuevosPct: Int
    let ocasionalesPct: Int
    let regularesPct: Int
}

// MARK: - Negocio: Analytics

struct AnalyticsKpisDTO: Decodable {
    let retencionPct: Int
    let totalSellos: Int
    let totalCanjes: Int
    let totalClientes: Int
}

struct AnalyticsLinePointDTO: Decodable {
    let label: String
    let value: Int
}

struct AnalyticsHoraDTO: Decodable {
    let label: String
    let pct: Float
    let isPeak: Bool
}

struct AnalyticsTopClienteDTO: Decodable {
    let id: String
    let nombre: String
    let visitas: Int
    let sellos: Int
}

struct AnalyticsCompletacionesDTO: Decodable {
    let data: [AnalyticsLinePointDTO]
    let totalMes: Int
}

// MARK: - Negocio: Push

struct PushAudienciaDTO: Decodable {
    let todos: Int
    let cercaPremio: Int
    let inactivos: Int
    let nuevos: Int
}

struct EnviarPushRequest: Encodable {
    let mensaje: String
    let audiencia: String
}

struct EnviarPushDTO: Decodable {
    let ok: Bool
    let enviados: Int
}

// MARK: - Negocio: Campañas

struct CampaniaDTO: Decodable {
    let id: String
    let tipo: String
    let titulo: String
    let descripcion: String?
    let estado: String
    let createdAt: String
    let fechaInicio: String?
    let fechaFin: String?
    let programaId: String?
    let programaNombre: String?
    let horaInicio: String?
    let horaFin: String?
}

struct CrearCampaniaRequest: Encodable {
    let tipo: String
    let titulo: String
    let descripcion: String?
    let enviarPush: Bool?
    let fechaInicio: String?
    let fechaFin: String?
    let programaId: String?
    let horaInicio: String?
    let horaFin: String?
}

struct CambiarEstadoCampaniaRequest: Encodable {
    let estado: String
}

// MARK: - Negocio: Plan

struct CambiarPlanRequest: Encodable {
    let plan: String
}

struct CambiarPlanDTO: Decodable {
    let ok: Bool
    let plan: String
}

// MARK: - Negocio: Automatizaciones

struct AutomationRuleDTO: Decodable {
    let id: String
    let tipo: String
    let nombre: String
    let descripcion: String?
    let triggerLabel: String?
    let accionLabel: String?
    let isActive: Int?
    let totalDisparos: Int?
    let ultimoDisparo: String?
}

struct ToggleAutomationRequest: Encodable {
    let isActive: Bool
}

// MARK: - Negocio: Items (menú/servicios)

struct NegocioItemDTO: Decodable {
    let id: String
    let negocioId: String
    let grupo: String
    let nombre: String
    let descripcion: String?
    let precio: Double?
    let duracionMin: Int?
    let disponible: Int?
    let createdAt: String
    let fechaInicio: String?
    let fechaFin: String?
}

struct CrearItemRequest: Encodable {
    let grupo: String
    let nombre: String
    let descripcion: String?
    let precio: Double?
    let duracionMin: Int?
    let fechaInicio: String?
    let fechaFin: String?
}

// MARK: - Negocio: Crear negocio

struct CrearNegocioRequest: Encodable {
    let nombre: String
    let categoria: String
    let direccion: String
    let descripcion: String?
    let telefono: String?
    let horario: String?
}

struct CrearNegocioDTO: Decodable {
    let ok: Bool
    let negocioId: String
}

// MARK: - Negocio: Tipo

struct ActualizarTipoRequest: Encodable {
    let tipoOperacion: String
    let categoriaId: Int
}

// MARK: - Negocio: Reseñas

struct ResenaDTO: Decodable {
    let id: String
    let nombre: String
    let estrellas: Int
    let texto: String
    let createdAt: String
}

struct CrearResenaRequest: Encodable {
    let estrellas: Int
    let texto: String
}

// MARK: - Negocio: Canjear premio

struct CanjearPremioRequest: Encodable {
    let token: String
}

struct CanjearPremioDTO: Decodable {
    let ok: Bool
    let clienteNombre: String
    let premio: String
    let programa: String
}

// MARK: - Negocio: Horarios (wrapper)

struct SaveHorarioRequest: Encodable {
    let horarios: [HorarioDiaDTO]
}

// MARK: - Negocio: Plan Info

struct PlanInfoDTO: Decodable, Sendable {
    let plan: String
    let limites: PlanLimitesDTO?
    let uso: PlanUsoDTO?
}

struct PlanLimitesDTO: Decodable, Sendable {
    let programas: Int?
    let clientes: Int?
    let analytics: Bool?
    let campanias: Bool?
    let automatizaciones: Bool?
    let mensajeria: Bool?
}

struct PlanUsoDTO: Decodable, Sendable {
    let programasActivos: Int?
    let clientesUnicos: Int?
}

// MARK: - Amigos

struct AmigoDTO: Decodable {
    let id: String
    let nombre: String
    let avatarId: Int?
    let totalSellos: Int?
}

struct SolicitudDTO: Decodable {
    let solicitudId: String
    let id: String
    let nombre: String
    let avatarId: Int?
    let totalSellos: Int?
}

struct BuscarAmigoDTO: Decodable {
    let id: String
    let nombre: String
    let avatarId: Int?
    let totalSellos: Int?
    let yaAmigo: Int?
    let solicitudEnviada: Int?
}

struct EnviarSolicitudRequest: Encodable {
    let destinatarioId: String
}

struct ResponderSolicitudRequest: Encodable {
    let accion: String
}

struct FriendActividadDTO: Decodable {
    let id: String
    let tipo: String
    let createdAt: String
    let amigoId: String
    let amigoNombre: String
    let negocioNombre: String
    let negocioCategoria: String?
    let sellosActuales: Int
    let sellosMeta: Int
}

// MARK: - Preferencias

struct PreferenciaEventoRequest: Encodable {
    let categoria: String
    let tipo: String
}

// MARK: - Solicitar cambio email

struct SolicitarCambioEmailDTO: Decodable {
    let ok: Bool?
    let diasRestantes: Int?
    let error: String?
}

// MARK: - Tipo usuario

struct TipoDTO: Decodable {
    let tipo: String
}

// MARK: - Generic OK

struct OkDTO: Decodable {
    let ok: Bool?
}

// MARK: - Register Response (puede incluir requiresVerification)

struct RegisterResponseDTO: Decodable {
    let token: String?
    let requiresVerification: Bool?
    let usuario: UsuarioDTO?
    let message: String?

    func toLoginResponse() -> LoginResponseDTO? {
        guard let token = token, let usuario = usuario else { return nil }
        return LoginResponseDTO(token: token, usuario: usuario, negocio: nil)
    }
}

// MARK: - Flex Decoding Helpers
// MySQL2 devuelve SUM() y AVG() como String ("3.5000") en lugar de Number.
// Estos helpers aceptan ambos tipos para no crashear al decodificar.

private extension KeyedDecodingContainer {
    func decodeFlexInt(forKey key: Key) -> Int? {
        if let i = try? decode(Int.self,    forKey: key) { return i }
        if let s = try? decode(String.self, forKey: key) { return Int(s) }
        return nil
    }
    func decodeFlexDouble(forKey key: Key) -> Double? {
        if let d = try? decode(Double.self, forKey: key) { return d }
        if let s = try? decode(String.self, forKey: key) { return Double(s) }
        return nil
    }
}
