import Foundation

// ─── FavoritesManager ─────────────────────────────────────────────────────────
//
// Persistencia local de negocios favoritos con UserDefaults.
// Mantiene orden de inserción para mostrar favoritos primero.
//
// En producción, sincronizar con API:
//   GET  /api/cliente/favoritos       → getAll()
//   POST /api/cliente/favoritos/toggle → toggle()
//
// Ruta: Seillo/Services/FavoritesManager.swift
// ─────────────────────────────────────────────────────────────────────────────

class FavoritesManager {

    static let shared = FavoritesManager()

    private let favsKey  = "seillo_favorites"
    private let orderKey = "seillo_favorites_order"

    private var favs:  UserDefaults { .standard }
    private var order: UserDefaults { .standard }

    private init() {}

    /// Verifica si un negocio es favorito
    func isFavorite(_ negocioId: String) -> Bool {
        let set = loadFavSet()
        return set.contains(negocioId)
    }

    /// Toggle favorito. Retorna el nuevo estado (true = es favorito ahora)
    @discardableResult
    func toggle(_ negocioId: String) -> Bool {
        var set = loadFavSet()
        var orderDict = loadOrderDict()

        if set.contains(negocioId) {
            set.remove(negocioId)
            orderDict.removeValue(forKey: negocioId)
        } else {
            set.insert(negocioId)
            orderDict[negocioId] = Date().timeIntervalSince1970
        }

        saveFavSet(set)
        saveOrderDict(orderDict)

        return set.contains(negocioId)
    }

    /// Todos los IDs favoritos, ordenados por fecha de inserción (más antiguo primero)
    func getAll() -> [String] {
        let set = loadFavSet()
        let orderDict = loadOrderDict()
        return set.sorted { a, b in
            (orderDict[a] ?? 0) < (orderDict[b] ?? 0)
        }
    }

    /// Cantidad de favoritos
    var count: Int { loadFavSet().count }

    /// Limpia todos los favoritos
    func clearAll() {
        favs.removeObject(forKey: favsKey)
        favs.removeObject(forKey: orderKey)
    }

    // MARK: - Private

    private func loadFavSet() -> Set<String> {
        let array = favs.stringArray(forKey: favsKey) ?? []
        return Set(array)
    }

    private func saveFavSet(_ set: Set<String>) {
        favs.set(Array(set), forKey: favsKey)
    }

    private func loadOrderDict() -> [String: Double] {
        (favs.dictionary(forKey: orderKey) as? [String: Double]) ?? [:]
    }

    private func saveOrderDict(_ dict: [String: Double]) {
        favs.set(dict, forKey: orderKey)
    }
}
