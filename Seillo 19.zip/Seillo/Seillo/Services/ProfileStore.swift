import SwiftUI
import Combine

// ─── ProfileStore (Backend Real) ─────────────────────────────────────────────
//
// Ahora carga datos reales de la sesión guardada por TokenStore.
// La identidad se carga desde APIClientService en lugar de mock.
//
// Ruta: Seillo/Services/ProfileStore.swift
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
class ProfileStore: ObservableObject {

    @Published var profile: UserProfile
    @Published var identidad: UserIdentity = .empty

    private let clientService: ClientServiceProtocol

    init(clientService: ClientServiceProtocol? = nil) {
        self.clientService = clientService ?? APIClientService()

        // Cargar datos de la sesión guardada (puede estar vacía si aún no hay login)
        self.profile = UserProfile(
            nombre: TokenStore.userName ?? "Usuario",
            email: TokenStore.userEmail ?? "",
            avatarId: TokenStore.avatarId
        )
    }

    /// Refresca el perfil desde los datos de sesión locales.
    /// Llamar después de login/register para actualizar el nombre.
    func refreshFromLocal() {
        profile.nombre = TokenStore.userName ?? profile.nombre
        profile.email = TokenStore.userEmail ?? profile.email
        profile.avatarId = TokenStore.avatarId
    }

    func update(nombre: String? = nil, avatarId: Int? = nil) {
        if let n = nombre {
            profile.nombre = n
            TokenStore.updateNombre(n)
        }
        if let a = avatarId {
            profile.avatarId = a
            TokenStore.updateAvatarId(a)
        }
    }

    /// Carga la identidad del usuario desde el backend.
    func loadIdentity() async {
        let result = await clientService.getIdentidad()
        switch result {
        case .success(let id):
            identidad = id
        case .failure:
            break
        }
    }
}
