import SwiftUI
import Combine
import AuthenticationServices

// ─── AuthManager (Backend Real) ──────────────────────────────────────────────
//
// AuthManager conectado al backend de Seillo.
// Reemplaza la versión mock — mismo API público, login real.
//
// Equivalente a AuthRepository.kt de Android.
//
// Cambios vs mock:
//   - login() → POST /api/login
//   - register() → POST /api/register
//   - loginWithApple() → POST /api/auth/google (adaptado para Apple)
//   - Sesión persiste en Keychain (JWT) + UserDefaults (datos)
//   - Al arranque, verifica si hay token guardado
//
// Ruta: Seillo/Services/AuthManager.swift
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
class AuthManager: ObservableObject {

    enum Role { case cliente, negocio }

    @Published var isLoggedIn      = false
    @Published var isBusiness      = false
    @Published var isLoading       = true
    @Published var appleUserName   = ""

    @AppStorage("apple.userIdentifier") private var savedAppleUserID = ""

    private let api = APIClient.shared

    // ── Init: verificar sesión guardada ──────────────────────────────────

    init() {
        Task {
            await restoreSession()
        }
    }

    /// Verifica si hay un JWT guardado y si sigue siendo válido.
    private func restoreSession() async {
        // Espera mínima para cubrir splash animation
        try? await Task.sleep(nanoseconds: 2_000_000_000)

        guard TokenStore.isLoggedIn else {
            isLoading = false
            return
        }

        // Verificar que el token aún sea válido con un endpoint ligero
        do {
            let _: [TarjetaDTO] = try await api.get("api/cliente/tarjetas")
            // Token válido — restaurar sesión
            isLoggedIn = true
            isBusiness = (TokenStore.userTipo == "negocio")
        } catch {
            // Token inválido/expirado — limpiar y pedir login
            TokenStore.clearAll()
        }

        isLoading = false
    }

    // MARK: - Login con email

    func login(email: String, password: String) async throws {
        let body = LoginRequest(email: email.trimmingCharacters(in: .whitespaces).lowercased(), password: password)
        let response: LoginResponseDTO = try await api.postPublic("api/login", body: body)

        saveSession(from: response)
    }

    // MARK: - Register

    /// Registra un usuario. Si es cliente, el backend envía email de verificación
    /// y retorna `requiresVerification: true`. En ese caso NO se hace login automático.
    func register(
        nombre: String,
        email: String,
        password: String,
        role: String = "cliente",
        bizNombre: String? = nil,
        bizDireccion: String? = nil,
        bizRuc: String? = nil,
        bizCategoria: String? = nil,
        bizCategoriaId: Int? = nil,
        bizDistrito: String? = nil
    ) async throws {
        let body = RegisterRequest(
            nombre: nombre,
            email: email.trimmingCharacters(in: .whitespaces).lowercased(),
            password: password,
            role: role,
            bizNombre: bizNombre,
            bizDireccion: bizDireccion,
            bizRuc: bizRuc,
            bizCategoria: bizCategoria,
            bizCategoriaId: bizCategoriaId,
            bizDistrito: bizDistrito
        )
        let response: RegisterResponseDTO = try await api.postPublic("api/register", body: body)

        if response.requiresVerification == true {
            // No hacer login — el usuario debe verificar su email primero
            throw AuthError.emailVerificationRequired
        }

        // Si no requiere verificación (negocio u otro caso), hacer login
        if let loginData = response.toLoginResponse() {
            saveSession(from: loginData)
        }
    }

    // MARK: - Resend Verification Email

    func resendVerificationEmail(email: String) async throws {
        struct ResendBody: Encodable { let email: String }
        let _: OkDTO = try await api.postPublic("api/auth/resend-verification", body: ResendBody(email: email))
    }

    // MARK: - Sign in with Apple

    /// Completa el login tras recibir el AppleCredential.
    /// Usa el endpoint de Google Auth adaptado para Apple en el backend.
    func loginWithApple(_ credential: AppleCredential) async throws {
        isLoading = true

        savedAppleUserID = credential.userIdentifier

        let name = credential.displayName
        if !name.isEmpty, name != "Usuario" {
            appleUserName = name
        }

        guard let tokenData = credential.identityToken,
              let tokenString = String(data: tokenData, encoding: .utf8) else {
            isLoading = false
            throw AuthError.appleFailed
        }

        let nombre = appleUserName.isEmpty ? "Usuario" : appleUserName
        let email = credential.email ?? ""

        // Intentar login primero
        do {
            let body = GoogleAuthRequest(
                nombre: nombre,
                email: email,
                idToken: tokenString,
                action: "login",
                role: "cliente"
            )
            let response: LoginResponseDTO = try await api.postPublic("api/auth/google", body: body)
            saveSession(from: response)
        } catch let error as APIError {
            // Si el usuario no existe (404), intentar registro
            if case .badStatus(404, _) = error {
                let body = GoogleAuthRequest(
                    nombre: nombre,
                    email: email,
                    idToken: tokenString,
                    action: "register",
                    role: "cliente"
                )
                let response: LoginResponseDTO = try await api.postPublic("api/auth/google", body: body)
                saveSession(from: response)
            } else {
                isLoading = false
                throw error
            }
        }

        isLoading = false
    }

    // MARK: - Forgot Password

    func forgotPassword(email: String) async throws {
        let body = ForgotPasswordRequest(email: email.trimmingCharacters(in: .whitespaces).lowercased())
        let _: OkDTO = try await api.postPublic("api/auth/forgot-password", body: body)
    }

    // MARK: - Reset Password

    func resetPassword(token: String, password: String) async throws {
        let body = ResetPasswordRequest(token: token, password: password)
        let _: OkDTO = try await api.postPublic("api/auth/reset-password", body: body)
    }

    // MARK: - Verificar Apple Credential

    func checkAppleCredentialState() async {
        guard !savedAppleUserID.isEmpty else { return }

        let state = try? await ASAuthorizationAppleIDProvider()
            .credentialState(forUserID: savedAppleUserID)

        await MainActor.run {
            if state == .revoked || state == .notFound {
                logout()
                savedAppleUserID = ""
            }
        }
    }

    // MARK: - Logout

    func logout() {
        // Llamar endpoint de logout (no-critical, fire and forget)
        Task {
            try? await api.post("api/logout", body: EmptyBody())
        }

        TokenStore.clearAll()
        isLoggedIn = false
        isBusiness = false
    }

    // MARK: - Helpers privados

    private func saveSession(from response: LoginResponseDTO) {
        let user = response.usuario

        TokenStore.saveToken(response.token)
        TokenStore.saveSession(
            id: user.id,
            nombre: user.nombre,
            email: user.email,
            tipo: user.tipo,
            avatarId: user.avatarId ?? 0,
            codigoAmigo: user.codigoAmigo
        )

        isLoggedIn = true
        isBusiness = (user.tipo == "negocio")
    }
}

// MARK: - AuthError

enum AuthError: LocalizedError {
    case badCredentials
    case appleFailed
    case serverError(String)
    case emailVerificationRequired

    var errorDescription: String? {
        switch self {
        case .badCredentials: return "Credenciales incorrectas. Revisa tu correo y contraseña."
        case .appleFailed:    return "No se pudo completar el acceso con Apple."
        case .serverError(let msg): return msg
        case .emailVerificationRequired: return "Revisa tu correo para verificar tu cuenta."
        }
    }
}

// MARK: - Empty body

private struct EmptyBody: Encodable {}
