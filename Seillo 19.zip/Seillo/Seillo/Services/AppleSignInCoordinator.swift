import AuthenticationServices
import SwiftUI
import Combine

// ─── AppleSignInCoordinator ───────────────────────────────────────────────────
// Coordinator pattern para Sign in with Apple.
//
// Uso desde una View:
//   @StateObject private var appleCoordinator = AppleSignInCoordinator()
//
//   Button("Continuar con Apple") {
//       appleCoordinator.startSignIn()
//   }
//   .onChange(of: appleCoordinator.result) { _, result in
//       guard let result else { return }
//       switch result {
//       case .success(let credential): await auth.loginWithApple(credential)
//       case .failure(let error):      errorMsg = error.localizedDescription
//       }
//   }
//
// NOTA: Requiere en Xcode:
//   Target → Signing & Capabilities → + → Sign in with Apple
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class AppleSignInCoordinator: NSObject, ObservableObject {

    // Publicar un contador entero — Equatable, compatible con .onChange(of:) en iOS 26
    // Las views leen lastCredential / lastError cuando triggerID cambia
    @Published var triggerID: Int = 0
    private(set) var lastCredential: AppleCredential? = nil
    private(set) var lastError:      Error?            = nil

    // Referencia al controller activo (evita que se dealoque durante la presentación)
    private var currentController: ASAuthorizationController?

    // MARK: - Iniciar Sign In

    func startSignIn() {
        let provider = ASAuthorizationAppleIDProvider()
        let request  = provider.createRequest()

        // Pedimos nombre y email — Apple solo los manda la primera vez
        // En logins subsecuentes solo viene el userIdentifier
        request.requestedScopes = [.fullName, .email]

        let controller = ASAuthorizationController(authorizationRequests: [request])
        controller.delegate           = self
        controller.presentationContextProvider = self
        controller.performRequests()

        currentController = controller
    }
}

// MARK: - ASAuthorizationControllerDelegate

extension AppleSignInCoordinator: ASAuthorizationControllerDelegate {

    func authorizationController(
        controller: ASAuthorizationController,
        didCompleteWithAuthorization authorization: ASAuthorization
    ) {
        guard let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential
        else {
            lastCredential = nil
            lastError      = AppleSignInError.invalidCredential
            triggerID     += 1
            return
        }

        // Construir el modelo limpio
        lastCredential = AppleCredential(from: appleIDCredential)
        lastError      = nil
        triggerID     += 1
        currentController = nil
    }

    func authorizationController(
        controller: ASAuthorizationController,
        didCompleteWithError error: Error
    ) {
        // El usuario canceló — no es un error real, no lo mostramos
        if let authError = error as? ASAuthorizationError,
           authError.code == .canceled {
            lastCredential = nil
            lastError      = nil
            currentController = nil
            return
        }
        lastCredential = nil
        lastError      = error
        triggerID     += 1
        currentController = nil
    }
}

// MARK: - ASAuthorizationControllerPresentationContextProviding

extension AppleSignInCoordinator: ASAuthorizationControllerPresentationContextProviding {
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        let scenes = UIApplication.shared.connectedScenes
        let windowScene = scenes
            .first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene
        // iOS 26: usar init(windowScene:) en lugar de init()
        if let scene = windowScene {
            return scene.keyWindow ?? UIWindow(windowScene: scene)
        }
        // Fallback: primera scene disponible
        let anyScene = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }.first
        if let scene = anyScene { return UIWindow(windowScene: scene) }
        // Último recurso — no debería llegar aquí en iOS 26
        fatalError("No UIWindowScene disponible para presentar Sign in with Apple")
    }
}

// MARK: - AppleCredential

/// Modelo limpio extraído de ASAuthorizationAppleIDCredential.
/// Separar el modelo de ASAuthorization evita exponer AuthenticationServices
/// en capas que no lo necesitan (AuthManager, vistas).
struct AppleCredential {
    let userIdentifier: String        // ID único y estable del usuario en Apple
    let email:          String?       // Solo viene la primera vez
    let fullName:       PersonNameComponents?
    let identityToken:  Data?         // JWT firmado por Apple — mandar al backend

    /// Nombre de display para la UI — Apple a veces no lo manda
    var displayName: String {
        if let name = fullName,
           let formatted = PersonNameComponentsFormatter().string(for: name),
           !formatted.isEmpty {
            return formatted
        }
        return email?.components(separatedBy: "@").first?.capitalized ?? "Usuario"
    }

    init(from credential: ASAuthorizationAppleIDCredential) {
        self.userIdentifier = credential.user
        self.email          = credential.email
        self.fullName       = credential.fullName
        self.identityToken  = credential.identityToken
    }
}

// MARK: - Errors

enum AppleSignInError: LocalizedError {
    case invalidCredential
    case tokenMissing

    var errorDescription: String? {
        switch self {
        case .invalidCredential: return "No se pudo obtener las credenciales de Apple."
        case .tokenMissing:      return "Token de Apple no disponible."
        }
    }
}
