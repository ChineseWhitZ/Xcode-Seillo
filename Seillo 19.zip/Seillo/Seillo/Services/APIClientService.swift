import SwiftUI

// ─── API Client Service ──────────────────────────────────────────────────────
//
// Implementación REAL de ClientServiceProtocol.
// Reemplaza a MockClientService — misma interfaz, datos del backend.
//
// Equivalente a ClientRepository.kt de Android.
//
// Ruta: Seillo/Services/APIClientService.swift
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
class APIClientService: ClientServiceProtocol {

    private let api = APIClient.shared

    // MARK: - Tarjetas

    func getTarjetas() async -> Result<[LoyaltyCard], Error> {
        do {
            let dtos: [TarjetaDTO] = try await api.get("api/cliente/tarjetas")
            let cards = dtos.map { dto in
                LoyaltyCard(
                    id: dto.id,
                    bizName: dto.negocioNombre,
                    location: dto.categoria ?? "",
                    rewardText: dto.premio,
                    totalStamps: dto.sellosMeta,
                    filledStamps: dto.sellosActuales,
                    negocioId: dto.negocioId,
                    programaId: dto.programaId
                )
            }
            return .success(cards)
        } catch {
            return .failure(error)
        }
    }

    func getHistorial() async -> Result<[HistoryEntry], Error> {
        do {
            let dtos: [HistorialDTO] = try await api.get("api/cliente/historial")
            let entries = dtos.map { dto in
                HistoryEntry(
                    bizName: dto.negocio,
                    action: dto.tipo == "sello" ? "Sello acumulado" : "Premio canjeado",
                    date: formatRelativeDate(dto.createdAt),
                    icon: dto.tipo == "sello" ? "seal.fill" : "gift.fill",
                    color: dto.tipo == "sello" ? .seilAccent : .seilGold,
                    isReward: dto.tipo == "canje"
                )
            }
            return .success(entries)
        } catch {
            return .failure(error)
        }
    }

    func getHistorialCompletadas() async -> Result<[CompletedCard], Error> {
        do {
            let dtos: [CartillaCompletadaDTO] = try await api.get("api/cliente/historial-completadas")
            let cards = dtos.enumerated().map { (i, dto) in
                CompletedCard(
                    id: "\(i)",
                    negocioNombre: dto.negocioNombre,
                    categoria: dto.negocioCategoria ?? "",
                    premio: dto.premio,
                    fechaCompletada: formatRelativeDate(dto.canjeadoAt),
                    sellosMeta: dto.sellosMeta
                )
            }
            return .success(cards)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - QR y Canje

    func getQR() async -> Result<String, Error> {
        do {
            let dto: QRDTO = try await api.get("api/cliente/qr")
            return .success(dto.qrCode)
        } catch {
            return .failure(error)
        }
    }

    func getCanjeToken(tarjetaId: String) async -> Result<String, Error> {
        do {
            let dto: CanjeTokenDTO = try await api.get("api/cliente/canje-token/\(tarjetaId)")
            return .success(dto.token)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Notificaciones

    func getNotificaciones() async -> Result<[NotificationItem], Error> {
        do {
            let dtos: [NotificacionDTO] = try await api.get("api/cliente/notificaciones")
            let items = dtos.map { dto in
                NotificationItem(
                    title: dto.titulo,
                    body: dto.mensaje,
                    time: formatRelativeDate(dto.createdAt),
                    icon: iconForNotificationType(dto.tipo),
                    color: colorForNotificationType(dto.tipo),
                    isRead: dto.leido == 1
                )
            }
            return .success(items)
        } catch {
            return .failure(error)
        }
    }

    func marcarNotificacionesLeidas() async -> Result<Void, Error> {
        do {
            try await api.putVoid("api/cliente/notificaciones/leer")
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Perfil

    func updatePerfil(nombre: String, avatarId: Int) async -> Result<Void, Error> {
        do {
            let body = UpdatePerfilRequest(nombre: nombre, avatarId: avatarId)
            try await api.patch("api/usuario/perfil", body: body)
            TokenStore.updateNombre(nombre)
            TokenStore.updateAvatarId(avatarId)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Favoritos

    func getFavoritos() async -> Result<Set<String>, Error> {
        do {
            let ids: [String] = try await api.get("api/cliente/favoritos")
            return .success(Set(ids))
        } catch {
            return .failure(error)
        }
    }

    func toggleFavorito(negocioId: String) async -> Result<Bool, Error> {
        do {
            // Intentar agregar; si ya existe, el backend maneja el toggle
            try await api.post("api/cliente/favoritos/\(negocioId)", body: EmptyBody())
            return .success(true)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Identidad

    func getIdentidad() async -> Result<UserIdentity, Error> {
        do {
            let dto: IdentidadDTO = try await api.get("api/cliente/identidad")
            let identity = UserIdentity(
                badgesGanados: (dto.badgesGanados ?? []).map { $0.toModel() },
                badgesVisibles: dto.badgesVisibles ?? [],
                framesGanados: (dto.framesGanados ?? []).map { $0.toModel() },
                frameActivo: dto.frameActivo,
                titulosGanados: (dto.titulosGanados ?? []).map { $0.toModel() },
                tituloActivo: dto.tituloActivo
            )
            return .success(identity)
        } catch {
            // Graceful fallback (igual que Android)
            return .success(.empty)
        }
    }

    func updateIdentidad(_ request: UpdateIdentityRequest) async -> Result<Void, Error> {
        do {
            let body = UpdateIdentidadRequest(
                frameActivo: request.frameActivo,
                tituloActivo: request.tituloActivo,
                badgesVisibles: request.badgesVisibles
            )
            try await api.patch("api/cliente/identidad", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Perfil público

    func getPerfilPublico(userId: String) async -> Result<PublicProfile, Error> {
        do {
            let dto: PerfilPublicoDTO = try await api.get("api/usuarios/\(userId)/perfil")
            let profile = PublicProfile(
                id: dto.id,
                nombre: dto.nombre,
                avatarId: dto.avatarId ?? 0,
                nivel: dto.nivel ?? "Nuevo",
                totalSellos: dto.totalSellos ?? 0,
                totalTarjetas: dto.totalTarjetas ?? 0,
                totalPremios: dto.totalPremios ?? 0,
                tarjetasActivas: (dto.tarjetasActivas ?? []).map {
                    PublicTarjeta(
                        negocioNombre: $0.negocioNombre,
                        sellosActuales: $0.sellosActuales,
                        sellosMeta: $0.sellosMeta,
                        categoria: $0.categoria ?? ""
                    )
                },
                identidad: PublicIdentity(
                    frameActivo: dto.identidad?.frameActivo,
                    tituloTexto: dto.identidad?.tituloTexto,
                    badgesVisibles: (dto.identidad?.badgesVisibles ?? []).map { $0.toModel() }
                ),
                esAmigo: dto.esAmigo ?? false
            )
            return .success(profile)
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Wizard

    func updateWizard(genero: String?, fechaNacimiento: String?, preferencias: [String]) async -> Result<Void, Error> {
        do {
            let body = UpdateWizardRequest(
                genero: genero,
                fechaNacimiento: fechaNacimiento,
                preferencias: preferencias
            )
            try await api.patch("api/usuario/wizard", body: body)
            return .success(())
        } catch {
            return .failure(error)
        }
    }

    // MARK: - Helpers privados

    // MEDIO: antes probaba solo 2 formatos ISO8601 — fallaba con timestamps
    // sin zona horaria, con espacio en lugar de 'T', o con offset +HH:MM.
    // Ahora usa una cadena de 4 formatters que cubre los formatos reales
    // que devuelve MySQL (DATETIME, TIMESTAMP, con y sin fracción).
    private func formatRelativeDate(_ iso: String) -> String {
        let date = Self.parseDate(iso)
        guard let date else { return iso }

        let diff = Date().timeIntervalSince(date)
        if diff < 60     { return "Ahora" }
        if diff < 3600   { return "Hace \(Int(diff / 60))min" }
        if diff < 86400  { return "Hace \(Int(diff / 3600))h" }
        if diff < 604800 { return "Hace \(Int(diff / 86400))d" }
        let df = DateFormatter()
        df.dateFormat = "dd MMM"
        df.locale = Locale(identifier: "es_PE")
        return df.string(from: date)
    }

    /// Parsea timestamps ISO8601 y MySQL DATETIME de forma robusta.
    /// Compartido como `static` para que `APIFriendService` lo reutilice
    /// en lugar de duplicar la lógica.
    static func parseDate(_ iso: String) -> Date? {
        // 1. ISO8601 con fracción de segundos  → "2025-03-15T14:23:01.456Z"
        // 2. ISO8601 sin fracción              → "2025-03-15T14:23:01Z"
        // 3. ISO8601 con offset +HH:MM         → "2025-03-15T14:23:01+05:00"
        // 4. MySQL DATETIME sin zona           → "2025-03-15 14:23:01"
        for options: ISO8601DateFormatter.Options in [
            [.withInternetDateTime, .withFractionalSeconds],
            [.withInternetDateTime],
            [.withInternetDateTime, .withTimeZone],
        ] {
            let f = ISO8601DateFormatter()
            f.formatOptions = options
            if let d = f.date(from: iso) { return d }
        }
        // MySQL DATETIME sin zona — asumir UTC
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss"
        df.timeZone = TimeZone(identifier: "UTC")
        df.locale = Locale(identifier: "en_US_POSIX")
        return df.date(from: iso)
    }

    private func iconForNotificationType(_ tipo: String) -> String {
        switch tipo {
        case "sello":    return "seal.fill"
        case "canje":    return "gift.fill"
        case "nearby":   return "location.fill"
        case "push":     return "megaphone.fill"
        case "campania": return "star.fill"
        case "amigo":    return "person.2.fill"
        default:         return "bell.fill"
        }
    }

    private func colorForNotificationType(_ tipo: String) -> Color {
        switch tipo {
        case "sello":    return .seilAccent
        case "canje":    return .seilGold
        case "nearby":   return .seilBlue
        case "push":     return .seilPurple
        case "campania": return .seilGreen
        case "amigo":    return .seilRose
        default:         return .seilMuted2
        }
    }
}

// MARK: - DTO → Model mappers

private extension BadgeItemDTO {
    func toModel() -> BadgeInfo {
        BadgeInfo(
            id: id,
            nombre: nombre,
            tipo: parseType(tipo)
        )
    }
}

private extension FrameItemDTO {
    func toModel() -> FrameInfo {
        FrameInfo(
            id: id,
            nombre: nombre,
            tipo: parseType(tipo)
        )
    }
}

private extension TituloItemDTO {
    func toModel() -> TituloInfo {
        TituloInfo(
            id: id,
            texto: texto,
            tipo: parseType(tipo)
        )
    }
}

private func parseType(_ s: String) -> IdentityItemType {
    switch s {
    case "event":    return .event
    case "seasonal": return .seasonal
    default:         return .earned
    }
}

// MARK: - Empty body helper

private struct EmptyBody: Encodable {}
