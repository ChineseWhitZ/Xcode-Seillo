import WidgetKit
import SwiftUI
import ActivityKit

// ─── SeillWidget ───────────────────────────────────────────────────────────────
// Widget de fidelidad — tres tamaños + Live Activity de sello recibido.
//
// iOS 26 Liquid Glass:
//  • containerBackground(.fill.tertiary) → sistema aplica el glass automático
//  • Sin contentMarginsDisabled() → márgenes forman parte de la forma del glass
//  • Colores adaptativos (.primary / .secondary) → funcionan en accented + vibrant
//  • @Environment(\.widgetRenderingMode) → ajusta visibilidad en cada modo
//  • widgetAccentable() → marca qué elementos destacan en modo Accented
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Timeline Provider

struct SeillProvider: TimelineProvider {

    func placeholder(in context: Context) -> SeillEntry {
        SeillEntry(date: .now, cards: WidgetCard.placeholders)
    }

    func getSnapshot(in context: Context, completion: @escaping (SeillEntry) -> Void) {
        completion(SeillEntry(date: .now, cards: AppGroupStore.readCards()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SeillEntry>) -> Void) {
        let entry      = SeillEntry(date: .now, cards: AppGroupStore.readCards())
        let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: .now) ?? .now
        completion(Timeline(entries: [entry], policy: .after(nextUpdate)))
    }
}

// MARK: - Entry

struct SeillEntry: TimelineEntry {
    let date:  Date
    let cards: [WidgetCard]

    var topCard:  WidgetCard?  { AppGroupStore.topCard() ?? cards.first }
    var top2:     [WidgetCard] { Array(cards.prefix(2)) }
    var top3:     [WidgetCard] { Array(cards.prefix(3)) }
    var hasCards: Bool         { !cards.isEmpty }
}

// MARK: - Dispatcher

struct SeillWidgetEntryView: View {
    @Environment(\.widgetFamily) private var family
    var entry: SeillEntry

    // URL de deep link según el tamaño:
    // Small → abre la tarjeta más cercana al premio
    // Medium/Large → abre home (el usuario toca tarjetas individuales con Link)
    private var deepLinkURL: URL {
        if family == .systemSmall, let card = entry.topCard {
            return URL(string: "seillo://card/\(card.id)") ?? URL(string: "seillo://home")!
        }
        return URL(string: "seillo://home")!
    }

    var body: some View {
        Group {
            switch family {
            case .systemSmall:  SmallView(entry: entry)
            case .systemMedium: MediumView(entry: entry)
            case .systemLarge:  LargeView(entry: entry)
            default:            SmallView(entry: entry)
            }
        }
        .widgetURL(deepLinkURL)
    }
}

// ─── Small Widget ─────────────────────────────────────────────────────────────

private struct SmallView: View {
    let entry: SeillEntry

    var body: some View {
        if let card = entry.topCard {
            SmallCardView(card: card)
        } else {
            EmptySmallView()
        }
    }
}

private struct SmallCardView: View {
    let card: WidgetCard
    @Environment(\.widgetRenderingMode) private var renderingMode

    var body: some View {
        ZStack {
            // Tinte sutil del color de la tarjeta sobre el glass
            card.color
                .opacity(renderingMode == .fullColor ? 0.12 : 0)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

            VStack(alignment: .leading, spacing: 0) {

                // ── Header ────────────────────────────────────────────────
                HStack {
                    ZStack {
                        Circle()
                            .fill(card.color.opacity(0.22))
                            .frame(width: 30, height: 30)
                        Image(systemName: card.icon)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(card.color)
                    }
                    .widgetAccentable()

                    Spacer()

                    if card.isComplete {
                        Image(systemName: "trophy.fill")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(card.color)
                            .widgetAccentable()
                    }
                }

                Spacer()

                // ── Nombre ────────────────────────────────────────────────
                Text(card.bizName)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                // ── Estado ────────────────────────────────────────────────
                Text(card.isComplete
                     ? "Premio listo 🎉"
                     : "Faltan \(card.remainingStamps) sello\(card.remainingStamps == 1 ? "" : "s")")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(card.isComplete ? AnyShapeStyle(card.color) : AnyShapeStyle(.secondary))
                    .padding(.top, 2)
                    .widgetAccentable(card.isComplete)

                // ── Barra de progreso ─────────────────────────────────────
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(.primary.opacity(0.10))
                            .frame(height: 5)
                        Capsule()
                            .fill(card.color)
                            .frame(
                                width: max(
                                    geo.size.width * CGFloat(card.progress),
                                    card.isComplete ? geo.size.width : 0
                                ),
                                height: 5
                            )
                            .widgetAccentable()
                    }
                }
                .frame(height: 5)
                .padding(.top, 6)

                // ── Contador ──────────────────────────────────────────────
                HStack(spacing: 2) {
                    Text("\(card.filledStamps)")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundColor(card.color)
                        .widgetAccentable()
                    Text("/\(card.totalStamps)")
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                }
                .padding(.top, 4)
            }
            .padding(14)
        }
    }
}

private struct EmptySmallView: View {
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "seal.fill")
                .font(.system(size: 26, weight: .semibold))
                .foregroundColor(Color(red: 1, green: 0.35, blue: 0))
                .widgetAccentable()
            Text("Abre Seillo")
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(.primary)
            Text("para ver tus tarjetas")
                .font(.system(size: 9))
                .foregroundStyle(.secondary)
        }
    }
}

// ─── Medium Widget ────────────────────────────────────────────────────────────

private struct MediumView: View {
    let entry: SeillEntry

    var body: some View {
        if entry.top2.isEmpty {
            EmptyMediumView()
        } else {
            VStack(alignment: .leading, spacing: 0) {

                // Header
                HStack {
                    HStack(spacing: 5) {
                        Image(systemName: "seal.fill")
                            .font(.system(size: 11, weight: .black))
                            .foregroundColor(Color(red: 1, green: 0.35, blue: 0))
                            .widgetAccentable()
                        Text("Seillo")
                            .font(.system(size: 12, weight: .heavy, design: .rounded))
                            .foregroundStyle(.primary)
                    }
                    Spacer()
                    Text("\(entry.cards.count) tarjeta\(entry.cards.count == 1 ? "" : "s")")
                        .font(.system(size: 10))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 14)
                .padding(.top, 12)
                .padding(.bottom, 8)

                // Cards
                VStack(spacing: 6) {
                    ForEach(entry.top2) { card in
                        MediumCardRow(card: card)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.bottom, 12)
            }
        }
    }
}

private struct MediumCardRow: View {
    let card: WidgetCard
    @Environment(\.widgetRenderingMode) private var renderingMode

    var body: some View {
        HStack(spacing: 10) {
            // Icono
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(card.color.opacity(0.20))
                    .frame(width: 36, height: 36)
                Image(systemName: card.icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(card.color)
            }
            .widgetAccentable()

            // Info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(card.bizName)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    if card.isComplete {
                        Image(systemName: "sparkles")
                            .font(.system(size: 9))
                            .foregroundColor(card.color)
                            .widgetAccentable()
                    }
                    Spacer()
                    Text(card.isComplete ? "¡Listo!" : "\(card.filledStamps)/\(card.totalStamps)")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundColor(card.color)
                        .widgetAccentable()
                }

                // Barra
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(.primary.opacity(0.08))
                            .frame(height: 4)
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [card.color.opacity(0.75), card.color],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                            .frame(
                                width: max(
                                    geo.size.width * CGFloat(card.progress),
                                    card.isComplete ? geo.size.width : 0
                                ),
                                height: 4
                            )
                            .widgetAccentable()
                    }
                }
                .frame(height: 4)
            }
        }
        .padding(10)
        .background(.primary.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct EmptyMediumView: View {
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "creditcard.fill")
                .font(.system(size: 22))
                .foregroundStyle(.secondary)
            Text("Sin tarjetas aún")
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// ─── Large Widget ─────────────────────────────────────────────────────────────

private struct LargeView: View {
    let entry: SeillEntry
    private var totalStamps: Int { entry.cards.reduce(0) { $0 + $1.filledStamps } }
    private var readyCount:  Int { entry.cards.filter { $0.isComplete }.count }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            // Header
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 5) {
                        Image(systemName: "seal.fill")
                            .font(.system(size: 13, weight: .black))
                            .foregroundColor(Color(red: 1, green: 0.35, blue: 0))
                            .widgetAccentable()
                        Text("Seillo")
                            .font(.system(size: 14, weight: .heavy, design: .rounded))
                            .foregroundStyle(.primary)
                    }
                    Text("Mis tarjetas de fidelidad")
                        .font(.system(size: 10))
                        .foregroundStyle(.tertiary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    if readyCount > 0 {
                        Label("\(readyCount) listo\(readyCount > 1 ? "s" : "")", systemImage: "trophy.fill")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(Color(red: 0, green: 0.79, blue: 0.48))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color(red: 0, green: 0.79, blue: 0.48).opacity(0.15))
                            .clipShape(Capsule())
                            .widgetAccentable()
                    }
                    Text("\(totalStamps) sellos total")
                        .font(.system(size: 9))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 14)
            .padding(.top, 14)
            .padding(.bottom, 10)

            // Divisor
            Rectangle()
                .fill(.primary.opacity(0.06))
                .frame(height: 1)
                .padding(.horizontal, 14)
                .padding(.bottom, 10)

            // Cards
            VStack(spacing: 8) {
                ForEach(entry.top3) { card in
                    LargeCardRow(card: card)
                }
            }
            .padding(.horizontal, 12)

            Spacer()

            // Footer
            if entry.top3.count < entry.cards.count {
                Text("Y \(entry.cards.count - entry.top3.count) tarjeta\(entry.cards.count - entry.top3.count == 1 ? "" : "s") más en la app")
                    .font(.system(size: 9))
                    .foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.bottom, 12)
            }
        }
    }
}

private struct LargeCardRow: View {
    let card: WidgetCard

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(card.color.opacity(0.20))
                        .frame(width: 34, height: 34)
                    Image(systemName: card.icon)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(card.color)
                }
                .widgetAccentable()

                VStack(alignment: .leading, spacing: 2) {
                    Text(card.bizName)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(card.rewardText)
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 1) {
                    Text("\(card.filledStamps)")
                        .font(.system(size: 16, weight: .heavy, design: .rounded))
                        .foregroundColor(card.color)
                        .widgetAccentable()
                    Text("de \(card.totalStamps)")
                        .font(.system(size: 9))
                        .foregroundStyle(.tertiary)
                }
            }

            // Dots de sellos
            HStack(spacing: 5) {
                ForEach(0..<min(card.totalStamps, 10), id: \.self) { i in
                    Circle()
                        .fill(i < card.filledStamps ? card.color : Color.primary.opacity(0.10))
                        .frame(width: 9, height: 9)
                        .widgetAccentable(i < card.filledStamps)
                }
                if card.totalStamps > 10 {
                    Text("+\(card.totalStamps - 10)")
                        .font(.system(size: 8))
                        .foregroundStyle(.tertiary)
                }
            }
        }
        .padding(10)
        .background(.primary.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// ─── Widget Declaration ───────────────────────────────────────────────────────

struct SeillWidget: Widget {
    let kind = "SeillWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: SeillProvider()) { entry in
            SeillWidgetEntryView(entry: entry)
                // iOS 26: el sistema aplica el glass automáticamente sobre este material
                .containerBackground(.fill.tertiary, for: .widget)
        }
        .configurationDisplayName("Seillo")
        .description("Seguí el progreso de tus tarjetas de fidelidad.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
        // ⚠️ NO usar .contentMarginsDisabled() — los márgenes son parte de la forma del glass
    }
}

// ─── Live Activity — Sello Recibido ───────────────────────────────────────────
// Se activa cuando el negocio escanea el QR del usuario y registra un sello.
// David: disparar con ActivityKit desde la app tras el POST /api/negocio/escanear.

struct SeillStampAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var sellosActuales: Int
        var sellosTotal:    Int
        var premioListo:    Bool
    }

    let bizName:    String
    let bizIcon:    String   // SF Symbol name
    let colorHex:  String   // color hex del negocio, ej. "#FF5A00"
}

struct SeillStampLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: SeillStampAttributes.self) { context in
            // ── Lock Screen / Banner ───────────────────────────────────────
            HStack(spacing: 14) {
                // Ícono negocio
                ZStack {
                    Circle()
                        .fill(Color(hex: context.attributes.colorHex).opacity(0.20))
                        .frame(width: 44, height: 44)
                    Image(systemName: context.attributes.bizIcon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(Color(hex: context.attributes.colorHex))
                }

                // Info
                VStack(alignment: .leading, spacing: 3) {
                    Text(context.state.premioListo ? "¡Premio completo!" : "¡Sello recibido!")
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .foregroundStyle(.primary)
                    Text(context.attributes.bizName)
                        .font(.system(size: 11))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                // Contador
                VStack(alignment: .trailing, spacing: 2) {
                    HStack(spacing: 2) {
                        Text("\(context.state.sellosActuales)")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundColor(
                                context.state.premioListo
                                    ? Color(red: 1.0, green: 0.72, blue: 0.0)
                                    : Color(hex: context.attributes.colorHex)
                            )
                        Text("/\(context.state.sellosTotal)")
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)
                    }
                    Text(context.state.premioListo
                         ? "Premio listo 🎉"
                         : "Faltan \(context.state.sellosTotal - context.state.sellosActuales)")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .activityBackgroundTint(.clear)
            .activitySystemActionForegroundColor(.primary)

        } dynamicIsland: { context in
            DynamicIsland {
                // ── Expanded ──────────────────────────────────────────────
                DynamicIslandExpandedRegion(.leading) {
                    ZStack {
                        Circle()
                            .fill(Color(hex: context.attributes.colorHex).opacity(0.20))
                            .frame(width: 40, height: 40)
                        Image(systemName: context.attributes.bizIcon)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(Color(hex: context.attributes.colorHex))
                    }
                    .padding(.leading, 4)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 2) {
                        HStack(spacing: 2) {
                            Text("\(context.state.sellosActuales)")
                                .font(.system(size: 20, weight: .black, design: .rounded))
                                .foregroundColor(Color(hex: context.attributes.colorHex))
                            Text("/\(context.state.sellosTotal)")
                                .font(.system(size: 11))
                                .foregroundStyle(.secondary)
                        }
                        Text(context.state.premioListo ? "¡Premio listo!" : "sellos")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(context.state.premioListo ? AnyShapeStyle(Color.yellow) : AnyShapeStyle(Color.secondary))
                    }
                    .padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(spacing: 2) {
                        Text(context.state.premioListo ? "¡Premio completo!" : "¡Sello recibido!")
                            .font(.system(size: 13, weight: .heavy, design: .rounded))
                            .foregroundStyle(.primary)
                        Text(context.attributes.bizName)
                            .font(.system(size: 10))
                            .foregroundStyle(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    // Mini barra de progreso
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(.primary.opacity(0.10))
                                .frame(height: 4)
                            Capsule()
                                .fill(Color(hex: context.attributes.colorHex))
                                .frame(
                                    width: geo.size.width * CGFloat(context.state.sellosActuales) / CGFloat(max(context.state.sellosTotal, 1)),
                                    height: 4
                                )
                        }
                    }
                    .frame(height: 4)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)
                }
            } compactLeading: {
                Image(systemName: context.attributes.bizIcon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(Color(hex: context.attributes.colorHex))
                    .padding(.leading, 4)
            } compactTrailing: {
                Text("\(context.state.sellosActuales)/\(context.state.sellosTotal)")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .foregroundColor(Color(hex: context.attributes.colorHex))
                    .padding(.trailing, 4)
            } minimal: {
                Image(systemName: context.state.premioListo ? "trophy.fill" : "checkmark.circle.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(
                        context.state.premioListo
                            ? Color(red: 1.0, green: 0.72, blue: 0.0)
                            : Color(hex: context.attributes.colorHex)
                    )
            }
        }
    }
}

// ─── Previews ─────────────────────────────────────────────────────────────────

private extension Color {
    init(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: h).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch h.count {
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(.sRGB,
                  red:     Double(r) / 255,
                  green:   Double(g) / 255,
                  blue:    Double(b) / 255,
                  opacity: Double(a) / 255)
    }
}

// ─── Previews ─────────────────────────────────────────────────────────────────

#Preview(as: .systemSmall) {
    SeillWidget()
} timeline: {
    SeillEntry(date: .now, cards: WidgetCard.placeholders)
}

#Preview(as: .systemMedium) {
    SeillWidget()
} timeline: {
    SeillEntry(date: .now, cards: WidgetCard.placeholders)
}

#Preview(as: .systemLarge) {
    SeillWidget()
} timeline: {
    SeillEntry(date: .now, cards: WidgetCard.placeholders)
}

#Preview(as: .dynamicIsland(.expanded), using: SeillStampAttributes(
    bizName:  "Café Inti",
    bizIcon:  "cup.and.saucer.fill",
    colorHex: "#FF5A00"
)) {
    SeillStampLiveActivity()
} contentStates: {
    SeillStampAttributes.ContentState(sellosActuales: 8, sellosTotal: 10, premioListo: false)
    SeillStampAttributes.ContentState(sellosActuales: 10, sellosTotal: 10, premioListo: true)
}
