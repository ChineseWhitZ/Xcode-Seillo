//
//  SeillWidgetLiveActivity.swift
//  SeillWidget
//
//  Created by Joshua Ferreyra on 16/03/26.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct SeillWidgetAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var emoji: String
    }

    // Fixed non-changing properties about your activity go here!
    var name: String
}

struct SeillWidgetLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: SeillWidgetAttributes.self) { context in
            // Lock screen/banner UI goes here
            VStack {
                Text("Hello \(context.state.emoji)")
            }
            .activityBackgroundTint(Color.cyan)
            .activitySystemActionForegroundColor(Color.black)

        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.leading) {
                    Text("Leading")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("Trailing")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("Bottom \(context.state.emoji)")
                    // more content
                }
            } compactLeading: {
                Text("L")
            } compactTrailing: {
                Text("T \(context.state.emoji)")
            } minimal: {
                Text(context.state.emoji)
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

extension SeillWidgetAttributes {
    fileprivate static var preview: SeillWidgetAttributes {
        SeillWidgetAttributes(name: "World")
    }
}

extension SeillWidgetAttributes.ContentState {
    fileprivate static var smiley: SeillWidgetAttributes.ContentState {
        SeillWidgetAttributes.ContentState(emoji: "😀")
     }
     
     fileprivate static var starEyes: SeillWidgetAttributes.ContentState {
         SeillWidgetAttributes.ContentState(emoji: "🤩")
     }
}

#Preview("Notification", as: .content, using: SeillWidgetAttributes.preview) {
   SeillWidgetLiveActivity()
} contentStates: {
    SeillWidgetAttributes.ContentState.smiley
    SeillWidgetAttributes.ContentState.starEyes
}
