import WidgetKit
import SwiftUI

// ─── SeillWidgetBundle ────────────────────────────────────────────────────────
// Entry point del widget extension.
// Agrupa el widget de tarjetas y el Live Activity de sello recibido.
// ─────────────────────────────────────────────────────────────────────────────

@main
struct SeillWidgetBundle: WidgetBundle {
    var body: some Widget {
        SeillWidget()
        SeillStampLiveActivity()
    }
}
