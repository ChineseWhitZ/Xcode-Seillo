import Foundation
import SwiftUI

// ─── AppGroupStore ────────────────────────────────────────────────────────────
// Puente de datos entre la app principal y el widget.
// Ambos targets comparten el mismo App Group: group.com.seillo.shared
//
// La app escribe → el widget lee.
// Llamar AppGroupStore.write(cards:) cada vez que las tarjetas cambien.
// ─────────────────────────────────────────────────────────────────────────────

private let groupID     = "group.com.seillo.shared"
private let cardsKey    = "seillo.widget.cards"
private let updatedKey  = "seillo.widget.lastUpdated"

// MARK: - Modelo ligero para el widget

/// Versión serializable de LoyaltyCard — no depende de SwiftUI.Color
struct WidgetCard: Codable, Identifiable {
    let id:           String
    let bizName:      String
    let rewardText:   String
    let filledStamps: Int
    let totalStamps:  Int
    let icon:         String
    let colorHex:     String   // "FF5A00", "4F9FFF", etc.
    let location:     String

    var progress: Double {
        guard totalStamps > 0 else { return 0 }
        return Double(filledStamps) / Double(totalStamps)
    }
    var remainingStamps: Int { max(0, totalStamps - filledStamps) }
    var isComplete: Bool     { filledStamps >= totalStamps }

    // Convierte colorHex → SwiftUI.Color (solo en contextos que importan SwiftUI)
    var color: Color {
        let hex = colorHex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r = Double((int >> 16) & 0xFF) / 255
        let g = Double((int >>  8) & 0xFF) / 255
        let b = Double( int        & 0xFF) / 255
        return Color(.sRGB, red: r, green: g, blue: b)
    }
}

// MARK: - AppGroupStore

enum AppGroupStore {

    private static var defaults: UserDefaults? {
        UserDefaults(suiteName: groupID)
    }

    // ── Escritura (app principal) ─────────────────────────────────────────────

    /// Serializa las tarjetas y las persiste en el App Group.
    /// Llamar después de cualquier cambio en el estado de tarjetas.
    static func write(cards: [WidgetCard]) {
        guard let defaults else { return }
        if let data = try? JSONEncoder().encode(cards) {
            defaults.set(data, forKey: cardsKey)
            defaults.set(Date(), forKey: updatedKey)
        }
    }

    // ── Lectura (widget) ──────────────────────────────────────────────────────

    static func readCards() -> [WidgetCard] {
        guard let defaults,
              let data  = defaults.data(forKey: cardsKey),
              let cards = try? JSONDecoder().decode([WidgetCard].self, from: data)
        else { return WidgetCard.placeholders }
        return cards
    }

    static func lastUpdated() -> Date {
        defaults?.object(forKey: updatedKey) as? Date ?? .now
    }

    // ── Tarjeta más cercana al premio ─────────────────────────────────────────

    static func topCard() -> WidgetCard? {
        let cards = readCards()
        // Primero: si hay alguna completa, mostrarla
        if let ready = cards.first(where: { $0.isComplete }) { return ready }
        // Si no: la más cercana al objetivo
        return cards.filter { !$0.isComplete }.max { $0.progress < $1.progress }
    }
}

// MARK: - Placeholders

extension WidgetCard {
    static let placeholders: [WidgetCard] = [
        WidgetCard(
            id: "ph1", bizName: "Café Inti",
            rewardText: "Café a elección gratis",
            filledStamps: 8, totalStamps: 10,
            icon: "cup.and.saucer.fill",
            colorHex: "FFB800", location: "café"
        ),
        WidgetCard(
            id: "ph2", bizName: "Barbería Rey",
            rewardText: "Corte + arreglo gratis",
            filledStamps: 5, totalStamps: 7,
            icon: "scissors",
            colorHex: "B06FEF", location: "barbería"
        ),
    ]

    static var placeholder: WidgetCard { placeholders[0] }
}
