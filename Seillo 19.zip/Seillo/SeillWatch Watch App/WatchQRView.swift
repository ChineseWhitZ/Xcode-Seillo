import SwiftUI

// ─── WatchQRView ──────────────────────────────────────────────────────────────
// Muestra el QR del usuario para que el negocio lo escanee.
// Comportamiento idéntico al de iOS:
//   • Countdown de 5 minutos con anillo animado
//   • Colores del anillo: verde → dorado (60s) → rojo (30s) → expirado
//   • Mantiene la pantalla encendida con .persistentSystemOverlays(.hidden)
//   • Botón de renovar cuando expira
// ─────────────────────────────────────────────────────────────────────────────

struct WatchQRView: View {
    let card: WatchCard

    @State private var secondsLeft = 300
    @State private var expired     = false
    @State private var timer: Timer? = nil
    @State private var appeared    = false

    private var progress: Double { Double(secondsLeft) / 300.0 }

    private var ringColor: Color {
        if expired           { return .red }
        if secondsLeft <= 30 { return .red }
        if secondsLeft <= 60 { return Color(red: 1, green: 0.72, blue: 0) } // dorado
        return .green
    }

    private var timeLabel: String {
        if expired { return "Expirado" }
        let m = secondsLeft / 60
        let s = secondsLeft % 60
        return String(format: "%d:%02d", m, s)
    }

    // Tamaño del QR ajustado al Watch — más grande en 45/49mm
    private let qrSize: CGFloat = 110

    var body: some View {
        VStack(spacing: 6) {
            // ── Negocio ────────────────────────────────────────────────
            HStack(spacing: 5) {
                Image(systemName: card.icon)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(card.color)
                Text(card.bizName)
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)
            }

            // ── QR + anillo de countdown ───────────────────────────────
            ZStack {
                // Track del anillo
                Circle()
                    .stroke(ringColor.opacity(0.15), lineWidth: 3)
                    .frame(width: qrSize + 10, height: qrSize + 10)

                // Anillo de progreso
                Circle()
                    .trim(from: 0, to: expired ? 0 : progress)
                    .stroke(ringColor,
                            style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .frame(width: qrSize + 10, height: qrSize + 10)
                    .rotationEffect(.degrees(-90))
                    .animation(.linear(duration: 1), value: secondsLeft)

                // QR box blanco
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(.white)
                        .frame(width: qrSize, height: qrSize)

                    if expired {
                        VStack(spacing: 4) {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.red)
                            Text("Expirado")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.red)
                        }
                    } else {
                        WatchMockQR()
                            .frame(width: qrSize - 12, height: qrSize - 12)
                    }
                }
                .scaleEffect(appeared ? 1 : 0.85)
                .animation(.spring(response: 0.4, dampingFraction: 0.7), value: appeared)
            }

            // ── Timer / estado ─────────────────────────────────────────
            if expired {
                Button {
                    renewQR()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 11, weight: .bold))
                        Text("Renovar")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                    }
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 7)
                    .background(Color.orange)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
            } else {
                // Badge de tiempo
                HStack(spacing: 4) {
                    Circle()
                        .fill(ringColor)
                        .frame(width: 5, height: 5)
                    Text(timeLabel)
                        .font(.system(size: 11, weight: .heavy, design: .monospaced))
                        .foregroundColor(ringColor)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(ringColor.opacity(0.12))
                .clipShape(Capsule())
            }
        }
        .padding(.horizontal, 4)
        .navigationTitle(card.isComplete ? "Canjear" : "Mi QR")
        .navigationBarTitleDisplayMode(.inline)
        // Mantiene pantalla encendida mientras se muestra el QR
        .persistentSystemOverlays(.hidden)
        .onAppear {
            appeared = true
            startTimer()
        }
        .onDisappear {
            stopTimer()
        }
    }

    // MARK: - Timer

    private func startTimer() {
        stopTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if secondsLeft > 0 {
                secondsLeft -= 1
            } else {
                expired = true
                stopTimer()
            }
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    private func renewQR() {
        expired     = false
        secondsLeft = 300
        appeared    = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            appeared = true
            startTimer()
        }
    }
}

// ─── WatchMockQR ──────────────────────────────────────────────────────────────
// Renderiza un QR visual realista sin dependencias externas.
// El patrón imita la estructura real de un QR code:
//   • 3 finder patterns en las esquinas (cuadrados concéntricos)
//   • Módulos de datos aleatorios en el centro
//   • Quiet zone blanca de 2 módulos

struct WatchMockQR: View {
    // Semilla fija para que el patrón no cambie al redibujar
    private let seed: UInt64 = 0xA5B3C1D7

    var body: some View {
        Canvas { ctx, size in
            let modules = 21          // QR versión 1 = 21×21
            let cell    = size.width / CGFloat(modules)
            let bg      = GraphicsContext.Shading.color(.white)
            let fg      = GraphicsContext.Shading.color(.black)

            // Fondo blanco
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: bg)

            // Dibuja cada módulo
            for row in 0..<modules {
                for col in 0..<modules {
                    let on = moduleOn(row: row, col: col, modules: modules)
                    if on {
                        let rect = CGRect(
                            x: CGFloat(col) * cell + 0.5,
                            y: CGFloat(row) * cell + 0.5,
                            width: cell - 1,
                            height: cell - 1
                        )
                        ctx.fill(Path(rect), with: fg)
                    }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 4))
    }

    private func moduleOn(row: Int, col: Int, modules: Int) -> Bool {
        // ── Finder patterns (esquinas) ────────────────────────────────
        if isFinderPattern(row: row, col: col, modules: modules) {
            return finderModule(row: row, col: col, modules: modules)
        }

        // ── Separators (fila/col 7 alrededor de finders) ─────────────
        if row == 7 || col == 7 || row == modules - 8 || col == modules - 8 {
            return false
        }

        // ── Timing patterns ───────────────────────────────────────────
        if row == 6 { return col % 2 == 0 }
        if col == 6 { return row % 2 == 0 }

        // ── Dark module ───────────────────────────────────────────────
        if row == 8 && col == modules - 8 { return true }

        // ── Datos (pseudo-aleatorio con semilla fija) ─────────────────
        let idx = UInt64(row * modules + col)
        let hash = (seed &* 6364136223846793005 &+ 1442695040888963407 &+ idx)
        return (hash >> 33) % 3 != 0
    }

    private func isFinderPattern(row: Int, col: Int, modules: Int) -> Bool {
        let topLeft     = row < 8 && col < 8
        let topRight    = row < 8 && col >= modules - 8
        let bottomLeft  = row >= modules - 8 && col < 8
        return topLeft || topRight || bottomLeft
    }

    private func finderModule(row: Int, col: Int, modules: Int) -> Bool {
        // Normaliza coordenadas al patrón 7×7 local
        let r: Int
        let c: Int
        if row < 8 && col < 8 {
            r = row; c = col
        } else if row < 8 {
            r = row; c = col - (modules - 7)
        } else {
            r = row - (modules - 7); c = col
        }

        // Borde exterior (0 y 6)
        if r == 0 || r == 6 || c == 0 || c == 6 { return true }
        // Separador interior (1 y 5)
        if r == 1 || r == 5 || c == 1 || c == 5 { return false }
        // Centro 3×3
        return true
    }
}
