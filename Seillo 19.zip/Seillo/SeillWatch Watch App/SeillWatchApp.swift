import SwiftUI
import WidgetKit

// ─── SeillWatchApp ────────────────────────────────────────────────────────────
// Entry point del Watch app.
// El WidgetBundle registra la complication directamente en este target —
// no se necesita un extension target separado en watchOS 9+.
// ─────────────────────────────────────────────────────────────────────────────

@main
struct SeillWatchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// ─── Widget Bundle ────────────────────────────────────────────────────────────
// Registra SeillComplication para que aparezca en el editor de esferas.
// watchOS lo detecta automáticamente al estar en el mismo target.

struct SeillWatchWidgetBundle: WidgetBundle {
    var body: some Widget {
        SeillComplication()
    }
}
