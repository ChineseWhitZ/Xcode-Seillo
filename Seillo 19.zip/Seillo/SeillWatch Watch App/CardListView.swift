import SwiftUI

// ─── CardListView ─────────────────────────────────────────────────────────────
// Lista de todas las tarjetas del usuario.
// Tap en cualquier tarjeta → WatchQRView con el QR de esa tarjeta.
// Ordenadas: primero las completas, luego por progreso descendente.
// ─────────────────────────────────────────────────────────────────────────────

struct CardListView: View {
    let cards: [WatchCard]

    private var sorted: [WatchCard] {
        let complete  = cards.filter { $0.isComplete }
        let inProgress = cards.filter { !$0.isComplete }
            .sorted { $0.progress > $1.progress }
        return complete + inProgress
    }

    var body: some View {
        List {
            ForEach(sorted) { card in
                NavigationLink(destination: WatchQRView(card: card)) {
                    CardRowWatch(card: card)
                }
                .listRowBackground(Color(white: 0.10))
                .listRowInsets(EdgeInsets(top: 6, leading: 8, bottom: 6, trailing: 8))
            }
        }
        .listStyle(.carousel)
        .navigationTitle("Tarjetas")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// ─── CardRowWatch ─────────────────────────────────────────────────────────────

struct CardRowWatch: View {
    let card: WatchCard

    var body: some View {
        HStack(spacing: 8) {
            // Ícono
            ZStack {
                Circle()
                    .fill(card.color.opacity(0.18))
                    .frame(width: 30, height: 30)
                Image(systemName: card.icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(card.color)
            }

            // Nombre + progreso
            VStack(alignment: .leading, spacing: 3) {
                Text(card.bizName)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)

                HStack(spacing: 4) {
                    ProgressBarWatch(progress: card.progress, color: card.isComplete ? .green : card.color)
                        .frame(width: 60)

                    Text(card.isComplete ? "Listo" : "\(card.filledStamps)/\(card.totalStamps)")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(card.isComplete ? .green : .gray)
                }
            }

            Spacer()

            // Badge completa
            if card.isComplete {
                Image(systemName: "star.fill")
                    .font(.system(size: 11))
                    .foregroundColor(.green)
            }
        }
        .padding(.vertical, 2)
    }
}
