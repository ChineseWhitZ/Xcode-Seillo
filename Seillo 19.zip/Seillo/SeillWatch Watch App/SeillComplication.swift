import WidgetKit
import SwiftUI

// ─── SeillComplication ────────────────────────────────────────────────────────
// Complication para la esfera del Apple Watch.
// Usa WidgetKit — misma infraestructura que el widget iOS.
// Lee del mismo App Group: group.com.seillo.shared
//
// Familias soportadas:
//   • accessoryCircular    — anillo de progreso + contador (esquina o centro)
//   • accessoryRectangular — nombre del negocio + barra + sellos (banda)
//   • accessoryInline      — texto de una línea (arriba de la esfera)
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - Entry

struct ComplicationEntry: TimelineEntry {
    let date:    Date
    let card:    WatchCard?

    static var placeholder: ComplicationEntry {
        ComplicationEntry(date: .now, card: WatchCard.placeholder)
    }
}

// MARK: - Provider

struct ComplicationProvider: TimelineProvider {

    func placeholder(in context: Context) -> ComplicationEntry {
        .placeholder
    }

    func getSnapshot(in context: Context, completion: @escaping (ComplicationEntry) -> Void) {
        completion(ComplicationEntry(date: .now, card: WatchAppGroupStore.topCard()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ComplicationEntry>) -> Void) {
        let entry    = ComplicationEntry(date: .now, card: WatchAppGroupStore.topCard())
        // Refresca cada 30 minutos — la app empuja cambios vía App Group
        let nextDate = Calendar.current.date(byAdding: .minute, value: 30, to: .now) ?? .now
        let timeline = Timeline(entries: [entry], policy: .after(nextDate))
        completion(timeline)
    }
}

// MARK: - Entry View

struct ComplicationEntryView: View {
    @Environment(\.widgetFamily) private var family
    let entry: ComplicationEntry

    var body: some View {
        switch family {
        case .accessoryCircular:
            circularView
        case .accessoryRectangular:
            rectangularView
        case .accessoryInline:
            inlineView
        default:
            circularView
        }
    }

    // ── Circular — anillo de progreso con contador ─────────────────────────
    private var circularView: some View {
        ZStack {
            if let card = entry.card {
                // Anillo de progreso
                ProgressView(
                    value: card.isComplete ? 1.0 : card.progress
                )
                .progressViewStyle(.circular)
                .tint(card.isComplete ? .green : .orange)

                // Centro
                VStack(spacing: 0) {
                    if card.isComplete {
                        Image(systemName: "star.fill")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.green)
                    } else {
                        Text("\(card.filledStamps)")
                            .font(.system(size: 14, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                        Text("/\(card.totalStamps)")
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(.gray)
                    }
                }
            } else {
                // Sin tarjetas
                Image(systemName: "seal.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(.orange)
            }
        }
    }

    // ── Rectangular — nombre + barra + estado ──────────────────────────────
    private var rectangularView: some View {
        if let card = entry.card {
            return AnyView(
                VStack(alignment: .leading, spacing: 4) {
                    // Nombre del negocio
                    HStack(spacing: 5) {
                        Image(systemName: card.icon)
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(card.isComplete ? Color.green : Color.orange)
                        Text(card.bizName)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                    }

                    // Barra de progreso
                    ProgressView(value: card.isComplete ? 1.0 : card.progress)
                        .progressViewStyle(.linear)
                        .tint(card.isComplete ? .green : .orange)
                        .frame(height: 4)

                    // Texto de estado
                    Text(card.isComplete
                         ? "¡Premio listo para canjear!"
                         : "\(card.filledStamps)/\(card.totalStamps) · Faltan \(card.remainingStamps) sello\(card.remainingStamps == 1 ? "" : "s")")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(card.isComplete ? Color.green : Color.gray)
                        .lineLimit(1)
                }
                .padding(.horizontal, 2)
            )
        } else {
            return AnyView(
                HStack(spacing: 8) {
                    Image(systemName: "seal.fill")
                        .font(.system(size: 18))
                        .foregroundStyle(.orange)
                    Text("Abre Seillo\nen iPhone")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                }
            )
        }
    }

    // ── Inline — una línea arriba de la esfera ─────────────────────────────
    private var inlineView: some View {
        if let card = entry.card {
            return AnyView(
                HStack(spacing: 4) {
                    Image(systemName: card.isComplete ? "star.fill" : card.icon)
                        .foregroundStyle(card.isComplete ? Color.green : Color.orange)
                    Text(card.isComplete
                         ? "\(card.bizName) · Premio listo"
                         : "\(card.bizName) · \(card.filledStamps)/\(card.totalStamps)")
                        .lineLimit(1)
                }
            )
        } else {
            return AnyView(
                Label("Seillo", systemImage: "seal.fill")
            )
        }
    }
}

// MARK: - Widget definition

struct SeillComplication: Widget {
    let kind = "SeillComplication"

    var body: some WidgetConfiguration {
        StaticConfiguration(
            kind: kind,
            provider: ComplicationProvider()
        ) { entry in
            ComplicationEntryView(entry: entry)
                .containerBackground(.black, for: .widget)
        }
        .configurationDisplayName("Seillo")
        .description("Tus sellos en la esfera del reloj")
        .supportedFamilies([
            .accessoryCircular,
            .accessoryRectangular,
            .accessoryInline
        ])
    }
}
