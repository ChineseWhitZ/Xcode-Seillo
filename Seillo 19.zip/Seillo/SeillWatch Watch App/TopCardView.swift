import SwiftUI

// ─── TopCardView ──────────────────────────────────────────────────────────────
// Pantalla principal del Watch. Muestra la tarjeta más relevante
// (la completa o la más cerca del premio) con acceso rápido al QR
// y navegación a la lista de todas las tarjetas.
// ─────────────────────────────────────────────────────────────────────────────

struct TopCardView: View {
    let cards: [WatchCard]

    private var topCard: WatchCard { WatchAppGroupStore.topCard() ?? cards[0] }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 10) {

                    // ── Tarjeta principal ──────────────────────────────────
                    mainCard

                    // ── Botón QR ───────────────────────────────────────────
                    NavigationLink(destination: WatchQRView(card: topCard)) {
                        HStack(spacing: 6) {
                            Image(systemName: topCard.isComplete ? "gift.fill" : "qrcode")
                                .font(.system(size: 14, weight: .semibold))
                            Text(topCard.isComplete ? "Canjear" : "Mi QR")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(topCard.isComplete ? Color.green : Color.orange)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)

                    // ── Ver todas ──────────────────────────────────────────
                    if cards.count > 1 {
                        NavigationLink(destination: CardListView(cards: cards)) {
                            HStack(spacing: 6) {
                                Image(systemName: "creditcard.fill")
                                    .font(.system(size: 12))
                                    .foregroundColor(.orange)
                                Text("Ver \(cards.count) tarjetas")
                                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                                    .foregroundColor(.white)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(Color(white: 0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 4)
            }
            .navigationTitle("Seillo")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    // MARK: - Main card

    private var mainCard: some View {
        VStack(alignment: .leading, spacing: 10) {

            // Negocio + ícono
            HStack(spacing: 8) {
                ZStack {
                    Circle()
                        .fill(topCard.color.opacity(0.20))
                        .frame(width: 32, height: 32)
                    Image(systemName: topCard.icon)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(topCard.color)
                }

                VStack(alignment: .leading, spacing: 1) {
                    Text(topCard.bizName)
                        .font(.system(size: 13, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                        .lineLimit(1)

                    Text(topCard.location.capitalized)
                        .font(.system(size: 10))
                        .foregroundColor(.gray)
                }

                Spacer()

                // Badge si está completa
                if topCard.isComplete {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 16))
                        .foregroundColor(.green)
                }
            }

            // Sellos
            StampsRowWatch(card: topCard)

            // Progreso en texto
            HStack {
                Text(topCard.isComplete
                     ? "¡Premio listo!"
                     : "Faltan \(topCard.remainingStamps) sello\(topCard.remainingStamps == 1 ? "" : "s")")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(topCard.isComplete ? .green : topCard.color)

                Spacer()

                Text("\(topCard.filledStamps)/\(topCard.totalStamps)")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundColor(.gray)
            }

            // Barra de progreso
            ProgressBarWatch(progress: topCard.progress, color: topCard.isComplete ? .green : topCard.color)
        }
        .padding(12)
        .background(
            LinearGradient(
                colors: [
                    topCard.color.opacity(0.18),
                    topCard.color.opacity(0.06)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(topCard.color.opacity(0.30), lineWidth: 1)
        )
    }
}

// ─── StampsRowWatch ───────────────────────────────────────────────────────────

struct StampsRowWatch: View {
    let card: WatchCard

    // En Watch caben máximo 10 iconos en una fila — si el total es mayor
    // se agrupan en dos filas de 5.
    private var columns: Int { min(card.totalStamps, 5) }
    private var rows: Int { Int(ceil(Double(card.totalStamps) / Double(columns))) }

    var body: some View {
        VStack(spacing: 3) {
            ForEach(0..<rows, id: \.self) { row in
                HStack(spacing: 4) {
                    ForEach(0..<columns, id: \.self) { col in
                        let index = row * columns + col
                        if index < card.totalStamps {
                            stampDot(filled: index < card.filledStamps)
                        }
                    }
                    // Rellena la fila si el total no es múltiplo exacto
                    if row == rows - 1 {
                        let lastRowCount = card.totalStamps - (rows - 1) * columns
                        ForEach(0..<(columns - lastRowCount), id: \.self) { _ in
                            Color.clear.frame(width: 16, height: 16)
                        }
                    }
                    Spacer()
                }
            }
        }
    }

    private func stampDot(filled: Bool) -> some View {
        ZStack {
            Circle()
                .fill(filled ? card.color.opacity(0.20) : Color(white: 0.15))
                .frame(width: 16, height: 16)
                .overlay(
                    Circle()
                        .stroke(filled ? card.color.opacity(0.60) : Color(white: 0.25), lineWidth: 1)
                )

            if filled {
                Image(systemName: "checkmark")
                    .font(.system(size: 7, weight: .heavy))
                    .foregroundColor(card.color)
            }
        }
    }
}

// ─── ProgressBarWatch ─────────────────────────────────────────────────────────

struct ProgressBarWatch: View {
    let progress: Double
    let color: Color

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color(white: 0.15))
                    .frame(height: 5)
                Capsule()
                    .fill(color)
                    .frame(
                        width: max(geo.size.width * progress, progress > 0 ? 6 : 0),
                        height: 5
                    )
            }
        }
        .frame(height: 5)
    }
}
