import SwiftUI

// ─── ContentView ──────────────────────────────────────────────────────────────
// Raíz de la app Watch. Carga las tarjetas del App Group y decide
// qué mostrar:
//   • Si hay tarjetas → TopCardView como pantalla principal
//   • Si no hay tarjetas → estado vacío con instrucción de abrir iOS
// ─────────────────────────────────────────────────────────────────────────────

struct ContentView: View {
    @State private var cards: [WatchCard] = []
    @State private var appeared = false

    var body: some View {
        Group {
            if cards.isEmpty {
                emptyState
            } else {
                TopCardView(cards: cards)
            }
        }
        .onAppear {
            cards = WatchAppGroupStore.readCards()
            withAnimation(.easeOut(duration: 0.3)) { appeared = true }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "iphone.and.arrow.forward")
                .font(.system(size: 28))
                .foregroundColor(.orange)

            Text("Abre Seillo\nen tu iPhone")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)

            Text("Tus tarjetas\naparecerán aquí")
                .font(.system(size: 11, weight: .regular))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .opacity(appeared ? 1 : 0)
    }
}
