import Foundation
import SwiftUI

// ─── WatchAppGroupStore ───────────────────────────────────────────────────────
// Lee las tarjetas desde el App Group compartido con la app iOS y el widget.
// El Watch nunca escribe — solo consume lo que la app iOS sincroniza.
//
// App Group: group.com.seillo.shared  (mismo que iOS + Widget)
// ─────────────────────────────────────────────────────────────────────────────

private let groupID  = "group.com.seillo.shared"
private let cardsKey = "seillo.widget.cards"

// ─── WatchCard ────────────────────────────────────────────────────────────────
// Idéntico a WidgetCard — decodifica el mismo JSON que escribe la app iOS.

struct WatchCard: Codable, Identifiable {
    let id:           String
    let bizName:      String
    let rewardText:   String
    let filledStamps: Int
    let totalStamps:  Int
    let icon:         String
    let colorHex:     String
    let location:     String

    var progress: Double {
        guard totalStamps > 0 else { return 0 }
        return Double(filledStamps) / Double(totalStamps)
    }
    var remainingStamps: Int { max(0, totalStamps - filledStamps) }
    var isComplete: Bool     { filledStamps >= totalStamps }

    var color: Color {
        let hex = colorHex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r = Double((int >> 16) & 0xFF) / 255
        let g = Double((int >>  8) & 0xFF) / 255
        let b = Double( int        & 0xFF) / 255
        return Color(.sRGB, red: r, green: g, blue: b)
    }

    // QR code string — igual que en iOS
    var qrCode: String { "SEILLO-USR-\(id.prefix(6).uppercased())" }
}

// ─── Store ────────────────────────────────────────────────────────────────────

enum WatchAppGroupStore {

    static func readCards() -> [WatchCard] {
        guard
            let defaults = UserDefaults(suiteName: groupID),
            let data     = defaults.data(forKey: cardsKey),
            let cards    = try? JSONDecoder().decode([WatchCard].self, from: data)
        else { return WatchCard.placeholders }
        return cards
    }

    /// Tarjeta más relevante: primero completa, luego la más cerca del premio.
    static func topCard() -> WatchCard? {
        let cards = readCards()
        if let ready = cards.first(where: { $0.isComplete }) { return ready }
        return cards.filter { !$0.isComplete }.max { $0.progress < $1.progress }
    }
}

// ─── Placeholders ─────────────────────────────────────────────────────────────

extension WatchCard {
    static let placeholders: [WatchCard] = [
        WatchCard(id: "ph1", bizName: "Café Inti",
                  rewardText: "Café a elección gratis",
                  filledStamps: 8, totalStamps: 10,
                  icon: "cup.and.saucer.fill", colorHex: "FFB800", location: "café"),
        WatchCard(id: "ph2", bizName: "Barbería Rey",
                  rewardText: "Corte + arreglo gratis",
                  filledStamps: 5, totalStamps: 7,
                  icon: "scissors", colorHex: "B06FEF", location: "barbería"),
        WatchCard(id: "ph3", bizName: "Brasa Real",
                  rewardText: "Pollo a la brasa familiar",
                  filledStamps: 2, totalStamps: 8,
                  icon: "flame.fill", colorHex: "FF4460", location: "pollería"),
    ]
    static var placeholder: WatchCard { placeholders[0] }
}
